<?php
/**
 * -------------------------------------------------------
 * multi_db.php — for hr2.atierahotelandrestaurant.com
 * -------------------------------------------------------
 * Connects to:
 * 1. competency database (main HR2 system)
 * 2. rest_api_db database (optional)
 * -------------------------------------------------------
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);

// ---------- DATABASE CREDENTIALS ----------
$servername = "localhost";
$username   = "hr2_atiera";
$password   = "DAJK^PNEBoIi#Otk";
$dbCompetency = "hr2_competency";
$dbRestApi   = "hr2_rest_api_db"; // optional, remove if not existing

// ---------- CONNECT TO COMPETENCY DATABASE ----------
$connCompetency = new mysqli($servername, $username, $password, $dbCompetency);

if ($connCompetency->connect_error) {
    die("❌ Connection failed to competency DB: " . $connCompetency->connect_error);
}

// ---------- CONNECT TO REST API DATABASE ----------
try {
    $connRestApi = new mysqli($servername, $username, $password, $dbRestApi);
    if ($connRestApi->connect_error) {
        $connRestApi = null; // continue even if this optional DB fails
    }
} catch (Throwable $e) {
    $connRestApi = null;
}

// ---------- UTF-8 ENCODING ----------
$connCompetency->set_charset("utf8mb4");
if ($connRestApi instanceof mysqli) { 
    $connRestApi->set_charset("utf8mb4"); 
}

// ✅ Optional Debug Message (for testing only)
// echo "✅ Databases connected successfully.";
?>
