<?php
session_start();
include('dblogin.php');
require_once __DIR__ . '/PHPGangsta/GoogleAuthenticator.php'; // direct include instead of vendor
$ga = new PHPGangsta_GoogleAuthenticator();

if (!isset($_SESSION['pending_user_id']) && !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$setup_user_id = $_SESSION['user_id'] ?? $_SESSION['pending_user_id'];

$otp = $_POST['otp'] ?? '';

$stmt = $conn->prepare("SELECT mfa_secret FROM users WHERE id = ?");
$stmt->bind_param("i", $setup_user_id);
$stmt->execute();
$stmt->bind_result($secret);
$stmt->fetch();
$stmt->close();

if ($ga->verifyCode($secret, $otp, 2)) {
    // Enable MFA for this user
    $stmt = $conn->prepare("UPDATE users SET mfa_enabled = 1 WHERE id = ?");
    $stmt->bind_param("i", $setup_user_id);
    $stmt->execute();
    $stmt->close();

    // If user was pending (just after login), finalize login
    if (isset($_SESSION['pending_user_id']) && !isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = $_SESSION['pending_user_id'];
        $_SESSION['role'] = $_SESSION['pending_user_role'] ?? 'user';
        unset($_SESSION['pending_user_id']);
        unset($_SESSION['pending_user_role']);
        header("Location: /ess_user/userinfo2.php");
        exit;
    }

    echo "<p class='text-green-600'>MFA Enabled successfully! <a href='index.php' class='text-blue-500'>Go to Dashboard</a></p>";
} else {
    echo "<p class='text-red-600'>Invalid code. <a href='mfa_setup.php'>Try again</a></p>";
}
