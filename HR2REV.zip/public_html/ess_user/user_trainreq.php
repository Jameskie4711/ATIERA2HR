<?php
include('../session_check.php'); 
include('../dblogin.php'); 
error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentPage = basename($_SERVER['PHP_SELF']);

// Fetch user info
$user_id = $_SESSION['user_id'] ?? null;
$sql = "SELECT id,
               CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname,
               Profile_Picture AS profile_pic
        FROM users
        WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Training Request</title>
  <link rel="icon" type="image/png" href="../logo2.png" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">

<!-- Sidebar -->
<?php include('user_sidebar.php'); ?>

<main class="flex-1 flex flex-col">

  <!-- TOP BAR -->
  <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
    <div class="flex items-center justify-between px-6 py-4">

      <h1 class="text-2xl font-bold text-gray-800 tracking-wide">
        Training Request
      </h1>

      <div class="flex items-center gap-4">

        <!-- Profile -->
        <div class="relative">
          <button id="profile-menu-btn"
                  class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">
            <?php $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg'; ?>
            <img src="<?= htmlspecialchars($pic) ?>"
                 class="w-8 h-8 rounded-full object-cover border-2 border-white">
            <i data-lucide="chevron-down" class="w-4 h-4"></i>
          </button>

          <div id="profile-menu"
               class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">

            <!-- Added missing links -->
            <a href="user_profile.php"
               class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
              <i data-lucide="user" class="w-4 h-4"></i> Profile
            </a>
            
            <a href="user_lms.php"
               class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
              <i data-lucide="book-open" class="w-4 h-4"></i> My Courses
            </a>

            <a href="user_settings.php"
               class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
              <i data-lucide="settings" class="w-4 h-4"></i> Settings
            </a>

            <hr class="border-gray-200">

            <a href="logout.php"
               class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
              <i data-lucide="log-out" class="w-4 h-4"></i> Logout
            </a>
          </div>
        </div>

      </div>
    </div>
  </header>

  <!-- CONTENT -->
  <section class="flex-1 p-6 space-y-6">

    <?php if(isset($_GET['submitted']) && $_GET['submitted'] == 1): ?>
      <div id="submission-banner"
           class="max-w-3xl mx-auto p-4 rounded-xl bg-green-100 text-green-800 shadow-md flex items-center gap-2">
        <i data-lucide="check-circle"></i>
        Your training request has been submitted and is now <strong>Pending</strong>.
      </div>
    <?php endif; ?>

    <!-- REQUEST FORM -->
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 max-w-3xl mx-auto">

      <h2 class="text-xl font-bold mb-4 text-gray-800">
        Request New Training
      </h2>

      <form method="POST" action="submit_trainreq.php"
            class="space-y-4 text-gray-800">

        <div>
          <label class="block mb-1 font-medium">Training Title</label>
          <input type="text" name="training_title" required
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-cyan-400">
        </div>

        <div>
          <label class="block mb-1 font-medium">Description</label>
          <textarea name="training_description" rows="3" required
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-cyan-400"></textarea>
        </div>

        <div>
          <label class="block mb-1 font-medium">Preferred Date</label>
          <input type="date" name="preferred_date" required
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-cyan-400">
        </div>

        <input type="hidden" name="employee_id" value="<?= $_SESSION['user_id'] ?>">
        <input type="hidden" name="employee_name" value="<?= htmlspecialchars($user['fullname']) ?>">

        <div class="flex justify-end pt-4">
          <button type="submit"
                  class="px-6 py-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500
                         text-white font-semibold hover:from-cyan-600 hover:to-blue-600
                         transition flex items-center gap-2">
            <i data-lucide="send" class="w-5 h-5"></i>
            Submit
          </button>
        </div>

      </form>
    </div>

  </section>

  <!-- FOOTER -->
  <footer class="text-center text-xs text-gray-400 py-4 mt-auto">
    ESS User Module • © <?= date('Y') ?>
  </footer>

</main>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();

  // Profile dropdown
  const btn = document.getElementById("profile-menu-btn");
  const menu = document.getElementById("profile-menu");
  btn.addEventListener("click", () => menu.classList.toggle("hidden"));
  document.addEventListener("click", e => {
    if (!btn.contains(e.target) && !menu.contains(e.target)) {
      menu.classList.add("hidden");
    }
  });
});
</script>

</body>
</html>