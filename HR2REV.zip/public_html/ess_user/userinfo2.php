<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

$sql = "
    SELECT 
        id AS user_id,
        Employee_ID AS employee_id,
        CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname,
        Gender AS gender,
        Birthday AS birthday,
        Email AS email,
        Phone_Number AS phone,
        Address AS address,
        Position AS position,
        Department AS department,
        Date_Hired AS date_hired,
        Employment_Status AS emp_status,
        Supervisor AS supervisor,
        Work_Location AS work_location,
        Profile_Picture AS profile_pic
    FROM users
    WHERE id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;

if (!$user) {
    die("User information not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ESS User Profile</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="min-h-screen bg-gray-50">

<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- Main -->
  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Page Title -->
        <h1 class="text-xl font-semibold text-gray-800">My Profile</h1>

        <!-- Right Actions -->
        <div class="flex items-center gap-4">

          <!-- Profile Dropdown -->
          <div class="relative">
            <button id="profile-menu-btn"
              class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">

              <?php $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg'; ?>
              <img src="<?= htmlspecialchars($pic); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover border-2 border-white">
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-menu"
              class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">


              <a href="user_settings.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="settings" class="w-4 h-4"></i>
                Settings
              </a>

              <hr class="border-gray-200">

              <a href="logout.php"
                class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                Logout
              </a>
            </div>
          </div>

        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6 max-w-6xl mx-auto">

      <!-- Compact Profile Summary -->
      <div class="bg-white rounded-2xl border shadow-sm border-gray-200 p-6 mb-6 flex flex-col md:flex-row items-center gap-6">
        <div class="flex-1 text-center md:text-left">
          <h2 class="text-2xl font-semibold text-gray-800"><?= htmlspecialchars($user['fullname']); ?></h2>
          <p class="text-gray-600"><?= htmlspecialchars($user['position'] ?? '—'); ?></p>
          <p class="text-sm text-gray-500"><?= htmlspecialchars($user['department'] ?? '—'); ?></p>
          <p class="flex items-center justify-center md:justify-start gap-1 text-sm text-gray-500 mt-1">
            <i data-lucide="map-pin" class="w-4 h-4"></i>
            <?= htmlspecialchars($user['work_location'] ?? '—'); ?>
          </p>
        </div>
      </div>

      <!-- Info Cards -->
      <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">

        <!-- Personal Details -->
        <div class="bg-white rounded-2xl border shadow-sm border-gray-200 p-6 hover:shadow-md transition duration-500">
          <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <i data-lucide="user" class="w-5 h-5 text-indigo-500"></i>
            Personal Details
          </h3>
          <div class="space-y-2 text-sm text-gray-700">
            <p><span class="text-gray-500">Employee ID:</span> <?= htmlspecialchars($user['employee_id'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Gender:</span> <?= htmlspecialchars($user['gender'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Birthday:</span> <?= htmlspecialchars($user['birthday'] ?? '—'); ?></p>
          </div>
        </div>

        <!-- Contact Information -->
        <div class="bg-white rounded-2xl border shadow-sm border-gray-200 p-6 hover:shadow-md transition duration-500">
          <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <i data-lucide="mail" class="w-5 h-5 text-indigo-500"></i>
            Contact Information
          </h3>
          <div class="space-y-2 text-sm text-gray-700">
            <p><span class="text-gray-500">Email:</span> <?= htmlspecialchars($user['email'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Phone:</span> <?= htmlspecialchars($user['phone'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Address:</span><br><?= nl2br(htmlspecialchars($user['address'] ?? '—')); ?></p>
          </div>
        </div>

        <!-- Employment Details -->
        <div class="bg-white rounded-2xl border shadow-sm border-gray-200 p-6 hover:shadow-md transition duration-500">
          <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <i data-lucide="briefcase" class="w-5 h-5 text-indigo-500"></i>
            Employment Details
          </h3>
          <div class="space-y-2 text-sm text-gray-700">
            <p><span class="text-gray-500">Date Hired:</span> <?= htmlspecialchars($user['date_hired'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Status:</span> <?= htmlspecialchars($user['emp_status'] ?? '—'); ?></p>
            <p><span class="text-gray-500">Supervisor:</span> <?= htmlspecialchars($user['supervisor'] ?? '—'); ?></p>
          </div>
        </div>

      </div>
    </section>

    <!-- Footer -->
    <footer class="text-center text-xs text-gray-400 py-4">
      ESS User Module • © <?= date('Y'); ?>
    </footer>

  </main>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();

  // Profile dropdown
  const menuBtn = document.getElementById("profile-menu-btn");
  const menu = document.getElementById("profile-menu");
  menuBtn.addEventListener("click", () => menu.classList.toggle("hidden"));
  document.addEventListener("click", (e) => {
    if (!menuBtn.contains(e.target) && !menu.contains(e.target)) menu.classList.add("hidden");
  });
});
</script>

</body>
</html>