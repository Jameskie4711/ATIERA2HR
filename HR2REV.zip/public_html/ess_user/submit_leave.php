<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

$leave_type = $_POST['leave_type'] ?? '';
$start_date = $_POST['start_date'] ?? '';
$end_date   = $_POST['end_date'] ?? '';
$reason     = $_POST['reason'] ?? '';

if (!$leave_type || !$start_date || !$end_date || !$reason) {
    header("Location: user_reqleave.php?error=1");
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO leave_requests
    (user_id, leave_type, start_date, end_date, reason, status, created_at)
    VALUES (?, ?, ?, ?, ?, 'Pending', NOW())
");

$stmt->bind_param(
    "issss",
    $user_id,
    $leave_type,
    $start_date,
    $end_date,
    $reason
);

if ($stmt->execute()) {
    header("Location: user_leavestatus.php?submitted=1");
    exit;
} else {
    die("Failed to submit leave request: " . $stmt->error);
}
