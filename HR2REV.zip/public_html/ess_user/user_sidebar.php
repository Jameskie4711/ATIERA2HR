<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS Sidebar</title>
  <link rel="icon" type="image/png" href="../logo2.png" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex min-h-screen bg-gray-100">

<!-- Sidebar -->
<div id="sidebar" class="bg-gray-800 text-white w-64 transition-all duration-300 flex flex-col overflow-y-auto">

  <!-- Logo -->
  <div class="flex items-center justify-between px-4 py-4 border-b border-gray-700">
    <img src="/logo.png" class="h-14 sidebar-logo-expanded">
    <img src="/logo2.png" class="h-14 sidebar-logo-collapsed hidden">

    <button id="sidebar-toggle">
      <i data-lucide="chevron-left" class="w-5 h-5 transition-transform"></i>
    </button>
  </div>

  <!-- Navigation -->
  <nav class="flex-1 px-2 py-4 space-y-1">

    <a href="userinfo2.php"
       class="flex items-center gap-3 px-3 py-2 rounded <?= ($currentPage == 'userinfo2.php') ? 'bg-gray-700' : 'hover:bg-gray-700' ?>">
      <i data-lucide="user"></i>
      <span class="sidebar-text">Profile</span>
    </a>

    <a href="user_claims.php"
       class="flex items-center gap-3 px-3 py-2 rounded <?= ($currentPage == 'user_claims.php') ? 'bg-gray-700' : 'hover:bg-gray-700' ?>">
      <i data-lucide="calendar-days"></i>
      <span class="sidebar-text">Claims & Reimbursement</span>
    </a>

    <!-- Manage Requests -->
    <div class="space-y-1">

      <button id="leave-btn"
              class="flex items-center justify-between w-full px-3 py-2 rounded hover:bg-gray-700">
        <div class="flex items-center gap-3">
          <i data-lucide="file-plus"></i>
          <span class="sidebar-text">Manage Requests</span>
        </div>
        <i data-lucide="chevron-down" id="leave-arrow" class="w-4 h-4 transition-transform"></i>
      </button>

      <div id="leave-menu" class="ml-8 space-y-1 hidden">

        <!-- Leave Status -->
        <a href="user_leavestatus.php"
           class="flex items-center gap-2 px-3 py-1.5 rounded <?= ($currentPage == 'user_leavestatus.php') ? 'bg-gray-700' : 'hover:bg-gray-700' ?>">
          <i data-lucide="plus-circle" class="w-4 h-4"></i>
          <span class="sidebar-text">Leave Status</span>
        </a>

        <!-- Training Request (NO DROPDOWN) -->
        <a href="user_trainstatus.php"
           class="flex items-center gap-2 px-3 py-1.5 rounded <?= ($currentPage == 'user_trainstatus.php') ? 'bg-gray-700' : 'hover:bg-gray-700' ?>">
          <i data-lucide="clock" class="w-4 h-4"></i>
          <span class="sidebar-text">Training Status</span>
        </a>

      </div>
    </div>

    <!-- Payslips -->
    <a href="user_payslips.php"
       class="flex items-center gap-3 px-3 py-2 rounded <?= ($currentPage == 'user_payslips.php') ? 'bg-gray-700' : 'hover:bg-gray-700' ?>">
      <i data-lucide="wallet"></i>
      <span class="sidebar-text">Payslips</span>
    </a>

    <!-- Records -->
    <div class="space-y-1">
      <button id="records-btn"
              class="flex items-center justify-between w-full px-3 py-2 rounded hover:bg-gray-700">
        <div class="flex items-center gap-3">
          <i data-lucide="folder"></i>
          <span class="sidebar-text">Records</span>
        </div>
        <i data-lucide="chevron-down" id="records-arrow"
           class="w-4 h-4 transition-transform"></i>
      </button>

      <div id="records-menu" class="ml-8 space-y-1 hidden">
        <a href="user_training.php" class="block px-3 py-1.5 rounded hover:bg-gray-700">Training</a>
        <a href="user_lms.php" class="block px-3 py-1.5 rounded hover:bg-gray-700">LMS</a>
      </div>
    </div>

  </nav>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {

  const toggleBtn = document.getElementById("sidebar-toggle");
  const sidebar = document.getElementById("sidebar");
  const logoExpanded = document.querySelector(".sidebar-logo-expanded");
  const logoCollapsed = document.querySelector(".sidebar-logo-collapsed");
  const sidebarText = document.querySelectorAll(".sidebar-text");

  const leaveBtn = document.getElementById("leave-btn");
  const leaveMenu = document.getElementById("leave-menu");
  const leaveArrow = document.getElementById("leave-arrow");

  const recordsBtn = document.getElementById("records-btn");
  const recordsMenu = document.getElementById("records-menu");
  const recordsArrow = document.getElementById("records-arrow");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("w-64");
    sidebar.classList.toggle("w-20");
    logoExpanded.classList.toggle("hidden");
    logoCollapsed.classList.toggle("hidden");
    sidebarText.forEach(el => el.classList.toggle("hidden"));
    toggleBtn.querySelector("i").classList.toggle("rotate-180");
  });

  leaveBtn.addEventListener("click", () => {
    leaveMenu.classList.toggle("hidden");
    leaveArrow.classList.toggle("rotate-180");
  });

  recordsBtn.addEventListener("click", () => {
    recordsMenu.classList.toggle("hidden");
    recordsArrow.classList.toggle("rotate-180");
  });

  lucide.createIcons();
});
</script>

</body>
</html>
