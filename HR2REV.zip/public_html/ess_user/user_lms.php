<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

// Fetch user info for navigation
$user_stmt = $conn->prepare("
    SELECT 
        id AS user_id,
        Employee_ID AS employee_id,
        CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname,
        Position AS position,
        Department AS department,
        Profile_Picture AS profile_pic
    FROM users
    WHERE id = ?
");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result ? $user_result->fetch_assoc() : null;

$lms_stmt = $conn->prepare("SELECT Course_ID, Title, Instructor, Start, End, Progress FROM user_lms WHERE user_id = ? ORDER BY Start DESC");
$lms_stmt->bind_param("i", $user_id);
$lms_stmt->execute();
$lms_result = $lms_stmt->get_result();
$lms_data = $lms_result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS User - Learning Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="min-h-screen bg-gray-50">

<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- Main -->
  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Page Title -->
        <h1 class="text-xl font-semibold text-gray-800">Learning Management System</h1>

        <!-- Right Actions -->
        <div class="flex items-center gap-4">

          <!-- Profile Dropdown -->
          <div class="relative">
            <button id="profile-menu-btn"
              class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">

              <?php 
              $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg';
              if ($user) {
                  $initial = strtoupper(substr($user['fullname'], 0, 1));
              } else {
                  $initial = 'U';
              }
              ?>
              <?php if (!empty($user['profile_pic'])): ?>
                <img src="<?= htmlspecialchars($pic); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover border-2 border-white">
              <?php else: ?>
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold text-sm border-2 border-white">
                    <?= $initial ?>
                </div>
              <?php endif; ?>
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-menu"
              class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">

             
              <a href="user_settings.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="settings" class="w-4 h-4"></i>
                Settings
              </a>

              <hr class="border-gray-200">

              <a href="logout.php"
                class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                Logout
              </a>
            </div>
          </div>

        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6">
      <div class="space-y-6">
        <!-- Page Header -->
        <div class="flex items-center justify-between">
          <div>
            <h2 class="text-2xl font-bold text-gray-800">My Courses</h2>
          </div>
          <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
            <?= count($lms_data) ?> Course<?= count($lms_data) != 1 ? 's' : '' ?>
          </span>
        </div>

        <!-- Courses Grid -->
        <div class="bg-white rounded-2xl shadow-xl p-6">
          <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold text-gray-800 flex items-center gap-2">
              <i data-lucide="books" class="w-5 h-5 text-blue-600"></i>
              My Learning Courses
            </h3>
          </div>

          <?php if ($lms_data): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <?php foreach ($lms_data as $course): 
                $progressClass = $course['Progress'] == 100 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
                $progressColor = $course['Progress'] == 100 ? 'from-green-500 to-emerald-600' : 'from-yellow-500 to-amber-600';
              ?>
                <div class="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                  <div class="flex items-start justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br <?= $progressColor ?> flex items-center justify-center">
                      <i data-lucide="<?= $course['Progress'] == 100 ? 'award' : 'book-open' ?>" class="w-6 h-6 text-white"></i>
                    </div>
                    <span class="px-3 py-1 rounded-full text-xs font-medium <?= $progressClass ?>">
                      <?= $course['Progress'] == 100 ? 'Completed' : 'In Progress' ?>
                    </span>
                  </div>
                  
                  <h4 class="text-lg font-bold text-gray-800 mb-2"><?= htmlspecialchars($course['Title']) ?></h4>
                  
                  <div class="space-y-2 mb-4 text-sm text-gray-600">
                    <p class="flex items-center gap-2">
                      <i data-lucide="user" class="w-4 h-4"></i>
                      <?= htmlspecialchars($course['Instructor']) ?>
                    </p>
                    <p class="flex items-center gap-2">
                      <i data-lucide="calendar" class="w-4 h-4"></i>
                      <?= date('M j, Y', strtotime($course['Start'])) ?> - <?= date('M j, Y', strtotime($course['End'])) ?>
                    </p>
                  </div>
                  
                  <!-- Progress Bar -->
                  <div class="mb-4">
                    <div class="flex justify-between items-center mb-1">
                      <span class="text-sm font-medium text-gray-700">Progress</span>
                      <span class="text-sm font-bold text-blue-600"><?= $course['Progress'] ?>%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                      <div class="h-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600" 
                           style="width: <?= $course['Progress'] ?>%"></div>
                    </div>
                  </div>
                  
                  <a href="course_detail.php?course_id=<?= urlencode($course['Course_ID']) ?>" 
                     class="inline-flex items-center justify-center gap-2 w-full bg-blue-600 text-white px-4 py-2.5 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                    <i data-lucide="eye" class="w-4 h-4"></i>
                    View Course Details
                  </a>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="text-center py-12">
              <div class="w-20 h-20 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
                <i data-lucide="book-open" class="w-10 h-10 text-gray-400"></i>
              </div>
              <h3 class="text-xl font-semibold text-gray-700 mb-2">No Courses Found</h3>
              <p class="text-gray-500 max-w-md mx-auto">
                You don't have any courses assigned yet. Please check back later or contact your administrator.
              </p>
            </div>
          <?php endif; ?>
        </div>

      

      </div>
    </section>

   
  </main>
</div>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
    
    // Profile dropdown
    const menuBtn = document.getElementById("profile-menu-btn");
    const menu = document.getElementById("profile-menu");
    if (menuBtn && menu) {
      menuBtn.addEventListener("click", () => menu.classList.toggle("hidden"));
      document.addEventListener("click", (e) => {
        if (!menuBtn.contains(e.target) && !menu.contains(e.target)) menu.classList.add("hidden");
      });
    }
  });
</script>
</body>
</html>