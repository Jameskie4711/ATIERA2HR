<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Include session check and database connection
include('session_check.php');
include('dblogin.php');

// Get logged-in user info
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

// Fetch sample claims for this user (you can replace this query later)
$claims = [
    ["Claim_ID" => "CLM-00123", "Type" => "Medical", "Amount" => 2500.00, "Status" => "Pending", "Date_Filed" => "2025-10-20"],
    ["Claim_ID" => "CLM-00122", "Type" => "Travel", "Amount" => 1200.00, "Status" => "Approved", "Date_Filed" => "2025-10-10"]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS User - Claims & Reimbursements</title>
  <link rel="icon" type="image/png" href="../logo2.png" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex h-screen bg-slate-50 font-sans">

  <!-- ✅ Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- ✅ Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6 flex-1">

      <!-- ✅ Header -->
      <div class="flex items-center justify-between border-b pb-4">
        <h1 class="text-2xl font-semibold text-gray-800">Claims & Reimbursements</h1>
        <button id="open-claim-modal" class="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          <i data-lucide="plus" class="w-4 h-4"></i> New Claim
        </button>
      </div>

      <!-- ✅ Breadcrumb -->
      <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
        <a href="userinfo2.php" class="hover:text-blue-600 transition-colors">Home</a>
        <span>Claims & Reimbursements</span>
      </div>

      <!-- ✅ Claims Table -->
      <div class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">My Claims</h2>
        <table class="w-full border-collapse text-sm">
          <thead>
            <tr class="bg-gray-100 text-left">
              <th class="p-2 border">Claim ID</th>
              <th class="p-2 border">Type</th>
              <th class="p-2 border">Amount</th>
              <th class="p-2 border">Status</th>
              <th class="p-2 border">Date Filed</th>
              <th class="p-2 border text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($claims)): ?>
              <?php foreach ($claims as $c): ?>
                <tr class="hover:bg-gray-50">
                  <td class="p-2 border"><?= htmlspecialchars($c['Claim_ID']) ?></td>
                  <td class="p-2 border"><?= htmlspecialchars($c['Type']) ?></td>
                  <td class="p-2 border">₱<?= number_format($c['Amount'], 2) ?></td>
                  <td class="p-2 border font-medium 
                    <?= $c['Status'] == 'Approved' ? 'text-green-600' : ($c['Status'] == 'Rejected' ? 'text-red-600' : 'text-yellow-700') ?>">
                    <?= ucfirst($c['Status']) ?>
                  </td>
                  <td class="p-2 border text-gray-600"><?= htmlspecialchars($c['Date_Filed']) ?></td>
                  <td class="p-2 border text-center">
                    <a href="#" class="text-indigo-600 hover:text-indigo-900 text-sm">View</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="6" class="p-4 text-center text-gray-500 border">No claims found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- ✅ Back Button -->
      <div>
        <a href="userinfo2.php" class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
          ← Back
        </a>
      </div>

      <footer class="mt-6 text-xs text-slate-400 text-center">
        Claims & Reimbursements • ESS Module
      </footer>

    </main>
  </div>

  <!-- ✅ Claim Modal -->
  <div id="claim-modal" class="fixed inset-0 flex items-center justify-center bg-black/50 hidden z-50">
    <div class="bg-white rounded-xl shadow-xl w-96 p-6">
      <h2 class="text-xl font-semibold mb-4">Submit a New Claim</h2>
      <form id="claim-form" class="space-y-4" method="POST" action="submit_claim.php" enctype="multipart/form-data">
        <div>
          <label class="text-sm text-gray-600">Claim Type</label>
          <select name="claim_type" class="w-full border border-gray-300 rounded px-3 py-2" required>
            <option value="">Select Type</option>
            <option value="Medical">Medical</option>
            <option value="Travel">Travel</option>
            <option value="Meal">Meal</option>
            <option value="Others">Others</option>
          </select>
        </div>

        <div>
          <label class="text-sm text-gray-600">Amount</label>
          <input type="number" name="amount" step="0.01" class="w-full border border-gray-300 rounded px-3 py-2" required>
        </div>

        <div>
          <label class="text-sm text-gray-600">Description</label>
          <textarea name="description" class="w-full border border-gray-300 rounded px-3 py-2" rows="3" placeholder="Enter details..."></textarea>
        </div>

        <div>
          <label class="text-sm text-gray-600">Attach Receipt</label>
          <input type="file" name="receipt" accept="image/*,application/pdf" class="w-full border border-gray-300 rounded px-3 py-2">
        </div>

        <div class="flex justify-end gap-2">
          <button type="button" id="close-claim-modal" class="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400">Cancel</button>
          <button type="submit" class="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">Submit</button>
        </div>
      </form>
    </div>
  </div>

  <!-- ✅ Scripts -->
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const openBtn = document.getElementById('open-claim-modal');
    const closeBtn = document.getElementById('close-claim-modal');
    const modal = document.getElementById('claim-modal');

    // Open / Close Modal
    openBtn.addEventListener('click', () => modal.classList.remove('hidden'));
    closeBtn.addEventListener('click', () => modal.classList.add('hidden'));

    lucide.createIcons();
  });
  </script>
</body>
</html>
