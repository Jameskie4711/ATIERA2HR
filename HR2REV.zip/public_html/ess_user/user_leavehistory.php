<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

// Fetch leave requests for the user
$stmt = $conn->prepare("SELECT leave_type, start_date, end_date, reason, status, created_at FROM leave_requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_requests = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Leave History</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-100 min-h-screen flex">

<!-- Sidebar -->
<?php include('user_sidebar.php'); ?>

<!-- Main Content -->
<main class="flex-1 p-6">

    <!-- Subheader -->
    <div class="flex items-center justify-between mb-6 bg-white shadow-md px-4 py-3 rounded-xl">
        <div class="flex items-center gap-3">
            <a href="userinfo2.php" class="flex items-center gap-2 text-gray-700 hover:text-gray-900">
                <i data-lucide="home" class="w-5 h-5"></i>
                <span class="font-medium">Home</span>
            </a>
            <span class="text-gray-400">/</span>
            <h2 class="text-lg font-semibold text-gray-800">Leave History</h2>
        </div>
        <a href="user_reqleave.php" class="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-4 py-2 rounded-lg shadow hover:from-cyan-600 hover:to-blue-600 transition">
            <i data-lucide="file-plus" class="w-4 h-4"></i> New Leave Request
        </a>
    </div>

    <!-- Leave History Table -->
    <div class="bg-white rounded-2xl shadow-lg p-6 overflow-x-auto">
        <?php if (empty($leave_requests)): ?>
            <p class="text-gray-500 text-center py-8">No leave requests found.</p>
        <?php else: ?>
            <table class="min-w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-gray-700 uppercase text-sm font-medium">
                        <th class="py-3 px-4 text-left">Leave Type</th>
                        <th class="py-3 px-4 text-left">Start Date</th>
                        <th class="py-3 px-4 text-left">End Date</th>
                        <th class="py-3 px-4 text-left">Reason</th>
                        <th class="py-3 px-4 text-left">Status</th>
                        <th class="py-3 px-4 text-left">Submitted On</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php foreach ($leave_requests as $leave): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="py-3 px-4"><?= htmlspecialchars($leave['leave_type']) ?></td>
                            <td class="py-3 px-4"><?= htmlspecialchars($leave['start_date']) ?></td>
                            <td class="py-3 px-4"><?= htmlspecialchars($leave['end_date']) ?></td>
                            <td class="py-3 px-4"><?= htmlspecialchars($leave['reason']) ?></td>
                            <td class="py-3 px-4">
                                <?php
                                    $status = $leave['status'];
                                    $badgeColor = match($status) {
                                        'Approved' => 'bg-green-100 text-green-800',
                                        'Rejected' => 'bg-red-100 text-red-800',
                                        default => 'bg-yellow-100 text-yellow-800',
                                    };
                                ?>
                                <span class="px-3 py-1 rounded-full text-sm font-semibold <?= $badgeColor ?>"><?= $status ?></span>
                            </td>
                            <td class="py-3 px-4"><?= date("F j, Y", strtotime($leave['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</main>

<script>
lucide.createIcons();
</script>
</body>
</html>
