<?php
include('session_check.php');
include('dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

// Fetch user info for profile dropdown
$sql = "SELECT id, CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname, Profile_Picture AS profile_pic FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>New Leave Request</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="min-h-screen bg-gray-50">

<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- Main -->
  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Page Title -->
        <h1 class="text-xl font-semibold text-gray-800">New Leave Request</h1>

        <!-- Right Actions -->
        <div class="flex items-center gap-4">

          <!-- Profile Dropdown -->
          <div class="relative">
            <button id="profile-menu-btn" class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">
              <?php $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg'; ?>
              <img src="<?= htmlspecialchars($pic); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover border-2 border-white">
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-menu" class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
              <!-- Added missing links -->
              <a href="user_profile.php" class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="user" class="w-4 h-4"></i> Profile
              </a>
              
              <a href="user_lms.php" class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="book-open" class="w-4 h-4"></i> My Courses
              </a>

              <a href="user_settings.php" class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="settings" class="w-4 h-4"></i> Settings
              </a>
              
              <hr class="border-gray-200">
              
              <a href="logout.php" class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <i data-lucide="log-out" class="w-4 h-4"></i> Logout
              </a>
            </div>
          </div>

        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6 max-w-6xl mx-auto">

        <!-- Toast Notification -->
        <div id="toast" class="fixed top-5 right-5 hidden bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300">
            All fields are required!
        </div>

        <form id="leaveForm" action="submit_leave.php" method="POST" class="bg-white shadow rounded-2xl p-6 flex flex-col gap-6 max-w-3xl mx-auto">
            <div class="grid md:grid-cols-2 gap-6">

                <!-- Leave Type -->
                <div class="flex flex-col">
                    <label class="text-gray-700 font-medium mb-2" for="leave_type">Leave Type</label>
                    <select id="leave_type" name="leave_type" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-cyan-400 focus:outline-none px-3 py-2 bg-white text-gray-800">
                        <option value="">Select Leave Type</option>
                        <option value="Vacation">Vacation</option>
                        <option value="Sick Leave">Sick Leave</option>
                        <option value="Maternity/Paternity">Maternity/Paternity</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <!-- Start Date -->
                <div class="flex flex-col">
                    <label class="text-gray-700 font-medium mb-2" for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-cyan-400 focus:outline-none px-3 py-2 bg-white text-gray-800">
                </div>

                <!-- End Date -->
                <div class="flex flex-col">
                    <label class="text-gray-700 font-medium mb-2" for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-cyan-400 focus:outline-none px-3 py-2 bg-white text-gray-800">
                </div>

                <!-- Reason -->
                <div class="flex flex-col md:col-span-2">
                    <label class="text-gray-700 font-medium mb-2" for="reason">Reason</label>
                    <textarea id="reason" name="reason" rows="5" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-cyan-400 focus:outline-none px-3 py-2 bg-white text-gray-800" placeholder="Enter reason for leave..."></textarea>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end">
                <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-6 py-2 rounded-lg shadow hover:from-cyan-600 hover:to-blue-600 transition font-semibold flex items-center gap-2">
                    <i data-lucide="send" class="w-4 h-4"></i> Submit Request
                </button>
            </div>
        </form>

    </section>

    <footer class="text-center text-xs text-gray-400 py-4">
      ESS User Module • © <?= date('Y'); ?>
    </footer>

  </main>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();

  // Profile dropdown
  const menuBtn = document.getElementById("profile-menu-btn");
  const menu = document.getElementById("profile-menu");
  menuBtn.addEventListener("click", () => menu.classList.toggle("hidden"));
  document.addEventListener("click", (e) => {
    if (!menuBtn.contains(e.target) && !menu.contains(e.target)) menu.classList.add("hidden");
  });

  // Leave Form Validation with Toast
  const leaveForm = document.getElementById("leaveForm");
  const toast = document.getElementById("toast");

  leaveForm.addEventListener("submit", function(e) {
      const leaveType = document.getElementById("leave_type").value.trim();
      const startDate = document.getElementById("start_date").value.trim();
      const endDate = document.getElementById("end_date").value.trim();
      const reason = document.getElementById("reason").value.trim();

      if (!leaveType || !startDate || !endDate || !reason) {
          e.preventDefault(); // stop submission
          toast.textContent = "All fields are required!";
          toast.classList.remove("hidden");
          setTimeout(() => toast.classList.add("hidden"), 3000);
      }
  });
});
</script>

</body>
</html>