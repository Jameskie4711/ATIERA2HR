<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) die("User not logged in.");

$attempt_id = $_GET['attempt_id'] ?? '';
$quiz_id = $_GET['quiz_id'] ?? '';
$course_id = $_GET['course_id'] ?? '';

// If we have an attempt_id, show quiz results
if ($attempt_id) {
    showQuizResults($conn, $user_id, $attempt_id, $quiz_id, $course_id);
} 
// If we only have course_id, show course details
elseif ($course_id) {
    showCourseDetails($conn, $user_id, $course_id);
} 
else {
    die("No course or quiz specified.");
}

// Function to show quiz results
function showQuizResults($conn, $user_id, $attempt_id, $quiz_id, $course_id) {
    // Fetch attempt details
    $attempt_stmt = $conn->prepare("
        SELECT qa.*, q.quiz_name, q.passing_score, q.description
        FROM quiz_attempts qa
        JOIN library_quizzes q ON qa.quiz_id = q.id
        WHERE qa.id = ? AND qa.user_id = ?
    ");
    $attempt_stmt->bind_param("ii", $attempt_id, $user_id);
    $attempt_stmt->execute();
    $attempt = $attempt_stmt->get_result()->fetch_assoc();

    if (!$attempt) {
        echo "<div class='p-8 text-center'>";
        echo "<h1 class='text-2xl font-bold text-red-600 mb-4'>Quiz Attempt Not Found</h1>";
        echo "<p class='text-gray-600 mb-6'>The quiz results you're looking for don't exist or you don't have permission to view them.</p>";
        if ($course_id) {
            echo "<a href='course_detail.php?course_id=" . urlencode($course_id) . "' class='bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors'>";
            echo "Back to Course</a>";
        } else {
            echo "<a href='user_lms.php' class='bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors'>";
            echo "Back to My Courses</a>";
        }
        echo "</div>";
        exit;
    }

    // Calculate passing status
    $passed = false;
    if (isset($attempt['score']) && isset($attempt['passing_score'])) {
        $passed = $attempt['score'] >= $attempt['passing_score'];
    }
    
    // Calculate time taken if available
    $time_taken = 'N/A';
    if (!empty($attempt['started_at']) && !empty($attempt['completed_at'])) {
        $start = new DateTime($attempt['started_at']);
        $end = new DateTime($attempt['completed_at']);
        $interval = $start->diff($end);
        
        // Format time nicely
        if ($interval->h > 0) {
            $time_taken = $interval->format('%hh %imin %ss');
        } elseif ($interval->i > 0) {
            $time_taken = $interval->format('%imin %ss');
        } else {
            $time_taken = $interval->format('%ss');
        }
    }
    
    // Calculate stats
    $total_questions = $attempt['total_questions'] ?? 0;
    $correct_answers = 0;
    $incorrect_answers = 0;
    
    if ($total_questions > 0 && isset($attempt['score'])) {
        $correct_answers = round(($attempt['score'] / 100) * $total_questions);
        $incorrect_answers = $total_questions - $correct_answers;
        $percentage = $attempt['score'];
    }
    
    // Fetch user info for navigation
    $user_stmt = $conn->prepare("
        SELECT 
            id AS user_id,
            Employee_ID AS employee_id,
            CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname,
            Position AS position,
            Department AS department,
            Profile_Picture AS profile_pic
        FROM users
        WHERE id = ?
    ");
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    $user = $user_result ? $user_result->fetch_assoc() : null;
    
    // Display quiz results
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz Results</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        .progress-ring {
            transform: rotate(-90deg);
            transform-origin: 50% 50%;
        }
        .progress-ring__circle {
            transition: stroke-dashoffset 0.35s;
            transform: rotate(90deg);
            transform-origin: 50% 50%;
        }
        .result-card {
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        .result-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
</head>
<body class="min-h-screen bg-gray-50">
<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- Main -->
  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Page Title -->
        <h1 class="text-xl font-semibold text-gray-800">Quiz Results</h1>

        <!-- Right Actions -->
        <div class="flex items-center gap-4">

          <!-- Profile Dropdown -->
          <div class="relative">
            <button id="profile-menu-btn"
              class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">

              <?php 
              $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg';
              if ($user) {
                  $initial = strtoupper(substr($user['fullname'], 0, 1));
              } else {
                  $initial = 'U';
              }
              ?>
              <?php if (!empty($user['profile_pic'])): ?>
                <img src="<?= htmlspecialchars($pic); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover border-2 border-white">
              <?php else: ?>
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold text-sm border-2 border-white">
                    <?= $initial ?>
                </div>
              <?php endif; ?>
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-menu"
              class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">

              <a href="user_profile.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="user" class="w-4 h-4"></i>
                Profile
              </a>
              
              <a href="user_lms.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="book-open" class="w-4 h-4"></i>
                My Courses
              </a>

              <a href="user_settings.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="settings" class="w-4 h-4"></i>
                Settings
              </a>

              <hr class="border-gray-200">

              <a href="logout.php"
                class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                Logout
              </a>
            </div>
          </div>

        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6 max-w-5xl mx-auto">
        <div class="space-y-6">
            <!-- Back Button -->
            <div class="mb-6">
                <a href="course_detail.php?course_id=<?= urlencode($course_id) ?>#quizzes" 
                   class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors group">
                    <i data-lucide="arrow-left" class="w-5 h-5 group-hover:-translate-x-1 transition-transform"></i>
                    <span class="font-medium">Back to Course</span>
                </a>
            </div>
            
            <!-- Main Result Card -->
            <div class="bg-white rounded-2xl shadow-xl overflow-hidden result-card border border-gray-200">
                <!-- Header with gradient -->
                <div class="bg-gradient-to-r <?= $passed ? 'from-green-500 to-emerald-600' : 'from-rose-500 to-pink-600' ?> p-8 text-white">
                    <div class="flex flex-col md:flex-row items-center justify-between">
                        <div>
                            <h1 class="text-2xl md:text-3xl font-bold">Quiz Results</h1>
                            <p class="text-white/90 mt-2"><?= htmlspecialchars($attempt['quiz_name'] ?? 'Quiz') ?></p>
                        </div>
                        <div class="mt-4 md:mt-0">
                            <span class="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium">
                                <?= $passed ? 'Passed' : 'Needs Improvement' ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Content -->
                <div class="p-8">
                    <!-- Score Circle -->
                    <div class="flex flex-col items-center mb-12">
                        <div class="relative w-48 h-48 mb-6">
                            <svg class="w-full h-full" viewBox="0 0 100 100">
                                <!-- Background circle -->
                                <circle cx="50" cy="50" r="45" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                                <!-- Progress circle -->
                                <circle cx="50" cy="50" r="45" fill="none" 
                                    stroke="<?= $passed ? '#10b981' : '#ef4444' ?>" 
                                    stroke-width="8" 
                                    stroke-linecap="round"
                                    stroke-dasharray="283"
                                    stroke-dashoffset="<?= 283 - (283 * ($percentage ?? 0) / 100) ?>"
                                    class="progress-ring__circle transition-all duration-1000"/>
                            </svg>
                            <div class="absolute inset-0 flex flex-col items-center justify-center">
                                <span class="text-4xl font-bold <?= $passed ? 'text-green-600' : 'text-red-600' ?>">
                                    <?= $percentage ?? 0 ?>%
                                </span>
                                <span class="text-gray-500">Your Score</span>
                            </div>
                        </div>
                        
                        <!-- Passing requirement -->
                        <div class="text-center">
                            <p class="text-gray-600">
                                <span class="font-semibold">Passing Score:</span> <?= $attempt['passing_score'] ?? 70 ?>%
                            </p>
                            <p class="mt-2 text-lg font-semibold <?= $passed ? 'text-green-700' : 'text-red-700' ?>">
                                <?= $passed ? '🎉 Congratulations! You passed!' : '📚 Keep practicing!' ?>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Stats Grid -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
                        <div class="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-lg bg-blue-500 flex items-center justify-center">
                                    <i data-lucide="help-circle" class="w-6 h-6 text-white"></i>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-gray-800"><?= $total_questions ?></p>
                                    <p class="text-gray-600 text-sm">Total Questions</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gradient-to-br from-green-50 to-emerald-100 p-6 rounded-xl border border-green-200">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-lg bg-green-500 flex items-center justify-center">
                                    <i data-lucide="check-circle" class="w-6 h-6 text-white"></i>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-gray-800"><?= $correct_answers ?></p>
                                    <p class="text-gray-600 text-sm">Correct Answers</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gradient-to-br from-red-50 to-rose-100 p-6 rounded-xl border border-red-200">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-lg bg-red-500 flex items-center justify-center">
                                    <i data-lucide="x-circle" class="w-6 h-6 text-white"></i>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-gray-800"><?= $incorrect_answers ?></p>
                                    <p class="text-gray-600 text-sm">Incorrect Answers</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gradient-to-br from-purple-50 to-violet-100 p-6 rounded-xl border border-purple-200">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-lg bg-purple-500 flex items-center justify-center">
                                    <i data-lucide="clock" class="w-6 h-6 text-white"></i>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-gray-800"><?= $time_taken ?></p>
                                    <p class="text-gray-600 text-sm">Time Taken</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Attempt Details -->
                    <div class="bg-gray-50 rounded-xl p-6 mb-8 border border-gray-200">
                        <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                            <i data-lucide="clipboard-list" class="w-5 h-5"></i>
                            Attempt Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-3">
                                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                                    <span class="text-gray-600">Started</span>
                                    <span class="font-medium text-gray-800"><?= !empty($attempt['started_at']) ? date('M j, Y g:i A', strtotime($attempt['started_at'])) : 'N/A' ?></span>
                                </div>
                                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                                    <span class="text-gray-600">Completed</span>
                                    <span class="font-medium text-gray-800"><?= !empty($attempt['completed_at']) ? date('M j, Y g:i A', strtotime($attempt['completed_at'])) : 'N/A' ?></span>
                                </div>
                            </div>
                            <div class="space-y-3">
                                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                                    <span class="text-gray-600">Status</span>
                                    <span class="px-3 py-1 rounded-full text-sm font-medium <?= $passed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= $passed ? 'Passed' : 'Failed' ?>
                                    </span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-600">Accuracy</span>
                                    <span class="font-medium text-gray-800"><?= $total_questions > 0 ? round(($correct_answers / $total_questions) * 100) : 0 ?>%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-4 justify-center pt-6 border-t border-gray-200">
                        <?php if ($course_id): ?>
                            <a href="course_detail.php?course_id=<?= urlencode($course_id) ?>#quizzes" 
                               class="inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-all duration-300 hover:shadow-lg font-medium">
                               <i data-lucide="book-open" class="w-5 h-5"></i>
                               Course Quizzes
                            </a>
                        <?php endif; ?>
                        
                        <a href="take_quiz.php?quiz_id=<?= $quiz_id ?>&course_id=<?= urlencode($course_id) ?>" 
                           class="inline-flex items-center justify-center gap-2 border border-blue-600 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition-all duration-300 font-medium">
                           <i data-lucide="refresh-cw" class="w-5 h-5"></i>
                           <?= $passed ? 'Retake Quiz' : 'Try Again' ?>
                        </a>
                        
                        <a href="user_lms.php" 
                           class="inline-flex items-center justify-center gap-2 border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-all duration-300 font-medium">
                           <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                           My Courses
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center text-xs text-gray-400 py-4">
      LMS Module • © <?= date('Y'); ?>
    </footer>

  </main>
</div>
    
    <script>
        lucide.createIcons();
        
        // Animate progress circle
        document.addEventListener('DOMContentLoaded', function() {
            const circles = document.querySelectorAll('.progress-ring__circle');
            circles.forEach(circle => {
                const length = circle.getTotalLength();
                circle.style.strokeDasharray = length;
                circle.style.strokeDashoffset = length;
                
                // Trigger animation
                setTimeout(() => {
                    circle.style.transition = 'stroke-dashoffset 1.5s ease-in-out';
                    const offset = circle.style.strokeDashoffset;
                    circle.style.strokeDashoffset = '0';
                }, 300);
            });
            
            // Profile dropdown
            const menuBtn = document.getElementById("profile-menu-btn");
            const menu = document.getElementById("profile-menu");
            if (menuBtn && menu) {
                menuBtn.addEventListener("click", () => menu.classList.toggle("hidden"));
                document.addEventListener("click", (e) => {
                    if (!menuBtn.contains(e.target) && !menu.contains(e.target)) menu.classList.add("hidden");
                });
            }
        });
    </script>
</body>
</html>
    <?php
}

// Function to show course details
function showCourseDetails($conn, $user_id, $course_id) {
    // Fetch course details
    $course_stmt = $conn->prepare("
        SELECT Course_ID, Title, Instructor, Start, End, Progress 
        FROM user_lms 
        WHERE Course_ID = ? AND user_id = ?
    ");
    $course_stmt->bind_param("si", $course_id, $user_id);
    $course_stmt->execute();
    $course = $course_stmt->get_result()->fetch_assoc();

    if (!$course) {
        echo "<div class='p-8 text-center'>";
        echo "<h1 class='text-2xl font-bold text-red-600 mb-4'>Course Not Found</h1>";
        echo "<p class='text-gray-600 mb-6'>The course you're looking for doesn't exist or you don't have access to it.</p>";
        echo "<a href='user_lms.php' class='bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors'>";
        echo "Back to My Courses</a>";
        echo "</div>";
        exit;
    }

    // Fetch quizzes for this course
    $quizzes_stmt = $conn->prepare("
        SELECT q.*, qa.id as attempt_id, qa.score, qa.completed_at, qa.total_questions
        FROM library_quizzes q
        LEFT JOIN quiz_attempts qa ON q.id = qa.quiz_id AND qa.user_id = ?
        WHERE q.course_id = ?
        ORDER BY q.created_at
    ");
    $quizzes_stmt->bind_param("is", $user_id, $course_id);
    $quizzes_stmt->execute();
    $quizzes = $quizzes_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Fetch user info for navigation
    $user_stmt = $conn->prepare("
        SELECT 
            id AS user_id,
            Employee_ID AS employee_id,
            CONCAT(First_Name, ' ', COALESCE(Middle_Initial, ''), ' ', Last_Name) AS fullname,
            Position AS position,
            Department AS department,
            Profile_Picture AS profile_pic
        FROM users
        WHERE id = ?
    ");
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    $user = $user_result ? $user_result->fetch_assoc() : null;
    
    // Display course details
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?= htmlspecialchars($course['Title']) ?> - Course Details</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://unpkg.com/lucide@latest"></script>
        <style>
            .quiz-card {
                transition: all 0.3s ease;
                border-left: 4px solid transparent;
            }
            .quiz-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            }
            .quiz-card.completed {
                border-left-color: #10b981;
            }
            .quiz-card.in-progress {
                border-left-color: #f59e0b;
            }
            .quiz-card.not-started {
                border-left-color: #6366f1;
            }
        </style>
    </head>
<body class="min-h-screen bg-gray-50">
<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- Main -->
  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-gray-200">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Page Title -->
        <h1 class="text-xl font-semibold text-gray-800"><?= htmlspecialchars($course['Title']) ?></h1>

        <!-- Right Actions -->
        <div class="flex items-center gap-4">

          <!-- Profile Dropdown -->
          <div class="relative">
            <button id="profile-menu-btn"
              class="flex items-center gap-2 px-2 py-1 rounded-full hover:bg-gray-100 transition">

              <?php 
              $pic = !empty($user['profile_pic']) ? $user['profile_pic'] : '/HR/picture/profile.jpg';
              if ($user) {
                  $initial = strtoupper(substr($user['fullname'], 0, 1));
              } else {
                  $initial = 'U';
              }
              ?>
              <?php if (!empty($user['profile_pic'])): ?>
                <img src="<?= htmlspecialchars($pic); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover border-2 border-white">
              <?php else: ?>
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold text-sm border-2 border-white">
                    <?= $initial ?>
                </div>
              <?php endif; ?>
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-menu"
              class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">

              <a href="user_settings.php"
                class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-gray-800">
                <i data-lucide="settings" class="w-4 h-4"></i>
                Settings
              </a>

              <hr class="border-gray-200">

              <a href="logout.php"
                class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                Logout
              </a>
            </div>
          </div>

        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6 max-w-6xl mx-auto">
        <div class="space-y-6">
            <!-- Back Button -->
            <div class="mb-6">
                <a href="user_lms.php" 
                   class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors group">
                    <i data-lucide="arrow-left" class="w-5 h-5 group-hover:-translate-x-1 transition-transform"></i>
                    <span class="font-medium">Back to My Courses</span>
                </a>
            </div>
            
            <!-- Course Header -->
            <div class="bg-white rounded-2xl shadow-xl p-6 md:p-8 mb-8 border border-gray-200">
                <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-8">
                    <div class="flex-1">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                                <i data-lucide="book-open" class="w-6 h-6 text-white"></i>
                            </div>
                            <div>
                                <h1 class="text-2xl md:text-3xl font-bold text-gray-800"><?= htmlspecialchars($course['Title']) ?></h1>
                                <p class="text-gray-600 mt-1 flex items-center gap-2">
                                    <i data-lucide="user" class="w-4 h-4"></i>
                                    <?= htmlspecialchars($course['Instructor']) ?>
                                </p>
                            </div>
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="max-w-md">
                            <div class="flex justify-between items-center mb-2">
                                <span class="text-sm font-medium text-gray-700">Course Progress</span>
                                <span class="text-sm font-bold <?= $course['Progress'] == 100 ? 'text-green-600' : 'text-blue-600' ?>">
                                    <?= $course['Progress'] ?>%
                                </span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-3">
                                <div class="h-3 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-500" 
                                     style="width: <?= $course['Progress'] ?>%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex flex-col gap-3">
                        <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-4 rounded-xl border border-blue-100">
                            <div class="text-center">
                                <p class="text-sm text-gray-600 mb-1">Course Duration</p>
                                <p class="font-bold text-gray-800">
                                    <?= date('M j', strtotime($course['Start'])) ?> - <?= date('M j, Y', strtotime($course['End'])) ?>
                                </p>
                            </div>
                        </div>
                        
                        <div class="bg-gradient-to-r <?= $course['Progress'] == 100 ? 'from-green-50 to-emerald-50' : 'from-yellow-50 to-amber-50' ?> 
                            px-6 py-4 rounded-xl border <?= $course['Progress'] == 100 ? 'border-green-100' : 'border-yellow-100' ?>">
                            <div class="text-center">
                                <p class="text-sm text-gray-600 mb-1">Status</p>
                                <p class="font-bold <?= $course['Progress'] == 100 ? 'text-green-700' : 'text-yellow-700' ?>">
                                    <?= $course['Progress'] == 100 ? 'Completed' : 'In Progress' ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
               
            
            <!-- Quizzes Section -->
            <div id="quizzes" class="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-200">
                <div class="flex items-center justify-between mb-8">
                    <h2 class="text-2xl font-bold text-gray-800 flex items-center gap-3">
                        <i data-lucide="clipboard-check" class="w-6 h-6 text-blue-600"></i>
                        Course Quizzes
                    </h2>
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                        <?= count($quizzes) ?> Quiz<?= count($quizzes) != 1 ? 'zes' : '' ?>
                    </span>
                </div>
                
                <?php if ($quizzes): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <?php foreach ($quizzes as $quiz): 
                            $hasAttempt = !empty($quiz['attempt_id']);
                            $passed = $hasAttempt && isset($quiz['score']) && isset($quiz['passing_score']) && $quiz['score'] >= $quiz['passing_score'];
                            $statusClass = $hasAttempt ? ($passed ? 'completed' : 'in-progress') : 'not-started';
                        ?>
                            <div class="quiz-card <?= $statusClass ?> bg-white border border-gray-200 rounded-xl p-6 relative overflow-hidden">
                                <!-- Status badge -->
                                <div class="absolute top-4 right-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium 
                                        <?= $hasAttempt ? 
                                            ($passed ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800') 
                                            : 'bg-blue-100 text-blue-800' ?>">
                                        <?= $hasAttempt ? ($passed ? 'Passed' : 'Attempted') : 'Not Started' ?>
                                    </span>
                                </div>
                                
                                <!-- Quiz icon -->
                                <div class="w-14 h-14 rounded-xl bg-gradient-to-br 
                                    <?= $hasAttempt ? 
                                        ($passed ? 'from-green-500 to-emerald-600' : 'from-amber-500 to-orange-600') 
                                        : 'from-blue-500 to-indigo-600' ?>
                                    flex items-center justify-center mb-4">
                                    <i data-lucide="<?= $hasAttempt ? 'clipboard-check' : 'clipboard-list' ?>" class="w-6 h-6 text-white"></i>
                                </div>
                                
                                <!-- Quiz info -->
                                <h3 class="text-lg font-bold text-gray-800 mb-2"><?= htmlspecialchars($quiz['quiz_name']) ?></h3>
                                
                                <?php if (!empty($quiz['description'])): ?>
                                    <p class="text-gray-600 mb-4 text-sm"><?= htmlspecialchars($quiz['description']) ?></p>
                                <?php endif; ?>
                                
                                <!-- Stats -->
                                <div class="flex items-center gap-4 text-sm text-gray-500 mb-6">
                                    <span class="flex items-center gap-1">
                                        <i data-lucide="target" class="w-4 h-4"></i>
                                        Pass: <?= $quiz['passing_score'] ?? 70 ?>%
                                    </span>
                                    <?php if ($hasAttempt): ?>
                                        <span class="flex items-center gap-1 <?= $passed ? 'text-green-600' : 'text-amber-600' ?>">
                                            <i data-lucide="star" class="w-4 h-4"></i>
                                            Score: <?= $quiz['score'] ?? 0 ?>%
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Action buttons -->
                                <div class="flex gap-3">
                                    <?php if ($hasAttempt): ?>
                                        <a href="course_detail.php?attempt_id=<?= $quiz['attempt_id'] ?>&quiz_id=<?= $quiz['id'] ?>&course_id=<?= $course_id ?>" 
                                           class="flex-1 inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2.5 rounded-lg hover:bg-blue-700 transition-all duration-300 text-sm font-medium">
                                           <i data-lucide="bar-chart-3" class="w-4 h-4"></i>
                                           View Results
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="take_quiz.php?quiz_id=<?= $quiz['id'] ?>&course_id=<?= $course_id ?>" 
                                       class="<?= $hasAttempt ? 'flex-1' : 'flex-1' ?> inline-flex items-center justify-center gap-2 
                                       border <?= $hasAttempt ? 'border-gray-300 text-gray-700 hover:bg-gray-50' : 'border-blue-600 text-blue-600 hover:bg-blue-50' ?>
                                       px-4 py-2.5 rounded-lg transition-all duration-300 text-sm font-medium">
                                        <i data-lucide="<?= $hasAttempt ? 'refresh-cw' : 'play' ?>" class="w-4 h-4"></i>
                                        <?= $hasAttempt ? 'Retake Quiz' : 'Start Quiz' ?>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12">
                        <div class="w-20 h-20 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
                            <i data-lucide="clipboard-x" class="w-10 h-10 text-gray-400"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">No Quizzes Available</h3>
                        <p class="text-gray-500 max-w-md mx-auto">
                            There are no quizzes available for this course yet. Check back later or contact your instructor.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Quick Stats -->
            <?php if ($quizzes): ?>
                <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php
                    $completed = 0;
                    $passed = 0;
                    $averageScore = 0;
                    
                    foreach ($quizzes as $quiz) {
                        if (!empty($quiz['attempt_id'])) {
                            $completed++;
                            if ($quiz['score'] >= $quiz['passing_score']) {
                                $passed++;
                            }
                            $averageScore += $quiz['score'];
                        }
                    }
                    
                    $averageScore = $completed > 0 ? round($averageScore / $completed) : 0;
                    ?>
                    
                    <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-600 text-sm mb-1">Quizzes Completed</p>
                                <p class="text-2xl font-bold text-gray-800"><?= $completed ?>/<?= count($quizzes) ?></p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-blue-500 flex items-center justify-center">
                                <i data-lucide="check-circle" class="w-6 h-6 text-white"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-600 text-sm mb-1">Quizzes Passed</p>
                                <p class="text-2xl font-bold text-gray-800"><?= $passed ?>/<?= $completed ?></p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-green-500 flex items-center justify-center">
                                <i data-lucide="award" class="w-6 h-6 text-white"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gradient-to-br from-purple-50 to-violet-50 rounded-xl p-6 border border-purple-100">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-600 text-sm mb-1">Average Score</p>
                                <p class="text-2xl font-bold text-gray-800"><?= $averageScore ?>%</p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-purple-500 flex items-center justify-center">
                                <i data-lucide="bar-chart-2" class="w-6 h-6 text-white"></i>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center text-xs text-gray-400 py-4">
      LMS Module • © <?= date('Y'); ?>
    </footer>

  </main>
</div>
    
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            lucide.createIcons();
            
            // Smooth scroll to quizzes section
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
            
            // Add hover effects to quiz cards
            const quizCards = document.querySelectorAll('.quiz-card');
            quizCards.forEach(card => {
                card.addEventListener('mouseenter', () => {
                    const icon = card.querySelector('i[data-lucide]');
                    if (icon) {
                        const currentIcon = icon.getAttribute('data-lucide');
                        if (currentIcon === 'clipboard-list') {
                            icon.setAttribute('data-lucide', 'play');
                        } else if (currentIcon === 'clipboard-check') {
                            icon.setAttribute('data-lucide', 'bar-chart-3');
                        }
                        lucide.createIcons();
                    }
                });
                
                card.addEventListener('mouseleave', () => {
                    const icon = card.querySelector('i[data-lucide]');
                    if (icon) {
                        const hasAttempt = card.classList.contains('completed') || card.classList.contains('in-progress');
                        icon.setAttribute('data-lucide', hasAttempt ? 'clipboard-check' : 'clipboard-list');
                        lucide.createIcons();
                    }
                });
            });
            
            // Profile dropdown
            const menuBtn = document.getElementById("profile-menu-btn");
            const menu = document.getElementById("profile-menu");
            if (menuBtn && menu) {
                menuBtn.addEventListener("click", () => menu.classList.toggle("hidden"));
                document.addEventListener("click", (e) => {
                    if (!menuBtn.contains(e.target) && !menu.contains(e.target)) menu.classList.add("hidden");
                });
            }
        });
    </script>
</body>
</html>
    <?php
}
?>