<?php
include('../session_check.php');
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $title = $_POST['training_title'];
    $description = $_POST['training_description'];
    $preferred_date = $_POST['preferred_date'];

    $stmt = $conn->prepare("INSERT INTO training_requests (employee_id, employee_name, training_title, training_description, preferred_date, status, date_requested) VALUES (?, ?, ?, ?, ?, 'Pending', NOW())");
    $stmt->bind_param("issss", $employee_id, $employee_name, $title, $description, $preferred_date);

    if ($stmt->execute()) {
        // Redirect back to user_trainreq.php with a confirmation flag
        header("Location: user_trainreq.php?submitted=1");
        exit;
    } else {
        die("Error submitting training request: " . $stmt->error);
    }
}
?>
