<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Include session check and DB
include('session_check.php');
include('dblogin.php');

// Get logged-in user info
$user_id = $_SESSION['user_id'] ?? null;
$user_email = $_SESSION['email'] ?? null; // make sure your login sets this

if (!$user_id || !$user_email) {
    die("User not logged in or missing email.");
}

// ✅ Fetch data from HR4 Payroll API
$api_url = "https://hr4.atierahotelandrestaurant.com/payroll_api.php";
$response = file_get_contents($api_url);
$data = json_decode($response, true);

// ✅ Filter the API data for this user's email
$payslips = [];
if ($data && $data['success'] && isset($data['payroll_data'])) {
    foreach ($data['payroll_data'] as $p) {
        if (strcasecmp($p['email'], $user_email) === 0) {
            $payslips[] = $p;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS User - Payslips</title>
  <link rel="icon" type="image/png" href="../logo2.png" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex h-screen bg-slate-50 font-sans">

  <!-- ✅ Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- ✅ Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6 flex-1">

      <!-- Topbar Header -->
      <div class="flex items-center justify-between border-b pb-4">
        <h1 class="text-2xl font-semibold text-gray-800">Payslips</h1>
      </div>

      <!-- Breadcrumb -->
      <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
        <a href="userinfo2.php" class="hover:text-blue-600 transition-colors">Home</a>
        <span>Payslips</span>
      </div>

      <!-- ✅ Payslip Table -->
      <div class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">My Payslips</h2>
        <table class="w-full border-collapse text-sm">
          <thead>
            <tr class="bg-gray-100 text-left">
              <th class="p-2 border">Name</th>
              <th class="p-2 border">Department</th>
              <th class="p-2 border">Position</th>
              <th class="p-2 border">Gross</th>
              <th class="p-2 border">Net</th>
              <th class="p-2 border">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($payslips): ?>
              <?php foreach ($payslips as $p): ?>
                <tr class="hover:bg-gray-50">
                  <td class="p-2 border"><?= htmlspecialchars($p['name']) ?></td>
                  <td class="p-2 border"><?= htmlspecialchars($p['department']) ?></td>
                  <td class="p-2 border"><?= htmlspecialchars($p['position']) ?></td>
                  <td class="p-2 border">₱<?= number_format($p['gross'], 2) ?></td>
                  <td class="p-2 border font-medium text-green-700">₱<?= number_format($p['net'], 2) ?></td>
                  <td class="p-2 border text-center">
                    <button 
                      class="view-btn text-blue-600 hover:underline"
                      data-name="<?= htmlspecialchars($p['name']) ?>"
                      data-position="<?= htmlspecialchars($p['position']) ?>"
                      data-department="<?= htmlspecialchars($p['department']) ?>"
                      data-gross="<?= $p['gross'] ?>"
                      data-net="<?= $p['net'] ?>"
                      data-records='<?= json_encode($p['records']) ?>'
                    >
                      View
                    </button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="6" class="p-2 text-center border text-gray-500">No payroll data found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Back Button -->
      <div>
        <a href="userinfo2.php" class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
          ← Back
        </a>
      </div>

      <footer class="mt-6 text-xs text-slate-400 text-center">
        Payslips • ESS Module
      </footer>

    </main>
  </div>

  <!-- ✅ Payslip Modal -->
  <div id="payslip-modal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-xl w-[400px] p-6">
      <h2 class="text-xl font-semibold mb-4">Payslip Details</h2>
      <div id="payslip-details" class="text-sm space-y-2"></div>
      <div class="flex justify-end mt-4">
        <button id="close-modal" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Close</button>
      </div>
    </div>
  </div>

  <!-- ✅ JS -->
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("payslip-modal");
    const closeModal = document.getElementById("close-modal");
    const details = document.getElementById("payslip-details");

    document.querySelectorAll(".view-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const name = btn.dataset.name;
        const position = btn.dataset.position;
        const department = btn.dataset.department;
        const gross = btn.dataset.gross;
        const net = btn.dataset.net;
        const records = JSON.parse(btn.dataset.records);

        details.innerHTML = `
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Position:</strong> ${position}</p>
          <p><strong>Department:</strong> ${department}</p>
          <p><strong>Basic Salary:</strong> ₱${Number(records.Basic_Salary).toLocaleString()}</p>
          <p><strong>Overtime:</strong> ₱${Number(records.Overtime).toLocaleString()}</p>
          <p><strong>Deductions:</strong> ₱${(Number(records.SSS) + Number(records.PhilHealth) + Number(records['Pag-IBIG']) + Number(records.Tax)).toLocaleString()}</p>
          <hr>
          <p><strong>Gross:</strong> ₱${Number(gross).toLocaleString()}</p>
          <p><strong>Net Pay:</strong> <span class="text-green-700 font-semibold">₱${Number(net).toLocaleString()}</span></p>
        `;
        modal.classList.remove("hidden");
      });
    });

    closeModal.addEventListener("click", () => modal.classList.add("hidden"));
    lucide.createIcons();
  });
  </script>

</body>
</html>
