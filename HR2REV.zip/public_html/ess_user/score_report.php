<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) die("User not logged in.");

$attempt_id = $_GET['attempt_id'] ?? '';

// Fetch attempt details
$attempt_stmt = $conn->prepare("
    SELECT qa.*, q.quiz_name, q.passing_score, u.username
    FROM quiz_attempts qa
    JOIN library_quizzes q ON qa.quiz_id = q.id
    JOIN users u ON qa.user_id = u.id
    WHERE qa.id = ? AND qa.user_id = ?
");
$attempt_stmt->bind_param("ii", $attempt_id, $user_id);
$attempt_stmt->execute();
$attempt = $attempt_stmt->get_result()->fetch_assoc();

if (!$attempt) die("Attempt not found.");

// Set headers for PDF download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="quiz_report_' . $attempt_id . '.pdf"');

// Generate PDF (you'll need a PDF library like TCPDF or Dompdf)
// This is a simplified version - you should implement proper PDF generation

echo "QUIZ REPORT\n";
echo "===========\n\n";
echo "Quiz: " . $attempt['quiz_name'] . "\n";
echo "User: " . $attempt['username'] . "\n";
echo "Score: " . $attempt['score'] . "%\n";
echo "Status: " . ($attempt['score'] >= $attempt['passing_score'] ? 'Passed' : 'Failed') . "\n";
echo "Date: " . $attempt['completed_at'] . "\n\n";
echo "--- END OF REPORT ---";
?>