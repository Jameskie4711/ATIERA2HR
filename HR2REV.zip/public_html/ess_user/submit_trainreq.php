<?php
include('../session_check.php');
include('../dblogin.php');

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $title = $_POST['training_title'];
    $description = $_POST['training_description'];
    $preferred_date = $_POST['preferred_date'];

    $stmt = $conn->prepare("INSERT INTO training_requests (employee_id, employee_name, training_title, training_description, preferred_date, status, date_requested) VALUES (?, ?, ?, ?, ?, 'Pending', NOW())");
    $stmt->bind_param("issss", $employee_id, $employee_name, $title, $description, $preferred_date);
    $stmt->execute();

    // Redirect back with a success flag
    header("Location: user_trainreq.php?submitted=1");
    exit;
}
?>
