<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in. Please <a href='login.php'>login</a> first.");
}

$attempt_id = $_GET['attempt_id'] ?? '';
$quiz_id = $_GET['quiz_id'] ?? '';
$course_id = $_GET['course_id'] ?? '';

echo "<h3>Debug Info:</h3>";
echo "User ID: $user_id<br>";
echo "Attempt ID: $attempt_id<br>";
echo "Quiz ID: $quiz_id<br>";
echo "Course ID: $course_id<br><br>";

// Debug: Show all attempts for this user
$debug_stmt = $conn->prepare("SELECT id, quiz_id, score FROM quiz_attempts WHERE user_id = ? ORDER BY id DESC LIMIT 5");
$debug_stmt->bind_param("i", $user_id);
$debug_stmt->execute();
$debug_results = $debug_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo "<h4>Recent attempts for user $user_id:</h4>";
if ($debug_results) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Attempt ID</th><th>Quiz ID</th><th>Score</th><th>Link</th></tr>";
    foreach ($debug_results as $row) {
        $link = "quiz_results.php?attempt_id=" . $row['id'] . "&quiz_id=" . $row['quiz_id'] . "&course_id=" . $course_id;
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['quiz_id'] . "</td>";
        echo "<td>" . ($row['score'] ?? 'N/A') . "</td>";
        echo "<td><a href='$link'>View Results</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No quiz attempts found for this user.<br>";
    echo "Make sure you've taken a quiz first.<br>";
}

// Check if specific attempt exists
if ($attempt_id) {
    $check_stmt = $conn->prepare("SELECT id FROM quiz_attempts WHERE id = ? AND user_id = ?");
    $check_stmt->bind_param("ii", $attempt_id, $user_id);
    $check_stmt->execute();
    $attempt_exists = $check_stmt->get_result()->fetch_assoc();
    
    echo "<br><strong>Checking attempt $attempt_id:</strong> ";
    if ($attempt_exists) {
        echo "✓ Found!<br>";
    } else {
        echo "✗ Not found or doesn't belong to you!<br>";
    }
}

// Now try to fetch the attempt details normally
if ($attempt_id) {
    $attempt_stmt = $conn->prepare("
        SELECT qa.*, q.quiz_name, q.passing_score, q.description
        FROM quiz_attempts qa
        JOIN library_quizzes q ON qa.quiz_id = q.id
        WHERE qa.id = ? AND qa.user_id = ?
    ");
    
    if ($attempt_stmt) {
        $attempt_stmt->bind_param("ii", $attempt_id, $user_id);
        $attempt_stmt->execute();
        $attempt = $attempt_stmt->get_result()->fetch_assoc();
        
        if (!$attempt) {
            echo "<h3 style='color: red;'>ERROR: Attempt not found in database.</h3>";
            echo "Possible reasons:<br>";
            echo "1. The attempt ID doesn't exist<br>";
            echo "2. The attempt belongs to a different user<br>";
            echo "3. Database tables aren't set up correctly<br>";
            echo "4. The quiz submission failed<br>";
            
            // Provide links to go back
            echo "<br><br>";
            echo "<a href='course_detail.php?course_id=$course_id' style='background: blue; color: white; padding: 10px; text-decoration: none;'>← Back to Course</a>";
            exit();
        }
        
        // If we get here, the attempt was found
        // Continue with the rest of your code...
        
    } else {
        die("Database error: " . $conn->error);
    }
} else {
    echo "<h3>No attempt ID provided.</h3>";
    echo "<p>Please take a quiz first or provide a valid attempt ID.</p>";
    exit();
}

// Rest of your quiz_results.php code continues here...
// Remove the debug section above and continue with your original HTML output
?>

<!-- Your original HTML code continues from here -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz Results</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50">
    <!-- ... rest of your HTML ... -->