<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die("User not logged in.");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

$attempt_id = $_POST['attempt_id'] ?? '';
$quiz_id = $_POST['quiz_id'] ?? '';
$course_id = $_POST['course_id'] ?? '';

// Validate inputs
if (empty($attempt_id) || empty($quiz_id)) {
    die("Missing required parameters.");
}

// First, verify the attempt exists and belongs to this user
$verify_stmt = $conn->prepare("SELECT * FROM quiz_attempts WHERE id = ? AND user_id = ?");
$verify_stmt->bind_param("ii", $attempt_id, $user_id);
$verify_stmt->execute();
$attempt = $verify_stmt->get_result()->fetch_assoc();

if (!$attempt) {
    die("Quiz attempt not found or doesn't belong to you.");
}

// Calculate score
$score = 0;
$total_questions = 0;
$answers = [];

foreach ($_POST as $key => $value) {
    if (strpos($key, 'question_') === 0) {
        $question_id = str_replace('question_', '', $key);
        $total_questions++;
        
        // Get correct answer
        $stmt = $conn->prepare("SELECT correct_answer FROM quiz_questions WHERE id = ?");
        $stmt->bind_param("i", $question_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result && $value == $result['correct_answer']) {
            $score++;
        }
        
        $answers[] = [
            'question_id' => $question_id,
            'user_answer' => $value,
            'correct_answer' => $result['correct_answer'] ?? ''
        ];
    }
}

$percentage = $total_questions > 0 ? round(($score / $total_questions) * 100) : 0;
$completed_at = date('Y-m-d H:i:s');

// Update attempt record with actual score
$update_stmt = $conn->prepare("
    UPDATE quiz_attempts 
    SET score = ?, total_questions = ?, completed_at = ?
    WHERE id = ?
");
$update_stmt->bind_param("iisi", $percentage, $total_questions, $completed_at, $attempt_id);
if (!$update_stmt->execute()) {
    die("Error updating attempt: " . $conn->error);
}

// Store detailed answers
foreach ($answers as $answer) {
    $is_correct = ($answer['user_answer'] == $answer['correct_answer']) ? 1 : 0;
    
    $answer_stmt = $conn->prepare("
        INSERT INTO quiz_answers (attempt_id, question_id, user_answer, is_correct)
        VALUES (?, ?, ?, ?)
    ");
    $answer_stmt->bind_param("iisi", $attempt_id, $answer['question_id'], $answer['user_answer'], $is_correct);
    $answer_stmt->execute();
}

// Update or insert user_quizzes record
$check_stmt = $conn->prepare("SELECT id, attempt_count FROM user_quizzes WHERE user_id = ? AND quiz_id = ?");
$check_stmt->bind_param("ii", $user_id, $quiz_id);
$check_stmt->execute();
$existing = $check_stmt->get_result()->fetch_assoc();

if ($existing) {
    // Update existing record
    $new_attempt_count = $existing['attempt_count'] + 1;
    $update_user_quiz = $conn->prepare("
        UPDATE user_quizzes 
        SET score = ?, attempted_at = NOW(), attempt_count = ?
        WHERE id = ?
    ");
    $update_user_quiz->bind_param("iii", $percentage, $new_attempt_count, $existing['id']);
    $update_user_quiz->execute();
} else {
    // Insert new record
    $insert_user_quiz = $conn->prepare("
        INSERT INTO user_quizzes (user_id, quiz_id, score, attempted_at, attempt_count)
        VALUES (?, ?, ?, NOW(), 1)
    ");
    $insert_user_quiz->bind_param("iii", $user_id, $quiz_id, $percentage);
    $insert_user_quiz->execute();
}

// Update course progress if needed
if ($percentage >= 70) { // Passing score
    $progress_stmt = $conn->prepare("
        UPDATE user_lms 
        SET Progress = LEAST(100, Progress + 10)
        WHERE user_id = ? AND Course_ID = ?
    ");
    $progress_stmt->bind_param("is", $user_id, $course_id);
    $progress_stmt->execute();
}

// Redirect to results page
header("Location: quiz_results.php?attempt_id=" . $attempt_id . "&quiz_id=" . $quiz_id . "&course_id=" . $course_id);
exit();
?>