<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('/home/hr2.atierahotelandrestaurant.com/public_html/session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? 0;

$query = $conn->prepare("
  SELECT 
    First_Name, Middle_Initial, Last_Name, Email, 
    Phone_Number AS phone, Address, Profile_Picture AS profile_pic
  FROM users WHERE id = ?
");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ESS User Settings</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-indigo-50">

<div class="flex min-h-screen">
  <?php include 'user_sidebar.php'; ?>

  <main class="flex-1 flex flex-col">

    <!-- TOP BAR -->
    <header class="sticky top-0 z-40 bg-white/80 backdrop-blur border-b">
      <div class="flex items-center justify-between px-6 py-4">

        <!-- Left: Title + Tabs -->
        <div>
          <h1 class="text-xl font-semibold text-slate-800">Account Settings</h1>
          <div class="flex gap-2 mt-2">
            <button id="tab-profile"
              class="px-4 py-1.5 rounded-full text-sm bg-indigo-100 text-indigo-700">
              Profile
            </button>
            <button id="tab-security"
              class="px-4 py-1.5 rounded-full text-sm text-slate-500 hover:bg-slate-100">
              Security
            </button>
          </div>
        </div>

        <!-- Right: Profile Dropdown -->
        <div class="relative">
          <button id="profile-menu-btn"
            class="flex items-center gap-2 rounded-full hover:bg-slate-100 px-2 py-1">
            <img
              src="<?= !empty($user['profile_pic']) ? htmlspecialchars($user['profile_pic']) : '/picture/profile.jpg' ?>"
              class="w-10 h-10 rounded-full object-cover border">
            <i data-lucide="chevron-down" class="w-4 h-4 text-slate-500"></i>
          </button>

          <!-- Dropdown -->
          <div id="profile-menu"
            class="hidden absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border overflow-hidden">

            <a href="user_settings.php"
              class="flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-100">
              <i data-lucide="settings" class="w-4 h-4"></i>
              Settings
            </a>

            <hr>

            <a href="logout.php"
              class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
              <i data-lucide="log-out" class="w-4 h-4"></i>
              Logout
            </a>
          </div>
        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <section class="flex-1 p-6">
      <div class="max-w-5xl mx-auto bg-white/80 backdrop-blur rounded-3xl border shadow-lg p-8">

        <!-- PROFILE TAB -->
        <div id="profile-tab">

          <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            <!-- Avatar -->
            <div class="flex flex-col items-center">
              <div class="relative group">
                <img id="profile-img"
                  src="<?= !empty($user['profile_pic']) ? htmlspecialchars($user['profile_pic']) : '/picture/profile.jpg' ?>"
                  class="w-36 h-36 rounded-full object-cover shadow ring-4 ring-white">

                <div
                  class="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                  <i data-lucide="camera" class="text-white w-6 h-6"></i>
                </div>
              </div>

              <input type="file" id="profile-upload"
                class="mt-4 text-xs text-slate-500">

              <button id="upload-btn"
                class="mt-3 px-4 py-2 rounded-full bg-indigo-600 text-white text-sm hover:bg-indigo-700">
                Update Photo
              </button>
            </div>

            <!-- Profile Form -->
            <form id="info-form"
              class="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-5">

              <?php
              function input($label, $name, $value, $type="text", $extra="") {
                echo "
                <div>
                  <label class='text-xs uppercase tracking-wide text-slate-500'>$label</label>
                  <input type='$type' name='$name' value='".htmlspecialchars($value ?? "")."' $extra
                    class='mt-1 w-full rounded-xl border px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400'>
                </div>";
              }

              input("First Name", "First_Name", $user['First_Name'], "text", "required");
              input("Middle Initial", "Middle_Initial", $user['Middle_Initial'], "text", "maxlength='1'");
              input("Last Name", "Last_Name", $user['Last_Name'], "text", "required");
              input("Email", "Email", $user['Email'], "email", "required");
              input("Phone Number", "Phone_Number", $user['phone']);
              input("Address", "Address", $user['Address']);
              ?>

              <div class="col-span-full flex justify-end gap-3 mt-6">
                <button type="submit"
                  class="px-6 py-2 rounded-full bg-emerald-600 text-white text-sm hover:bg-emerald-700">
                  Save
                </button>
                <button type="button" id="change-pass-btn"
                  class="px-6 py-2 rounded-full bg-slate-700 text-white text-sm hover:bg-slate-800">
                  Change Password
                </button>
              </div>

              <p id="info-msg" class="text-sm col-span-full"></p>
            </form>

          </div>
        </div>

        <!-- SECURITY TAB -->
        <div id="security-tab" class="hidden max-w-md">
          <form id="password-form" class="space-y-5">

            <div>
              <label class="text-xs uppercase tracking-wide text-slate-500">Current Password</label>
              <input type="password" name="current_password" required
                class="mt-1 w-full rounded-xl border px-4 py-2 text-sm">
            </div>

            <div>
              <label class="text-xs uppercase tracking-wide text-slate-500">New Password</label>
              <input type="password" name="new_password" required
                class="mt-1 w-full rounded-xl border px-4 py-2 text-sm">
            </div>

            <div>
              <label class="text-xs uppercase tracking-wide text-slate-500">Confirm Password</label>
              <input type="password" name="confirm_password" required
                class="mt-1 w-full rounded-xl border px-4 py-2 text-sm">
            </div>

            <div class="flex justify-end">
              <button type="submit"
                class="px-6 py-2 rounded-full bg-indigo-600 text-white text-sm hover:bg-indigo-700">
                Update Password
              </button>
            </div>

            <p id="password-msg" class="text-sm"></p>
          </form>
        </div>

      </div>
    </section>

    <footer class="text-center text-xs text-slate-400 py-4">
      ESS User Module • © <?= date('Y'); ?>
    </footer>

  </main>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();

  // Tabs
  const profileTab = document.getElementById("profile-tab");
  const securityTab = document.getElementById("security-tab");
  const tabProfileBtn = document.getElementById("tab-profile");
  const tabSecurityBtn = document.getElementById("tab-security");

  tabProfileBtn.onclick = () => {
    profileTab.classList.remove("hidden");
    securityTab.classList.add("hidden");
    tabProfileBtn.classList.add("bg-indigo-100","text-indigo-700");
    tabSecurityBtn.classList.remove("bg-indigo-100","text-indigo-700");
  };

  tabSecurityBtn.onclick = () => {
    securityTab.classList.remove("hidden");
    profileTab.classList.add("hidden");
    tabSecurityBtn.classList.add("bg-indigo-100","text-indigo-700");
    tabProfileBtn.classList.remove("bg-indigo-100","text-indigo-700");
  };

  // Profile dropdown
  const menuBtn = document.getElementById("profile-menu-btn");
  const menu = document.getElementById("profile-menu");

  menuBtn.onclick = () => menu.classList.toggle("hidden");

  document.addEventListener("click", e => {
    if (!menuBtn.contains(e.target) && !menu.contains(e.target)) {
      menu.classList.add("hidden");
    }
  });
});
</script>

</body>
</html>
