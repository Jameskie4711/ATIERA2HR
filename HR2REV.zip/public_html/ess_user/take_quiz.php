<?php
// take_quiz.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
$quiz_id = $_GET['quiz_id'] ?? 0;
$course_id = $_GET['course_id'] ?? '';

if (!$user_id) die("User not logged in.");
if (!$quiz_id) die("No quiz specified.");

// Fetch quiz details
$quiz_stmt = $conn->prepare("SELECT * FROM library_quizzes WHERE id = ?");
$quiz_stmt->bind_param("i", $quiz_id);
$quiz_stmt->execute();
$quiz = $quiz_stmt->get_result()->fetch_assoc();

if (!$quiz) die("Quiz not found.");

// Fetch questions
$questions_stmt = $conn->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY RAND()");
$questions_stmt->bind_param("i", $quiz_id);
$questions_stmt->execute();
$questions = $questions_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Create a new attempt - UPDATED to match your table structure
$attempt_stmt = $conn->prepare("
    INSERT INTO quiz_attempts (user_id, quiz_id, total_questions, started_at) 
    VALUES (?, ?, ?, NOW())
");
$total_questions = count($questions);
$attempt_stmt->bind_param("iii", $user_id, $quiz_id, $total_questions);
$attempt_stmt->execute();
$attempt_id = $conn->insert_id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($quiz['quiz_name']) ?> - Take Quiz</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen p-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="mb-8">
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800"><?= htmlspecialchars($quiz['quiz_name']) ?></h1>
                        <p class="text-gray-600">Questions: <?= $total_questions ?> | Time Limit: <?= $quiz['time_limit'] ?? 'No limit' ?> minutes</p>
                    </div>
                    <a href="course_detail.php?course_id=<?= urlencode($course_id) ?>" 
                       class="text-blue-600 hover:text-blue-800">
                       Cancel & Return
                    </a>
                </div>
                <div class="bg-blue-50 p-4 rounded-lg">
                    <p class="text-blue-800"><strong>Instructions:</strong> <?= htmlspecialchars($quiz['description'] ?? 'Answer all questions to the best of your ability.') ?></p>
                    <p class="text-blue-800 mt-1"><strong>Passing Score:</strong> <?= $quiz['passing_score'] ?? 70 ?>%</p>
                </div>
            </div>
            
            <!-- Quiz Form -->
            <form id="quizForm" action="submit_quiz.php" method="POST">
                <input type="hidden" name="attempt_id" value="<?= $attempt_id ?>">
                <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">
                <input type="hidden" name="course_id" value="<?= htmlspecialchars($course_id) ?>">
                <input type="hidden" name="total_questions" value="<?= $total_questions ?>">
                
                <div class="space-y-6">
                    <?php foreach ($questions as $index => $question): 
                        $options = json_decode($question['options'] ?? '[]', true);
                    ?>
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <div class="flex items-start mb-4">
                                <span class="bg-gray-100 text-gray-800 font-bold rounded-full w-8 h-8 flex items-center justify-center mr-3">
                                    <?= $index + 1 ?>
                                </span>
                                <h3 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($question['question_text']) ?></h3>
                            </div>
                            
                            <?php if ($question['question_type'] === 'multiple_choice' && $options): ?>
                                <div class="space-y-2">
                                    <?php foreach ($options as $key => $option): ?>
                                        <label class="flex items-center p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                                            <input type="radio" name="question_<?= $question['id'] ?>" value="<?= $key ?>" 
                                                   class="mr-3 h-5 w-5 text-blue-600" required>
                                            <span class="text-gray-700"><?= htmlspecialchars($option) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <textarea name="question_<?= $question['id'] ?>" 
                                          rows="3" 
                                          class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Type your answer here..."
                                          required></textarea>
                            <?php endif; ?>
                            
                            <input type="hidden" name="question_ids[]" value="<?= $question['id'] ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Submit Button -->
                <div class="mt-8 text-center">
                    <button type="submit" 
                            class="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors text-lg font-medium">
                        <i data-lucide="send" class="w-5 h-5 inline mr-2"></i>
                        Submit Quiz
                    </button>
                    <p class="text-gray-500 text-sm mt-3">You cannot change your answers after submission.</p>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            lucide.createIcons();
            
            // Timer functionality (if time_limit is set)
            const timeLimit = <?= $quiz['time_limit'] ?? 0 ?>;
            if (timeLimit > 0) {
                let timeLeft = timeLimit * 60; // Convert minutes to seconds
                const timerDisplay = document.createElement('div');
                timerDisplay.className = 'fixed top-4 right-4 bg-red-600 text-white px-4 py-2 rounded-lg shadow-lg font-bold';
                document.body.appendChild(timerDisplay);
                
                const updateTimer = () => {
                    const minutes = Math.floor(timeLeft / 60);
                    const seconds = timeLeft % 60;
                    timerDisplay.textContent = `Time Left: ${minutes}:${seconds.toString().padStart(2, '0')}`;
                    
                    if (timeLeft <= 0) {
                        clearInterval(timerInterval);
                        alert('Time is up! Submitting quiz...');
                        document.getElementById('quizForm').submit();
                    }
                    timeLeft--;
                };
                
                updateTimer();
                const timerInterval = setInterval(updateTimer, 1000);
            }
            
            // Add form validation
            document.getElementById('quizForm').addEventListener('submit', function(e) {
                const unanswered = [];
                const questions = document.querySelectorAll('[name^="question_"]');
                
                questions.forEach(q => {
                    if (q.type === 'radio') {
                        const name = q.name;
                        const checked = document.querySelectorAll(`input[name="${name}"]:checked`).length;
                        if (checked === 0 && !unanswered.includes(name)) {
                            unanswered.push(name.replace('question_', ''));
                        }
                    } else if (q.type === 'textarea' && !q.value.trim()) {
                        unanswered.push(q.name.replace('question_', ''));
                    }
                });
                
                if (unanswered.length > 0) {
                    e.preventDefault();
                    if (confirm(`You have ${unanswered.length} unanswered question(s). Are you sure you want to submit?`)) {
                        return true;
                    }
                }
            });
        });
    </script>
</body>
</html>