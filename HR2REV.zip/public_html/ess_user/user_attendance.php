<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Include session check and database connection
include('session_check.php');
include('dblogin.php');

// Get logged-in user ID from session
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    die("User not logged in.");
}

// Fetch attendance records for this user
$attendance_stmt = $conn->prepare("
    SELECT `Date`, `Time`, `Type` 
    FROM user_attendance 
    WHERE user_id = ? 
    ORDER BY `Date` DESC, `Time` DESC
");
$attendance_stmt->bind_param("i", $user_id);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();
$attendance_data = $attendance_result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS User - Attendance</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex h-screen bg-slate-50 font-sans">

  <!-- ✅ Include Sidebar -->
  <?php include('user_sidebar.php'); ?>

  <!-- ✅ Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6 flex-1">

      <!-- Header -->
      <div class="flex items-center justify-between border-b pb-4">
        <h1 class="text-2xl font-semibold text-gray-800">Claims & Reimbursements</h1>
        <button id="open-modal" class="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          <i data-lucide="plus" class="w-4 h-4"></i> Log Attendance
        </button>
      </div>

      <!-- Breadcrumb -->
      <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
        <a href="userinfo2.php" class="hover:text-blue-600 transition-colors">Home</a>
        <span>Attendance</span>
      </div>

      <!-- Attendance Table -->
      <div class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">My Attendance</h2>
        <table class="w-full border-collapse text-sm">
          <thead>
            <tr class="bg-gray-100 text-left">
              <th class="p-2 border">Date</th>
              <th class="p-2 border">Time</th>
              <th class="p-2 border">Type</th>
            </tr>
          </thead>
          <tbody id="attendance-tbody">
            <?php if ($attendance_data): ?>
              <?php foreach ($attendance_data as $att): ?>
                <?php
                  $typeClass = "";
                  if ($att['Type'] === "check-in") $typeClass = "text-green-600 font-medium";
                  elseif ($att['Type'] === "check-out") $typeClass = "text-blue-600 font-medium";
                  elseif ($att['Type'] === "break") $typeClass = "text-yellow-600 font-medium";
                ?>
                <tr class="hover:bg-gray-50">
                  <td class="p-2 border"><?= htmlspecialchars($att['Date']) ?></td>
                  <td class="p-2 border"><?= htmlspecialchars($att['Time']) ?></td>
                  <td class="p-2 border <?= $typeClass ?>"><?= htmlspecialchars(ucfirst($att['Type'])) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="3" class="p-2 text-center border text-gray-500">No attendance records found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Back Button -->
      <div>
        <a href="userinfo2.php" class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
          ← Back
        </a>
      </div>

      <footer class="mt-6 text-xs text-slate-400 text-center">
        Attendance • ESS Module
      </footer>
    </main>
  </div>

  <!-- ✅ Log Attendance Modal -->
  <div id="modal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-xl w-[400px] p-6">
      <h2 class="text-xl font-semibold mb-4">Log Attendance</h2>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-gray-600">Date</label>
          <input id="att-date" type="date" class="w-full border border-gray-300 rounded px-3 py-2">
        </div>
        <div>
          <label class="text-sm text-gray-600">Time</label>
          <input id="att-time" type="time" class="w-full border border-gray-300 rounded px-3 py-2">
        </div>
        <div>
          <label class="text-sm text-gray-600">Type</label>
          <select id="att-type" class="w-full border border-gray-300 rounded px-3 py-2">
            <option value="check-in">Check-in</option>
            <option value="check-out">Check-out</option>
            <option value="break">Break</option>
          </select>
        </div>
        <div class="flex justify-end gap-2">
          <button id="close-modal" class="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400">Cancel</button>
          <button id="submit-attendance" class="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">Submit</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ✅ JS Script -->
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("modal");
    const openModal = document.getElementById("open-modal");
    const closeModal = document.getElementById("close-modal");
    const submitBtn = document.getElementById("submit-attendance");
    const tbody = document.getElementById("attendance-tbody");

    openModal.addEventListener("click", () => modal.classList.remove("hidden"));
    closeModal.addEventListener("click", () => modal.classList.add("hidden"));

    submitBtn.addEventListener("click", () => {
      const date = document.getElementById("att-date").value;
      const time = document.getElementById("att-time").value;
      const type = document.getElementById("att-type").value;

      if (!date || !time) return alert("Date and Time are required.");

      const tr = document.createElement("tr");
      let typeClass = "";
      if (type === "check-in") typeClass = "text-green-600 font-medium";
      else if (type === "check-out") typeClass = "text-blue-600 font-medium";
      else if (type === "break") typeClass = "text-yellow-600 font-medium";

      tr.innerHTML = `
        <td class="p-2 border">${date}</td>
        <td class="p-2 border">${time}</td>
        <td class="p-2 border ${typeClass}">${type}</td>
      `;
      tbody.prepend(tr);
      modal.classList.add("hidden");
    });

    lucide.createIcons();
  });
  </script>

</body>
</html>
