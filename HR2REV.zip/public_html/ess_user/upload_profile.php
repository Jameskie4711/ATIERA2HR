<?php
include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    echo json_encode(["success" => false, "message" => "Not logged in."]);
    exit;
}

if (!isset($_FILES['profile_pic'])) {
    echo json_encode(["success" => false, "message" => "No file uploaded."]);
    exit;
}

$file = $_FILES['profile_pic'];
$allowed = ['jpg', 'jpeg', 'png', 'gif'];
$upload_dir = __DIR__ . '/uploads/';

if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

if ($file['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        echo json_encode(["success" => false, "message" => "Invalid file type."]);
        exit;
    }

    $new_name = 'profile_' . $user_id . '_' . time() . '.' . $ext;
    $path = $upload_dir . $new_name;
    $web_path = 'uploads/' . $new_name;

    if (move_uploaded_file($file['tmp_name'], $path)) {
        $stmt = $conn->prepare("UPDATE users SET Profile_Picture = ? WHERE id = ?");
        $stmt->bind_param("si", $web_path, $user_id);
        $stmt->execute();
        echo json_encode(["success" => true, "url" => $web_path]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to move file."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Upload error."]);
}
