<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) die("User not logged in.");

// Create a test attempt
$quiz_id = 1; // Use the first quiz
$course_id = 'CS101'; // Example course ID
$started_at = date('Y-m-d H:i:s');

$stmt = $conn->prepare("INSERT INTO quiz_attempts (user_id, quiz_id, started_at) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $user_id, $quiz_id, $started_at);
$stmt->execute();
$attempt_id = $conn->insert_id;

echo "<h1>Test Quiz Submission</h1>";
echo "<p>Created test attempt with ID: $attempt_id</p>";
echo "<p>User ID: $user_id</p>";
echo "<p>Quiz ID: $quiz_id</p>";

// Create a simple form to submit answers
?>
<form action="submit_quiz.php" method="POST">
    <input type="hidden" name="attempt_id" value="<?= $attempt_id ?>">
    <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">
    <input type="hidden" name="course_id" value="<?= $course_id ?>">
    
    <h3>Sample Questions:</h3>
    
    <div>
        <p>1. What does PHP stand for?</p>
        <input type="radio" name="question_1" value="A"> A. Hypertext Preprocessor<br>
        <input type="radio" name="question_1" value="B"> B. Personal Home Page<br>
        <input type="radio" name="question_1" value="C"> C. Programmable Hypertext Processor<br>
        <input type="radio" name="question_1" value="D"> D. Private Home Page<br>
    </div>
    
    <div>
        <p>2. PHP is a server-side scripting language.</p>
        <input type="radio" name="question_2" value="A"> A. true<br>
        <input type="radio" name="question_2" value="B"> B. false<br>
    </div>
    
    <div>
        <p>3. Which symbol is used to declare a variable in PHP?</p>
        <input type="radio" name="question_3" value="A"> A. &<br>
        <input type="radio" name="question_3" value="B"> B. $<br>
        <input type="radio" name="question_3" value="C"> C. #<br>
        <input type="radio" name="question_3" value="D"> D. @<br>
    </div>
    
    <br>
    <input type="submit" value="Submit Test Quiz" style="background: green; color: white; padding: 10px 20px;">
</form>

<p>After submitting, you should be redirected to: quiz_results.php?attempt_id=<?= $attempt_id ?>&quiz_id=<?= $quiz_id ?>&course_id=<?= $course_id ?></p>