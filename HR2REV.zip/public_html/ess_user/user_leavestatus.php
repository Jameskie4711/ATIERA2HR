<?php
include('session_check.php');
include('dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    die('User not logged in');
}

$stmt = $conn->prepare("
    SELECT id,
           leave_type,
           start_date,
           end_date,
           reason,
           status,
           created_at
    FROM leave_requests
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$leaves = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Leave Request Status</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="flex min-h-screen bg-gray-100">

<!-- Sidebar -->
<?php include('user_sidebar.php'); ?>

<main class="flex-1 flex flex-col">

<!-- Header -->
<header class="bg-white border-b shadow-sm">
  <div class="px-6 py-4">
    <h1 class="text-2xl font-bold text-gray-800">Leave Request Status</h1>
    <p class="text-sm text-gray-500">
      Track the status of your submitted leave requests
    </p>
  </div>
</header>

<!-- Content -->
<section class="flex-1 p-6">

<?php if (empty($leaves)): ?>
  <!-- EMPTY STATE -->
  <div class="max-w-3xl mx-auto bg-white rounded-xl p-10 text-center shadow border">
    <i data-lucide="calendar-x" class="w-12 h-12 mx-auto text-gray-400"></i>
    <h2 class="mt-4 text-lg font-semibold text-gray-700">
      No Leave Requests Found
    </h2>
    <p class="text-sm text-gray-500 mt-1">
      You haven’t submitted any leave requests yet.
    </p>
    <a href="user_reqleave.php"
       class="inline-flex mt-5 px-6 py-2 rounded-full bg-cyan-600 text-white hover:bg-cyan-700 transition">
      Request Leave
    </a>
  </div>

<?php else: ?>

<div class="max-w-4xl mx-auto space-y-4">

<?php foreach ($leaves as $leave): ?>
<?php
$status = strtolower($leave['status']);
$badge = match ($status) {
    'approved' => 'bg-green-100 text-green-700',
    'rejected' => 'bg-red-100 text-red-700',
    default    => 'bg-yellow-100 text-yellow-700'
};
$icon = match ($status) {
    'approved' => 'check-circle',
    'rejected' => 'x-circle',
    default    => 'clock'
};
?>

<div class="bg-white rounded-xl p-6 shadow border hover:shadow-lg transition relative">

  <!-- Status Badge -->
  <span class="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-semibold <?= $badge ?>">
    <?= ucfirst($leave['status']) ?>
  </span>

  <div class="flex items-start gap-4">
    <div class="p-3 rounded-full bg-cyan-100">
      <i data-lucide="<?= $icon ?>" class="w-6 h-6 text-cyan-600"></i>
    </div>

    <div class="flex-1">
      <h3 class="text-lg font-bold text-gray-800">
        <?= htmlspecialchars($leave['leave_type']) ?>
      </h3>

      <p class="text-sm text-gray-600 mt-1">
        <?= date('M d, Y', strtotime($leave['start_date'])) ?>
        –
        <?= date('M d, Y', strtotime($leave['end_date'])) ?>
      </p>

      <p class="text-sm text-gray-500 mt-2">
        Reason: <?= htmlspecialchars($leave['reason']) ?>
      </p>

      <div class="flex gap-6 text-xs text-gray-500 mt-3">
        <span class="flex items-center gap-1">
          <i data-lucide="calendar" class="w-4 h-4"></i>
          Requested: <?= date('M d, Y', strtotime($leave['created_at'])) ?>
        </span>
        <span class="flex items-center gap-1">
          <i data-lucide="hash" class="w-4 h-4"></i>
          Request ID: <?= $leave['id'] ?>
        </span>
      </div>
    </div>
  </div>

</div>

<?php endforeach; ?>

</div>
<?php endif; ?>

</section>

<footer class="text-center text-xs text-gray-400 py-4">
  ESS User Module • © <?= date('Y') ?>
</footer>

</main>

<script>
lucide.createIcons();
</script>

</body>
</html>
