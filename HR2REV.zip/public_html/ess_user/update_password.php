<?php
session_start();
include('dblogin.php');
header('Content-Type: application/json');

$user_id = $_SESSION['user_id'];
$current = $_POST['current_password'] ?? '';
$new = $_POST['new_password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

if (!$current || !$new || !$confirm) {
  echo json_encode(["success" => false, "message" => "All fields are required."]);
  exit;
}
if ($new !== $confirm) {
  echo json_encode(["success" => false, "message" => "New passwords do not match."]);
  exit;
}

$stmt = $conn->prepare("SELECT Password FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user || !password_verify($current, $user['Password'])) {
  echo json_encode(["success" => false, "message" => "Current password is incorrect."]);
  exit;
}

$newHash = password_hash($new, PASSWORD_DEFAULT);
$update = $conn->prepare("UPDATE users SET Password = ? WHERE id = ?");
$update->bind_param("si", $newHash, $user_id);
$update->execute();

echo json_encode(["success" => true, "message" => "Password updated successfully!"]);
