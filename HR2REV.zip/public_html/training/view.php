<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include('../db.php');

$training_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Training Details — View</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .fade-in { animation: fadeIn 0.3s ease-out; }
    .status-badge {
      display: inline-flex;
      align-items: center;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.875rem;
      font-weight: 500;
    }
    .status-pending { background-color: #fef3c7; color: #92400e; }
    .status-assigned { background-color: #dbeafe; color: #1e40af; }
    .status-completed { background-color: #d1fae5; color: #065f46; }
    .card-hover {
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .card-hover:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    .session-card {
      border-left: 4px solid #4f46e5;
    }
    .progress-bar {
      height: 6px;
      border-radius: 3px;
      overflow: hidden;
      background-color: #e5e7eb;
    }
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, #4f46e5, #7c3aed);
      transition: width 0.5s ease;
    }
  </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-blue-50 font-sans min-h-screen flex">

  <!-- Sidebar -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content -->
  <main class="flex-1 p-6 lg:p-8">
    <div class="max-w-6xl mx-auto">
      <!-- Header -->
      <header class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
        <div>
          <nav class="flex items-center text-sm text-gray-600 mb-2">
            <a href="trainings.php" class="hover:text-indigo-600 transition-colors">
              <i class="fas fa-arrow-left mr-2"></i>Back to Trainings
            </a>
            <span class="mx-2">/</span>
            <span class="text-gray-800 font-medium">Training Details</span>
          </nav>
          <h1 class="text-3xl font-bold text-gray-900">Training Details</h1>
          <p class="text-gray-600 mt-1">View and manage training information</p>
        </div>
        <?php include __DIR__ . '/../profile.php'; ?>
      </header>

      <!-- Main Content Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Left Column: Training Info -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Training Summary Card -->
          <div class="bg-white rounded-2xl shadow-lg p-6 card-hover fade-in">
            <div class="flex flex-col md:flex-row md:items-start justify-between mb-6">
              <div>
                <div class="flex items-center gap-3 mb-2">
                  <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
                    <i class="fas fa-user-graduate text-xl text-indigo-600"></i>
                  </div>
                  <div>
                    <h2 id="employeeName" class="text-2xl font-bold text-gray-900">Loading...</h2>
                    <p class="text-gray-600" id="employeeDepartment">Loading department...</p>
                  </div>
                </div>
                <div id="trainingStatusBadge" class="inline-block mt-2">
                  <span class="status-badge status-pending">
                    <i class="fas fa-clock mr-1.5"></i>
                    <span id="trainingStatus">Loading...</span>
                  </span>
                </div>
              </div>
              
              <div class="mt-4 md:mt-0 md:text-right">
                <p class="text-sm text-gray-500">Training ID</p>
                <p class="text-lg font-mono font-semibold text-gray-800">#<?php echo str_pad($training_id, 6, '0', STR_PAD_LEFT); ?></p>
              </div>
            </div>

            <!-- Info Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div class="bg-gray-50 p-4 rounded-xl">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <i class="fas fa-calendar-day text-blue-600"></i>
                  </div>
                  <div>
                    <p class="text-sm text-gray-500">Assigned Date</p>
                    <p id="assignedDate" class="font-medium text-gray-900">-</p>
                  </div>
                </div>
              </div>
              
              <div class="bg-gray-50 p-4 rounded-xl">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <i class="fas fa-chalkboard-teacher text-purple-600"></i>
                  </div>
                  <div>
                    <p class="text-sm text-gray-500">Trainer</p>
                    <p id="trainerName" class="font-medium text-gray-900">-</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Progress Bar -->
            <div class="mt-8">
              <div class="flex justify-between items-center mb-2">
                <p class="text-sm font-medium text-gray-700">Training Progress</p>
                <p id="progressText" class="text-sm font-medium text-indigo-600">0%</p>
              </div>
              <div class="progress-bar">
                <div id="progressFill" class="progress-fill" style="width: 0%"></div>
              </div>
            </div>
          </div>

          <!-- Training Schedule Card -->
          <div class="bg-white rounded-2xl shadow-lg p-6 card-hover fade-in">
            <div class="flex items-center justify-between mb-6">
              <h3 class="text-xl font-bold text-gray-900 flex items-center gap-2">
                <i class="fas fa-calendar-alt text-indigo-600"></i>
                Training Schedule
              </h3>
              <span class="text-sm text-gray-500" id="scheduleCount">5 sessions</span>
            </div>
            
            <div class="overflow-hidden rounded-xl border border-gray-200">
              <table class="w-full">
                <thead>
                  <tr class="bg-gradient-to-r from-gray-50 to-indigo-50 text-left">
                    <th class="py-4 px-6 font-semibold text-gray-700">Session</th>
                    <th class="py-4 px-6 font-semibold text-gray-700">Date & Time</th>
                    <th class="py-4 px-6 font-semibold text-gray-700 text-center">Duration</th>
                  </tr>
                </thead>
                <tbody id="scheduleList" class="divide-y divide-gray-100">
                  <tr>
                    <td colspan="3" class="py-8 px-6 text-center text-gray-500">
                      <i class="fas fa-spinner fa-spin mr-2"></i>Loading schedule...
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div class="mt-6 text-sm text-gray-500 flex items-center gap-2">
              <i class="fas fa-info-circle text-indigo-500"></i>
              <p>Sessions are scheduled for 2 hours each, Monday to Friday</p>
            </div>
          </div>
        </div>

        <!-- Right Column: Actions & Details -->
        <div class="space-y-6">
          <!-- Actions Card -->
          <div class="bg-white rounded-2xl shadow-lg p-6 card-hover fade-in">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
              <i class="fas fa-bolt text-yellow-500"></i>
              Quick Actions
            </h3>
            
            <div class="space-y-4">
              <button onclick="window.history.back()" 
                      class="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl font-medium transition-colors">
                <i class="fas fa-arrow-left"></i>
                Go Back
              </button>
              
              <button id="assignTrainerBtn" 
                      class="w-full hidden flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-xl font-medium transition-all transform hover:-translate-y-0.5">
                <i class="fas fa-robot"></i>
                Auto-Assign Trainer (AI)
              </button>
              
              <button id="markCompletedBtn" 
                      class="w-full hidden flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-xl font-medium transition-all transform hover:-translate-y-0.5">
                <i class="fas fa-check-circle"></i>
                Mark as Completed
              </button>
              
              <button onclick="downloadTrainingReport()" 
                      class="w-full flex items-center justify-center gap-2 py-3 px-4 border-2 border-indigo-200 hover:border-indigo-300 text-indigo-600 hover:text-indigo-700 bg-white rounded-xl font-medium transition-colors">
                <i class="fas fa-file-export"></i>
                Export Report
              </button>
            </div>
          </div>

          <!-- Additional Info Card -->
          <div class="bg-white rounded-2xl shadow-lg p-6 card-hover fade-in">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
              <i class="fas fa-info-circle text-blue-500"></i>
              Additional Information
            </h3>
            
            <div class="space-y-4">
              <div class="flex items-center justify-between py-2">
                <span class="text-gray-600">Created On</span>
                <span id="createdDate" class="font-medium text-gray-900">-</span>
              </div>
              <div class="flex items-center justify-between py-2">
                <span class="text-gray-600">Last Updated</span>
                <span id="updatedDate" class="font-medium text-gray-900">-</span>
              </div>
              <div class="flex items-center justify-between py-2">
                <span class="text-gray-600">Training Type</span>
                <span id="trainingType" class="font-medium text-gray-900">Onboarding</span>
              </div>
              <div class="flex items-center justify-between py-2">
                <span class="text-gray-600">Estimated Completion</span>
                <span id="estimatedCompletion" class="font-medium text-gray-900">-</span>
              </div>
            </div>
            
            <div class="mt-6 pt-6 border-t border-gray-100">
              <h4 class="font-medium text-gray-700 mb-3">Need Help?</h4>
              <button onclick="openChatbot()" class="w-full flex items-center justify-center gap-2 py-2 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white rounded-lg font-medium transition-colors">
                <i class="fas fa-comments"></i>
                Open Support Chat
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

  <!-- CONFIRMATION MODAL -->
  <div id="confirmModal" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black/50 backdrop-blur-sm transition-opacity">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 transform transition-all duration-300 scale-95">
      <div class="p-6 text-center">
        <div class="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
          <i class="fas fa-question text-2xl text-indigo-600"></i>
        </div>
        <h2 class="text-xl font-bold text-gray-900 mb-2">Confirm Action</h2>
        <p id="confirmModalMessage" class="text-gray-600 mb-6"></p>

        <div class="flex gap-3">
          <button onclick="closeConfirmModal()" 
                  class="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl font-medium transition-colors">
            Cancel
          </button>
          <button id="confirmBtn" 
                  class="flex-1 px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-medium transition-colors shadow-md hover:shadow-lg">
            Confirm
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- LOADING OVERLAY -->
  <div id="loadingOverlay" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black/40 backdrop-blur-sm transition-opacity">
    <div class="flex flex-col items-center gap-4 bg-white px-8 py-8 rounded-2xl shadow-2xl transform transition-all duration-300">
      <div class="relative">
        <div class="w-16 h-16 rounded-full border-4 border-gray-200"></div>
        <div class="w-16 h-16 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin absolute top-0 left-0"></div>
      </div>
      <div class="text-center">
        <p class="font-bold text-gray-800 text-lg">Processing</p>
        <p class="text-gray-600 text-sm">Please wait a moment...</p>
      </div>
    </div>
  </div>

<script>
let currentTrainingId = <?php echo $training_id; ?>;
let currentName = '';
let currentDepartment = '';
let currentRole = '';
let currentStatus = '';
let pendingAction = null;

async function loadTrainingDetails() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id') || currentTrainingId;
  
  if (!id || id === '0') {
    showError('No training ID provided. Please go back and select a training.');
    return;
  }

  currentTrainingId = id;
  showLoading();

  try {
    const response = await fetch('fetch_training_details.php?id=' + encodeURIComponent(id));
    const data = await response.json();
    
    if (data.status === 'success') {
      const training = data.data;
      
      // Store data for later use
      currentName = training.employee_name;
      currentDepartment = training.department;
      currentRole = training.role;
      currentStatus = training.status;
      
      // Display the data
      document.getElementById('employeeName').textContent = training.employee_name || 'Not specified';
      document.getElementById('employeeDepartment').textContent = training.department || 'Not specified';
      document.getElementById('assignedDate').textContent = training.assigned_date ? formatDate(training.assigned_date) : 'Not specified';
      document.getElementById('createdDate').textContent = training.created_at ? formatDate(training.created_at) : '-';
      document.getElementById('updatedDate').textContent = training.updated_at ? formatDate(training.updated_at) : '-';
      
      // Update status badge
      updateStatusBadge(training.status || 'Pending');
      
      // Update progress based on status
      updateProgress(training.status);
      
      // Display trainer if assigned
      if (training.trainer_name && training.trainer_name !== 'Not assigned') {
        document.getElementById('trainerName').textContent = training.trainer_name;
      } else {
        document.getElementById('trainerName').textContent = 'Not assigned yet';
        // Show "Auto-Assign Trainer" button
        const assignBtn = document.getElementById('assignTrainerBtn');
        assignBtn.classList.remove('hidden');
        assignBtn.onclick = () => openConfirmModal(
          'Do you want to automatically assign a trainer using AI logic? This will select the best available trainer based on skills and availability.',
          autoAssignTrainer
        );
      }

      // Generate schedule based on assigned date
      generateSchedule(training.assigned_date);

      // Handle mark as completed button
      const markBtn = document.getElementById('markCompletedBtn');
      markBtn.classList.remove('hidden');
      
      if (training.status && training.status.toLowerCase() === 'completed') {
        markBtn.disabled = true;
        markBtn.classList.add('opacity-50', 'cursor-not-allowed');
        markBtn.innerHTML = '<i class="fas fa-check-circle"></i> Already Completed';
        markBtn.classList.remove('hover:from-green-600', 'hover:to-emerald-700', 'hover:-translate-y-0.5');
      } else {
        markBtn.disabled = false;
        markBtn.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Completed';
        markBtn.onclick = () => openConfirmModal(
          'Are you sure you want to mark this training as completed? This action cannot be undone.',
          markTrainingCompleted
        );
      }
      
      // Set estimated completion date
      if (training.assigned_date) {
        const completionDate = new Date(training.assigned_date);
        completionDate.setDate(completionDate.getDate() + 7);
        document.getElementById('estimatedCompletion').textContent = formatDate(completionDate);
      }
      
    } else {
      showError(data.message || 'Failed to load training details');
    }
  } catch (error) {
    console.error('Error loading training details:', error);
    showError('Network error. Please check your connection and try again.');
  } finally {
    hideLoading();
  }
}

function updateStatusBadge(status) {
  const badge = document.getElementById('trainingStatusBadge');
  const statusText = document.getElementById('trainingStatus');
  statusText.textContent = status.charAt(0).toUpperCase() + status.slice(1);
  
  badge.innerHTML = '';
  let badgeClass = 'status-pending';
  let icon = 'fa-clock';
  
  if (status.toLowerCase() === 'assigned') {
    badgeClass = 'status-assigned';
    icon = 'fa-user-check';
  } else if (status.toLowerCase() === 'completed') {
    badgeClass = 'status-completed';
    icon = 'fa-check-circle';
  } else if (status.toLowerCase() === 'in progress') {
    badgeClass = 'status-assigned';
    icon = 'fa-spinner fa-pulse';
  }
  
  badge.innerHTML = `
    <span class="status-badge ${badgeClass}">
      <i class="fas ${icon} mr-1.5"></i>
      <span id="trainingStatus">${status.charAt(0).toUpperCase() + status.slice(1)}</span>
    </span>
  `;
}

function updateProgress(status) {
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  
  let progress = 0;
  if (status.toLowerCase() === 'pending') progress = 10;
  else if (status.toLowerCase() === 'assigned') progress = 40;
  else if (status.toLowerCase() === 'in progress') progress = 75;
  else if (status.toLowerCase() === 'completed') progress = 100;
  
  progressFill.style.width = `${progress}%`;
  progressText.textContent = `${progress}%`;
}

function generateSchedule(startDate) {
  const list = document.getElementById('scheduleList');
  
  if (!startDate) {
    list.innerHTML = `
      <tr>
        <td colspan="3" class="py-8 px-6 text-center text-gray-500">
          <i class="fas fa-calendar-times text-2xl mb-2 block"></i>
          No schedule available
        </td>
      </tr>`;
    return;
  }
  
  list.innerHTML = '';
  
  const start = new Date(startDate);
  const today = new Date();
  
  for (let i = 0; i < 5; i++) {
    const day = new Date(start);
    day.setDate(start.getDate() + i);
    
    const isToday = day.toDateString() === today.toDateString();
    const isPast = day < today && !isToday;
    
    const formattedDate = day.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
    
    const row = document.createElement('tr');
    row.className = isToday ? 'bg-blue-50' : isPast ? 'bg-gray-50' : '';
    row.innerHTML = 
      `<td class="py-4 px-6">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-lg ${isToday ? 'bg-blue-500' : isPast ? 'bg-gray-400' : 'bg-indigo-100'} flex items-center justify-center">
            <i class="fas fa-book ${isToday ? 'text-white' : isPast ? 'text-white' : 'text-indigo-600'}"></i>
          </div>
          <div>
            <p class="font-medium text-gray-900">Day ${i + 1}</p>
            <p class="text-sm ${isToday ? 'text-blue-600' : isPast ? 'text-gray-500' : 'text-gray-600'}">
              ${formattedDate}
            </p>
          </div>
        </div>
      </td>
      <td class="py-4 px-6">
        <p class="font-medium text-gray-900">8:00 AM - 10:00 AM</p>
        <p class="text-sm text-gray-600">Morning Session</p>
      </td>
      <td class="py-4 px-6 text-center">
        <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full ${isToday ? 'bg-blue-100 text-blue-800' : isPast ? 'bg-gray-100 text-gray-800' : 'bg-indigo-100 text-indigo-800'}">
          <i class="fas fa-clock"></i>
          <span class="font-medium">2h</span>
        </span>
      </td>`;
    list.appendChild(row);
  }
}

// AI-style automatic trainer assignment
async function autoAssignTrainer() {
  closeConfirmModal();
  showLoading();
  
  try {
    const response = await fetch('assign_training.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: `id=${currentTrainingId}`
    });
    
    const data = await response.json();
    
    if (data.status === 'success') {
      const assignedData = data.data;
      
      // Update UI with assigned trainer information
      document.getElementById('trainerName').textContent = assignedData.trainer_name;
      document.getElementById('assignedDate').textContent = formatDate(assignedData.assigned_date);
      document.getElementById('trainingStatus').textContent = 'Assigned';
      
      // Update status badge and progress
      updateStatusBadge('Assigned');
      updateProgress('Assigned');
      
      // Hide the assign button
      document.getElementById('assignTrainerBtn').classList.add('hidden');
      
      // Show success message
      showToast(`Trainer assigned successfully! Assigned to: ${assignedData.trainer_name}`, 'success');
      
      // Update current status
      currentStatus = 'Assigned';
      
      // Generate new schedule based on new assignment date
      generateSchedule(assignedData.assigned_date);
      
    } else {
      showToast('Failed to assign trainer: ' + data.message, 'error');
    }
  } catch (error) {
    console.error('Error assigning trainer:', error);
    showToast('Network error. Please try again.', 'error');
  } finally {
    hideLoading();
  }
}

async function markTrainingCompleted() {
  closeConfirmModal();
  showLoading();

  try {
    const response = await fetch('mark_completed.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: currentTrainingId,
        name: currentName,
        department: currentDepartment
      })
    });

    const data = await response.json();

    if (data.status === 'success') {
      // Update UI
      updateStatusBadge('Completed');
      updateProgress('Completed');
      
      const btn = document.getElementById('markCompletedBtn');
      btn.disabled = true;
      btn.classList.add('opacity-50', 'cursor-not-allowed');
      btn.innerHTML = '<i class="fas fa-check-circle"></i> Already Completed';
      btn.classList.remove('hover:from-green-600', 'hover:to-emerald-700', 'hover:-translate-y-0.5');
      
      // Show success message
      showToast('Training marked as completed successfully!', 'success');
    } else {
      showToast(data.message || 'Failed to complete training', 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showToast('Network error. Please try again.', 'error');
  } finally {
    hideLoading();
  }
}

function formatDate(dateString) {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

function showError(message) {
  const container = document.querySelector('main');
  container.innerHTML = 
    `<div class="max-w-2xl mx-auto text-center py-16">
      <div class="w-24 h-24 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
        <i class="fas fa-exclamation-triangle text-4xl text-red-500"></i>
      </div>
      <h3 class="text-2xl font-bold text-gray-900 mb-3">Error Loading Data</h3>
      <p class="text-gray-600 mb-8 max-w-md mx-auto">${message}</p>
      <div class="flex flex-col sm:flex-row gap-3 justify-center">
        <button onclick="window.history.back()" class="px-6 py-3 bg-gray-800 hover:bg-gray-900 text-white rounded-xl font-medium transition-colors">
          <i class="fas fa-arrow-left mr-2"></i>Go Back
        </button>
        <button onclick="loadTrainingDetails()" class="px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-xl font-medium transition-colors">
          <i class="fas fa-redo mr-2"></i>Try Again
        </button>
      </div>
    </div>`;
}

function openConfirmModal(message, actionCallback) {
  document.getElementById('confirmModalMessage').textContent = message;
  pendingAction = actionCallback;
  const modal = document.getElementById('confirmModal');
  modal.classList.remove('hidden');
  setTimeout(() => {
    modal.querySelector('div').classList.remove('scale-95');
  }, 10);
}

function closeConfirmModal() {
  const modal = document.getElementById('confirmModal');
  modal.querySelector('div').classList.add('scale-95');
  setTimeout(() => {
    modal.classList.add('hidden');
    pendingAction = null;
  }, 200);
}

function showLoading() {
  const overlay = document.getElementById('loadingOverlay');
  overlay.classList.remove('hidden');
  setTimeout(() => {
    overlay.classList.remove('opacity-0');
  }, 10);
}

function hideLoading() {
  const overlay = document.getElementById('loadingOverlay');
  overlay.classList.add('opacity-0');
  setTimeout(() => {
    overlay.classList.add('hidden');
  }, 300);
}

function showToast(message, type = 'info') {
  // Remove existing toasts
  const existingToast = document.querySelector('.toast-message');
  if (existingToast) existingToast.remove();
  
  const toast = document.createElement('div');
  toast.className = `toast-message fixed top-6 right-6 z-50 px-6 py-4 rounded-xl shadow-2xl font-medium transform transition-all duration-300 translate-x-full`;
  toast.style.background = type === 'success' 
    ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
    : type === 'error'
    ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
    : 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)';
  
  toast.innerHTML = `
    <div class="flex items-center gap-3 text-white">
      <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'} text-xl"></i>
      <span>${message}</span>
    </div>
  `;
  
  document.body.appendChild(toast);
  
  // Animate in
  setTimeout(() => {
    toast.classList.remove('translate-x-full');
  }, 10);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    toast.classList.add('translate-x-full');
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

function downloadTrainingReport() {
  showToast('Export feature coming soon!', 'info');
}

function openChatbot() {
  // Trigger chatbot opening
  const chatbotBtn = document.querySelector('[onclick*="chatbot"]') || 
                     document.querySelector('[href*="chatbot"]');
  if (chatbotBtn) chatbotBtn.click();
  else showToast('Chatbot is not available at the moment', 'error');
}

/* ---------- EVENT LISTENERS ---------- */
document.getElementById('confirmBtn').addEventListener('click', () => {
  if (pendingAction) {
    pendingAction();
  }
});

// Load data when page loads
document.addEventListener('DOMContentLoaded', loadTrainingDetails);

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeConfirmModal();
  if (e.key === 'r' && e.ctrlKey) {
    e.preventDefault();
    loadTrainingDetails();
  }
});
</script>

</body>
</html>