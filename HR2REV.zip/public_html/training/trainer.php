<?php include('../session_check.php'); ?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');

// --- Fetch all trainers from the database with ACTUAL assigned trainee count ---
$query = $conn->query("
    SELECT 
        t.id,
        t.employee_name, 
        t.max_load, 
        t.rating,
        t.experience_years,
        t.is_active,
        -- Count actual assigned trainees from training_assigned table
        COALESCE(ta.assigned_count, 0) as current_load
    FROM trainers t 
    LEFT JOIN (
        SELECT trainer_name, COUNT(*) as assigned_count 
        FROM training_assigned 
        WHERE status = 'Assigned'
        GROUP BY trainer_name
    ) ta ON ta.trainer_name = t.employee_name
    WHERE t.is_active = 1 
    ORDER BY t.employee_name ASC
");

$trainers = [];

while($row = $query->fetch_assoc()) {
    // Get assigned trainees for this trainer
    $trainer_name = $row['employee_name'];
    $assigned_trainees = [];
    
    $trainee_query = $conn->query("
        SELECT 
            ta.employee_name,
            ta.department,
            ta.role,
            ta.assigned_date
        FROM training_assigned ta
        WHERE ta.trainer_name = '" . $conn->real_escape_string($trainer_name) . "'
        AND ta.status = 'Assigned'
        ORDER BY ta.assigned_date DESC
    ");
    
    $actual_trainee_count = 0;
    while($trainee = $trainee_query->fetch_assoc()) {
        $assigned_trainees[] = [
            "name" => $trainee['employee_name'],
            "department" => $trainee['department'],
            "role" => $trainee['role'],
            "assigned_date" => $trainee['assigned_date']
        ];
        $actual_trainee_count++;
    }
    
    // Update trainer's current_load to match actual count
    // This ensures data consistency
    if ($row['current_load'] != $actual_trainee_count) {
        $update_sql = "UPDATE trainers SET current_load = $actual_trainee_count 
                      WHERE employee_name = '" . $conn->real_escape_string($trainer_name) . "'";
        $conn->query($update_sql);
        $row['current_load'] = $actual_trainee_count;
    }
    
    $trainers[] = [
        "id" => $row['id'],
        "name" => $row['employee_name'],
        "trainees" => intval($row['current_load']),
        "max_trainees" => intval($row['max_load']),
        "rating" => floatval($row['rating']),
        "experience" => intval($row['experience_years']),
        "is_active" => boolval($row['is_active']),
        "is_busy" => ($row['current_load'] >= $row['max_load']),
        "assigned_trainees" => $assigned_trainees
    ];
}

// Calculate statistics based on ACTUAL data
$totalTrainers = count($trainers);
$availableCount = count(array_filter($trainers, fn($t) => !$t['is_busy']));
$busyCount = count(array_filter($trainers, fn($t) => $t['is_busy']));
$maxLoad = $totalTrainers > 0 ? max(array_column($trainers, 'trainees')) : 0;
$totalAssignedTrainees = array_sum(array_column($trainers, 'trainees'));

// Default color for all trainers (since departments are removed)
$defaultColor = ["bg" => "from-blue-50 to-indigo-50", "text" => "text-blue-700", "border" => "border-blue-100"];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Trainer Availability — Kanban</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      overflow: hidden;
      height: 100vh;
      margin: 0;
    }
    
    .glass-card {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
    }
    
    .scrollbar-thin::-webkit-scrollbar { width: 6px; }
    .scrollbar-thin::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 10px; }
    .scrollbar-thin::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    .scrollbar-thin::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    
    .highlight-card {
      transition: all 0.3s ease;
      border-left: 4px solid transparent;
    }
    
    .highlight-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }
    
    .trainee-card {
      background: rgba(249, 250, 251, 0.7);
      border: 1px solid rgba(229, 231, 235, 0.5);
      border-radius: 8px;
      padding: 10px;
      margin-top: 6px;
      font-size: 0.8rem;
    }
    
    .status-badge {
      padding: 6px 16px;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-fadeIn {
      animation: fadeIn 0.3s ease-out forwards;
    }
    
    .main-content-scroll {
      overflow-y: auto;
      height: calc(100vh - 2rem);
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
      padding-right: 0.5rem;
    }
    
    .main-content-scroll::-webkit-scrollbar { width: 8px; }
    .main-content-scroll::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 4px; }
    .main-content-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
    .main-content-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    
    .main-content-scroll { scroll-behavior: smooth; }
    
    .column-scroll {
      max-height: 600px;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
    }
    
    .column-scroll::-webkit-scrollbar { width: 6px; }
    .column-scroll::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 3px; }
    .column-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
    .column-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    
    .progress-bar {
      height: 6px;
      border-radius: 3px;
      background: #e5e7eb;
      overflow: hidden;
      margin-top: 8px;
    }
    
    .progress-fill {
      height: 100%;
      border-radius: 3px;
      transition: width 0.3s ease;
    }
  </style>
</head>
<body class="min-h-screen">

<div class="flex h-screen overflow-hidden">
    
  <!-- Sidebar - Fixed -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content - Scrollable Area -->
  <div class="flex-1 flex flex-col overflow-hidden">
    <!-- Main content with scrolling -->
    <main class="main-content-scroll p-6 space-y-6 max-w-7xl mx-auto w-full">

      <!-- Enhanced Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
            <i data-lucide="users" class="w-7 h-7 text-blue-600"></i>
          </div>
          <div>
            <h1 class="text-2xl font-bold text-gray-900">Trainer Availability</h1>
            <p class="text-sm text-gray-500">Real-time trainer load based on actual assigned trainees</p>
          </div>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Navigation Tabs -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
        <a href="/training/trainings.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="calendar" class="w-4 h-4"></i> Training
        </a>
        <a href="/training/trainer.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors bg-gray-700">
          <i data-lucide="users" class="w-4 h-4"></i> Trainers
        </a>
        <a href="/training/trainhistory.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="clipboard-check" class="w-4 h-4"></i> Monitoring
        </a>
      </div>

      <!-- Statistics Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Active Trainers</p>
              <p class="text-2xl font-bold text-gray-900"><?= $totalTrainers ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
              <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Available</p>
              <p class="text-2xl font-bold text-green-600"><?= $availableCount ?></p>
            </div>
            <div class="p-3 bg-green-50 rounded-xl">
              <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">At Full Capacity</p>
              <p class="text-2xl font-bold text-amber-600"><?= $busyCount ?></p>
            </div>
            <div class="p-3 bg-amber-50 rounded-xl">
              <i data-lucide="clock" class="w-6 h-6 text-amber-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Total Assigned</p>
              <p class="text-2xl font-bold text-blue-600"><?= $totalAssignedTrainees ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
              <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Search and Filter (Simplified - no department filter) -->
      <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex flex-col lg:flex-row items-center justify-between gap-4">
          <div class="relative w-full lg:w-96">
            <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
            <input type="text" id="searchInput" placeholder="Search trainers by name..." 
                   class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          </div>
          
          <div class="flex items-center gap-4">
            <div class="relative">
              <i data-lucide="users" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <select id="availabilityFilter" class="pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">All Availability</option>
                <option value="available">Available (Not at capacity)</option>
                <option value="busy">Busy (At full capacity)</option>
                <option value="no-trainees">No Trainees Assigned</option>
                <option value="has-trainees">Has Trainees Assigned</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Kanban Board -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Available Column -->
        <section class="glass-card rounded-2xl p-6 border border-gray-100">
          <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
              <div class="p-2 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
                <i data-lucide="check-circle" class="w-5 h-5 text-green-600"></i>
              </div>
              <div>
                <h2 class="text-lg font-semibold text-gray-900">Available Trainers</h2>
                <p class="text-sm text-gray-500">Trainers with current capacity (can take more trainees)</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <div class="text-sm text-gray-500">Count:</div>
              <span id="countAvailable" class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">0</span>
            </div>
          </div>
          <div id="colAvailable" class="space-y-4 min-h-[300px] column-scroll pr-2"></div>
        </section>

        <!-- Busy Column -->
        <section class="glass-card rounded-2xl p-6 border border-gray-100">
          <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
              <div class="p-2 bg-gradient-to-br from-amber-50 to-orange-50 rounded-lg">
                <i data-lucide="clock" class="w-5 h-5 text-amber-600"></i>
              </div>
              <div>
                <h2 class="text-lg font-semibold text-gray-900">At Full Capacity</h2>
                <p class="text-sm text-gray-500">Trainers who cannot take more trainees at this time</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <div class="text-sm text-gray-500">Count:</div>
              <span id="countBusy" class="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-medium">0</span>
            </div>
          </div>
          <div id="colBusy" class="space-y-4 min-h-[300px] column-scroll pr-2"></div>
        </section>
      </div>

    </main>
  </div>
</div>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

<script>
lucide.createIcons();

// Trainers data from PHP
const trainers = <?= json_encode($trainers); ?>;
const defaultColor = <?= json_encode($defaultColor); ?>;

const colAvailable = document.getElementById("colAvailable");
const colBusy = document.getElementById("colBusy");
const countAvailable = document.getElementById("countAvailable");
const countBusy = document.getElementById("countBusy");
const searchInput = document.getElementById("searchInput");
const availabilityFilter = document.getElementById("availabilityFilter");

function formatDate(dateString) {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: 'numeric'
  });
}

function renderBoard() {
  const searchTerm = searchInput.value.toLowerCase().trim();
  const availFilter = availabilityFilter.value;
  
  colAvailable.innerHTML = '';
  colBusy.innerHTML = '';
  
  let availableCount = 0;
  let busyCount = 0;
  
  const filteredTrainers = trainers.filter(trainer => {
    if (searchTerm) {
      const matchesSearch = trainer.name.toLowerCase().includes(searchTerm);
      if (!matchesSearch) return false;
    }
    
    // Enhanced availability filtering
    if (availFilter === 'available' && trainer.is_busy) return false;
    if (availFilter === 'busy' && !trainer.is_busy) return false;
    if (availFilter === 'no-trainees' && trainer.trainees > 0) return false;
    if (availFilter === 'has-trainees' && trainer.trainees === 0) return false;
    
    return true;
  });
  
  filteredTrainers.sort((a, b) => {
    if (!a.is_busy && b.is_busy) return -1;
    if (a.is_busy && !b.is_busy) return 1;
    // Sort by actual trainee count (higher first for busy, lower first for available)
    return a.is_busy ? b.trainees - a.trainees : a.trainees - b.trainees;
  });
  
  filteredTrainers.forEach(trainer => {
    const isBusy = trainer.is_busy;
    const loadPercent = trainer.max_trainees > 0 ? 
      Math.round((trainer.trainees / trainer.max_trainees) * 100) : 0;
    const progressColor = loadPercent === 0 ? 'bg-gray-300' :
                         loadPercent < 70 ? 'bg-green-500' : 
                         loadPercent < 90 ? 'bg-yellow-500' : 'bg-red-500';
    
    const card = document.createElement("div");
    card.className = `highlight-card bg-white border ${defaultColor.border} rounded-xl p-4 animate-fadeIn`;
    
    // Build assigned trainees list
    let traineesListHTML = '';
    if (trainer.assigned_trainees && trainer.assigned_trainees.length > 0) {
      trainer.assigned_trainees.forEach(trainee => {
        traineesListHTML += `
          <div class="trainee-card">
            <div class="flex justify-between items-start">
              <div>
                <div class="font-medium text-gray-800">${trainee.name}</div>
                <div class="text-xs text-gray-500 mt-1">
                  ${trainee.role} ${trainee.department ? '• ' + trainee.department : ''}
                </div>
              </div>
              <div class="text-xs text-gray-400">
                ${formatDate(trainee.assigned_date)}
              </div>
            </div>
          </div>
        `;
      });
    } else {
      traineesListHTML = `
        <div class="trainee-card text-center text-gray-400 italic">
          No trainees currently assigned
        </div>
      `;
    }
    
    card.innerHTML = `
      <div class="flex items-start justify-between">
        <div class="flex items-start gap-3">
          <div class="w-12 h-12 bg-gradient-to-br ${defaultColor.bg} rounded-lg flex items-center justify-center">
            <i data-lucide="user" class="w-6 h-6 ${defaultColor.text}"></i>
          </div>
          <div class="flex-1">
            <h3 class="font-semibold text-gray-900">${trainer.name}</h3>
            <div class="flex items-center gap-2 mt-2">
              <span class="inline-block px-3 py-1 ${isBusy ? 'bg-amber-100 text-amber-800' : 
                trainer.trainees > 0 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'} rounded-full text-xs font-medium">
                <i data-lucide="${isBusy ? 'users' : trainer.trainees > 0 ? 'user-check' : 'user'}" class="w-3 h-3 inline mr-1"></i>
                ${trainer.trainees}/${trainer.max_trainees} trainees
              </span>
              <span class="inline-block px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium">
                <i data-lucide="star" class="w-3 h-3 inline mr-1"></i>
                ${trainer.rating}/5.0
              </span>
            </div>
            
            <!-- Progress bar -->
            <div class="mt-3">
              <div class="flex justify-between text-xs text-gray-600 mb-1">
                <span>Capacity: ${loadPercent}%</span>
                <span>${trainer.trainees} of ${trainer.max_trainees}</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill ${progressColor}" style="width: ${loadPercent}%"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-right">
          <div class="flex items-center gap-2 ${isBusy ? 'text-amber-600' : 
            trainer.trainees > 0 ? 'text-green-600' : 'text-gray-600'}">
            <i data-lucide="${isBusy ? 'clock' : trainer.trainees > 0 ? 'check-circle' : 'user'}" class="w-4 h-4"></i>
            <span class="text-sm font-medium">${isBusy ? 'At Capacity' : 
              trainer.trainees > 0 ? 'Available' : 'No Assignments'}</span>
          </div>
          <div class="mt-2 text-xs text-gray-500">
            Exp: ${trainer.experience} years
          </div>
        </div>
      </div>
      
      <!-- Assigned Trainees Section -->
      <div class="mt-4 pt-4 border-t border-gray-100">
        <div class="flex items-center justify-between mb-2">
          <div class="text-sm font-medium text-gray-700 flex items-center gap-2">
            <i data-lucide="users" class="w-4 h-4"></i>
            Assigned Trainees (${trainer.assigned_trainees.length})
          </div>
          <div class="text-xs text-gray-500">
            ${isBusy ? 'Cannot accept more' : 
             trainer.trainees === 0 ? 'Can accept ' + trainer.max_trainees + ' trainees' :
             'Can accept ' + (trainer.max_trainees - trainer.trainees) + ' more'}
          </div>
        </div>
        <div class="space-y-2">
          ${traineesListHTML}
        </div>
      </div>
    `;
    
    if (isBusy) {
      colBusy.appendChild(card);
      busyCount++;
    } else {
      colAvailable.appendChild(card);
      availableCount++;
    }
  });
  
  countAvailable.textContent = availableCount;
  countBusy.textContent = busyCount;
  
  if (availableCount === 0) {
    colAvailable.innerHTML = `
      <div class="text-center py-12">
        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
          <i data-lucide="users" class="w-8 h-8 text-gray-400"></i>
        </div>
        <h3 class="text-lg font-medium text-gray-700 mb-2">No Available Trainers</h3>
        <p class="text-gray-500 max-w-md mx-auto">
          No trainers are currently available based on your filters.
        </p>
      </div>
    `;
  }
  
  if (busyCount === 0) {
    colBusy.innerHTML = `
      <div class="text-center py-12">
        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
          <i data-lucide="clock" class="w-8 h-8 text-gray-400"></i>
        </div>
        <h3 class="text-lg font-medium text-gray-700 mb-2">No Trainers at Full Capacity</h3>
        <p class="text-gray-500 max-w-md mx-auto">
          No trainers are currently at full capacity.
        </p>
      </div>
    `;
  }
  
  lucide.createIcons();
}

searchInput.addEventListener('input', renderBoard);
availabilityFilter.addEventListener('change', renderBoard);

renderBoard();

document.addEventListener('DOMContentLoaded', function() {
  const cards = document.querySelectorAll('.highlight-card');
  cards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
      card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      card.style.opacity = '1';
      card.style.transform = 'translateY(0)';
    }, index * 100);
  });
  
  const sidebar = document.querySelector('aside, .sidebar');
  if (sidebar) {
    sidebar.style.overflowY = 'auto';
    sidebar.style.position = 'sticky';
    sidebar.style.top = '0';
    sidebar.style.height = '100vh';
  }
});
</script>
</body>
</html>