<?php
include('../db.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || empty($data['id'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
    exit;
}

$id = intval($data['id']);

$conn->begin_transaction();

try {
    // Fetch employee info from training_assigned INCLUDING department
    $fetch = $conn->prepare("SELECT employee_name, role, department FROM training_assigned WHERE id = ?");
    $fetch->bind_param("i", $id);
    $fetch->execute();
    $result = $fetch->get_result();
    $employee = $result->fetch_assoc();

    if (!$employee) {
        throw new Exception("Employee not found.");
    }

    // Update training status
    $update = $conn->prepare("UPDATE training_assigned SET status = 'Completed' WHERE id = ?");
    $update->bind_param("i", $id);
    $update->execute();

    // -----------------------------
    // Insert/update employees table
    // -----------------------------
    $check = $conn->prepare("SELECT 1 FROM employees WHERE name = ? AND role = ? AND department = ?");
    $check->bind_param("sss", $employee['employee_name'], $employee['role'], $employee['department']);
    $check->execute();
    $exists = $check->get_result()->num_rows;

    if (!$exists) {
        $insert = $conn->prepare("
            INSERT INTO employees (name, role, department, readiness)
            VALUES (?, ?, ?, 'Ready Now')
        ");
        $insert->bind_param(
            "sss",
            $employee['employee_name'],
            $employee['role'],
            $employee['department']
        );
        $insert->execute();
    } else {
        $updateEmployee = $conn->prepare("
            UPDATE employees 
            SET department = ? 
            WHERE name = ? AND role = ?
        ");
        $updateEmployee->bind_param(
            "sss",
            $employee['department'],
            $employee['employee_name'],
            $employee['role']
        );
        $updateEmployee->execute();
    }

    // -----------------------------
    // Insert/update competency_records table
    // -----------------------------
    $employee_id = "EMP-" . str_pad($id, 5, '0', STR_PAD_LEFT);
    $current_date = date('Y-m-d');

    $checkCompetency = $conn->prepare("SELECT id FROM competency_records WHERE employee_id = ?");
    $checkCompetency->bind_param("s", $employee_id);
    $checkCompetency->execute();
    $competencyExists = $checkCompetency->get_result()->num_rows;

    if (!$competencyExists) {
        $insertCompetency = $conn->prepare("
            INSERT INTO competency_records (
                employee_id, employee_name, position, department, status, start_date, notes
            ) VALUES (?, ?, ?, ?, 'completed', ?, ?)
        ");

        $notes = "Training completed successfully on " . $current_date . ". ";
        $notes .= "Employee has been marked as 'Ready Now'. Position: " . $employee['role'] . " | Department: " . $employee['department'];

        $insertCompetency->bind_param(
            "ssssss",
            $employee_id,
            $employee['employee_name'],
            $employee['role'],
            $employee['department'],
            $current_date,
            $notes
        );

        $insertCompetency->execute();
    } else {
        $updateCompetency = $conn->prepare("
            UPDATE competency_records 
            SET status = 'completed',
                last_updated = NOW(),
                department = ?,
                position = ?,
                notes = CONCAT(COALESCE(notes, ''), '\nTraining updated: Completed on " . $current_date . "')
            WHERE employee_id = ?
        ");
        $updateCompetency->bind_param(
            "sss",
            $employee['department'],
            $employee['role'],
            $employee_id
        );
        $updateCompetency->execute();
    }

    // -----------------------------
    // NEW: Insert into training_complete table
    // -----------------------------
    $checkTrainingComplete = $conn->prepare("SELECT 1 FROM training_complete WHERE employee_name = ? AND department = ?");
    $checkTrainingComplete->bind_param("ss", $employee['employee_name'], $employee['department']);
    $checkTrainingComplete->execute();
    $existsTrainingComplete = $checkTrainingComplete->get_result()->num_rows;

    if (!$existsTrainingComplete) {
        $insertTrainingComplete = $conn->prepare("
            INSERT INTO training_complete (employee_name, department)
            VALUES (?, ?)
        ");
        $insertTrainingComplete->bind_param("ss", $employee['employee_name'], $employee['department']);
        $insertTrainingComplete->execute();
    }

    $conn->commit();

    echo json_encode([
        "status" => "success",
        "message" => "Training marked as completed. Employee added to employees, competency records, and training_complete table.",
        "data" => [
            "employee_id" => $employee_id,
            "employee_name" => $employee['employee_name'],
            "position" => $employee['role'],
            "department" => $employee['department']
        ]
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}

$conn->close();
?>
