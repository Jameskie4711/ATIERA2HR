<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

include '../../db.php';

$id = $_POST['id'] ?? 0;

if (!$id) {
  echo json_encode(["success" => false, "message" => "Missing employee ID"]);
  exit;
}

// Log check
if (!isset($conn)) {
  echo json_encode(["success" => false, "message" => "Database not connected"]);
  exit;
}

// Check or create training record
$check = $conn->prepare("SELECT id FROM training_requests WHERE employee_id = ?");
$check->bind_param("i", $id);
$check->execute();
$result = $check->get_result();

if ($result && $result->num_rows > 0) {
  $update = $conn->prepare("UPDATE training_requests SET status = 'Assigned' WHERE employee_id = ?");
  $update->bind_param("i", $id);
  $ok = $update->execute();
  echo json_encode(["success" => $ok, "message" => $ok ? "Updated existing record" : "Failed to update"]);
  exit;
}

$stmt = $conn->prepare("INSERT INTO training_requests (employee_id, status, assigned_at) VALUES (?, 'Assigned', NOW())");
$stmt->bind_param("i", $id);
$ok = $stmt->execute();

if ($ok) {
  echo json_encode(["success" => true, "message" => "Training assigned successfully"]);
} else {
  echo json_encode(["success" => false, "message" => "Database insert failed: ".$conn->error]);
}
?>
