<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');

// Fetch Pending requests
$reqs = [];
$res = $conn->query("SELECT id, employee_name, department, role, status FROM training_requests ORDER BY date_requested DESC");
if ($res && $res->num_rows > 0) {
  while ($row = $res->fetch_assoc()) {
    $reqs[] = [
      "id" => (int)$row['id'],
      "name" => $row['employee_name'],
      "dept" => $row['department'],
      "role" => $row['role'],
      "status" => $row['status']
    ];
  }
}

// Fetch Assigned data
$assigned = [];
$res2 = $conn->query("SELECT id, employee_name, department, role, status FROM training_assigned ORDER BY assigned_date DESC");
if ($res2 && $res2->num_rows > 0) {
  while ($row = $res2->fetch_assoc()) {
    $assigned[] = [
      "id" => (int)$row['id'],
      "name" => $row['employee_name'],
      "dept" => $row['department'],
      "role" => $row['role'],
      "status" => $row['status']
    ];
  }
}

// Calculate statistics
$totalRequests = count($reqs) + count($assigned);
$pendingCount = count($reqs);
$assignedCount = count($assigned);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>HRMS — Training Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      overflow: hidden;
      height: 100vh;
      margin: 0;
    }
    
    .glass-card {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
    }
    
    .btn-primary {
      background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
      transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
    }
    
    .btn-success {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      transition: all 0.3s ease;
    }
    
    .btn-success:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
    }
    
    .btn-warning {
      background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
      transition: all 0.3s ease;
    }
    
    .btn-warning:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(245, 158, 11, 0.3);
    }
    
    .scrollbar-thin::-webkit-scrollbar {
      width: 6px;
    }
    
    .scrollbar-thin::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 10px;
    }
    
    .scrollbar-thin::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 10px;
    }
    
    .scrollbar-thin::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    .highlight-card {
      transition: all 0.3s ease;
      border-left: 4px solid transparent;
    }
    
    .highlight-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }
    
    .status-badge {
      padding: 6px 16px;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-fadeIn {
      animation: fadeIn 0.3s ease-out forwards;
    }
    
    .modal-enter {
      animation: modalFadeIn 0.3s ease-out forwards;
    }
    
    @keyframes modalFadeIn {
      from { opacity: 0; transform: translateY(-20px) scale(0.95); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    
    .animate-pulse {
      animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    
    .animate-spin {
      animation: spin 1s linear infinite;
    }
    
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-10px); }
    }
    
    .animate-bounce {
      animation: bounce 1s infinite;
    }
    
    .main-content-scroll {
      overflow-y: auto;
      height: calc(100vh - 2rem);
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
      padding-right: 0.5rem;
    }
    
    .main-content-scroll::-webkit-scrollbar {
      width: 8px;
    }
    
    .main-content-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    .main-content-scroll {
      scroll-behavior: smooth;
    }
    
    .column-scroll {
      max-height: 600px;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
    }
    
    .column-scroll::-webkit-scrollbar {
      width: 6px;
    }
    
    .column-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 3px;
    }
    
    .column-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 3px;
    }
    
    .column-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    .loading-overlay {
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
      transition: opacity 0.3s ease-out, visibility 0.3s ease-out;
      z-index: 100;
    }
    
    .loading-overlay.active {
      opacity: 1;
      visibility: visible;
      pointer-events: auto;
    }
    
    @keyframes thinkingDots {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 1; }
    }
    
    .thinking-dot {
      animation: thinkingDots 1.5s infinite;
    }
    
    .thinking-dot:nth-child(2) {
      animation-delay: 0.2s;
    }
    
    .thinking-dot:nth-child(3) {
      animation-delay: 0.4s;
    }
    
    /* Modal centering fix */
    .modal-center {
      display: flex !important;
      align-items: center;
      justify-content: center;
    }
  </style>
</head>
<body class="min-h-screen">

<div class="flex h-screen overflow-hidden">
    
  <!-- Sidebar - Fixed -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content - Scrollable Area -->
  <div class="flex-1 flex flex-col overflow-hidden">
    <!-- Main content with scrolling -->
    <main class="main-content-scroll p-6 space-y-6 max-w-7xl mx-auto w-full">

      <!-- Enhanced Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
            <i data-lucide="graduation-cap" class="w-7 h-7 text-blue-600"></i>
          </div>
          <div>
            <h1 class="text-2xl font-bold text-gray-900">Training Management</h1>
            <p class="text-sm text-gray-500">Manage training requests and assignments</p>
          </div>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Tabs -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
        <a href="/training/trainings.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors bg-gray-700">
          <i data-lucide="calendar" class="w-4 h-4"></i>
          Training
        </a>
        <a href="/training/trainer.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="users" class="w-4 h-4"></i>
          Trainers
        </a>
        <a href="/training/trainhistory.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="clipboard-check" class="w-4 h-4"></i>
          Monitoring
        </a>
      </div>

      <!-- Statistics Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Total Requests</p>
              <p class="text-2xl font-bold text-gray-900"><?= $totalRequests ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
              <i data-lucide="file-text" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Pending</p>
              <p class="text-2xl font-bold text-amber-600"><?= $pendingCount ?></p>
            </div>
            <div class="p-3 bg-amber-50 rounded-xl">
              <i data-lucide="clock" class="w-6 h-6 text-amber-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Assigned</p>
              <p class="text-2xl font-bold text-green-600"><?= $assignedCount ?></p>
            </div>
            <div class="p-3 bg-green-50 rounded-xl">
              <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Filters -->
      <div class="glass-card rounded-2xl p-6 border border-gray-100">
        <div class="flex flex-col lg:flex-row items-center justify-between gap-4">
          <div class="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
            <div class="relative w-full sm:w-64">
              <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <input id="search" type="search" placeholder="Search by name, role, or department..." 
                     class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
            
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full sm:w-auto">
              <div class="relative">
                <i data-lucide="briefcase" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                <select id="filterRole" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="">All Roles</option>
                </select>
              </div>
              
              <div class="relative">
                <i data-lucide="building" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                <select id="filterDept" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="">All Departments</option>
                </select>
              </div>
              
              <div class="relative">
                <i data-lucide="filter" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                <select id="filterStatus" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="">All Statuses</option>
                  <option value="Pending">Pending</option>
                  <option value="Assigned">Assigned</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Kanban Board -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Pending Column -->
        <section class="glass-card rounded-2xl p-6 border border-gray-100">
          <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
              <div class="p-2 bg-gradient-to-br from-amber-50 to-orange-50 rounded-lg">
                <i data-lucide="clock" class="w-5 h-5 text-amber-600"></i>
              </div>
              <div>
                <h2 class="text-lg font-semibold text-gray-900">Pending Requests</h2>
                <p class="text-sm text-gray-500">Awaiting approval and assignment</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <div class="text-sm text-gray-500">Count:</div>
              <span id="countPending" class="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-medium">0</span>
            </div>
          </div>
          <div id="colPending" class="space-y-4 min-h-[200px] column-scroll pr-2"></div>
        </section>

        <!-- Assigned Column -->
        <section class="glass-card rounded-2xl p-6 border border-gray-100">
          <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
              <div class="p-2 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
                <i data-lucide="check-circle" class="w-5 h-5 text-green-600"></i>
              </div>
              <div>
                <h2 class="text-lg font-semibold text-gray-900">Assigned Trainings</h2>
                <p class="text-sm text-gray-500">Training sessions in progress</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <div class="text-sm text-gray-500">Count:</div>
              <span id="countAssigned" class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">0</span>
            </div>
          </div>
          <div id="colAssigned" class="space-y-4 min-h-[200px] column-scroll pr-2"></div>
        </section>
      </div>

    </main>
  </div>
</div>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

  <!-- AI Loading Modal - PERFECTLY CENTERED -->
  <div id="aiLoadingModal" class="loading-overlay fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[110]">
    <div class="glass-card rounded-2xl w-full max-w-md p-8 shadow-2xl modal-enter mx-4">
      <div class="flex flex-col items-center text-center">
        <!-- Animated AI Brain Icon -->
        <div class="relative mb-6">
          <div class="w-20 h-20 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-full flex items-center justify-center">
            <div class="relative">
              <i data-lucide="brain" class="w-12 h-12 text-purple-600 animate-bounce"></i>
              <div class="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
            </div>
          </div>
          <!-- Orbiting dots -->
          <div class="absolute inset-0">
            <div class="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div class="w-3 h-3 bg-blue-400 rounded-full thinking-dot"></div>
            </div>
            <div class="absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
              <div class="w-3 h-3 bg-purple-400 rounded-full thinking-dot"></div>
            </div>
            <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2">
              <div class="w-3 h-3 bg-green-400 rounded-full thinking-dot"></div>
            </div>
          </div>
        </div>
        
        <!-- AI Analysis Messages -->
        <h3 id="aiLoadingTitle" class="text-xl font-bold text-gray-900 mb-2">AI is analyzing trainers...</h3>
        <p id="aiLoadingSub" class="text-gray-600 mb-6">Finding the best match based on skills, workload, and experience.</p>
        
        <!-- Progress Bar -->
        <div class="w-full bg-gray-200 rounded-full h-2 mb-6">
          <div id="aiProgressBar" class="h-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-1000" style="width: 0%"></div>
        </div>
        
        <!-- Thinking Dots -->
        <div class="flex space-x-2 mb-6">
          <div class="w-2 h-2 bg-blue-500 rounded-full thinking-dot"></div>
          <div class="w-2 h-2 bg-blue-500 rounded-full thinking-dot"></div>
          <div class="w-2 h-2 bg-blue-500 rounded-full thinking-dot"></div>
        </div>
        
        <!-- Estimated Time -->
        <p class="text-sm text-gray-500">Estimated time: <span id="timeRemaining">5 seconds</span></p>
      </div>
    </div>
  </div>

  <!-- Confirmation Modal -->
  <div id="modalConfirm" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-full max-w-md p-8 shadow-2xl modal-enter">
      <div class="flex items-center gap-3 mb-6">
        <div class="p-2 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
          <i data-lucide="help-circle" class="w-5 h-5 text-blue-600"></i>
        </div>
        <div>
          <h4 class="text-xl font-bold text-gray-900">Please Confirm</h4>
          <p class="text-sm text-gray-500">Confirm your action</p>
        </div>
      </div>
      <p id="confirmMsg" class="text-gray-600 mb-6"></p>
      <div class="flex gap-3">
        <button id="confirmNo" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
          Cancel
        </button>
        <button id="confirmYes" class="flex-1 btn-primary px-4 py-3 rounded-xl text-white font-medium">
          Confirm
        </button>
      </div>
    </div>
  </div>

<?php
$all = array_merge($reqs, $assigned);
?>
<script>
lucide.createIcons();

let requests = <?= json_encode($all) ?>;
const colPending = document.getElementById('colPending');
const colAssigned = document.getElementById('colAssigned');
const countPending = document.getElementById('countPending');
const countAssigned = document.getElementById('countAssigned');
const searchInput = document.getElementById('search');
const filterRole = document.getElementById('filterRole');
const filterDept = document.getElementById('filterDept');
const filterStatus = document.getElementById('filterStatus');

const modalConfirm = document.getElementById('modalConfirm');
const confirmMsg = document.getElementById('confirmMsg');
const confirmYes = document.getElementById('confirmYes');
const confirmNo = document.getElementById('confirmNo');
const aiLoadingModal = document.getElementById('aiLoadingModal');
const aiLoadingTitle = document.getElementById('aiLoadingTitle');
const aiLoadingSub = document.getElementById('aiLoadingSub');
const aiProgressBar = document.getElementById('aiProgressBar');
const timeRemaining = document.getElementById('timeRemaining');

let confirmYesCb = null;
let aiAnalysisInterval = null;
let progressTimer = null;
let minimumDisplayTime = 5500; // 5.5 seconds minimum
let analysisStartTime = 0;

/* =========================
   🤖 AI Loading Functions - ENSURE 5-6 Seconds
========================= */

const aiAnalysisMessages = [
  { title: "Analyzing trainer database...", sub: "Reviewing available trainers and their expertise." },
  { title: "Evaluating skill compatibility...", sub: "Matching training requirements with trainer skills." },
  { title: "Checking trainer availability...", sub: "Reviewing schedules and current workload." },
  { title: "Optimizing assignment...", sub: "Finding the perfect trainer match for optimal learning." },
  { title: "Finalizing selection...", sub: "Preparing trainer assignment and scheduling details." }
];

let currentMessageIndex = 0;

function startAIAnalysis() {
  // Reset state
  currentMessageIndex = 0;
  aiProgressBar.style.width = '0%';
  analysisStartTime = Date.now();
  
  // Show the modal
  aiLoadingModal.classList.add('active');
  
  // Update initial message
  updateAIMessage();
  
  // Start message rotation every 2 seconds
  aiAnalysisInterval = setInterval(updateAIMessage, 2000);
  
  // Start progress bar animation (5-6 seconds)
  const duration = minimumDisplayTime; // 5.5 seconds
  const startTime = Date.now();
  const endTime = startTime + duration;
  
  // Update time remaining
  updateTimeRemaining(endTime);
  const timeInterval = setInterval(() => updateTimeRemaining(endTime), 1000);
  
  // Animate progress bar
  let progress = 0;
  progressTimer = setInterval(() => {
    const elapsed = Date.now() - startTime;
    progress = Math.min(100, (elapsed / duration) * 100);
    aiProgressBar.style.width = `${progress}%`;
    
    if (progress >= 100) {
      clearInterval(progressTimer);
      clearInterval(timeInterval);
    }
  }, 50);
}

function updateAIMessage() {
  const message = aiAnalysisMessages[currentMessageIndex];
  aiLoadingTitle.textContent = message.title;
  aiLoadingSub.textContent = message.sub;
  
  currentMessageIndex = (currentMessageIndex + 1) % aiAnalysisMessages.length;
}

function updateTimeRemaining(endTime) {
  const remaining = Math.max(0, endTime - Date.now());
  const seconds = Math.ceil(remaining / 1000);
  timeRemaining.textContent = `${seconds} second${seconds !== 1 ? 's' : ''}`;
  
  if (seconds <= 0) {
    timeRemaining.textContent = "Almost done...";
  }
}

function stopAIAnalysis() {
  clearInterval(aiAnalysisInterval);
  clearInterval(progressTimer);
  
  // Calculate how long the modal has been displayed
  const elapsedTime = Date.now() - analysisStartTime;
  
  // If less than minimum display time, wait the remaining time
  if (elapsedTime < minimumDisplayTime) {
    const remainingTime = minimumDisplayTime - elapsedTime;
    setTimeout(() => {
      aiLoadingModal.classList.remove('active');
    }, remainingTime);
  } else {
    // If already displayed for minimum time, hide immediately
    aiLoadingModal.classList.remove('active');
  }
}

/* ========================= */

function unique(arr) { return [...new Set(arr)]; }

function openConfirm(msg, yesCb){
  confirmMsg.textContent = msg;
  modalConfirm.classList.remove('hidden');
  modalConfirm.classList.add('flex');
  confirmYesCb = yesCb;
}

function closeConfirm(){
  modalConfirm.classList.add('hidden');
  modalConfirm.classList.remove('flex');
  confirmYesCb = null;
}

confirmNo.onclick = closeConfirm;
confirmYes.onclick = ()=>{ if(confirmYesCb) confirmYesCb(); };

function populateFilters() {
  const roles = unique(requests.map(r => r.role).filter(r => r && r.trim() !== '')).sort();
  const depts = unique(requests.map(r => r.dept).filter(d => d && d.trim() !== '')).sort();
  
  filterRole.innerHTML = '<option value="">All Roles</option>' + roles.map(r=>`<option value="${r}">${r}</option>`).join('');
  filterDept.innerHTML = '<option value="">All Departments</option>' + depts.map(d=>`<option value="${d}">${d}</option>`).join('');
}

function renderBoard(){
  const q = searchInput.value.trim().toLowerCase();
  const roleF = filterRole.value;
  const deptF = filterDept.value;
  const statusF = filterStatus.value;

  colPending.innerHTML = '';
  colAssigned.innerHTML = '';

  const visible = requests.filter(r=>{
    if(roleF && r.role !== roleF) return false;
    if(deptF && r.dept !== deptF) return false;
    if(statusF && r.status !== statusF) return false;
    if(q) return r.name.toLowerCase().includes(q) || (r.role && r.role.toLowerCase().includes(q)) || (r.dept && r.dept.toLowerCase().includes(q));
    return true;
  });

  const pending = visible.filter(r => r.status === 'Pending');
  const assigned = visible.filter(r => r.status === 'Assigned');

  countPending.textContent = pending.length;
  countAssigned.textContent = assigned.length;

  function makeCard(r){
    const card = document.createElement('div');
    card.className = 'highlight-card bg-white border border-gray-100 rounded-xl p-4 animate-fadeIn';

    let infoText = r.role ? `${r.role}${r.dept ? ' • ' + r.dept : ''}` : (r.dept || '');

    card.innerHTML = `
      <div class="flex items-start justify-between">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-gradient-to-br ${r.status === 'Assigned' ? 'from-green-50 to-emerald-50' : 'from-amber-50 to-orange-50'} rounded-lg flex items-center justify-center">
            <i data-lucide="${r.status === 'Assigned' ? 'check-circle' : 'clock'}" class="w-5 h-5 ${r.status === 'Assigned' ? 'text-green-600' : 'text-amber-600'}"></i>
          </div>
          <div>
            <div class="font-semibold text-gray-900">${r.name}</div>
            <div class="text-sm text-gray-500 mt-1">${infoText}</div>
          </div>
        </div>
        <div class="status-badge ${r.status === 'Assigned' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}">
          <i data-lucide="${r.status === 'Assigned' ? 'check-circle' : 'clock'}" class="w-3 h-3"></i>
          ${r.status}
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        ${r.status === 'Pending' 
          ? `<button class="assignBtn btn-success flex-1 px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center justify-center gap-2" data-id="${r.id}" data-name="${r.name}">
              <i data-lucide="user-check" class="w-4 h-4"></i> Assign
            </button>` 
          : `<button class="viewBtn btn-primary flex-1 px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center justify-center gap-2" data-id="${r.id}">
              <i data-lucide="eye" class="w-4 h-4"></i> View Details
            </button>`}
        <button class="archiveBtn flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium text-sm flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors" data-id="${r.id}">
          <i data-lucide="archive" class="w-4 h-4"></i> Archive
        </button>
      </div>
    `;
    return card;
  }

  pending.forEach(r => colPending.appendChild(makeCard(r)));
  assigned.forEach(r => colAssigned.appendChild(makeCard(r)));

  attachCardActions();
  lucide.createIcons();
}

function attachCardActions(){
  document.querySelectorAll('.archiveBtn').forEach(btn => {
    btn.onclick = () => {
      const id = +btn.dataset.id;
      const request = requests.find(r => r.id === id);

      openConfirm(`Archive "${request?.name || 'this'}" training request?`, () => {
        closeConfirm();
        startAIAnalysis();

        // Make AJAX request
        fetch('archive_request.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: `id=${id}`
        })
        .then(res => res.json())
        .then(data => {
          // Stop AI analysis after minimum 5.5 seconds
          setTimeout(() => {
            stopAIAnalysis();
            
            if(data.status === 'success'){
              requests = requests.filter(x => x.id !== id);
              populateFilters();
              renderBoard();
            } else {
              alert(data.message || 'Failed to archive request');
            }
          }, 0); // The stopAIAnalysis function now handles the minimum display time
        })
        .catch(() => { 
          setTimeout(() => {
            stopAIAnalysis();
            alert('Request failed'); 
          }, 0);
        });
      });
    };
  });

  document.querySelectorAll('.assignBtn').forEach(btn => {
    btn.onclick = () => {
      const id = +btn.dataset.id;
      const name = btn.dataset.name;

      openConfirm(`Assign training for "${name}"?`, () => {
        closeConfirm();
        startAIAnalysis();

        // Make AJAX request
        fetch('assign_training.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: `id=${id}`
        })
        .then(res => res.json())
        .then(data => {
          // Stop AI analysis after minimum 5.5 seconds
          setTimeout(() => {
            stopAIAnalysis();
            
            if (data.status === 'success') {
              const req = requests.find(r => r.id === id);
              if (req) req.status = 'Assigned';
              populateFilters();
              renderBoard();
            } else {
              alert(data.message || 'Assignment failed');
            }
          }, 0); // The stopAIAnalysis function now handles the minimum display time
        })
        .catch(() => { 
          setTimeout(() => {
            stopAIAnalysis();
            alert('Request failed'); 
          }, 0);
        });
      });
    };
  });

  document.querySelectorAll('.viewBtn').forEach(btn => {
    btn.onclick = () => {
      const id = +btn.dataset.id;
      window.location.href = `view.php?id=${id}`;
    };
  });
}

searchInput.addEventListener('input', renderBoard);
filterRole.addEventListener('change', renderBoard);
filterDept.addEventListener('change', renderBoard);
filterStatus.addEventListener('change', renderBoard);

window.addEventListener('click', e => { 
  if (e.target.id === 'modalConfirm') closeConfirm();
  if (e.target.id === 'aiLoadingModal') stopAIAnalysis();
});

// Initialize the board
document.addEventListener('DOMContentLoaded', () => {
  populateFilters();
  renderBoard();
});
</script>
</body>
</html>