<?php
/**
 * assign_training.php
 * AI-powered trainer assignment using LibTorch-style JS inference
 * Database: hr2_competency
 */

include('../session_check.php');
include('../db.php');

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* ============================
   1️⃣ VALIDATE REQUEST
============================ */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'Missing training request ID']);
    exit;
}

/* ============================
   2️⃣ START TRANSACTION
============================ */
$conn->begin_transaction();

try {
    /* ============================
       FETCH TRAINING REQUEST
    ============================ */
    $stmt = $conn->prepare("
        SELECT id, employee_id, employee_name, department, role
        FROM training_requests
        WHERE id = ?
        FOR UPDATE
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $trainee = $stmt->get_result()->fetch_assoc();

    if (!$trainee) {
        throw new Exception("Training request not found");
    }

    /* ============================
       FETCH ACTIVE & AVAILABLE TRAINERS
       (current_load < max_load)
    ============================ */
    $trainers = [];
    $sql = "
        SELECT
            id,
            employee_name,
            specialization,
            skills,
            experience_years,
            departments,
            current_load,
            max_load,
            rating,
            is_active,
            next_available
        FROM trainers
        WHERE is_active = 1
        AND current_load < max_load
        ORDER BY current_load ASC, rating DESC
    ";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $trainers[] = $row;
    }

    if (empty($trainers)) {
        throw new Exception("No available trainers at the moment");
    }

    /* ============================
       RUN AI INFERENCE (Node.js)
    ============================ */
    $payload = json_encode([
        "trainers" => $trainers,
        "trainee"  => $trainee
    ]);

    $cmd = "node " . escapeshellarg(__DIR__ . "/trainer_ai/run_trainer_ai.js") . " "
         . escapeshellarg($payload);

    $output = shell_exec($cmd);

    if (!$output) {
        throw new Exception("Trainer AI inference failed");
    }

    $trainer = json_decode($output, true);

    if (!$trainer || !isset($trainer['id'])) {
        throw new Exception("No suitable trainer found by AI");
    }

    $trainer_id   = $trainer['id'];
    $trainer_name = $trainer['employee_name'];

    /* ============================
       INSERT ASSIGNMENT
    ============================ */
    $stmt = $conn->prepare("
        INSERT INTO training_assigned
        (employee_name, department, role, trainer_name, status, assigned_date)
        VALUES (?, ?, ?, ?, 'Assigned', NOW())
    ");
    $stmt->bind_param(
        "ssss",
        $trainee['employee_name'],
        $trainee['department'],
        $trainee['role'],
        $trainer_name
    );
    $stmt->execute();

    $assigned_id = $conn->insert_id;

    /* ============================
       UPDATE TRAINER LOAD
    ============================ */
    $stmt = $conn->prepare("
        UPDATE trainers
        SET
            current_load = current_load + 1,
            last_assigned = NOW()
        WHERE id = ?
    ");
    $stmt->bind_param("i", $trainer_id);
    $stmt->execute();

    /* ============================
       REMOVE TRAINING REQUEST
    ============================ */
    $stmt = $conn->prepare("
        DELETE FROM training_requests
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    /* ============================
       COMMIT TRANSACTION
    ============================ */
    $conn->commit();

    /* ============================
       SUCCESS RESPONSE
    ============================ */
    echo json_encode([
        "status" => "success",
        "data" => [
            "assigned_id"   => $assigned_id,
            "employee_name" => $trainee['employee_name'],
            "department"    => $trainee['department'],
            "role"          => $trainee['role'],
            "trainer_name"  => $trainer_name,
            "assigned_date" => date("Y-m-d H:i:s")
        ]
    ]);

} catch (Exception $e) {

    $conn->rollback();

    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}
