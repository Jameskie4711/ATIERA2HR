<?php include('../session_check.php'); ?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');

// --- Fetch ACTUAL training data from database ---
$trainingData = [];

// Fetch all assigned trainings from training_assigned table
$query = $conn->query("
    SELECT 
        ta.id,
        ta.employee_name,
        ta.trainer_name,
        ta.assigned_date as start_date,
        ta.status,
        ta.department,
        ta.role as description,
        ta.assigned_date,
        -- Calculate end date (assuming 2 weeks training duration)
        DATE_ADD(ta.assigned_date, INTERVAL 14 DAY) as end_date,
        -- Default training hours (can be adjusted based on your requirements)
        40 as hours,
        -- Add rating/score if available in your database
        NULL as score,
        -- Add certificate if available
        CONCAT('CERT-', ta.id, '-', YEAR(ta.assigned_date)) as certificate,
        -- Default location
        'Training Room' as location
    FROM training_assigned ta
    WHERE ta.status IN ('Assigned', 'Completed', 'In Progress', 'Overdue')
    ORDER BY ta.assigned_date DESC
");

if ($query && $query->num_rows > 0) {
    while ($row = $query->fetch_assoc()) {
        // Determine status based on dates
        $start_date = new DateTime($row['start_date']);
        $end_date = new DateTime($row['end_date']);
        $today = new DateTime();
        
        // Calculate days remaining
        $days_remaining = $today->diff($end_date)->days;
        
        // Determine status
        $status = $row['status'];
        if ($status === 'Assigned') {
            if ($end_date < $today) {
                $status = 'Overdue';
            } else {
                $status = 'In Progress';
            }
        }
        
        $trainingData[] = [
            'id' => (int)$row['id'],
            'employee' => $row['employee_name'],
            'trainer' => $row['trainer_name'],
            'start' => $row['start_date'],
            'end' => $row['end_date'],
            'status' => $status,
            'description' => $row['description'],
            'department' => $row['department'],
            'location' => $row['location'],
            'hours' => (int)$row['hours'],
            'score' => $row['score'] ? (int)$row['score'] : null,
            'certificate' => $row['certificate']
        ];
    }
}

// Calculate statistics
$totalTrainings = count($trainingData);
$completedCount = count(array_filter($trainingData, fn($t) => $t['status'] === 'Completed'));
$inProgressCount = count(array_filter($trainingData, fn($t) => $t['status'] === 'In Progress'));
$overdueCount = count(array_filter($trainingData, fn($t) => $t['status'] === 'Overdue'));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Training History</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    overflow: hidden;
    height: 100vh;
    margin: 0;
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
  }
  
  .animate-fadeIn {
    animation: fadeIn 0.3s ease-out forwards;
  }
  
  .animate-slideIn {
    animation: slideIn 0.3s ease-out forwards;
  }
  
  .animate-slideOut {
    animation: slideOut 0.3s ease-out forwards;
  }
  
  .table-row-hover:hover {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.02) 100%);
  }
  
  .detail-panel {
    transform: translateX(100%);
    transition: transform 0.3s ease-out;
  }
  
  .detail-panel.open {
    transform: translateX(0);
  }
  
  .certificate-panel {
    transform: scale(0.9);
    opacity: 0;
    pointer-events: none;
    transition: transform 0.3s ease-out, opacity 0.3s ease-out;
  }
  
  .certificate-panel.open {
    transform: scale(1);
    opacity: 1;
    pointer-events: auto;
  }
  
  .certificate-panel .flex-col {
    max-height: 90vh;
    overflow-y: auto;
  }
  
  .overlay {
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s ease-out;
    pointer-events: none;
  }
  
  .overlay.active {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
  }
  
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 0.5rem;
  }
  
  .main-content-scroll::-webkit-scrollbar {
    width: 8px;
  }
  
  .main-content-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .main-content-scroll {
    scroll-behavior: smooth;
  }
</style>
</head>
<body class="min-h-screen">

<div class="flex h-screen overflow-hidden">
    
  <!-- Sidebar - Fixed -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content - Scrollable Area -->
  <div class="flex-1 flex flex-col overflow-hidden">
    <!-- Main content with scrolling -->
    <main class="main-content-scroll p-6 space-y-6 max-w-7xl mx-auto w-full">

      <!-- Enhanced Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
            <i data-lucide="clipboard-check" class="w-7 h-7 text-blue-600"></i>
          </div>
          <div>
            <h1 class="text-2xl font-bold text-gray-900">Training History</h1>
            <p class="text-sm text-gray-500">Track and monitor training progress and completion</p>
          </div>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Top Tabs -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
        <a href="/training/trainings.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="calendar" class="w-4 h-4"></i> Training
        </a>
        <a href="/training/trainer.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
          <i data-lucide="users" class="w-4 h-4"></i> Trainers
        </a>
        <a href="/training/trainhistory.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors bg-gray-700">
          <i data-lucide="clipboard-check" class="w-4 h-4"></i> Monitoring
        </a>
      </div>

      <!-- Statistics Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Total Trainings</p>
              <p class="text-2xl font-bold text-gray-900"><?= $totalTrainings ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
              <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Completed</p>
              <p class="text-2xl font-bold text-green-600"><?= $completedCount ?></p>
            </div>
            <div class="p-3 bg-green-50 rounded-xl">
              <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">In Progress</p>
              <p class="text-2xl font-bold text-amber-600"><?= $inProgressCount ?></p>
            </div>
            <div class="p-3 bg-amber-50 rounded-xl">
              <i data-lucide="clock" class="w-6 h-6 text-amber-600"></i>
            </div>
          </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Overdue</p>
              <p class="text-2xl font-bold text-red-600"><?= $overdueCount ?></p>
            </div>
            <div class="p-3 bg-red-50 rounded-xl">
              <i data-lucide="alert-triangle" class="w-6 h-6 text-red-600"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Search and Filter -->
      <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex flex-col lg:flex-row items-center justify-between gap-4">
          <div class="flex items-center gap-4 w-full lg:w-auto">
            <div class="relative flex-1 lg:w-96">
              <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <input type="text" id="searchEmployee" placeholder="Search by employee name..." 
                     class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
            
            <div class="relative">
              <i data-lucide="filter" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <select id="statusFilter" class="pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">All Status</option>
                <option value="Completed">Completed</option>
                <option value="In Progress">In Progress</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>
            
            <button onclick="applyFilters()" 
                    class="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-200 flex items-center gap-2 shadow-sm">
              <i data-lucide="filter" class="w-4 h-4"></i> Apply Filters
            </button>
          </div>
        </div>
      </div>

      <!-- Training History Table -->
      <div class="glass-card rounded-2xl p-6 border border-gray-100 overflow-hidden">
        <div class="flex items-center justify-between mb-6">
          <div>
            <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <i data-lucide="list" class="w-5 h-5 text-blue-600"></i>
              Training Records
            </h3>
            <p class="text-sm text-gray-500 mt-1">Detailed view of all training sessions</p>
          </div>
          <div class="text-sm text-gray-500">
            <span id="visibleCount"><?= $totalTrainings ?></span> of <?= $totalTrainings ?> records shown
          </div>
        </div>

        <div class="overflow-x-auto scrollbar-thin">
          <table class="w-full">
            <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
              <tr>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Training ID</th>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Employee</th>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Trainer</th>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Timeline</th>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Status</th>
                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody id="tableBody" class="divide-y divide-gray-100"></tbody>
          </table>
        </div>
        
        <!-- Empty State -->
        <div id="emptyState" class="hidden text-center py-12">
          <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <i data-lucide="search" class="w-8 h-8 text-gray-400"></i>
          </div>
          <h3 class="text-lg font-medium text-gray-700 mb-2">No Training Records Found</h3>
          <p class="text-gray-500 max-w-md mx-auto">
            No training records match your current filters. Try adjusting your search criteria.
          </p>
        </div>
      </div>

    </main>
  </div>
</div>

  <!-- Training Detail Panel -->
  <div id="detailOverlay" class="overlay fixed inset-0 bg-black bg-opacity-50 z-40" onclick="closeDetailPanel()"></div>
  
  <div id="detailPanel" class="detail-panel fixed right-0 top-0 h-full w-full max-w-lg bg-white shadow-2xl z-50 overflow-y-auto">
    <div class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-bold text-gray-900">Training Details</h2>
        <button onclick="closeDetailPanel()" class="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <i data-lucide="x" class="w-6 h-6 text-gray-500"></i>
        </button>
      </div>
      
      <!-- Loading State -->
      <div id="detailLoading" class="hidden text-center py-12">
        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p class="mt-4 text-gray-500">Loading details...</p>
      </div>
      
      <!-- Content -->
      <div id="detailContent" class="space-y-6">
        <!-- Training ID Badge -->
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="p-3 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl">
              <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
            </div>
            <div>
              <h3 id="detailId" class="text-lg font-semibold text-gray-900"></h3>
              <p id="detailTitle" class="text-sm text-gray-500"></p>
            </div>
          </div>
          <div id="detailStatusBadge" class="status-badge"></div>
        </div>
        
        <!-- Info Grid -->
        <div class="grid grid-cols-2 gap-4">
          <div class="bg-gray-50 p-4 rounded-xl">
            <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
              <i data-lucide="user" class="w-4 h-4"></i>
              Employee
            </div>
            <p id="detailEmployee" class="font-medium text-gray-900"></p>
          </div>
          
          <div class="bg-gray-50 p-4 rounded-xl">
            <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
              <i data-lucide="user-check" class="w-4 h-4"></i>
              Trainer
            </div>
            <p id="detailTrainer" class="font-medium text-gray-900"></p>
          </div>
          
          <div class="bg-gray-50 p-4 rounded-xl">
            <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
              <i data-lucide="building" class="w-4 h-4"></i>
              Department
            </div>
            <p id="detailDepartment" class="font-medium text-gray-900"></p>
          </div>
          
          <div class="bg-gray-50 p-4 rounded-xl">
            <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
              <i data-lucide="map-pin" class="w-4 h-4"></i>
              Location
            </div>
            <p id="detailLocation" class="font-medium text-gray-900"></p>
          </div>
        </div>
        
        <!-- Timeline -->
        <div class="space-y-4">
          <h4 class="font-semibold text-gray-900 flex items-center gap-2">
            <i data-lucide="calendar" class="w-5 h-5 text-blue-600"></i>
            Timeline
          </h4>
          <div class="flex items-center justify-between">
            <div class="text-center">
              <div class="text-sm text-gray-500">Start Date</div>
              <div id="detailStart" class="text-lg font-semibold text-gray-900"></div>
            </div>
            <div class="flex-1 h-1 bg-gray-200 mx-4 relative">
              <div id="detailProgressBar" class="absolute top-0 left-0 h-full bg-blue-600 rounded-full"></div>
            </div>
            <div class="text-center">
              <div class="text-sm text-gray-500">End Date</div>
              <div id="detailEnd" class="text-lg font-semibold text-gray-900"></div>
            </div>
          </div>
          <div class="text-center text-sm text-gray-500">
            <span id="detailDaysLeft"></span> days remaining
          </div>
        </div>
        
        <!-- Training Details -->
        <div class="space-y-3">
          <h4 class="font-semibold text-gray-900 flex items-center gap-2">
            <i data-lucide="info" class="w-5 h-5 text-blue-600"></i>
            Training Details
          </h4>
          <div class="bg-gray-50 p-4 rounded-xl">
            <p id="detailDescription" class="text-gray-700"></p>
            <div class="flex items-center gap-4 mt-3 text-sm">
              <div class="flex items-center gap-2 text-gray-500">
                <i data-lucide="clock" class="w-4 h-4"></i>
                <span id="detailHours"></span> hours
              </div>
              <div class="flex items-center gap-2 text-gray-500">
                <i data-lucide="award" class="w-4 h-4"></i>
                Score: <span id="detailScore" class="font-medium"></span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Certificate Section -->
        <div id="certificateSection" class="hidden">
          <h4 class="font-semibold text-gray-900 flex items-center gap-2 mb-3">
            <i data-lucide="file-text" class="w-5 h-5 text-green-600"></i>
            Certificate
          </h4>
          <div class="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4">
            <div class="flex items-center justify-between">
              <div>
                <p class="font-medium text-green-800">Certificate Issued</p>
                <p id="detailCertificateId" class="text-sm text-green-600 mt-1"></p>
              </div>
              <button onclick="viewCertificate()" 
                      class="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-medium text-sm flex items-center gap-2 hover:shadow-lg transition-all duration-200">
                <i data-lucide="eye" class="w-4 h-4"></i> View Certificate
              </button>
            </div>
          </div>
        </div>
        
        <!-- Actions -->
        <div class="pt-6 border-t border-gray-200">
          <div class="flex gap-3">
            <button onclick="markCompletedFromDetail()" id="markCompleteBtn"
                    class="flex-1 px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2">
              <i data-lucide="check" class="w-5 h-5"></i> Mark Complete
            </button>
            <button onclick="sendReminder()" 
                    class="flex-1 px-4 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2">
              <i data-lucide="bell" class="w-5 h-5"></i> Reminder
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Certificate View Panel -->
  <div id="certificateOverlay" class="overlay fixed inset-0 bg-black bg-opacity-70 z-[100]" onclick="closeCertificatePanel()"></div>
  
  <div id="certificatePanel" class="certificate-panel fixed inset-0 flex items-center justify-center p-4 z-[110]">
    <div class="w-full max-w-6xl h-full max-h-[90vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col">
      <div class="p-6 border-b border-gray-200 bg-white flex-shrink-0">
        <div class="flex items-center justify-between">
          <h2 class="text-2xl font-bold text-gray-900">Certificate of Completion</h2>
          <div class="flex gap-2">
            <button onclick="downloadCertificate()" 
                    class="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-500 hover:text-blue-600">
              <i data-lucide="download" class="w-6 h-6"></i>
            </button>
            <button onclick="printCertificate()" 
                    class="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-500 hover:text-blue-600">
              <i data-lucide="printer" class="w-6 h-6"></i>
            </button>
            <button onclick="closeCertificatePanel()" class="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <i data-lucide="x" class="w-6 h-6 text-gray-500"></i>
            </button>
          </div>
        </div>
      </div>
      
      <!-- Loading State -->
      <div id="certificateLoading" class="hidden text-center py-12 flex-grow flex items-center justify-center">
        <div class="text-center">
          <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p class="mt-4 text-gray-500">Loading certificate...</p>
        </div>
      </div>
      
      <!-- Certificate Content -->
      <div id="certificateContent" class="hidden flex-grow overflow-y-auto">
        <div class="p-6">
          <!-- Certificate Design -->
          <div class="max-w-3xl mx-auto border-4 border-yellow-400 bg-gradient-to-br from-yellow-50 to-amber-50 p-12 rounded-2xl shadow-2xl">
            <!-- Certificate Header -->
            <div class="text-center mb-12">
              <div class="flex justify-center mb-4">
                <div class="p-4 bg-yellow-100 rounded-full">
                  <i data-lucide="award" class="w-16 h-16 text-yellow-600"></i>
                </div>
              </div>
              <h1 class="text-5xl font-bold text-gray-900 mb-2">CERTIFICATE OF COMPLETION</h1>
              <div class="w-48 h-1 bg-gradient-to-r from-yellow-400 to-amber-500 mx-auto rounded-full mb-4"></div>
              <p class="text-xl text-gray-600">This is to certify that</p>
            </div>
            
            <!-- Recipient Name -->
            <div class="text-center mb-12">
              <h2 id="certEmployeeName" class="text-6xl font-bold text-gray-900 mb-4"></h2>
              <p class="text-xl text-gray-600">has successfully completed the training program</p>
            </div>
            
            <!-- Training Details -->
            <div class="text-center mb-12">
              <h3 id="certTrainingTitle" class="text-4xl font-bold text-blue-700 mb-4"></h3>
              <div class="grid grid-cols-3 gap-8 mb-8">
                <div class="text-center">
                  <div class="text-sm text-gray-500 mb-1">Training ID</div>
                  <div id="certTrainingId" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div class="text-center">
                  <div class="text-sm text-gray-500 mb-1">Duration</div>
                  <div id="certTrainingHours" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div class="text-center">
                  <div class="text-sm text-gray-500 mb-1">Score</div>
                  <div id="certTrainingScore" class="text-lg font-semibold text-gray-900"></div>
                </div>
              </div>
            </div>
            
            <!-- Certificate Info -->
            <div class="grid grid-cols-2 gap-12 mb-12">
              <div>
                <div class="mb-4">
                  <div class="text-sm text-gray-500 mb-1">Certificate ID</div>
                  <div id="certId" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div class="mb-4">
                  <div class="text-sm text-gray-500 mb-1">Issue Date</div>
                  <div id="certIssueDate" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div>
                  <div class="text-sm text-gray-500 mb-1">Department</div>
                  <div id="certDepartment" class="text-lg font-semibold text-gray-900"></div>
                </div>
              </div>
              <div>
                <div class="mb-4">
                  <div class="text-sm text-gray-500 mb-1">Trainer</div>
                  <div id="certTrainer" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div class="mb-4">
                  <div class="text-sm text-gray-500 mb-1">Location</div>
                  <div id="certLocation" class="text-lg font-semibold text-gray-900"></div>
                </div>
                <div>
                  <div class="text-sm text-gray-500 mb-1">Validity</div>
                  <div id="certValidity" class="text-lg font-semibold text-gray-900">Valid for 2 years</div>
                </div>
              </div>
            </div>
            
            <!-- Signatures -->
            <div class="grid grid-cols-3 gap-8 pt-8 border-t-2 border-gray-300">
              <div class="text-center">
                <div class="h-16 mb-2"></div>
                <div class="text-sm text-gray-500 mb-1">Trainer Signature</div>
                <div id="certTrainerName" class="font-semibold text-gray-900"></div>
              </div>
              <div class="text-center">
                <div class="flex justify-center mb-2">
                  <i data-lucide="badge-check" class="w-16 h-16 text-green-500"></i>
                </div>
                <div class="text-sm text-gray-500 mb-1">Verified & Approved</div>
                <div class="font-semibold text-gray-900">Training Department</div>
              </div>
              <div class="text-center">
                <div class="h-16 mb-2"></div>
                <div class="text-sm text-gray-500 mb-1">HR Department</div>
                <div class="font-semibold text-gray-900">Human Resources</div>
              </div>
            </div>
          </div>
          
          <!-- Certificate Details -->
          <div class="max-w-3xl mx-auto mt-8">
            <div class="glass-card rounded-2xl p-6 border border-gray-100">
              <h4 class="font-semibold text-gray-900 flex items-center gap-2 mb-4">
                <i data-lucide="info" class="w-5 h-5 text-blue-600"></i>
                Certificate Details
              </h4>
              <div class="grid grid-cols-3 gap-6">
                <div class="bg-gray-50 p-4 rounded-xl">
                  <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
                    <i data-lucide="shield" class="w-4 h-4"></i>
                    Security Features
                  </div>
                  <ul class="text-sm text-gray-700 space-y-1">
                    <li>• Unique Certificate ID</li>
                    <li>• Digital Verification Code</li>
                    <li>• QR Code Enabled</li>
                  </ul>
                </div>
                <div class="bg-gray-50 p-4 rounded-xl">
                  <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
                    <i data-lucide="download" class="w-4 h-4"></i>
                    Export Options
                  </div>
                  <div class="flex gap-2 mt-2">
                    <button onclick="downloadPDF()" class="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors">
                      <i data-lucide="file-text" class="w-4 h-4 inline mr-1"></i> PDF
                    </button>
                    <button onclick="downloadImage()" class="px-3 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors">
                      <i data-lucide="image" class="w-4 h-4 inline mr-1"></i> PNG
                    </button>
                  </div>
                </div>
                <div class="bg-gray-50 p-4 rounded-xl">
                  <div class="flex items-center gap-2 text-sm text-gray-500 mb-1">
                    <i data-lucide="share-2" class="w-4 h-4"></i>
                    Share Certificate
                  </div>
                  <div class="flex gap-2 mt-2">
                    <button onclick="shareCertificate('email')" class="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                      <i data-lucide="mail" class="w-4 h-4"></i>
                    </button>
                    <button onclick="shareCertificate('linkedin')" class="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                      <i data-lucide="linkedin" class="w-4 h-4"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

<script>
lucide.createIcons();

// Global variable to store training data from PHP
const trainingData = <?= json_encode($trainingData); ?>;
let currentTrainingId = null;
let filteredData = [...trainingData];

// Initialize table
document.addEventListener('DOMContentLoaded', function() {
    renderTable(trainingData);
    setupEventListeners();
});

function renderTable(data) {
    const tbody = document.getElementById('tableBody');
    const emptyState = document.getElementById('emptyState');
    const visibleCount = document.getElementById('visibleCount');
    
    tbody.innerHTML = '';
    visibleCount.textContent = data.length;
    
    if (data.length === 0) {
        emptyState.classList.remove('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    
    data.forEach(training => {
        const row = document.createElement('tr');
        row.className = 'table-row-hover hover:bg-gray-50 transition-colors';
        row.innerHTML = `
            <td class="py-4 px-6">
                <div class="font-semibold text-gray-900">TRAIN-${training.id.toString().padStart(4, '0')}</div>
            </td>
            <td class="py-4 px-6">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-full flex items-center justify-center">
                        <i data-lucide="user" class="w-5 h-5 text-blue-600"></i>
                    </div>
                    <div>
                        <div class="font-medium text-gray-900">${training.employee}</div>
                        <div class="text-sm text-gray-500">${training.department}</div>
                    </div>
                </div>
            </td>
            <td class="py-4 px-6">
                <div class="font-medium text-gray-900">${training.trainer}</div>
            </td>
            <td class="py-4 px-6">
                <div class="text-sm">
                    <div class="font-medium text-gray-900">${formatDate(training.start)} - ${formatDate(training.end)}</div>
                    <div class="text-gray-500">${calculateDaysRemaining(training.end)} days left</div>
                </div>
            </td>
            <td class="py-4 px-6">
                ${getStatusBadge(training.status)}
            </td>
            <td class="py-4 px-6">
                <div class="flex gap-2">
                    <button onclick="viewDetails(${training.id})" 
                            class="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg font-medium text-sm hover:bg-blue-100 transition-colors flex items-center gap-2">
                        <i data-lucide="eye" class="w-4 h-4"></i> View
                    </button>
                    <button onclick="markCompleted(${training.id})" 
                            class="px-4 py-2 bg-green-50 text-green-600 rounded-lg font-medium text-sm hover:bg-green-100 transition-colors flex items-center gap-2">
                        <i data-lucide="check" class="w-4 h-4"></i> Complete
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Refresh icons
    lucide.createIcons();
}

function setupEventListeners() {
    const searchInput = document.getElementById('searchEmployee');
    const statusFilter = document.getElementById('statusFilter');
    
    // Real-time search
    searchInput.addEventListener('input', function() {
        applyFilters();
    });
    
    // Status filter change
    statusFilter.addEventListener('change', function() {
        applyFilters();
    });
    
    // Apply filters button
    document.querySelector('button[onclick="applyFilters()"]').addEventListener('click', applyFilters);
}

function applyFilters() {
    const searchTerm = document.getElementById('searchEmployee').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    
    filteredData = trainingData.filter(training => {
        const matchesSearch = training.employee.toLowerCase().includes(searchTerm) ||
                            training.trainer.toLowerCase().includes(searchTerm) ||
                            training.department.toLowerCase().includes(searchTerm);
        
        const matchesStatus = !statusFilter || training.status === statusFilter;
        
        return matchesSearch && matchesStatus;
    });
    
    renderTable(filteredData);
}

function getStatusBadge(status) {
    const statusConfig = {
        'Completed': { color: 'bg-green-100 text-green-800', icon: 'check-circle' },
        'In Progress': { color: 'bg-amber-100 text-amber-800', icon: 'clock' },
        'Overdue': { color: 'bg-red-100 text-red-800', icon: 'alert-triangle' }
    };
    
    const config = statusConfig[status] || { color: 'bg-gray-100 text-gray-800', icon: 'help-circle' };
    
    return `
        <div class="status-badge ${config.color}">
            <i data-lucide="${config.icon}" class="w-3 h-3"></i>
            ${status}
        </div>
    `;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function calculateDaysRemaining(endDate) {
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
}

function viewDetails(trainingId) {
    currentTrainingId = trainingId;
    const training = trainingData.find(t => t.id === trainingId);
    
    if (!training) return;
    
    // Show loading
    document.getElementById('detailLoading').classList.remove('hidden');
    document.getElementById('detailContent').classList.add('hidden');
    
    // Open panel
    document.getElementById('detailPanel').classList.add('open');
    document.getElementById('detailOverlay').classList.add('active');
    
    // Set content after a brief delay for animation
    setTimeout(() => {
        populateDetailPanel(training);
        document.getElementById('detailLoading').classList.add('hidden');
        document.getElementById('detailContent').classList.remove('hidden');
    }, 300);
}

function populateDetailPanel(training) {
    // Basic info
    document.getElementById('detailId').textContent = `TRAIN-${training.id.toString().padStart(4, '0')}`;
    document.getElementById('detailTitle').textContent = training.description;
    document.getElementById('detailEmployee').textContent = training.employee;
    document.getElementById('detailTrainer').textContent = training.trainer;
    document.getElementById('detailDepartment').textContent = training.department;
    document.getElementById('detailLocation').textContent = training.location;
    document.getElementById('detailDescription').textContent = training.description;
    document.getElementById('detailHours').textContent = training.hours;
    document.getElementById('detailScore').textContent = training.score || 'N/A';
    
    // Dates
    document.getElementById('detailStart').textContent = formatDate(training.start);
    document.getElementById('detailEnd').textContent = formatDate(training.end);
    
    // Calculate progress
    const start = new Date(training.start);
    const end = new Date(training.end);
    const today = new Date();
    const totalDuration = end - start;
    const elapsed = today - start;
    const progress = Math.min(Math.max((elapsed / totalDuration) * 100, 0), 100);
    const daysLeft = calculateDaysRemaining(training.end);
    
    document.getElementById('detailProgressBar').style.width = `${progress}%`;
    document.getElementById('detailDaysLeft').textContent = daysLeft;
    
    // Status badge
    document.getElementById('detailStatusBadge').innerHTML = getStatusBadge(training.status);
    
    // Certificate section
    const certSection = document.getElementById('certificateSection');
    const markCompleteBtn = document.getElementById('markCompleteBtn');
    
    if (training.status === 'Completed' && training.certificate) {
        certSection.classList.remove('hidden');
        document.getElementById('detailCertificateId').textContent = training.certificate;
        markCompleteBtn.classList.add('hidden');
    } else {
        certSection.classList.add('hidden');
        markCompleteBtn.classList.remove('hidden');
        markCompleteBtn.disabled = training.status === 'Completed';
    }
}

function closeDetailPanel() {
    document.getElementById('detailPanel').classList.remove('open');
    document.getElementById('detailOverlay').classList.remove('active');
    currentTrainingId = null;
}

function markCompleted(trainingId) {
    if (confirm('Mark this training as completed?')) {
        // Find training
        const index = trainingData.findIndex(t => t.id === trainingId);
        if (index !== -1) {
            // Update status
            trainingData[index].status = 'Completed';
            
            // Add certificate
            trainingData[index].certificate = `CERT-${trainingId}-${new Date().getFullYear()}`;
            
            // Add random score
            trainingData[index].score = Math.floor(Math.random() * 30) + 70;
            
            // Re-render table
            renderTable(filteredData);
            
            // Show success message
            showNotification('Training marked as completed!', 'success');
            
            // Update stats
            updateStatistics();
            
            // If detail panel is open for this training, refresh it
            if (currentTrainingId === trainingId) {
                populateDetailPanel(trainingData[index]);
            }
        }
    }
}

function markCompletedFromDetail() {
    if (currentTrainingId) {
        markCompleted(currentTrainingId);
    }
}

function sendReminder() {
    if (currentTrainingId) {
        const training = trainingData.find(t => t.id === currentTrainingId);
        if (training) {
            showNotification(`Reminder sent to ${training.employee}`, 'info');
        }
    }
}

function viewCertificate() {
    if (!currentTrainingId) return;
    
    const training = trainingData.find(t => t.id === currentTrainingId);
    if (!training || !training.certificate) return;
    
    // First close the detail panel
    closeDetailPanel();
    
    // Show loading
    document.getElementById('certificateLoading').classList.remove('hidden');
    document.getElementById('certificateContent').classList.add('hidden');
    
    // Open panel
    document.getElementById('certificatePanel').classList.add('open');
    document.getElementById('certificateOverlay').classList.add('active');
    
    // Populate certificate data after delay
    setTimeout(() => {
        populateCertificate(training);
        document.getElementById('certificateLoading').classList.add('hidden');
        document.getElementById('certificateContent').classList.remove('hidden');
    }, 500);
}

function populateCertificate(training) {
    document.getElementById('certEmployeeName').textContent = training.employee;
    document.getElementById('certTrainingTitle').textContent = training.description;
    document.getElementById('certTrainingId').textContent = `TRAIN-${training.id.toString().padStart(4, '0')}`;
    document.getElementById('certTrainingHours').textContent = `${training.hours} hours`;
    document.getElementById('certTrainingScore').textContent = training.score || 'N/A';
    document.getElementById('certId').textContent = training.certificate;
    document.getElementById('certIssueDate').textContent = formatDate(new Date());
    document.getElementById('certDepartment').textContent = training.department;
    document.getElementById('certTrainer').textContent = training.trainer;
    document.getElementById('certTrainerName').textContent = training.trainer;
    document.getElementById('certLocation').textContent = training.location;
}

function closeCertificatePanel() {
    document.getElementById('certificatePanel').classList.remove('open');
    document.getElementById('certificateOverlay').classList.remove('active');
}

function downloadCertificate() {
    showNotification('Certificate download started!', 'success');
    // In a real app, this would generate and download a PDF
}

function printCertificate() {
    window.print();
}

function downloadPDF() {
    showNotification('PDF generation in progress...', 'info');
}

function downloadImage() {
    showNotification('Image download started!', 'success');
}

function shareCertificate(platform) {
    const message = platform === 'email' 
        ? 'Certificate shared via email!' 
        : 'Certificate shared on LinkedIn!';
    showNotification(message, 'info');
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-[150] px-6 py-4 rounded-xl shadow-lg animate-fadeIn ${type === 'success' ? 'bg-green-500' : 'bg-blue-500'} text-white`;
    notification.innerHTML = `
        <div class="flex items-center gap-3">
            <i data-lucide="${type === 'success' ? 'check-circle' : 'info'}" class="w-5 h-5"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    lucide.createIcons();
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function updateStatistics() {
    // Recalculate statistics
    const totalTrainings = trainingData.length;
    const completedCount = trainingData.filter(t => t.status === 'Completed').length;
    const inProgressCount = trainingData.filter(t => t.status === 'In Progress').length;
    const overdueCount = trainingData.filter(t => t.status === 'Overdue').length;
    
    // Update DOM elements (you might need to add IDs to your stat cards)
    const statElements = document.querySelectorAll('.text-2xl');
    if (statElements.length >= 4) {
        statElements[0].textContent = totalTrainings;
        statElements[1].textContent = completedCount;
        statElements[2].textContent = inProgressCount;
        statElements[3].textContent = overdueCount;
    }
}
</script>
</body>
</html>