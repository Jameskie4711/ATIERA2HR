<?php include('../session_check.php'); ?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- Sample data ---
$trainers = [
  [ "name" => "Mr. Lopez", "role" => "Team Lead Trainer", "trainees" => 2 ],
  [ "name" => "Ms. Garcia", "role" => "Engineering Trainer", "trainees" => 0 ],
  [ "name" => "Dr. Santos", "role" => "Finance Trainer", "trainees" => 1 ],
  [ "name" => "Ms. Reyes", "role" => "HR Trainer", "trainees" => 0 ]
];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Trainer Availability — Kanban</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 font-sans min-h-screen flex">

  <!-- Sidebar -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
<main class="p-4 space-y-8 max-w-7xl mx-auto w-full">

    <!-- Header / Profile -->
      <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h2 class="text-2xl font-extrabold text-gray-800 flex items-center gap-2">Availability</h2>
          </div>
          <?php include '../profile.php'; ?>
        </div>

<div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
  <a href="/training/trainings.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3M4 11h16M6 19h12a2 2 0 002-2V7a2 2 0 00-2-2H6a2 2 0 00-2 2v10a2 2 0 002 2z"/>
    </svg>
    Training
  </a>

  <a href="/training/avail.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
    </svg>
    Availability
  </a>

  <a href="/training/trainer.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a4 4 0 00-4-4h-1M9 20H4v-2a4 4 0 014-4h1m4-4a4 4 0 100-8 4 4 0 000 8zm6 4a3 3 0 100-6 3 3 0 000 6z"/>
    </svg>
    Trainers
  </a>

  <a href="/training/trainhistory.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
    </svg>
    History
  </a>
</div>




    <!-- Board -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">

      <!-- Available Column -->
      <section class="bg-white p-4 rounded-lg shadow">
        <div class="flex items-center justify-between mb-3">
          <h2 class="font-semibold">Available</h2>
          <span id="countAvailable" class="text-slate-400 text-sm"></span>
        </div>
        <div id="colAvailable" class="space-y-3 min-h-[120px]"></div>
      </section>

      <!-- Busy Column -->
      <section class="bg-white p-4 rounded-lg shadow">
        <div class="flex items-center justify-between mb-3">
          <h2 class="font-semibold">Busy</h2>
          <span id="countBusy" class="text-slate-400 text-sm"></span>
        </div>
        <div id="colBusy" class="space-y-3 min-h-[120px]"></div>
      </section>

    </div>
  </main>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

<script>
const trainers = <?= json_encode($trainers); ?>;

const colAvailable = document.getElementById("colAvailable");
const colBusy = document.getElementById("colBusy");
const countAvailable = document.getElementById("countAvailable");
const countBusy = document.getElementById("countBusy");

function renderBoard() {
  colAvailable.innerHTML = '';
  colBusy.innerHTML = '';

  let available = 0, busy = 0;

  trainers.forEach(trainer => {
    const card = document.createElement("div");
    card.className = 'bg-slate-50 border rounded-lg p-3 shadow-sm flex items-start justify-between';
    const status = trainer.trainees === 0 ? "Available" : "Busy";

    card.innerHTML = `
      <div>
        <div class="font-medium">${trainer.name}</div>
        <div class="text-xs text-slate-500">${trainer.role}</div>
        ${status === "Busy" ? `<div class="text-xs text-red-600 mt-1">${trainer.trainees} trainee${trainer.trainees > 1 ? 's' : ''}</div>` : ''}
      </div>
    `;

    if(status === "Available"){
      colAvailable.appendChild(card);
      available++;
    } else {
      colBusy.appendChild(card);
      busy++;
    }
  });

  countAvailable.textContent = `(${available})`;
  countBusy.textContent = `(${busy})`;
}

renderBoard();
</script>
</body>
</html>
