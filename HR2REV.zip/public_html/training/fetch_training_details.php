<?php
// fetch_training_details.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');
include('../session_check.php');
header('Content-Type: application/json');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid ID"]);
    exit;
}

try {
    // 1️⃣ Fetch training_assigned record
    $stmt = $conn->prepare("
        SELECT 
            id,
            employee_name,
            role,
            department,
            assigned_date,
            status,
            trainer_name
        FROM training_assigned
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "Training not found"]);
        exit;
    }

    $training = $result->fetch_assoc();

    // 2️⃣ If trainer_name is empty, automatically assign a trainer
    if (empty($training['trainer_name'])) {
        $conn->begin_transaction();

        // Find available trainer
        $stmt2 = $conn->prepare("
            SELECT id, employee_name, current_load, max_load
            FROM trainers
            WHERE current_load < max_load AND is_active = 1
            ORDER BY current_load ASC, next_available ASC
            LIMIT 1
        ");
        $stmt2->execute();
        $trainer = $stmt2->get_result()->fetch_assoc();

        if ($trainer) {
            // Update training_assigned with trainer
            $stmt3 = $conn->prepare("
                UPDATE training_assigned
                SET trainer_name = ?, status = 'Assigned', assigned_date = NOW()
                WHERE id = ?
            ");
            $stmt3->bind_param("si", $trainer['employee_name'], $id);
            $stmt3->execute();

            // Update trainer load
            $stmt4 = $conn->prepare("
                UPDATE trainers
                SET current_load = current_load + 1, last_assigned = NOW()
                WHERE id = ?
            ");
            $stmt4->bind_param("i", $trainer['id']);
            $stmt4->execute();

            $conn->commit();

            // Refresh training data
            $training['trainer_name'] = $trainer['employee_name'];
            $training['status'] = 'Assigned';
            $training['assigned_date'] = date("Y-m-d H:i:s");
        } else {
            $conn->rollback();
            $training['trainer_name'] = 'No available trainer';
        }
    }

    echo json_encode([
        "status" => "success",
        "data" => $training
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
} finally {
    $conn->close();
}
