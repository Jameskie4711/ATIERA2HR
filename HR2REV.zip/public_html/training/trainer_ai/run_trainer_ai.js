const { selectBestTrainer } = require('./trainer_ai');

const input = JSON.parse(process.argv[2]);
const trainer = selectBestTrainer(input.trainers, input.trainee);

console.log(JSON.stringify(trainer));
