/**
 * trainer_ai.js
 * LibTorch-style AI logic implemented in JavaScript
 * Matches hr2_competency database EXACTLY
 */

/* ============================
   Tensor Utilities (Torch-like)
============================ */

class Tensor {
  constructor(values) {
    this.values = values.map(v => Number(v) || 0);
  }

  dot(other) {
    return this.values.reduce((sum, v, i) => sum + v * other.values[i], 0);
  }

  static softmax(scores) {
    const max = Math.max(...scores);
    const exps = scores.map(s => Math.exp(s - max));
    const sum = exps.reduce((a, b) => a + b, 0);
    return exps.map(e => e / sum);
  }
}

/* ============================
   Feature Engineering
============================ */

function encodeTrainer(trainer, trainee) {
  const loadRatio = trainer.max_load > 0 ? trainer.current_load / trainer.max_load : 1;

  return new Tensor([
    loadRatio,                                                // Load ratio
    (trainer.rating || 0) / 5,                                // Rating score
    (trainer.experience_years || 0) / 20,                     // Experience
    trainer.is_active ? 1 : 0,                                 // Active flag
    trainer.departments?.includes(trainee.department) ? 1 : 0, // Dept match
    trainer.specialization === trainee.role ? 1 : 0            // Role match
  ]);
}

/* ============================
   AI Model (Linear Scoring)
============================ */

const WEIGHTS = new Tensor([
  -2.5,  // penalize high load
   3.0,  // rating importance
   2.0,  // experience
   4.0,  // active trainer
   3.5,  // department match
   3.0   // role match
]);

/* ============================
   Main Inference Function
============================ */

/**
 * AI Trainer Selection
 * @param {Array} trainers
 * @param {Object} trainee
 * @returns {Object|null}
 */
function selectBestTrainer(trainers, trainee) {
  if (!trainers || trainers.length === 0) return null;

  const scores = [];
  const featureBreakdown = [];

  trainers.forEach(trainer => {
    // Skip overloaded or inactive trainers
    if (!trainer.is_active || trainer.current_load >= trainer.max_load) {
      scores.push(-Infinity);
      featureBreakdown.push(null);
      return;
    }

    const tVec = encodeTrainer(trainer, trainee);
    const score = tVec.dot(WEIGHTS);
    scores.push(score);

    // Explainable AI breakdown
    featureBreakdown.push({
      load_score: (trainer.current_load / trainer.max_load) * WEIGHTS.values[0],
      rating_score: ((trainer.rating || 0) / 5) * WEIGHTS.values[1],
      experience_score: ((trainer.experience_years || 0) / 20) * WEIGHTS.values[2],
      active_score: (trainer.is_active ? 1 : 0) * WEIGHTS.values[3],
      dept_score: (trainer.departments?.includes(trainee.department) ? 1 : 0) * WEIGHTS.values[4],
      role_score: (trainer.specialization === trainee.role ? 1 : 0) * WEIGHTS.values[5]
    });
  });

  const probs = Tensor.softmax(scores);
  const bestIndex = probs.indexOf(Math.max(...probs));
  const bestTrainer = trainers[bestIndex];

  if (!bestTrainer || scores[bestIndex] === -Infinity) return null;

  return {
    id: bestTrainer.id,
    employee_name: bestTrainer.employee_name,
    score: Number(scores[bestIndex].toFixed(2)),
    confidence: Number(probs[bestIndex].toFixed(4)),
    reasoning: featureBreakdown[bestIndex]
  };
}

/* ============================
   EXPORT (Node / Browser safe)
============================ */

if (typeof module !== "undefined") {
  module.exports = { selectBestTrainer };
}
