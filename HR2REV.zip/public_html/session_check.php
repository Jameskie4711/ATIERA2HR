<?php
// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Session timeout (15 minutes)
$timeout_duration = 900;

// Get current file
$current_page = basename($_SERVER['SCRIPT_NAME']);

// Public pages (no login required)
$public_pages = ['login.php', 'register.php', 'forgot_password.php', 'sso_login.php'];

// Skip checks for public pages
if (!in_array($current_page, $public_pages, true)) {

    // 🔐 Check if user is logged in (supports BOTH systems)
    $loggedIn =
        (isset($_SESSION['hr_user']) && !empty($_SESSION['hr_user']['id'])) ||
        (isset($_SESSION['user_id']) && !empty($_SESSION['user_id']));

    if (!$loggedIn) {
        if ($current_page !== 'login.php') {
            header("Location: /login.php");
            exit;
        }
    }

    // ⏳ Session timeout
    if (isset($_SESSION['last_activity']) &&
        (time() - $_SESSION['last_activity']) > $timeout_duration) {

        session_unset();
        session_destroy();
        header("Location: /login.php?timeout=1");
        exit;
    }

    // Refresh activity timestamp
    $_SESSION['last_activity'] = time();
}
?>
