<?php
session_start();
include('dblogin.php');
require_once __DIR__ . '/PHPGangsta/GoogleAuthenticator.php';

$ga = new PHPGangsta_GoogleAuthenticator();

// Ensure pending user session
if (!isset($_SESSION['pending_user_id']) || $_SESSION['pending_user_role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['pending_user_id'];

// Get or create MFA secret
$stmt = $conn->prepare("SELECT mfa_secret, mfa_enabled FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($secret, $enabled);
$stmt->fetch();
$stmt->close();

if (!$secret) {
    $secret = $ga->createSecret();
    $stmt = $conn->prepare("UPDATE users SET mfa_secret = ? WHERE id = ?");
    $stmt->bind_param("si", $secret, $user_id);
    $stmt->execute();
    $stmt->close();
}

$qrCodeUrl = $ga->getQRCodeGoogleUrl('ATIERA User', $secret);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User MFA Setup — ATIERA</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full bg-white p-6 rounded shadow">
        <h2 class="text-xl font-bold mb-4 text-center text-blue-700">Enable Multi-Factor Authentication</h2>
        <p class="mb-2 text-gray-700 text-center">Scan this QR code using your Google Authenticator app:</p>

        <div class="flex justify-center mb-4">
            <img src="<?= $qrCodeUrl ?>" alt="MFA QR Code">
        </div>

        <p class="text-center mb-4 text-gray-700">Or use this code manually:</p>
        <p class="text-center font-mono text-lg mb-4"><?= htmlspecialchars($secret) ?></p>

        <form method="POST" action="mfa_verify_setup.php" class="text-center">
            <input type="text" name="otp" placeholder="Enter code from app"
                   class="border p-2 rounded w-full mb-4 text-center" required>
            <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Verify & Enable MFA
            </button>
        </form>
    </div>
</body>
</html>
