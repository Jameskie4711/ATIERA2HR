<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Detect current file for active highlighting
$currentPage = basename($_SERVER['PHP_SELF']);
$currentUri = $_SERVER['REQUEST_URI'];
?>

<!-- Sidebar -->
<div id="sidebar"
     class="bg-gray-800 text-white w-64 transition-all duration-300 flex flex-col overflow-y-auto">

  <!-- Logo & Toggle -->
  <div class="flex items-center justify-between px-4 py-4 border-b border-gray-700 shrink-0">
    <img src="/logo.png" alt="Logo" class="h-14 sidebar-logo-expanded" />
    <img src="/logo2.png" alt="Logo" class="h-14 sidebar-logo-collapsed hidden" />

    <button id="sidebar-toggle" class="text-white focus:outline-none">
      <i data-lucide="chevron-left" class="w-5 h-5 transition-transform"></i>
    </button>
  </div>



  <!-- Navigation -->
  <nav class="flex-1 px-2 py-4 space-y-2 overflow-y-auto">

    <!-- Dashboard -->
    <a href="/index.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= ($currentPage === 'index.php' || $currentUri === '/') ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="home" class="w-5 h-5"></i>
      <span class="sidebar-text">Dashboard</span>
    </a>

    <!-- Competency Management -->
    <a href="/competencies/competencies.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= (strpos($currentUri, '/competencies') !== false) ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="badge-check" class="w-5 h-5"></i>
      <span class="sidebar-text">Competency Management</span>
    </a>

    <!-- Learning Management -->
    <a href="/learning/learning.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= (strpos($currentUri, '/learning') !== false) ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="book-open" class="w-5 h-5"></i>
      <span class="sidebar-text">Learning Management</span>
    </a>

    <!-- Training Management -->
    <a href="/training/trainings.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= (strpos($currentUri, '/training') !== false) ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="graduation-cap" class="w-5 h-5"></i>
      <span class="sidebar-text">Training Management</span>
    </a>

    <!-- Succession Planning -->
    <a href="/succession/succession.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= (strpos($currentUri, '/succession') !== false) ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="git-branch" class="w-5 h-5"></i>
      <span class="sidebar-text">Succession Planning</span>
    </a>

    <!-- Employee Self-Service -->
    <a href="/ess/ess_admin.php"
       class="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700 <?= (strpos($currentUri, '/ess') !== false) ? 'bg-gray-700 text-white' : '' ?>">
      <i data-lucide="user" class="w-5 h-5"></i>
      <span class="sidebar-text">Employee Self-Service</span>
    </a>

  </nav>
</div>

<!-- Lucide Icons and Sidebar Toggle Script -->
<script src="https://unpkg.com/lucide@latest"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("sidebar-toggle");
  const sidebar = document.getElementById("sidebar");
  const logoExpanded = document.querySelector(".sidebar-logo-expanded");
  const logoCollapsed = document.querySelector(".sidebar-logo-collapsed");
  const sidebarText = document.querySelectorAll(".sidebar-text");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("w-64");
    sidebar.classList.toggle("w-20");
    sidebar.classList.toggle("overflow-hidden");

    // Toggle logos
    logoExpanded.classList.toggle("hidden");
    logoCollapsed.classList.toggle("hidden");

    // Toggle text visibility
    sidebarText.forEach(el => el.classList.toggle("hidden"));

    // Rotate the toggle icon
    toggleBtn.querySelector("i")?.classList.toggle("rotate-180");
  });

  lucide.createIcons();
});
</script>
