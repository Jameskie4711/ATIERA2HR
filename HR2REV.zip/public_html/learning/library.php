<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Modules - Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/lucide@latest/dist/lucide.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    transition: all 0.3s ease;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
  }
  
  .btn-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
  }
  
  .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  
  .btn-danger {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    transition: all 0.3s ease;
  }
  
  .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95) translateY(10px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
  }
  
  .animate-fadeIn {
    animation: fadeIn 0.3s ease-out forwards;
  }
  
  .department-tag {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
  }
</style>
</head>
<body class="min-h-screen flex">

<?php include '../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-y-auto">
<main class="p-6 space-y-6 max-w-7xl mx-auto w-full">

<!-- Enhanced Header -->
<div class="flex items-center justify-between">
    <div class="flex items-center gap-4">
        <div class="p-3 rounded-xl bg-gradient-to-br from-green-50 to-emerald-50">
            <i data-lucide="book-open" class="w-7 h-7 text-green-600"></i>
        </div>
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Learning Library</h1>
            <p class="text-sm text-gray-500">Manage learning modules and course materials</p>
        </div>
    </div>
    <?php include '../profile.php'; ?>
</div>

<!-- Top Tabs -->
<div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
    <a href="/learning/learning.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
        <i data-lucide="users" class="w-4 h-4"></i> Employees
    </a>
    <a href="/learning/library.php" class="bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
        <i data-lucide="book" class="w-4 h-4"></i> Libraries
    </a>
    <a href="/learning/track_course.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
        <i data-lucide="clipboard-list" class="w-4 h-4"></i> Track Courses
    </a>
</div>

<!-- Stats Cards -->
<?php
$totalModules = $conn->query("SELECT COUNT(*) as count FROM library_modules")->fetch_assoc()['count'] ?? 0;
$recentModules = $conn->query("SELECT COUNT(*) as count FROM library_modules WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'] ?? 0;
$departments = $conn->query("SELECT COUNT(DISTINCT department) as count FROM library_modules")->fetch_assoc()['count'] ?? 0;
?>
<div class="grid grid-cols-3 gap-4">
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Modules</p>
                <p class="text-2xl font-bold text-gray-900"><?= $totalModules ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
                <i data-lucide="layers" class="w-6 h-6 text-blue-600"></i>
            </div>
        </div>
    </div>
    
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Recent (7 Days)</p>
                <p class="text-2xl font-bold text-gray-900"><?= $recentModules ?></p>
            </div>
            <div class="p-3 bg-green-50 rounded-xl">
                <i data-lucide="clock" class="w-6 h-6 text-green-600"></i>
            </div>
        </div>
    </div>
    
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Departments</p>
                <p class="text-2xl font-bold text-gray-900"><?= $departments ?></p>
            </div>
            <div class="p-3 bg-purple-50 rounded-xl">
                <i data-lucide="briefcase" class="w-6 h-6 text-purple-600"></i>
            </div>
        </div>
    </div>
</div>

<!-- Action Bar -->
<div class="glass-card rounded-2xl p-4 border border-gray-100">
    <div class="flex flex-col lg:flex-row items-center justify-between gap-4">
        <!-- Filters -->
        <div class="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
            <div class="relative w-full sm:w-48">
                <i data-lucide="filter" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                <select id="departmentSelect" onchange="filterModules()" 
                        class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
                    <option value="">All Departments</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="hotel">Hotel</option>
                    <option value="logistics">Logistics</option>
                    <option value="hr">Human Resource</option>
                    <option value="finance">Finance</option>
                    <option value="admin">Administrative</option>
                </select>
            </div>
            
            <div class="relative w-full sm:w-64">
                <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                <input type="text" id="moduleSearch" placeholder="Search modules by name..." onkeyup="filterModules()"
                       class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
            </div>
        </div>
        
        <!-- Add Module Button -->
        <button onclick="openAddModal()" class="btn-success px-6 py-3 rounded-xl text-white font-medium flex items-center gap-2 whitespace-nowrap">
            <i data-lucide="plus" class="w-4 h-4"></i> Add New Module
        </button>
    </div>
</div>

<!-- Modules Grid -->
<div id="moduleGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
<?php
$result = $conn->query("SELECT * FROM library_modules ORDER BY id DESC");
if ($result && $result->num_rows > 0):
    while ($row = $result->fetch_assoc()):
        $module_name = htmlspecialchars($row['module_name'] ?? 'N/A');
        $department  = htmlspecialchars($row['department'] ?? 'N/A');
        $deadline    = !empty($row['deadline']) ? date('M d, Y', strtotime($row['deadline'])) : '-';
        $attachment  = $row['attachment'] ?? '';
        $created_at  = !empty($row['created_at']) ? date('M d, Y', strtotime($row['created_at'])) : '-';
        
        // Department colors
        $deptColors = [
            'restaurant' => 'from-orange-50 to-red-50 border-orange-100',
            'hotel' => 'from-blue-50 to-indigo-50 border-blue-100',
            'logistics' => 'from-green-50 to-emerald-50 border-green-100',
            'hr' => 'from-purple-50 to-pink-50 border-purple-100',
            'finance' => 'from-amber-50 to-yellow-50 border-amber-100',
            'admin' => 'from-gray-50 to-slate-50 border-gray-100'
        ];
        $deptColor = $deptColors[strtolower($department)] ?? $deptColors['admin'];
        
        // Department tag colors
        $deptTagColors = [
            'restaurant' => 'bg-orange-100 text-orange-800',
            'hotel' => 'bg-blue-100 text-blue-800',
            'logistics' => 'bg-green-100 text-green-800',
            'hr' => 'bg-purple-100 text-purple-800',
            'finance' => 'bg-amber-100 text-amber-800',
            'admin' => 'bg-gray-100 text-gray-800'
        ];
        $deptTagColor = $deptTagColors[strtolower($department)] ?? $deptTagColors['admin'];
?>
<div class="highlight-card glass-card rounded-2xl p-6 border border-gray-100 animate-fadeIn cursor-pointer"
     onclick="openUploadModal(<?= $row['id'] ?>)">
    
    <!-- Module Header -->
    <div class="flex items-start justify-between mb-4">
        <div>
            <div class="flex items-center gap-2 mb-2">
                <div class="p-2 bg-gradient-to-br <?= $deptColor ?> rounded-lg">
                    <i data-lucide="book-open" class="w-5 h-5 text-gray-700"></i>
                </div>
                <span class="department-tag <?= $deptTagColor ?>">
                    <?= $department ?>
                </span>
            </div>
            <h3 class="text-lg font-bold text-gray-900 module-name"><?= $module_name ?></h3>
        </div>
        <div class="text-xs text-gray-500 text-right">
            <div>Added</div>
            <div class="font-medium"><?= $created_at ?></div>
        </div>
    </div>
    
    <!-- Module Details -->
    <div class="space-y-3 mb-6">
        <div class="flex items-center gap-2 text-sm">
            <i data-lucide="calendar" class="w-4 h-4 text-gray-400"></i>
            <span class="text-gray-600">Deadline:</span>
            <span class="font-medium text-gray-900"><?= $deadline ?></span>
        </div>
        
        <?php if($attachment): ?>
        <div class="flex items-center gap-2 text-sm">
            <i data-lucide="paperclip" class="w-4 h-4 text-gray-400"></i>
            <span class="text-gray-600">Attachment:</span>
            <a href="uploads/<?= $attachment ?>" target="_blank" 
               class="text-blue-600 hover:text-blue-800 font-medium transition-colors">
               View File
            </a>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-sm">
            <i data-lucide="file" class="w-4 h-4 text-gray-400"></i>
            <span class="text-gray-500 italic">No attachment</span>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Action Button -->
    <div class="flex justify-end">
        <button onclick="event.stopPropagation(); deleteModule(<?= $row['id'] ?>, '<?= addslashes($module_name) ?>')"
                class="btn-danger px-4 py-2 rounded-lg text-white text-sm font-medium flex items-center gap-2">
            <i data-lucide="trash-2" class="w-4 h-4"></i> Delete
        </button>
    </div>
</div>
<?php endwhile; else: ?>
<div class="col-span-full text-center py-12">
    <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
        <i data-lucide="book-open" class="w-8 h-8 text-gray-400"></i>
    </div>
    <h3 class="text-lg font-medium text-gray-700 mb-2">No Learning Modules</h3>
    <p class="text-gray-500 max-w-md mx-auto mb-6">
        No learning modules have been created yet. Click "Add New Module" to create your first module.
    </p>
    <button onclick="openAddModal()" class="btn-success px-6 py-3 rounded-xl text-white font-medium flex items-center gap-2 mx-auto">
        <i data-lucide="plus" class="w-4 h-4"></i> Create First Module
    </button>
</div>
<?php endif; ?>
</div>

</main>
</div>

<!-- Add Module Modal -->
<div id="moduleModal" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-full max-w-md p-8 shadow-2xl animate-fadeIn">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
                <div class="p-2 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
                    <i data-lucide="plus" class="w-5 h-5 text-green-600"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-900">Create New Module</h2>
                    <p class="text-sm text-gray-500">Add a learning module to the library</p>
                </div>
            </div>
            <button onclick="closeModal()" class="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <i data-lucide="x" class="w-5 h-5 text-gray-500"></i>
            </button>
        </div>
        
        <form id="moduleForm" class="space-y-4">
            <div class="space-y-2">
                <label for="moduleName" class="block text-sm font-medium text-gray-700">Module Name</label>
                <input type="text" name="module_name" id="moduleName" required
                       class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                       placeholder="Enter module name">
            </div>

            <div class="space-y-2">
                <label for="modalDepartment" class="block text-sm font-medium text-gray-700">Department</label>
                <select name="department" id="modalDepartment" required
                        class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
                    <option value="" disabled selected>Select Department</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="hotel">Hotel</option>
                    <option value="logistics">Logistics</option>
                    <option value="hr">Human Resource</option>
                    <option value="finance">Finance</option>
                    <option value="admin">Administrative</option>
                </select>
            </div>

            <div class="space-y-2">
                <label for="moduleDeadline" class="block text-sm font-medium text-gray-700">Deadline (Optional)</label>
                <input type="date" name="deadline" id="moduleDeadline"
                       class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
            </div>

            <div class="flex gap-3 pt-4">
                <button type="button" onclick="closeModal()" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                    Cancel
                </button>
                <button type="submit" 
                        class="flex-1 btn-success px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                    <i data-lucide="save" class="w-4 h-4"></i> Create Module
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Upload Attachment Modal -->
<div id="uploadModal" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-full max-w-md p-8 shadow-2xl animate-fadeIn">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
                <div class="p-2 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
                    <i data-lucide="upload" class="w-5 h-5 text-blue-600"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-900">Upload Attachment</h2>
                    <p class="text-sm text-gray-500">Add course material to module</p>
                </div>
            </div>
            <button onclick="closeUploadModal()" class="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <i data-lucide="x" class="w-5 h-5 text-gray-500"></i>
            </button>
        </div>
        
        <form id="uploadForm" class="space-y-4" enctype="multipart/form-data">
            <input type="hidden" name="module_id" id="uploadModuleId">
            <div class="space-y-2">
                <label for="moduleFile" class="block text-sm font-medium text-gray-700">Choose File</label>
                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-500 transition-colors">
                    <i data-lucide="upload-cloud" class="w-12 h-12 text-gray-400 mx-auto mb-3"></i>
                    <p class="text-sm text-gray-500 mb-2">Drag & drop or click to browse</p>
                    <p class="text-xs text-gray-400 mb-4">Supports PDF, DOC, DOCX, TXT, XLSX (Max: 10MB)</p>
                    <input type="file" name="module_file" id="moduleFile" required
                           class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                           accept=".pdf,.doc,.docx,.txt,.xlsx,.xls">
                </div>
            </div>
            <div class="flex gap-3 pt-4">
                <button type="button" onclick="closeUploadModal()" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                    Cancel
                </button>
                <button type="submit" 
                        class="flex-1 btn-primary px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                    <i data-lucide="upload" class="w-4 h-4"></i> Upload File
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div id="deleteModal" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-full max-w-md p-8 shadow-2xl animate-fadeIn text-center">
        <div class="mx-auto w-16 h-16 bg-gradient-to-br from-red-50 to-pink-50 rounded-full flex items-center justify-center mb-4">
            <i data-lucide="alert-triangle" class="w-8 h-8 text-red-600"></i>
        </div>
        <h2 class="text-xl font-bold text-gray-900 mb-2">Confirm Deletion</h2>
        <p id="deleteMessage" class="text-gray-600 mb-2">Are you sure you want to delete this module?</p>
        <p class="text-sm text-gray-500 mb-6">This action cannot be undone.</p>
        <div class="flex gap-3">
            <button onclick="closeDeleteModal()" 
                    class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
            <button id="confirmDeleteBtn" 
                    class="flex-1 btn-danger px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                <i data-lucide="trash-2" class="w-4 h-4"></i> Delete Module
            </button>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl px-8 py-6 flex flex-col items-center gap-4">
        <div class="relative">
            <div class="w-16 h-16 border-4 border-green-100 rounded-full"></div>
            <div class="w-16 h-16 border-4 border-transparent border-t-green-600 rounded-full animate-spin absolute top-0 left-0"></div>
        </div>
        <div class="text-center">
            <p class="font-medium text-gray-800">Processing Request</p>
            <p class="text-sm text-gray-500 mt-1">Please wait...</p>
        </div>
    </div>
</div>

<script>
lucide.createIcons();

// Open/close modals
function openAddModal(){ 
    document.getElementById("moduleForm").reset(); 
    document.getElementById("moduleModal").classList.remove("hidden"); 
}
function closeModal(){ 
    document.getElementById("moduleModal").classList.add("hidden"); 
}
function openUploadModal(id){ 
    document.getElementById("uploadModuleId").value = id; 
    document.getElementById("uploadModal").classList.remove("hidden"); 
}
function closeUploadModal(){ 
    document.getElementById("uploadForm").reset();
    document.getElementById("uploadModal").classList.add("hidden"); 
}

// Loading functions
function showLoading() {
    document.getElementById('loadingOverlay').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hidden');
}

// Add Module Form
document.getElementById("moduleForm").addEventListener("submit", function(e){
    e.preventDefault();
    showLoading();
    
    const formData = new FormData(this);
    fetch("add_module.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        hideLoading();
        if(data.trim() === "success"){
            closeModal();
            location.reload();
        } else {
            alert("Error: " + data);
        }
    })
    .catch(error => {
        hideLoading();
        alert("Failed to create module. Please try again.");
        console.error(error);
    });
});

// Upload Attachment Form
document.getElementById("uploadForm").addEventListener("submit", function(e){
    e.preventDefault();
    showLoading();
    
    const formData = new FormData(this);
    fetch("upload_attachment.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        hideLoading();
        if(data.trim() === "success"){
            closeUploadModal();
            location.reload();
        } else {
            alert("Error: " + data);
        }
    })
    .catch(error => {
        hideLoading();
        alert("Failed to upload attachment. Please try again.");
        console.error(error);
    });
});

// Delete Module
let moduleToDelete = null;
function deleteModule(id, moduleName){
    moduleToDelete = id;
    const deleteMessage = document.getElementById("deleteMessage");
    deleteMessage.textContent = `Are you sure you want to delete "${moduleName}"?`;
    document.getElementById("deleteModal").classList.remove("hidden");
}

function closeDeleteModal(){
    moduleToDelete = null;
    document.getElementById("deleteModal").classList.add("hidden");
}

document.getElementById("confirmDeleteBtn").addEventListener("click", function(){
    if(!moduleToDelete) return;
    
    showLoading();
    
    fetch("delete_module.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: "id=" + moduleToDelete
    })
    .then(res => res.text())
    .then(data => {
        hideLoading();
        if(data.trim() === "success"){
            closeDeleteModal();
            location.reload();
        } else {
            alert("Error deleting module: " + data);
        }
    })
    .catch(error => {
        hideLoading();
        alert("Failed to delete module. Please try again.");
        console.error(error);
    });
});

// Filter Modules
function filterModules(){
    const query = document.getElementById("moduleSearch").value.toLowerCase();
    const dept = document.getElementById("departmentSelect").value.toLowerCase();
    const cards = document.querySelectorAll(".module-card");
    
    cards.forEach(card => {
        const name = card.querySelector(".module-name").innerText.toLowerCase();
        const cardDept = card.querySelector(".department-tag").innerText.toLowerCase();
        
        const matchesDept = !dept || cardDept.includes(dept);
        const matchesQuery = !query || name.includes(query);
        
        card.style.display = (matchesDept && matchesQuery) ? "block" : "none";
    });
}

// Add animation to module cards on load
document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.module-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
});

// Close modals when clicking outside
window.addEventListener('click', function(e) {
    if(e.target.id === 'moduleModal') closeModal();
    if(e.target.id === 'uploadModal') closeUploadModal();
    if(e.target.id === 'deleteModal') closeDeleteModal();
});
</script>
</body>
</html>