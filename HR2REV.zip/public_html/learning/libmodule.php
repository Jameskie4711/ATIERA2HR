<?php
include('../session_check.php');
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$id = $_GET['id'] ?? null;
if(!$id) die("Module ID missing");

$stmt = $conn->prepare("SELECT * FROM library_modules WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$module = $result->fetch_assoc();
if(!$module) die("Module not found");

$pdf_url = "uploads/" . $module['pdf_file'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<title><?= htmlspecialchars($module['module_name']) ?></title>
</head>
<body class="bg-gray-50 p-6">

<div class="max-w-4xl mx-auto bg-white p-6 rounded shadow">
    <h1 class="text-2xl font-bold mb-2"><?= htmlspecialchars($module['module_name']) ?></h1>
    <p class="text-gray-500"><?= htmlspecialchars($module['category']) ?> | <?= htmlspecialchars($module['department']) ?> | <?= htmlspecialchars($module['role']) ?></p>
    <p class="mt-1 text-gray-400">Duration: <?= htmlspecialchars($module['duration']) ?></p>

    <div class="mt-4">
        <embed src="<?= $pdf_url ?>" type="application/pdf" width="100%" height="600px" class="border rounded shadow"/>
    </div>

    <div class="mt-4">
        <a href="add_module.php" class="text-blue-600 hover:underline">&larr; Back to Modules</a>
    </div>
</div>

</body>
</html>
