<?php
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $employee_id = intval($_POST['employee_id']);
    $module_id = intval($_POST['module_id']);

    if (!$employee_id || !$module_id) {
        echo "Missing employee or module ID";
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM assigned_modules WHERE employee_id = ? AND module_id = ?");
    $stmt->bind_param("ii", $employee_id, $module_id);
    
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
