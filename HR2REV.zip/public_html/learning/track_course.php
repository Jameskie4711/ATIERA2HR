<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');

// Fetch employees
$sql = "SELECT id, employee_name, department FROM learning_emp";
$result = $conn->query($sql);

$employees = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $empId = (int)$row["id"];

        // Fetch assigned modules with attachments
        $modulesRes = $conn->query("
            SELECT m.id AS module_id, m.module_name, m.attachment, am.completed, am.assigned_at, am.deadline
            FROM assigned_modules am
            JOIN library_modules m ON am.module_id = m.id
            WHERE am.employee_id = $empId
        ");

        $courses = [];
        if ($modulesRes && $modulesRes->num_rows > 0) {
            while ($m = $modulesRes->fetch_assoc()) {
                $completed = (int)($m['completed'] ?? 0);
                $progress = $completed ? 100 : 0;
                $status = $completed ? 'Completed' : 'In Progress';

                $courses[] = [
                    'module_id' => $m['module_id'],
                    'name' => $m['module_name'],
                    'attachment' => $m['attachment'],
                    'status' => $status,
                    'progress' => $progress,
                    'assigned_at' => $m['assigned_at'],
                    'deadline' => $m['deadline'],
                    'is_overdue' => !$completed && strtotime($m['deadline']) < time()
                ];
            }
        }

        $employees[] = [
            "id" => $row["id"],
            "name" => $row["employee_name"],
            "dept" => $row["department"],
            "courses" => $courses,
            "total_courses" => count($courses),
            "completed_courses" => count(array_filter($courses, fn($c) => $c['status'] === 'Completed'))
        ];
    }
}

// Calculate statistics
$totalEmployees = count($employees);
$totalCourses = array_sum(array_column($employees, 'total_courses'));
$totalCompleted = array_sum(array_column($employees, 'completed_courses'));
$completionRate = $totalCourses > 0 ? round(($totalCompleted / $totalCourses) * 100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Track Courses - LMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/lucide@latest/dist/lucide.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    overflow: hidden; /* Prevent body scrolling */
    height: 100vh;
    margin: 0;
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  .table-row-hover:hover {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.02) 100%);
  }
  
  .progress-ring {
    transform: rotate(-90deg);
  }
  
  .progress-ring-circle {
    stroke-linecap: round;
    transition: stroke-dashoffset 0.35s;
    transform: rotate(90deg);
    transform-origin: 50% 50%;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  .animate-fadeIn {
    animation: fadeIn 0.3s ease-out forwards;
  }
  
  /* Main content scrolling */
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 0.5rem; /* Add some padding for scrollbar */
  }
  
  .main-content-scroll::-webkit-scrollbar {
    width: 8px;
  }
  
  .main-content-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  /* Smooth scrolling */
  .main-content-scroll {
    scroll-behavior: smooth;
  }
</style>
</head>
<body class="min-h-screen">

<div class="flex h-screen overflow-hidden">
    
    <!-- Sidebar - Fixed -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content - Scrollable Area -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Main content with scrolling -->
        <main class="main-content-scroll p-6 space-y-6 max-w-7xl mx-auto w-full">
            
            <!-- Enhanced Header -->
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
                        <i data-lucide="clipboard-check" class="w-7 h-7 text-blue-600"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Course Tracking Dashboard</h1>
                        <p class="text-sm text-gray-500">Monitor learning progress and course completion</p>
                    </div>
                </div>
                <?php include '../profile.php'; ?>
            </div>

            <!-- Top Tabs -->
            <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
                <a href="/learning/learning.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
                    <i data-lucide="users" class="w-4 h-4"></i> Employees
                </a>
                <a href="/learning/library.php" class="flex items-center gap-2 px-3 py-1 rounded transition-colors hover:bg-gray-700">
                    <i data-lucide="book" class="w-4 h-4"></i> Libraries
                </a>
                <a href="/learning/track_course.php" class="flex items-center gap-2 px-3 py-1 rounded bg-gray-700">
                    <i data-lucide="clipboard-list" class="w-4 h-4"></i> Track Courses
                </a>
            </div>

            <!-- Statistics Dashboard -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Total Employees</p>
                            <p class="text-2xl font-bold text-gray-900"><?= $totalEmployees ?></p>
                        </div>
                        <div class="p-3 bg-blue-50 rounded-xl">
                            <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Total Courses</p>
                            <p class="text-2xl font-bold text-gray-900"><?= $totalCourses ?></p>
                        </div>
                        <div class="p-3 bg-green-50 rounded-xl">
                            <i data-lucide="book-open" class="w-6 h-6 text-green-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Completed</p>
                            <p class="text-2xl font-bold text-gray-900"><?= $totalCompleted ?></p>
                        </div>
                        <div class="p-3 bg-purple-50 rounded-xl">
                            <i data-lucide="check-circle" class="w-6 h-6 text-purple-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Completion Rate</p>
                            <p class="text-2xl font-bold text-gray-900"><?= $completionRate ?>%</p>
                        </div>
                        <div class="p-3 bg-indigo-50 rounded-xl">
                            <i data-lucide="trending-up" class="w-6 h-6 text-indigo-600"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="glass-card rounded-2xl p-4 border border-gray-100">
                <div class="flex flex-col sm:flex-row justify-between gap-4">
                    <div class="relative flex-1">
                        <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                        <input id="search" type="text" placeholder="Search by employee name..." onkeyup="filterTable()" 
                               class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    <div class="relative flex-1">
                        <i data-lucide="filter" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                        <select id="statusFilter" onchange="filterTable()" 
                                class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">All Status</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                        </select>
                        <i data-lucide="chevron-down" class="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none"></i>
                    </div>
                </div>
            </div>

            <!-- Courses Table -->
            <div class="glass-card rounded-2xl p-6 shadow-lg border border-gray-100 overflow-hidden">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            <i data-lucide="list" class="w-5 h-5 text-blue-600"></i>
                            Course Assignments
                        </h3>
                        <p class="text-sm text-gray-500 mt-1">Track learning progress across all employees</p>
                    </div>
                    <div class="text-sm text-gray-500">
                        <span id="visibleCount"><?= $totalCourses ?></span> of <?= $totalCourses ?> courses shown
                    </div>
                </div>

                <div class="overflow-x-auto scrollbar-thin">
                    <table id="coursesTable" class="w-full">
                        <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                            <tr>
                                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Employee</th>
                                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Course Details</th>
                                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Status</th>
                                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Progress</th>
                                <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Timeline</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if(!empty($employees)): ?>
                                <?php foreach($employees as $emp): ?>
                                    <?php if(!empty($emp['courses'])): ?>
                                        <?php foreach($emp['courses'] as $course): ?>
                                            <tr class="table-row-hover transition-colors duration-200">
                                                <!-- Employee Column -->
                                                <td class="py-4 px-6">
                                                    <div class="flex items-center gap-3">
                                                        <div class="w-10 h-10 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg flex items-center justify-center">
                                                            <i data-lucide="user" class="w-5 h-5 text-blue-600"></i>
                                                        </div>
                                                        <div>
                                                            <div class="font-medium text-gray-900"><?= htmlspecialchars($emp['name']) ?></div>
                                                            <div class="text-xs text-gray-500">
                                                                ID: <?= $emp['id'] ?> • <?= htmlspecialchars($emp['dept']) ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                                <!-- Course Details Column -->
                                                <td class="py-4 px-6">
                                                    <div class="space-y-1">
                                                        <div class="font-medium text-gray-900"><?= htmlspecialchars($course['name']) ?></div>
                                                        <?php if(!empty($course['attachment'])): ?>
                                                            <a href="uploads/<?= $course['attachment'] ?>" target="_blank" 
                                                               class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm transition-colors">
                                                                <i data-lucide="paperclip" class="w-3 h-3"></i>
                                                                View Course Material
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- Status Column -->
                                                <td class="py-4 px-6">
                                                    <div class="status-badge <?= 
                                                        $course['status'] === 'Completed' ? 'bg-green-100 text-green-800' : 
                                                        ($course['is_overdue'] ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800')
                                                    ?>">
                                                        <?php if($course['status'] === 'Completed'): ?>
                                                            <i data-lucide="check-circle" class="w-3 h-3"></i>
                                                        <?php elseif($course['is_overdue']): ?>
                                                            <i data-lucide="alert-circle" class="w-3 h-3"></i>
                                                        <?php else: ?>
                                                            <i data-lucide="clock" class="w-3 h-3"></i>
                                                        <?php endif; ?>
                                                        <?= $course['is_overdue'] ? 'Overdue' : htmlspecialchars($course['status']) ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- Progress Column -->
                                                <td class="py-4 px-6">
                                                    <div class="flex items-center gap-3">
                                                        <div class="flex-1">
                                                            <div class="w-full bg-gray-200 rounded-full h-2">
                                                                <div class="bg-blue-500 h-2 rounded-full" style="width: <?= $course['progress'] ?>%"></div>
                                                            </div>
                                                            <div class="text-xs text-gray-500 mt-1"><?= $course['progress'] ?>% complete</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                                <!-- Timeline Column -->
                                                <td class="py-4 px-6">
                                                    <div class="space-y-2 text-sm">
                                                        <div class="flex items-center gap-2">
                                                            <i data-lucide="calendar-plus" class="w-4 h-4 text-gray-400"></i>
                                                            <span class="text-gray-600">Assigned:</span>
                                                            <span class="font-medium text-gray-900">
                                                                <?= !empty($course['assigned_at']) ? date('M d, Y', strtotime($course['assigned_at'])) : '-' ?>
                                                            </span>
                                                        </div>
                                                        <div class="flex items-center gap-2">
                                                            <i data-lucide="calendar" class="w-4 h-4 <?= 
                                                                $course['is_overdue'] ? 'text-red-500' : 'text-gray-400'
                                                            ?>"></i>
                                                            <span class="text-gray-600">Deadline:</span>
                                                            <span class="font-medium <?= 
                                                                $course['is_overdue'] ? 'text-red-600' : 'text-gray-900'
                                                            ?>">
                                                                <?= !empty($course['deadline']) ? date('M d, Y', strtotime($course['deadline'])) : '-' ?>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr class="table-row-hover">
                                            <td class="py-4 px-6">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-10 h-10 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center">
                                                        <i data-lucide="user" class="w-5 h-5 text-gray-400"></i>
                                                    </div>
                                                    <div>
                                                        <div class="font-medium text-gray-900"><?= htmlspecialchars($emp['name']) ?></div>
                                                        <div class="text-xs text-gray-500">ID: <?= $emp['id'] ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="py-4 px-6 text-gray-500" colspan="4">
                                                <div class="flex items-center gap-2">
                                                    <i data-lucide="info" class="w-4 h-4"></i>
                                                    No courses assigned to this employee
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-12">
                                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                            <i data-lucide="users" class="w-8 h-8 text-gray-400"></i>
                                        </div>
                                        <h3 class="text-lg font-medium text-gray-700 mb-2">No Employees Found</h3>
                                        <p class="text-gray-500 max-w-md mx-auto">
                                            There are no employees in the learning management system yet.
                                        </p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>
</div>

<script>
lucide.createIcons();

// Filter table
function filterTable() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const table = document.getElementById('coursesTable');
    const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    
    let visibleCount = 0;
    
    for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        if (!cells.length) continue;
        
        // Get employee name from first cell
        const employeeNameCell = cells[0].querySelector('.font-medium');
        const empName = employeeNameCell ? employeeNameCell.textContent.toLowerCase() : '';
        
        // Get status from third cell (status badge)
        const statusCell = cells[2];
        const statusBadge = statusCell.querySelector('.status-badge');
        const courseStatus = statusBadge ? statusBadge.textContent.trim() : '';
        
        // Determine if row should be visible
        const matchesSearch = empName.includes(searchInput);
        const matchesStatus = statusFilter === '' || courseStatus === statusFilter || 
                            (statusFilter === 'In Progress' && (courseStatus === 'In Progress' || courseStatus === 'Overdue'));
        
        rows[i].style.display = (matchesSearch && matchesStatus) ? '' : 'none';
        
        if (matchesSearch && matchesStatus) {
            visibleCount++;
        }
    }
    
    // Update visible count
    document.getElementById('visibleCount').textContent = visibleCount;
}

// Add fade-in animation to table rows
document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('#coursesTable tbody tr');
    rows.forEach((row, index) => {
        row.style.opacity = '0';
        row.style.transform = 'translateY(10px)';
        
        setTimeout(() => {
            row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            row.style.opacity = '1';
            row.style.transform = 'translateY(0)';
        }, index * 50);
    });
    
    // Initialize filter count
    filterTable();
    
    // Ensure sidebar doesn't scroll
    const sidebar = document.querySelector('aside, .sidebar');
    if (sidebar) {
        sidebar.style.overflowY = 'auto';
        sidebar.style.position = 'sticky';
        sidebar.style.top = '0';
        sidebar.style.height = '100vh';
    }
});
</script>
</body>
</html>