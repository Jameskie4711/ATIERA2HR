<?php
include('../db.php');  // Connect to database
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status'=>'error', 'message'=>'Invalid request method']);
    exit;
}

// Read POST parameters safely
$employee_id = isset($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;
$module_id   = isset($_POST['module_id']) ? intval($_POST['module_id']) : 0;
$deadline    = isset($_POST['deadline']) ? trim($_POST['deadline']) : null;

if ($employee_id <= 0 || $module_id <= 0) {
    echo json_encode(['status'=>'error', 'message'=>'Employee ID and Module ID are required']);
    exit;
}

// Convert deadline to MySQL format or NULL
if (!empty($deadline)) {
    $deadline_db = date('Y-m-d', strtotime($deadline));
} else {
    $deadline_db = null;
}

// Prevent duplicate assignment
$stmtCheck = $conn->prepare("SELECT id FROM assigned_modules WHERE employee_id=? AND module_id=?");
$stmtCheck->bind_param("ii", $employee_id, $module_id);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();
if ($resultCheck->num_rows > 0) {
    echo json_encode(['status'=>'error', 'message'=>'Module already assigned to this employee']);
    exit;
}

// Insert assignment
$stmt = $conn->prepare("
    INSERT INTO assigned_modules (employee_id, module_id, assigned_at, deadline, completed, progress)
    VALUES (?, ?, NOW(), ?, 0, 0)
");

$stmt->bind_param("iis", $employee_id, $module_id, $deadline_db);

if ($stmt->execute()) {
    echo json_encode(['status'=>'success', 'message'=>'Module assigned successfully']);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Database error: '.$stmt->error]);
}

$stmt->close();
$conn->close();
