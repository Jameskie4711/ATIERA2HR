<?php
include('../session_check.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');

// Ensure request is valid
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request.");
}

// Get POST values
$employee_id   = $_POST['employee_id'] ?? null;
$employee_name = $_POST['employee_name'] ?? '';
$department    = $_POST['position'] ?? '';
$role          = $_POST['role'] ?? '';

// Check required fields
if (!$employee_id) {
    die("Missing required fields: employee_id.");
}

// Check if employee already has a pending training request
$check = $conn->prepare("SELECT id FROM training_requests WHERE employee_id = ? AND status = 'Pending'");
$check->bind_param("i", $employee_id);
$check->execute();
$checkResult = $check->get_result();

if ($checkResult->num_rows > 0) {
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Training Request - Warning</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://unpkg.com/lucide@latest"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            @import url("https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap");
            body {
                font-family: "Inter", sans-serif;
                background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .modal-content {
                animation: modalSlideIn 0.3s ease-out;
            }
            
            @keyframes modalSlideIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        </style>
    </head>
    <body>
        <div class="modal-content bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4">
            <div class="flex items-center gap-4 mb-6">
                <div class="w-12 h-12 bg-gradient-to-br from-yellow-50 to-amber-50 rounded-xl flex items-center justify-center">
                    <i data-lucide="alert-triangle" class="w-6 h-6 text-yellow-600"></i>
                </div>
                <div>
                    <h3 class="text-xl font-bold text-gray-900">Request Already Exists</h3>
                    <p class="text-gray-600">This employee already has a pending training request</p>
                </div>
            </div>
            
            <div class="mb-8">
                <div class="bg-yellow-50 border border-yellow-100 rounded-xl p-4">
                    <p class="text-yellow-800 font-medium">' . htmlspecialchars($employee_name) . '</p>
                    <p class="text-sm text-yellow-600 mt-1">A training request is already pending for this employee.</p>
                </div>
                <p class="text-sm text-gray-500 mt-4">You cannot create duplicate training requests for the same employee while the previous request is still pending.</p>
            </div>
            
            <div class="flex gap-3">
                <button onclick="window.location.href=\'learning.php\'" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center gap-2">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    Back to List
                </button>
                <button onclick="window.location.href=\'/training/trainings.php\'" 
                        class="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                    <i data-lucide="eye" class="w-4 h-4"></i>
                    View Requests
                </button>
            </div>
        </div>
        <script>lucide.createIcons();</script>
    </body>
    </html>';
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Insert into training_requests using employee_id as user_id
    $insert = $conn->prepare("
        INSERT INTO training_requests (user_id, employee_id, employee_name, department, role, status, date_requested)
        VALUES (?, ?, ?, ?, ?, 'Pending', NOW())
    ");
    $insert->bind_param("iisss", $employee_id, $employee_id, $employee_name, $department, $role);
    $insert->execute();

    // Remove from learning_emp
    $delete = $conn->prepare("DELETE FROM learning_emp WHERE id = ?");
    $delete->bind_param("i", $employee_id);
    $delete->execute();

    // Commit transaction
    $conn->commit();

    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Training Request - Success</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://unpkg.com/lucide@latest"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            @import url("https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap");
            body {
                font-family: "Inter", sans-serif;
                background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .modal-content {
                animation: modalSlideIn 0.3s ease-out;
            }
            
            @keyframes modalSlideIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .success-badge {
                animation: successPulse 2s ease-in-out infinite;
            }
            
            @keyframes successPulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.05); }
            }
        </style>
    </head>
    <body>
        <div class="modal-content bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4">
            <div class="flex flex-col items-center text-center mb-8">
                <div class="success-badge w-20 h-20 bg-gradient-to-br from-green-50 to-emerald-50 rounded-full flex items-center justify-center mb-4">
                    <i data-lucide="check-circle" class="w-10 h-10 text-green-600"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Request Submitted Successfully!</h3>
                <p class="text-gray-600">Training request has been created</p>
            </div>
            
            <div class="mb-8">
                <div class="bg-green-50 border border-green-100 rounded-xl p-4 mb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-green-200">
                            <i data-lucide="user" class="w-5 h-5 text-green-600"></i>
                        </div>
                        <div class="text-left">
                            <p class="font-medium text-green-800">' . htmlspecialchars($employee_name) . '</p>
                            <p class="text-sm text-green-600">' . htmlspecialchars($department) . ' • ' . htmlspecialchars($role) . '</p>
                        </div>
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-blue-50 border border-blue-100 rounded-xl p-3">
                        <div class="flex items-center gap-2">
                            <i data-lucide="calendar" class="w-4 h-4 text-blue-600"></i>
                            <span class="text-xs text-blue-800">Date Submitted</span>
                        </div>
                        <p class="font-medium text-blue-900 text-sm mt-1">' . date('M d, Y') . '</p>
                    </div>
                    
                    <div class="bg-purple-50 border border-purple-100 rounded-xl p-3">
                        <div class="flex items-center gap-2">
                            <i data-lucide="clock" class="w-4 h-4 text-purple-600"></i>
                            <span class="text-xs text-purple-800">Status</span>
                        </div>
                        <p class="font-medium text-purple-900 text-sm mt-1">Pending Review</p>
                    </div>
                </div>
                
                <div class="bg-gray-50 border border-gray-100 rounded-xl p-4 mt-4">
                    <p class="text-sm text-gray-600 text-center">
                        The employee has been removed from the learning list and the training request is now pending approval.
                    </p>
                </div>
            </div>
            
            <div class="flex gap-3">
                <button onclick="window.location.href=\'learning.php\'" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center gap-2">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    Back to List
                </button>
                <button onclick="window.location.href=\'/training/trainings.php\'" 
                        class="flex-1 px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                    <i data-lucide="eye" class="w-4 h-4"></i>
                    View Request
                </button>
            </div>
        </div>
        <script>lucide.createIcons();</script>
    </body>
    </html>';

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Training Request - Error</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://unpkg.com/lucide@latest"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            @import url("https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap");
            body {
                font-family: "Inter", sans-serif;
                background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .modal-content {
                animation: modalSlideIn 0.3s ease-out;
            }
            
            @keyframes modalSlideIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        </style>
    </head>
    <body>
        <div class="modal-content bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4">
            <div class="flex items-center gap-4 mb-6">
                <div class="w-12 h-12 bg-gradient-to-br from-red-50 to-rose-50 rounded-xl flex items-center justify-center">
                    <i data-lucide="x-circle" class="w-6 h-6 text-red-600"></i>
                </div>
                <div>
                    <h3 class="text-xl font-bold text-gray-900">Processing Error</h3>
                    <p class="text-gray-600">Failed to create training request</p>
                </div>
            </div>
            
            <div class="mb-8">
                <div class="bg-red-50 border border-red-100 rounded-xl p-4 mb-4">
                    <p class="text-red-800 font-medium">Error Details</p>
                    <p class="text-sm text-red-600 mt-1">' . htmlspecialchars($e->getMessage()) . '</p>
                </div>
                <p class="text-sm text-gray-500">Please try again or contact system administrator if the problem persists.</p>
            </div>
            
            <div class="flex gap-3">
                <button onclick="window.history.back()" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center gap-2">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    Go Back
                </button>
                <button onclick="window.location.href=\'learning.php\'" 
                        class="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                    <i data-lucide="home" class="w-4 h-4"></i>
                    Home
                </button>
            </div>
        </div>
        <script>lucide.createIcons();</script>
    </body>
    </html>';
}

$conn->close();
?>