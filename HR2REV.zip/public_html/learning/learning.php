<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include __DIR__ . '/../db.php';

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_employee_id'])) {
    $employeeId = intval($_POST['delete_employee_id']);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First delete assigned modules for this employee
        $conn->query("DELETE FROM assigned_modules WHERE employee_id = $employeeId");
        
        // Then delete the employee from learning_emp
        $conn->query("DELETE FROM learning_emp WHERE id = $employeeId");
        
        // Commit transaction
        $conn->commit();
        
        // Redirect to refresh the page
        header("Location: " . $_SERVER['PHP_SELF'] . "?deleted=1");
        exit();
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        $deleteError = "Failed to delete employee: " . $e->getMessage();
    }
}

// ✅ Fetch employees (use position, fallback to role)
$sql = "SELECT id, employee_name, department FROM learning_emp";

$result = $conn->query($sql);

$employees = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = [
            "id"       => $row["id"],
            "name"     => $row["employee_name"],
            "department" => $row["department"]
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learning Management - Admin</title>

<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Lucide Icons -->
<script src="https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" type="image/png" href="/favicon.ico" />
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    overflow: hidden; /* Prevent body scrolling */
    height: 100vh;
    margin: 0;
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    transition: all 0.3s ease;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
  }
  
  .btn-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
  }
  
  .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  
  .btn-warning {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    transition: all 0.3s ease;
  }
  
  .btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(245, 158, 11, 0.3);
  }
  
  .btn-danger {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    transition: all 0.3s ease;
  }
  
  .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateX(5px);
    border-left-color: #3b82f6;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  .table-row-hover:hover {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.02) 100%);
  }
  
  .avatar-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  /* Custom scrollbar for main content */
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
  }
  
  /* Smooth scrolling */
  .main-content-scroll {
    scroll-behavior: smooth;
  }
  
  /* Modal styles */
  .modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
  }
  
  .modal-overlay.active {
    display: flex;
  }
  
  .modal-content {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    animation: modalSlideIn 0.3s ease-out;
  }
  
  @keyframes modalSlideIn {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  /* Toast notification */
  .toast {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    z-index: 1001;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    animation: toastSlideIn 0.3s ease-out;
  }
  
  .toast.error {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  }
  
  @keyframes toastSlideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>
</head>
<body class="min-h-screen">

<div class="flex h-screen overflow-hidden">
    
    <!-- Sidebar - Fixed -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content - Scrollable -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Main content area with scrolling -->
        <main class="main-content-scroll p-6 space-y-6 max-w-7xl mx-auto w-full">
            
            <!-- Enhanced Header -->
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
                        <i data-lucide="layers" class="w-7 h-7 text-blue-600"></i>
                    </div>
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900">Learning Management</h2>
                        <p class="text-sm text-gray-500">Manage employee learning paths and modules</p>
                    </div>
                </div>
                <?php include '../profile.php'; ?>
            </div>

            <!-- Top Tabs -->
            <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
                <a href="/learning/learning.php" class="flex items-center gap-2 px-3 py-1 rounded hover:bg-gray-700">
                    <i data-lucide="users" class="w-4 h-4"></i> Employees
                </a>
                <a href="/learning/library.php" class="flex items-center gap-2 px-3 py-1 rounded hover:bg-gray-700">
                    <i data-lucide="book" class="w-4 h-4"></i> Libraries
                </a>
                <a href="/learning/track_course.php" class="flex items-center gap-2 px-3 py-1 rounded hover:bg-gray-700">
                    <i data-lucide="clipboard-list" class="w-4 h-4"></i> Track Courses
                </a>
            </div>

            <!-- Success/Error Messages -->
            <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
                <div class="rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 p-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <i data-lucide="check-circle" class="w-5 h-5 text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-green-800">Employee deleted successfully</p>
                            <p class="text-sm text-green-600 mt-1">The employee has been removed from the learning management system.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (isset($deleteError)): ?>
                <div class="rounded-xl bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 p-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                            <i data-lucide="alert-circle" class="w-5 h-5 text-red-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-red-800">Delete Failed</p>
                            <p class="text-sm text-red-600 mt-1"><?= htmlspecialchars($deleteError) ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Total Employees</p>
                            <p class="text-2xl font-bold text-gray-900"><?= count($employees) ?></p>
                        </div>
                        <div class="p-3 bg-blue-50 rounded-xl">
                            <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">With Modules</p>
                            <p class="text-2xl font-bold text-gray-900">
                                <?php 
                                $withModules = 0;
                                foreach ($employees as $emp) {
                                    $empId = (int)($emp['id'] ?? 0);
                                    $check = $conn->query("SELECT COUNT(*) AS cnt FROM assigned_modules WHERE employee_id = $empId");
                                    if ($check && $check->fetch_assoc()['cnt'] > 0) {
                                        $withModules++;
                                    }
                                }
                                echo $withModules;
                                ?>
                            </p>
                        </div>
                        <div class="p-3 bg-green-50 rounded-xl">
                            <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="glass-card rounded-2xl p-4 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-500">Ready to Proceed</p>
                            <p class="text-2xl font-bold text-gray-900">
                                <?php 
                                $readyCount = 0;
                                foreach ($employees as $emp) {
                                    $empId = (int)($emp['id'] ?? 0);
                                    $check = $conn->query("SELECT COUNT(*) AS cnt FROM assigned_modules WHERE employee_id = $empId");
                                    if ($check && $check->fetch_assoc()['cnt'] > 0) {
                                        $readyCount++;
                                    }
                                }
                                echo $readyCount;
                                ?>
                            </p>
                        </div>
                        <div class="p-3 bg-purple-50 rounded-xl">
                            <i data-lucide="arrow-right-circle" class="w-6 h-6 text-purple-600"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Employee List -->
            <div class="glass-card rounded-2xl p-6 shadow-lg border border-gray-100">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            <i data-lucide="clipboard" class="w-5 h-5 text-blue-600"></i>
                            Employee Directory
                        </h3>
                        <p class="text-sm text-gray-500 mt-1">Manage learning modules for each employee</p>
                    </div>
                    <div class="text-sm text-gray-500">
                        Showing <?= count($employees) ?> employee<?= count($employees) != 1 ? 's' : '' ?>
                    </div>
                </div>

                <div class="overflow-x-auto scrollbar-thin">
                    <div class="min-w-full inline-block align-middle">
                        <div class="overflow-hidden rounded-xl border border-gray-200">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                                    <tr>
                                        <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Employee ID</th>
                                        <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Employee Name</th>
                                        <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Position/Department</th>
                                        <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Status</th>
                                        <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    <?php if (!empty($employees)): ?>
                                        <?php foreach ($employees as $emp): ?>
                                            <?php
                                            $empId = (int)($emp['id'] ?? 0);
                                            $check = $conn->query("SELECT COUNT(*) AS cnt FROM assigned_modules WHERE employee_id = $empId");
                                            $hasModules = $check && $check->fetch_assoc()['cnt'] > 0;
                                            ?>
                                            <tr class="table-row-hover transition-colors duration-200 hover:bg-gray-50">
                                                <td class="py-4 px-6 whitespace-nowrap">
                                                    <div class="flex items-center gap-2">
                                                        <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                                                        <span class="font-mono font-semibold text-gray-700"><?= htmlspecialchars($emp["id"]) ?></span>
                                                    </div>
                                                </td>
                                                <td class="py-4 px-6 whitespace-nowrap">
                                                    <div class="flex items-center gap-3">
                                                        <div class="w-8 h-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg flex items-center justify-center">
                                                            <i data-lucide="user" class="w-4 h-4 text-blue-600"></i>
                                                        </div>
                                                        <div>
                                                            <div class="font-medium text-gray-900"><?= htmlspecialchars($emp["name"]) ?></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="py-4 px-6 whitespace-nowrap">
                                                    <div class="flex items-center gap-2">
                                                        <i data-lucide="briefcase" class="w-4 h-4 text-gray-400"></i>
                                                        <span class="text-gray-700"><?= htmlspecialchars($emp["department"] ?? 'N/A') ?></span>
                                                    </div>
                                                </td>
                                                <td class="py-4 px-6 whitespace-nowrap">
                                                    <?php if ($hasModules): ?>
                                                        <div class="status-badge bg-green-100 text-green-800">
                                                            <i data-lucide="check-circle" class="w-3 h-3"></i>
                                                            Modules Assigned
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="status-badge bg-yellow-100 text-yellow-800">
                                                            <i data-lucide="clock" class="w-3 h-3"></i>
                                                            No Modules
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="py-4 px-6 whitespace-nowrap">
                                                    <div class="flex flex-wrap gap-2">
                                                        <?php if ($hasModules): ?>
                                                            <form action="proceed_learning.php" method="POST" class="inline-block">
                                                                <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                                                <input type="hidden" name="employee_name" value="<?= htmlspecialchars($emp['name']) ?>">
                                                                <input type="hidden" name="position" value="<?= htmlspecialchars($emp['department']) ?>">
                                                                <button type="submit" class="btn-success px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2">
                                                                    <i data-lucide="arrow-right" class="w-4 h-4"></i> Proceed
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                        <a href="/learning/learn_pg2.php?id=<?= urlencode($emp['id']) ?>"
                                                           class="btn-primary px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2">
                                                            <i data-lucide="settings" class="w-4 h-4"></i> Manage Modules
                                                        </a>
                                                        
                                                        <!-- Delete Button -->
                                                        <button type="button" 
                                                                onclick="openDeleteModal(<?= $emp['id'] ?>, '<?= htmlspecialchars(addslashes($emp['name'])) ?>')"
                                                                class="btn-danger px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2">
                                                            <i data-lucide="trash-2" class="w-4 h-4"></i> Delete
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-12">
                                                <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                                    <i data-lucide="users" class="w-8 h-8 text-gray-400"></i>
                                                </div>
                                                <h3 class="text-lg font-medium text-gray-700 mb-2">No Employees Found</h3>
                                                <p class="text-gray-500 max-w-md mx-auto">
                                                    There are no employees in the learning management system yet.
                                                </p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Footer Note -->
                <div class="mt-6 pt-6 border-t border-gray-100">
                    <div class="flex items-start gap-3">
                        <div class="p-2 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
                            <i data-lucide="info" class="w-4 h-4 text-blue-600"></i>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-800 mb-1">Learning Management Notes</p>
                            <p class="text-xs text-gray-600">
                                • "Proceed" button appears only when modules are assigned to the employee.<br>
                                • Use "Manage Modules" to assign or modify learning modules for each employee.<br>
                                • "Delete" will permanently remove the employee and all their assigned modules.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content">
        <div class="flex items-center gap-3 mb-6">
            <div class="w-12 h-12 bg-gradient-to-br from-red-50 to-rose-50 rounded-xl flex items-center justify-center">
                <i data-lucide="alert-triangle" class="w-6 h-6 text-red-600"></i>
            </div>
            <div>
                <h3 class="text-xl font-bold text-gray-900">Confirm Deletion</h3>
                <p class="text-gray-600">This action cannot be undone</p>
            </div>
        </div>
        
        <div class="mb-6">
            <p class="text-gray-700" id="deleteMessage">Are you sure you want to delete this employee?</p>
            <p class="text-sm text-gray-500 mt-2">
                This will permanently delete the employee and all their assigned learning modules from the system.
            </p>
        </div>
        
        <form id="deleteForm" method="POST" action="">
            <input type="hidden" name="delete_employee_id" id="deleteEmployeeId" value="">
            <div class="flex gap-3">
                <button type="button" onclick="closeDeleteModal()" 
                        class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                    Cancel
                </button>
                <button type="submit" 
                        class="flex-1 px-4 py-3 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                    <i data-lucide="trash-2" class="w-5 h-5"></i>
                    Delete Employee
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Toast Notification -->
<div id="toast" class="toast hidden">
    <i data-lucide="check-circle" class="w-5 h-5"></i>
    <span id="toastMessage">Action completed successfully</span>
</div>

<script>
  // Initialize Lucide icons
  lucide.createIcons();
  
  // Delete Modal Functions
  let currentDeleteId = null;
  let currentDeleteName = null;
  
  function openDeleteModal(employeeId, employeeName) {
    currentDeleteId = employeeId;
    currentDeleteName = employeeName;
    
    // Update modal content
    document.getElementById('deleteMessage').textContent = 
        `Are you sure you want to delete "${employeeName}"?`;
    document.getElementById('deleteEmployeeId').value = employeeId;
    document.getElementById('deleteForm').action = window.location.href;
    
    // Show modal
    document.getElementById('deleteModal').classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  
  function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
    document.body.style.overflow = '';
    currentDeleteId = null;
    currentDeleteName = null;
  }
  
  // Close modal when clicking outside
  document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) {
      closeDeleteModal();
    }
  });
  
  // Close modal with Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeDeleteModal();
    }
  });
  
  // Toast notification function
  function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    
    if (isError) {
      toast.classList.add('error');
    } else {
      toast.classList.remove('error');
    }
    
    // Auto-hide toast after 5 seconds
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 5000);
  }
  
  // Add hover effects to table rows
  document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('tbody tr');
    rows.forEach(row => {
      row.addEventListener('mouseenter', function() {
        this.classList.add('bg-gray-50');
      });
      row.addEventListener('mouseleave', function() {
        this.classList.remove('bg-gray-50');
      });
    });
    
    // Ensure sidebar doesn't scroll
    const sidebar = document.querySelector('aside, .sidebar');
    if (sidebar) {
      sidebar.style.overflowY = 'auto';
      sidebar.style.position = 'sticky';
      sidebar.style.top = '0';
      sidebar.style.height = '100vh';
    }
    
    // Show success toast if deleted
    <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
      showToast('Employee deleted successfully');
    <?php endif; ?>
    
    // Show error toast if delete failed
    <?php if (isset($deleteError)): ?>
      showToast('Failed to delete employee', true);
    <?php endif; ?>
  });
</script>
</body>
</html>