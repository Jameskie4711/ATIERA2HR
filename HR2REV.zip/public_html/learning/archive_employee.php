<?php
include('../session_check.php');
include('../db.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['employee_name'] ?? '');
    $dept = trim($_POST['department'] ?? '');
    $gap = trim($_POST['competency_gap'] ?? '');

    if ($id > 0 && $name && $dept) {
        // 1️⃣ Insert into learning_archive
        $stmt = $conn->prepare("INSERT INTO learning_archive (employee_name, department, competency_gap) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $dept, $gap);
        $stmt->execute();
        $stmt->close();

        // 2️⃣ Delete from learning_emp
        $stmt2 = $conn->prepare("DELETE FROM learning_emp WHERE id = ?");
        $stmt2->bind_param("i", $id);
        $stmt2->execute();
        $stmt2->close();

        // 3️⃣ Redirect back with success
        header("Location: learning.php?archived=1");
        exit;
    } else {
        header("Location: learning.php?error=Invalid+data");
        exit;
    }
} else {
    header("Location: learning.php");
    exit;
}
?>
