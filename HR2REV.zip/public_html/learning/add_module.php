<?php
include('../session_check.php');
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Read POST values safely
$module_name = trim($_POST['module_name'] ?? '');
$department  = trim($_POST['department'] ?? '');
$deadline    = trim($_POST['deadline'] ?? ''); // NEW: deadline

// Validate required fields
if(empty($module_name) || empty($department)){
    echo "Please fill all required fields.";
    exit;
}

// Convert deadline to proper MySQL format or set NULL if empty
if(!empty($deadline)){
    $deadline_db = date('Y-m-d', strtotime($deadline));
}else{
    $deadline_db = null;
}

// Default values
$course_id  = 0;           // default for now
$category   = 'General';
$role       = 'All';
$duration   = 0;
$created_at = date('Y-m-d H:i:s');

// Prepare insert query
$stmt = $conn->prepare("
    INSERT INTO library_modules 
    (course_id, module_name, category, department, role, duration, created_at, deadline) 
    VALUES (?,?,?,?,?,?,?,?)
");

if(!$stmt){
    echo "DB prepare error: ".$conn->error;
    exit;
}

// Bind parameters (s = string, i = int, d = double)
$stmt->bind_param("isssdiss",
    $course_id,
    $module_name,
    $category,
    $department,
    $role,
    $duration,
    $created_at,
    $deadline_db
);

// Execute insert
if($stmt->execute()){
    echo "success";
}else{
    echo "DB execute error: ".$stmt->error;
}

$stmt->close();
$conn->close();
?>
