<?php
include('../session_check.php');
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$module_id = intval($_POST['module_id'] ?? 0);

if($module_id <= 0){
    echo "Invalid module ID";
    exit;
}

if(!isset($_FILES['module_file'])){
    echo "No file uploaded";
    exit;
}

$file = $_FILES['module_file'];
$allowed = ['pdf','doc','docx','txt','xlsx'];
$ext = strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));

if(!in_array($ext,$allowed)){
    echo "File type not allowed";
    exit;
}

// Create uploads folder if not exists
$upload_dir = __DIR__ . '/uploads/';
if(!is_dir($upload_dir)) mkdir($upload_dir,0755,true);

$filename = time().'_'.preg_replace('/[^a-zA-Z0-9_\.-]/','_',$file['name']);
$filepath = $upload_dir.$filename;

if(move_uploaded_file($file['tmp_name'],$filepath)){
    // Update DB
    $stmt = $conn->prepare("UPDATE library_modules SET attachment=? WHERE id=?");
    $stmt->bind_param("si",$filename,$module_id);
    if($stmt->execute()){
        echo "success";
    }else{
        echo "DB update error: ".$stmt->error;
    }
    $stmt->close();
}else{
    echo "Failed to move uploaded file";
}

$conn->close();
?>
