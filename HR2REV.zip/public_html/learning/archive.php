<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Include database connection
include __DIR__ . '/../db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Archived Learners - Learning Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/favicon.ico" />
</head>

<body class="bg-slate-50 min-h-screen">
<div class="flex min-h-screen">

  <!-- Sidebar -->
  <?php include '../sidebar.php'; ?>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-8 max-w-7xl mx-auto w-full">

      <!-- Header -->
      <div class="flex items-center justify-between border-b py-6">
        <h2 class="text-xl font-semibold text-gray-800">Learning Management - Archive</h2>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Top Tabs (Match Sidebar Color) -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
        <a href="/learning/learning.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Learners</a>
        <a href="/learning/library.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Library</a>
        <a href="/learning/archive.php" class="bg-gray-700 px-3 py-1 rounded">Archive</a>
      </div>

      <!-- Archived Employees Section -->
      <div class="bg-white shadow-md rounded-xl p-6">
        <h2 class="text-xl font-semibold mb-4">Archived Employees</h2>
        <table class="w-full border border-gray-200 rounded-lg">
          <thead class="bg-gray-100">
            <tr>
              <th class="p-2 border">Employee Name</th>
              <th class="p-2 border">Department</th>
              <th class="p-2 border">Competency Gap</th>
              <th class="p-2 border">Action</th>
            </tr>
          </thead>
          <tbody id="archivedTableBody" class="text-center"></tbody>
        </table>
      </div>

    </main>
  </div>
</div>

<!-- Confirm Modal -->
<div id="confirmModal" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center hidden">
  <div class="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
    <h2 id="modalTitle" class="text-xl font-semibold mb-4">Confirm Restore</h2>
    <p id="modalMessage" class="mb-6 text-gray-700">Do you want to restore this employee?</p>
    <div class="flex justify-end gap-3">
      <button onclick="closeModal()" class="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400">Cancel</button>
      <button id="modalConfirmBtn" class="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700">Restore</button>
    </div>
  </div>
</div>

<script>
let restoreIndex = null;

function openModal(index) {
  restoreIndex = index;
  document.getElementById("confirmModal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("confirmModal").classList.add("hidden");
  restoreIndex = null;
}

function confirmAction() {
  if (restoreIndex !== null) restoreEmployee(restoreIndex);
  closeModal();
}

function restoreEmployee(index) {
  let archivedEmployees = JSON.parse(localStorage.getItem("archivedEmployees")) || [];
  const emp = archivedEmployees[index];

  // Remove from archived list
  archivedEmployees.splice(index, 1);
  localStorage.setItem("archivedEmployees", JSON.stringify(archivedEmployees));

  // Optionally, send to server or log restoration here

  renderArchived();
}

function renderArchived() {
  let archivedEmployees = JSON.parse(localStorage.getItem("archivedEmployees")) || [];
  const tbody = document.getElementById("archivedTableBody");
  tbody.innerHTML = "";
  if (archivedEmployees.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" class="p-4 text-gray-500">No archived employees.</td></tr>`;
    return;
  }
  archivedEmployees.forEach((emp, index) => {
    tbody.innerHTML += `
      <tr>
        <td class="p-2 border">${emp.name}</td>
        <td class="p-2 border">${emp.dept}</td>
        <td class="p-2 border">${emp.gap}</td>
        <td class="p-2 border">
          <button onclick="openModal(${index})" 
            class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition">
            Restore
          </button>
        </td>
      </tr>
    `;
  });
}

document.getElementById("modalConfirmBtn").addEventListener("click", confirmAction);
renderArchived();
</script>

</body>
</html>
