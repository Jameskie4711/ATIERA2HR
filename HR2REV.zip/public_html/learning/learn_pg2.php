<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../db.php');

$employee_id = $_GET['id'] ?? null;
if (!$employee_id) die("Employee ID not specified.");

// Fetch employee info
$empQuery = $conn->prepare("SELECT id, employee_name, role FROM learning_emp WHERE id = ?");
$empQuery->bind_param("i", $employee_id);
$empQuery->execute();
$employee = $empQuery->get_result()->fetch_assoc();
if (!$employee) die("Employee not found.");

// Fetch all modules including their deadline
$modules = $conn->query("SELECT id, module_name, category, deadline FROM library_modules ORDER BY id ASC")
                ->fetch_all(MYSQLI_ASSOC);

// Fetch assigned modules for this employee
$assignedQuery = $conn->prepare("
    SELECT am.module_id, am.assigned_at, am.deadline, am.completed, lm.module_name, lm.category
    FROM assigned_modules am
    JOIN library_modules lm ON am.module_id = lm.id
    WHERE am.employee_id = ?
");
$assignedQuery->bind_param("i", $employee_id);
$assignedQuery->execute();
$assignedModules = $assignedQuery->get_result()->fetch_all(MYSQLI_ASSOC);

$assignedIds = array_column($assignedModules, 'module_id');

// Calculate statistics
$totalModules = count($modules);
$assignedCount = count($assignedModules);
$completedCount = count(array_filter($assignedModules, fn($am) => $am['completed']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Learning Modules</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" href="/web/picture/logo2.png">

<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    overflow: hidden; /* Prevent body scrolling */
    height: 100vh;
    margin: 0;
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    transition: all 0.3s ease;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
  }
  
  .btn-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
  }
  
  .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  
  .btn-danger {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    transition: all 0.3s ease;
  }
  
  .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
  }
  
  .btn-warning {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    transition: all 0.3s ease;
  }
  
  .btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(245, 158, 11, 0.3);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  .module-card {
    transition: all 0.3s ease;
  }
  
  .module-card:hover {
    transform: translateY(-6px) scale(1.01);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
  }
  
  .progress-ring {
    transform: rotate(-90deg);
  }
  
  .progress-ring-circle {
    stroke-linecap: round;
    transition: stroke-dashoffset 0.35s;
    transform: rotate(90deg);
    transform-origin: 50% 50%;
  }
  
  /* Main content scrolling */
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 0.5rem;
  }
  
  .main-content-scroll::-webkit-scrollbar {
    width: 8px;
  }
  
  .main-content-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  /* Modal styles */
  .modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
  }
  
  .modal-overlay.active {
    display: flex;
  }
  
  .modal-content {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    animation: modalSlideIn 0.3s ease-out;
  }
  
  @keyframes modalSlideIn {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  /* Toast notification */
  .toast {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    z-index: 1001;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    animation: toastSlideIn 0.3s ease-out;
  }
  
  .toast.error {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  }
  
  @keyframes toastSlideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>
</head>

<body class="min-h-screen flex h-screen overflow-hidden">

<?php include '../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-hidden">
  <!-- Main content with scrolling -->
  <main class="main-content-scroll max-w-7xl mx-auto w-full px-6 py-6 space-y-6">

    <!-- Enhanced Header -->
    <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
            <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
                <i data-lucide="book-open" class="w-7 h-7 text-blue-600"></i>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Learning Module Management</h1>
                <p class="text-sm text-gray-500">Assign and manage learning modules for employees</p>
            </div>
        </div>
        <?php include '../profile.php'; ?>
    </div>

    <!-- Top Tabs -->
    <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
        <a href="/learning/learning.php" class="flex items-center gap-2 px-3 py-1 rounded hover:bg-gray-700">
            <i data-lucide="home" class="w-4 h-4"></i> Home
        </a>
    </div>

    <!-- Employee Header Card -->
    <div class="glass-card rounded-2xl p-6 shadow-lg border border-gray-100">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold">
                    <?= strtoupper(substr($employee['employee_name'], 0, 1)) ?>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-900"><?= htmlspecialchars($employee['employee_name']) ?></h2>
                    <div class="flex items-center gap-3 mt-1">
                        <span class="text-sm text-gray-600"><?= htmlspecialchars($employee['role']) ?></span>
                        <span class="text-sm font-medium text-gray-700 bg-gray-100 px-3 py-1 rounded-full">ID: <?= $employee['id'] ?></span>
                    </div>
                </div>
            </div>
            <div class="text-right">
                <div class="text-sm text-gray-500">Managing Learning Modules</div>
                <div class="text-lg font-bold text-blue-600"><?= $assignedCount ?> of <?= $totalModules ?> modules</div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Total Modules</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $totalModules ?></p>
                </div>
                <div class="p-3 bg-blue-50 rounded-xl">
                    <i data-lucide="book" class="w-6 h-6 text-blue-600"></i>
                </div>
            </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Assigned</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $assignedCount ?></p>
                </div>
                <div class="p-3 bg-green-50 rounded-xl">
                    <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
                </div>
            </div>
        </div>
        
        <div class="glass-card rounded-2xl p-4 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Completed</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $completedCount ?></p>
                </div>
                <div class="p-3 bg-purple-50 rounded-xl">
                    <i data-lucide="award" class="w-6 h-6 text-purple-600"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="flex items-center justify-between">
        <div>
            <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <i data-lucide="layers" class="w-5 h-5 text-blue-600"></i>
                Available Modules
            </h3>
            <p class="text-sm text-gray-500 mt-1">Assign learning modules to <?= htmlspecialchars($employee['employee_name']) ?></p>
        </div>
        <div class="relative w-64">
            <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
            <input id="moduleSearch" onkeyup="filterModules()" placeholder="Search modules..." 
                   class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
    </div>

    <!-- Module Grid -->
    <div id="modulesContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

    <?php foreach ($modules as $mod):
        $isAssigned = in_array($mod['id'], $assignedIds);
        $assignedData = $isAssigned ? current(array_filter($assignedModules, fn($a)=>$a['module_id']==$mod['id'])) : null;
        $status = $isAssigned ? ($assignedData['completed'] ? 'Completed' : 'Ongoing') : 'Not Assigned';
        $statusColor = !$isAssigned ? 'gray' : ($assignedData['completed'] ? 'green' : 'yellow');
    ?>

    <div id="module_<?= $mod['id'] ?>" data-deadline="<?= $mod['deadline'] ?>" data-module-name="<?= htmlspecialchars($mod['module_name']) ?>"
         class="module-card glass-card rounded-2xl p-6 border border-gray-100 flex flex-col">

        <!-- Module Header -->
        <div class="flex items-start justify-between mb-4">
            <div>
                <div class="flex items-center gap-2 mb-2">
                    <div class="p-2 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
                        <i data-lucide="book-open" class="w-4 h-4 text-blue-600"></i>
                    </div>
                    <span class="text-xs font-medium text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                        <?= htmlspecialchars($mod['category']) ?>
                    </span>
                </div>
                <h4 class="text-lg font-bold text-gray-900">
                    <?= htmlspecialchars($mod['module_name']) ?>
                </h4>
            </div>
            <div class="status-badge <?= 
                $statusColor === 'gray' ? 'bg-gray-100 text-gray-700' :
                ($statusColor === 'green' ? 'bg-green-100 text-green-700' :
                'bg-yellow-100 text-yellow-700')
            ?>">
                <?php if ($statusColor === 'green'): ?>
                    <i data-lucide="check-circle" class="w-3 h-3"></i>
                <?php elseif ($statusColor === 'yellow'): ?>
                    <i data-lucide="clock" class="w-3 h-3"></i>
                <?php else: ?>
                    <i data-lucide="x-circle" class="w-3 h-3"></i>
                <?php endif; ?>
                <?= $status ?>
            </div>
        </div>

        <!-- Deadline Info -->
        <div class="space-y-3 mb-6">
            <div class="flex items-center justify-between text-sm">
                <div class="flex items-center gap-2">
                    <i data-lucide="calendar" class="w-4 h-4 text-gray-400"></i>
                    <span class="text-gray-600">Deadline:</span>
                </div>
                <span class="font-medium <?= 
                    $isAssigned && !$assignedData['completed'] && strtotime($assignedData['deadline']) < time() 
                    ? 'text-red-600' : 'text-gray-900'
                ?>">
                    <?= $assignedData['deadline'] ?? $mod['deadline'] ?>
                </span>
            </div>
            <?php if ($isAssigned): ?>
                <div class="flex items-center justify-between text-sm">
                    <div class="flex items-center gap-2">
                        <i data-lucide="calendar-plus" class="w-4 h-4 text-gray-400"></i>
                        <span class="text-gray-600">Assigned:</span>
                    </div>
                    <span class="font-medium text-gray-900"><?= $assignedData['assigned_at'] ?></span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Action Buttons -->
        <div class="mt-auto">
            <?php if ($isAssigned && !$assignedData['completed']): ?>
                <div class="flex gap-2">
                    <button onclick="openUnassignModal(<?= $employee['id'] ?>, <?= $mod['id'] ?>, '<?= htmlspecialchars(addslashes($employee['employee_name'])) ?>', '<?= htmlspecialchars(addslashes($mod['module_name'])) ?>')"
                            class="flex-1 btn-danger px-4 py-3 rounded-xl text-white font-medium text-sm flex items-center justify-center gap-2">
                        <i data-lucide="x" class="w-4 h-4"></i> Unassign
                    </button>
                    <button onclick="openCompleteModal(<?= $employee['id'] ?>, <?= $mod['id'] ?>, '<?= htmlspecialchars(addslashes($employee['employee_name'])) ?>', '<?= htmlspecialchars(addslashes($mod['module_name'])) ?>')"
                            class="flex-1 btn-success px-4 py-3 rounded-xl text-white font-medium text-sm flex items-center justify-center gap-2">
                        <i data-lucide="check" class="w-4 h-4"></i> Complete
                    </button>
                </div>
            <?php elseif (!$isAssigned): ?>
                <button onclick="openAssignModal(<?= $employee['id'] ?>, <?= $mod['id'] ?>, '<?= htmlspecialchars(addslashes($employee['employee_name'])) ?>', '<?= htmlspecialchars(addslashes($mod['module_name'])) ?>', '<?= $mod['deadline'] ?>')"
                        class="w-full btn-primary px-4 py-3 rounded-xl text-white font-medium text-sm flex items-center justify-center gap-2">
                    <i data-lucide="plus" class="w-4 h-4"></i> Assign Module
                </button>
            <?php else: ?>
                <div class="text-center py-2">
                    <span class="text-sm text-green-600 font-medium flex items-center justify-center gap-2">
                        <i data-lucide="check-circle" class="w-4 h-4"></i> Module Completed
                    </span>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <?php endforeach; ?>
    </div>

  </main>
</div>

<!-- Assign Confirmation Modal -->
<div id="assignModal" class="modal-overlay">
    <div class="modal-content">
        <div class="flex items-center gap-3 mb-6">
            <div class="w-12 h-12 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl flex items-center justify-center">
                <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
            </div>
            <div>
                <h3 class="text-xl font-bold text-gray-900">Assign Learning Module</h3>
                <p class="text-gray-600">Confirm module assignment</p>
            </div>
        </div>
        
        <div class="mb-6">
            <div class="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-4">
                <p class="font-medium text-blue-800" id="assignModuleName"></p>
                <p class="text-sm text-blue-600 mt-1" id="assignEmployeeName"></p>
            </div>
            <div class="flex items-center gap-3 bg-gray-50 rounded-xl p-4">
                <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                    <i data-lucide="calendar" class="w-5 h-5 text-gray-600"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Deadline</p>
                    <p class="font-medium text-gray-900" id="assignDeadline"></p>
                </div>
            </div>
            <p class="text-sm text-gray-500 mt-4">
                This module will be assigned to the employee with the specified deadline. The employee will be able to access and complete the module.
            </p>
        </div>
        
        <div class="flex gap-3">
            <button type="button" onclick="closeAssignModal()" 
                    class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
            <button type="button" onclick="confirmAssign()" 
                    class="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="check" class="w-5 h-5"></i>
                Assign Module
            </button>
        </div>
    </div>
</div>

<!-- Unassign Confirmation Modal -->
<div id="unassignModal" class="modal-overlay">
    <div class="modal-content">
        <div class="flex items-center gap-3 mb-6">
            <div class="w-12 h-12 bg-gradient-to-br from-red-50 to-rose-50 rounded-xl flex items-center justify-center">
                <i data-lucide="x-circle" class="w-6 h-6 text-red-600"></i>
            </div>
            <div>
                <h3 class="text-xl font-bold text-gray-900">Unassign Module</h3>
                <p class="text-gray-600">Confirm module removal</p>
            </div>
        </div>
        
        <div class="mb-6">
            <p class="text-gray-700" id="unassignMessage"></p>
            <div class="bg-red-50 border border-red-100 rounded-xl p-4 mt-4">
                <p class="text-sm text-red-600 font-medium flex items-center gap-2">
                    <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                    Note: This will remove the module from the employee's learning path.
                </p>
            </div>
        </div>
        
        <div class="flex gap-3">
            <button type="button" onclick="closeUnassignModal()" 
                    class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
            <button type="button" onclick="confirmUnassign()" 
                    class="flex-1 px-4 py-3 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="trash-2" class="w-5 h-5"></i>
                Unassign Module
            </button>
        </div>
    </div>
</div>

<!-- Complete Confirmation Modal -->
<div id="completeModal" class="modal-overlay">
    <div class="modal-content">
        <div class="flex items-center gap-3 mb-6">
            <div class="w-12 h-12 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl flex items-center justify-center">
                <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
            <div>
                <h3 class="text-xl font-bold text-gray-900">Mark as Completed</h3>
                <p class="text-gray-600">Confirm module completion</p>
            </div>
        </div>
        
        <div class="mb-6">
            <p class="text-gray-700" id="completeMessage"></p>
            <div class="bg-green-50 border border-green-100 rounded-xl p-4 mt-4">
                <p class="text-sm text-green-600 font-medium flex items-center gap-2">
                    <i data-lucide="award" class="w-4 h-4"></i>
                    This will mark the module as completed in the employee's learning record.
                </p>
            </div>
        </div>
        
        <div class="flex gap-3">
            <button type="button" onclick="closeCompleteModal()" 
                    class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
            <button type="button" onclick="confirmComplete()" 
                    class="flex-1 px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="check" class="w-5 h-5"></i>
                Mark as Completed
            </button>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl px-8 py-6 flex flex-col items-center gap-4">
        <div class="relative">
            <div class="w-16 h-16 border-4 border-blue-100 rounded-full"></div>
            <div class="w-16 h-16 border-4 border-transparent border-t-blue-600 rounded-full animate-spin absolute top-0 left-0"></div>
        </div>
        <div class="text-center">
            <p class="font-medium text-gray-800">Processing Request</p>
            <p class="text-sm text-gray-500 mt-1">Please wait...</p>
        </div>
    </div>
</div>

<!-- Toast Notification -->
<div id="toast" class="toast hidden">
    <i data-lucide="check-circle" class="w-5 h-5"></i>
    <span id="toastMessage">Action completed successfully</span>
</div>

<script>
lucide.createIcons();

// Modal state variables
let currentEmpId = null;
let currentModId = null;
let currentModuleName = null;
let currentEmployeeName = null;
let currentDeadline = null;

// Show loading
function showLoading() {
    document.getElementById('loadingOverlay').classList.remove('hidden');
    document.getElementById('loadingOverlay').classList.add('flex');
}

// Hide loading
function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hidden');
    document.getElementById('loadingOverlay').classList.remove('flex');
}

// Show toast notification
function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    
    if (isError) {
        toast.classList.add('error');
    } else {
        toast.classList.remove('error');
    }
    
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 5000);
}

// Assign Module Modal Functions
function openAssignModal(empId, modId, empName, modName, deadline) {
    currentEmpId = empId;
    currentModId = modId;
    currentModuleName = modName;
    currentEmployeeName = empName;
    currentDeadline = deadline;
    
    document.getElementById('assignModuleName').textContent = modName;
    document.getElementById('assignEmployeeName').textContent = `To: ${empName}`;
    document.getElementById('assignDeadline').textContent = deadline;
    
    document.getElementById('assignModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeAssignModal() {
    document.getElementById('assignModal').classList.remove('active');
    document.body.style.overflow = '';
    resetModalState();
}

function confirmAssign() {
    if (currentEmpId && currentModId) {
        showLoading();
        
        fetch('assigned_modules.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `employee_id=${currentEmpId}&module_id=${currentModId}&deadline=${currentDeadline}`
        })
        .then(res => res.json())
        .then(data => {
            hideLoading();
            if (data.status === 'success') {
                closeAssignModal();
                showToast('Module assigned successfully');
                setTimeout(() => location.reload(), 1000);
            } else {
                closeAssignModal();
                showToast(data.message || 'Failed to assign module', true);
            }
        })
        .catch(error => {
            hideLoading();
            closeAssignModal();
            showToast('Failed to assign module. Please try again.', true);
            console.error(error);
        });
    }
}

// Unassign Module Modal Functions
function openUnassignModal(empId, modId, empName, modName) {
    currentEmpId = empId;
    currentModId = modId;
    currentModuleName = modName;
    currentEmployeeName = empName;
    
    document.getElementById('unassignMessage').textContent = 
        `Are you sure you want to unassign "${modName}" from ${empName}?`;
    
    document.getElementById('unassignModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeUnassignModal() {
    document.getElementById('unassignModal').classList.remove('active');
    document.body.style.overflow = '';
    resetModalState();
}

function confirmUnassign() {
    if (currentEmpId && currentModId) {
        showLoading();
        
        fetch('unassign_module.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `employee_id=${currentEmpId}&module_id=${currentModId}`
        })
        .then(r => r.text())
        .then(d => {
            hideLoading();
            if (d.trim() === 'success') {
                closeUnassignModal();
                showToast('Module unassigned successfully');
                setTimeout(() => location.reload(), 1000);
            } else {
                closeUnassignModal();
                showToast(d || 'Failed to unassign module', true);
            }
        })
        .catch(error => {
            hideLoading();
            closeUnassignModal();
            showToast('Failed to unassign module. Please try again.', true);
            console.error(error);
        });
    }
}

// Complete Module Modal Functions
function openCompleteModal(empId, modId, empName, modName) {
    currentEmpId = empId;
    currentModId = modId;
    currentModuleName = modName;
    currentEmployeeName = empName;
    
    document.getElementById('completeMessage').textContent = 
        `Are you sure you want to mark "${modName}" as completed for ${empName}?`;
    
    document.getElementById('completeModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCompleteModal() {
    document.getElementById('completeModal').classList.remove('active');
    document.body.style.overflow = '';
    resetModalState();
}

function confirmComplete() {
    if (currentEmpId && currentModId) {
        showLoading();
        
        fetch('mark_completed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `employee_id=${currentEmpId}&module_id=${currentModId}`
        })
        .then(r => r.text())
        .then(d => {
            hideLoading();
            if (d.trim() === 'success') {
                closeCompleteModal();
                showToast('Module marked as completed');
                setTimeout(() => location.reload(), 1000);
            } else {
                closeCompleteModal();
                showToast(d || 'Failed to mark as completed', true);
            }
        })
        .catch(error => {
            hideLoading();
            closeCompleteModal();
            showToast('Failed to mark as completed. Please try again.', true);
            console.error(error);
        });
    }
}

// Reset modal state
function resetModalState() {
    currentEmpId = null;
    currentModId = null;
    currentModuleName = null;
    currentEmployeeName = null;
    currentDeadline = null;
}

// Close modals when clicking outside
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            if (this.id === 'assignModal') closeAssignModal();
            if (this.id === 'unassignModal') closeUnassignModal();
            if (this.id === 'completeModal') closeCompleteModal();
        }
    });
});

// Close modals with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAssignModal();
        closeUnassignModal();
        closeCompleteModal();
    }
});

function filterModules() {
    const searchTerm = document.getElementById("moduleSearch").value.toLowerCase();
    const modules = document.querySelectorAll("#modulesContainer > div");
    
    modules.forEach(module => {
        const moduleText = module.innerText.toLowerCase();
        module.style.display = moduleText.includes(searchTerm) ? "flex" : "none";
    });
}

// Add animation to module cards on load
document.addEventListener('DOMContentLoaded', function() {
    const modules = document.querySelectorAll('.module-card');
    modules.forEach((module, index) => {
        module.style.opacity = '0';
        module.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            module.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            module.style.opacity = '1';
            module.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Ensure sidebar doesn't scroll
    const sidebar = document.querySelector('aside, .sidebar');
    if (sidebar) {
        sidebar.style.overflowY = 'auto';
        sidebar.style.position = 'sticky';
        sidebar.style.top = '0';
        sidebar.style.height = '100vh';
    }
});
</script>

</body>
</html>