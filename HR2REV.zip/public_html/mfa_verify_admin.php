<?php
session_start();
include('dblogin.php');
require_once __DIR__ . '/PHPGangsta/GoogleAuthenticator.php';

$ga = new PHPGangsta_GoogleAuthenticator();

// ✅ Ensure admin is setting up MFA
if (!isset($_SESSION['pending_user_id']) || $_SESSION['pending_user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = trim($_POST['otp'] ?? '');
    $admin_id = $_SESSION['pending_user_id'];

    // Retrieve admin's secret
    $stmt = $conn->prepare("SELECT mfa_secret FROM admin WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $stmt->bind_result($secret);
    $stmt->fetch();
    $stmt->close();

    // Verify OTP
    if (!empty($secret) && $ga->verifyCode($secret, $otp, 2)) {
        // ✅ Enable MFA for admin
        $stmt = $conn->prepare("UPDATE admin SET mfa_enabled = 1 WHERE id = ?");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stmt->close();

        // ✅ Finalize login
        $_SESSION['user_id'] = $admin_id;
        $_SESSION['role'] = 'admin';
        $_SESSION['username'] = $_SESSION['pending_username'] ?? 'Admin';

        // Clean up pending session
        unset($_SESSION['pending_user_id']);
        unset($_SESSION['pending_user_role']);
        unset($_SESSION['pending_username']);

        header("Location: index.php");
        exit;
    } else {
        $error = 'Invalid code. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify Admin MFA — ATIERA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Countdown logic (1 minute = 60 seconds)
        let timeLeft = 60;

        function startCountdown() {
            const timerDisplay = document.getElementById('timer');
            const interval = setInterval(() => {
                timeLeft--;
                timerDisplay.textContent = timeLeft;

                if (timeLeft <= 0) {
                    clearInterval(interval);
                    alert("Session expired. Please log in again.");
                    window.location.href = "logout.php?timeout=1";
                }
            }, 1000);
        }

        window.onload = startCountdown;
    </script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full bg-white p-6 rounded-lg shadow-lg">
        <div class="text-center mb-6">
            <img src="logo.png" alt="ATIERA Logo" class="mx-auto w-20 mb-2">
            <h2 class="text-2xl font-bold text-blue-700">Admin MFA Verification</h2>
            <p class="text-gray-500 text-sm mb-2">
                Enter the 6-digit code from your Google Authenticator app.
            </p>
            <p class="text-red-600 text-sm font-semibold">
                Session expires in <span id="timer">60</span> seconds
            </p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-center">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-4">
            <input type="text" name="otp" inputmode="numeric" pattern="[0-9]*" maxlength="6"
                   class="w-full border rounded px-3 py-2 text-center text-lg tracking-widest"
                   placeholder="Enter 6-digit code" required>
            <button type="submit"
                    class="w-full bg-blue-700 text-white py-2 rounded hover:bg-blue-800 transition">
                Verify & Continue
            </button>
            <a href="login.php"
               class="block w-full text-center text-sm text-gray-500 hover:text-gray-700 mt-3">
                Cancel
            </a>
        </form>
    </div>
</body>
</html>
