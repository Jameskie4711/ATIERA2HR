<?php
// db.php - Database connection for competency system

$host = "localhost";      // XAMPP default host
$user = "hr2_atiera";           // Default user in XAMPP
$pass = "DAJK^PNEBoIi#Otk";               // Default password (empty unless you set one in phpMyAdmin)
$dbname = "hr2_competency";   // Your database name (from competency.sql)

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Optional: uncomment for debugging
// echo "Database connected successfully!";
?>
