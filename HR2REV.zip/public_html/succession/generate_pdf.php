<?php
require('../vendor/fpdf/fpdf.php');
include('../db.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get GET parameters
$employee_id = $_GET['id'] ?? '';
$view = isset($_GET['view']); // if true, open inline
$report_type = 'Succession'; // you can expand later

// Fetch employee(s)
$employees = [];

if ($employee_id) {
    // Fetch single employee
    $stmt = $conn->prepare("SELECT name, role, readiness FROM employees WHERE id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
} else {
    // Fetch all employees
    $result = $conn->query("SELECT name, role, readiness FROM employees ORDER BY name ASC");
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}

// Create PDF
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

/* Title */
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,12,"$report_type Report",0,1,'C');
$pdf->Ln(5);

/* Table Header */
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(240,240,240);
$pdf->Cell(15,10,"#",1,0,'C',true);
$pdf->Cell(65,10,"Employee Name",1,0,'C',true);
$pdf->Cell(60,10,"Role",1,0,'C',true);
$pdf->Cell(40,10,"Readiness",1,1,'C',true);

/* Table Body */
$pdf->SetFont('Arial','',12);
$counter = 1;

if (!empty($employees)) {
    foreach ($employees as $emp) {
        $pdf->Cell(15,10,$counter,1,0,'C');
        $pdf->Cell(65,10,$emp['name'],1,0,'L');
        $pdf->Cell(60,10,$emp['role'],1,0,'L');
        $pdf->Cell(40,10,$emp['readiness'],1,1,'C');
        $counter++;
    }
} else {
    $pdf->Cell(180,10,"No records found.",1,1,'C');
}

/* Output PDF */
$filename = "Succession_Report_" . date('Ymd_His') . ".pdf";
$pdf->Output($view ? 'I' : 'D', $filename);
