// succession-ai.js - Pure JavaScript Succession Planning AI with TensorFlow.js

class SuccessionAI {
    constructor() {
        this.model = null;
        this.featureNames = [
            'skill_match', 'experience_level', 'performance_score',
            'readiness_score', 'training_completion', 'competency_gap',
            'department_match', 'leadership_score', 'tenure_months'
        ];
        this.weights = {
            skill_match: 0.25,
            experience_level: 0.20,
            performance_score: 0.15,
            readiness_score: 0.12,
            training_completion: 0.10,
            competency_gap: -0.08, // Negative because gap is negative
            department_match: 0.05,
            leadership_score: 0.08,
            tenure_months: 0.07
        };
        this.thresholds = {
            ready_now: 0.85,
            ready_soon: 0.70,
            not_ready: 0.50
        };
        this.trainingHistory = [];
    }

    // Initialize AI model
    async initialize() {
        console.log('Initializing Succession Planning AI...');
        
        try {
            // Create a simple neural network model
            this.model = tf.sequential();
            
            // Input layer
            this.model.add(tf.layers.dense({
                units: 16,
                activation: 'relu',
                inputShape: [this.featureNames.length]
            }));
            
            // Hidden layers
            this.model.add(tf.layers.dense({
                units: 8,
                activation: 'relu'
            }));
            
            this.model.add(tf.layers.dense({
                units: 4,
                activation: 'relu'
            }));
            
            // Output layer (readiness score 0-1)
            this.model.add(tf.layers.dense({
                units: 1,
                activation: 'sigmoid'
            }));
            
            // Compile model
            this.model.compile({
                optimizer: tf.train.adam(0.001),
                loss: 'meanSquaredError',
                metrics: ['accuracy']
            });
            
            console.log('AI Model initialized successfully');
            return true;
        } catch (error) {
            console.error('Failed to initialize AI model:', error);
            return false;
        }
    }

    // Calculate feature scores for an employee
    calculateFeatures(employee, targetRole) {
        const features = {};
        
        // 1. Skill Match (0-1)
        features.skill_match = this.calculateSkillMatch(
            employee.skills || [],
            targetRole.required_skills || []
        );
        
        // 2. Experience Level (0-1)
        features.experience_level = Math.min(
            (employee.experience_years || 0) / 
            (targetRole.min_experience || 5), 
            1
        );
        
        // 3. Performance Score (0-1)
        features.performance_score = (employee.performance_rating || 0) / 5;
        
        // 4. Readiness Score (from existing system)
        features.readiness_score = this.mapReadinessToScore(employee.readiness);
        
        // 5. Training Completion (0-1)
        features.training_completion = (employee.training_completed || 0) / 
                                     (employee.training_total || 1);
        
        // 6. Competency Gap (0-1, lower is better)
        features.competency_gap = Math.max(0, 1 - 
            (employee.competency_gap_score || 0.5)
        );
        
        // 7. Department Match (0 or 1)
        features.department_match = (employee.department === targetRole.department) ? 1 : 0.5;
        
        // 8. Leadership Score (0-1)
        features.leadership_score = employee.leadership_assessments ? 
            employee.leadership_assessments.reduce((a, b) => a + b.score, 0) / 
            (employee.leadership_assessments.length * 5) : 0.5;
        
        // 9. Tenure in months (normalized)
        features.tenure_months = Math.min((employee.tenure_months || 0) / 60, 1);
        
        return features;
    }

    // Calculate skill match between employee and role requirements
    calculateSkillMatch(employeeSkills, requiredSkills) {
        if (!requiredSkills || requiredSkills.length === 0) return 1;
        
        const employeeSkillSet = new Set(employeeSkills.map(s => s.toLowerCase()));
        const requiredSkillSet = new Set(requiredSkills.map(s => s.toLowerCase()));
        
        // Find intersection
        const matchingSkills = [...requiredSkillSet].filter(skill => 
            employeeSkillSet.has(skill)
        );
        
        return matchingSkills.length / requiredSkillSet.size;
    }

    // Map readiness text to numeric score
    mapReadinessToScore(readiness) {
        const readinessMap = {
            'ready_now': 1.0,
            'ready_soon': 0.75,
            'not_ready': 0.3,
            'qualified': 1.0,
            'in_progress': 0.75,
            'not_qualified': 0.3
        };
        
        return readinessMap[readiness?.toLowerCase()] || 0.5;
    }

    // Calculate weighted score (rule-based approach)
    calculateWeightedScore(features) {
        let totalScore = 0;
        let totalWeight = 0;
        
        for (const [feature, weight] of Object.entries(this.weights)) {
            if (features[feature] !== undefined) {
                totalScore += features[feature] * weight;
                totalWeight += Math.abs(weight);
            }
        }
        
        // Normalize score
        return totalWeight > 0 ? totalScore / totalWeight : 0;
    }

    // Predict using ML model (if available) or fallback to rule-based
    async predictReadiness(features) {
        try {
            if (this.model) {
                // Convert features to tensor
                const featureArray = this.featureNames.map(name => 
                    features[name] || 0
                );
                const inputTensor = tf.tensor2d([featureArray]);
                
                // Make prediction
                const prediction = this.model.predict(inputTensor);
                const score = await prediction.data();
                
                // Clean up tensors
                inputTensor.dispose();
                prediction.dispose();
                
                return score[0];
            }
        } catch (error) {
            console.warn('ML prediction failed, using rule-based scoring:', error);
        }
        
        // Fallback to rule-based scoring
        return this.calculateWeightedScore(features);
    }

    // Analyze and recommend successors for a role
    async analyzeSuccession(role, candidates, maxRecommendations = 3) {
        console.log(`Analyzing successors for role: ${role.title}`);
        
        const recommendations = [];
        
        // Analyze each candidate
        for (const candidate of candidates) {
            // Calculate features
            const features = this.calculateFeatures(candidate, role);
            
            // Predict readiness score
            const readinessScore = await this.predictReadiness(features);
            
            // Determine readiness category
            let readinessCategory = 'not_ready';
            if (readinessScore >= this.thresholds.ready_now) {
                readinessCategory = 'ready_now';
            } else if (readinessScore >= this.thresholds.ready_soon) {
                readinessCategory = 'ready_soon';
            }
            
            // Calculate strengths and gaps
            const analysis = this.generateAnalysis(features, readinessScore);
            
            recommendations.push({
                candidate_id: candidate.id,
                candidate_name: candidate.name,
                candidate_role: candidate.position,
                department: candidate.department,
                readiness_score: readinessScore,
                readiness_category: readinessCategory,
                features: features,
                strengths: analysis.strengths,
                gaps: analysis.gaps,
                recommended_actions: analysis.actions,
                match_percentage: Math.round(readinessScore * 100)
            });
            
            // Log for training data
            this.trainingHistory.push({
                features: Object.values(features),
                score: readinessScore,
                candidate: candidate.id,
                role: role.id
            });
        }
        
        // Sort by readiness score (highest first)
        recommendations.sort((a, b) => b.readiness_score - a.readiness_score);
        
        // Return top recommendations
        const topRecommendations = recommendations.slice(0, maxRecommendations);
        
        // Generate overall insights
        const insights = this.generateInsights(topRecommendations, role);
        
        return {
            role: role.title,
            role_id: role.id,
            total_candidates: candidates.length,
            recommendations: topRecommendations,
            insights: insights,
            analysis_date: new Date().toISOString()
        };
    }

    // Generate detailed analysis for a candidate
    generateAnalysis(features, overallScore) {
        const strengths = [];
        const gaps = [];
        const actions = [];
        
        // Identify strengths (features > 0.8)
        for (const [feature, value] of Object.entries(features)) {
            if (value >= 0.8) {
                strengths.push({
                    feature: this.formatFeatureName(feature),
                    score: value,
                    description: this.getFeatureDescription(feature, value)
                });
            } else if (value <= 0.4) {
                gaps.push({
                    feature: this.formatFeatureName(feature),
                    score: value,
                    description: this.getFeatureDescription(feature, value)
                });
                
                // Suggest actions for gaps
                const action = this.getImprovementAction(feature, value);
                if (action) actions.push(action);
            }
        }
        
        return { strengths, gaps, actions };
    }

    // Format feature name for display
    formatFeatureName(feature) {
        return feature
            .split('_')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    // Get description for feature score
    getFeatureDescription(feature, score) {
        const descriptions = {
            skill_match: score >= 0.8 ? 'Excellent skill alignment' : 
                        score >= 0.6 ? 'Good skill match' : 
                        'Skill development needed',
            experience_level: score >= 0.8 ? 'Extensive experience' : 
                           score >= 0.6 ? 'Adequate experience' : 
                           'Additional experience required',
            performance_score: score >= 0.8 ? 'Outstanding performance' : 
                             score >= 0.6 ? 'Strong performance' : 
                             'Performance improvement needed'
        };
        
        return descriptions[feature] || `Score: ${Math.round(score * 100)}%`;
    }

    // Get improvement actions for gaps
    getImprovementAction(feature, score) {
        const actions = {
            skill_match: {
                low: 'Enroll in skill-specific training programs',
                medium: 'Participate in cross-training opportunities'
            },
            training_completion: {
                low: 'Complete pending training modules',
                medium: 'Accelerate training plan completion'
            },
            competency_gap: {
                low: 'Focus on competency gap closure through mentoring',
                medium: 'Develop targeted competency improvement plan'
            },
            leadership_score: {
                low: 'Join leadership development program',
                medium: 'Take on small leadership roles to build experience'
            }
        };
        
        const actionSet = actions[feature];
        if (!actionSet) return null;
        
        if (score <= 0.3) return actionSet.low;
        if (score <= 0.6) return actionSet.medium;
        
        return null;
    }

    // Generate overall insights from recommendations
    generateInsights(recommendations, role) {
        if (recommendations.length === 0) {
            return {
                status: 'critical',
                message: 'No suitable successors identified',
                risk_level: 'high',
                immediate_actions: [
                    'Consider external recruitment',
                    'Develop internal talent pipeline',
                    'Review role requirements'
                ]
            };
        }
        
        const topScore = recommendations[0]?.readiness_score || 0;
        const avgScore = recommendations.reduce((sum, rec) => sum + rec.readiness_score, 0) / 
                        recommendations.length;
        
        let status = 'adequate';
        let riskLevel = 'low';
        let message = '';
        
        if (topScore >= 0.9) {
            status = 'excellent';
            message = 'Strong succession pipeline with highly qualified candidates';
        } else if (topScore >= 0.7) {
            status = 'good';
            message = 'Adequate succession options with some development needed';
            riskLevel = 'medium';
        } else {
            status = 'concern';
            message = 'Limited succession options requiring significant development';
            riskLevel = 'high';
        }
        
        // Identify common gaps across candidates
        const commonGaps = this.findCommonGaps(recommendations);
        
        return {
            status: status,
            message: message,
            risk_level: riskLevel,
            top_candidate_score: Math.round(topScore * 100),
            average_score: Math.round(avgScore * 100),
            common_development_needs: commonGaps,
            timeline_recommendation: this.getTimelineRecommendation(topScore)
        };
    }

    // Find common gaps across multiple candidates
    findCommonGaps(recommendations) {
        const gapFrequency = {};
        
        recommendations.forEach(rec => {
            rec.gaps?.forEach(gap => {
                const feature = gap.feature;
                gapFrequency[feature] = (gapFrequency[feature] || 0) + 1;
            });
        });
        
        // Return gaps that appear in at least half of candidates
        return Object.entries(gapFrequency)
            .filter(([_, count]) => count >= Math.ceil(recommendations.length / 2))
            .map(([feature, count]) => ({
                feature: feature,
                frequency: count,
                percentage: Math.round((count / recommendations.length) * 100)
            }));
    }

    // Recommend timeline based on readiness score
    getTimelineRecommendation(score) {
        if (score >= 0.85) return {
            timeline: '0-3 months',
            recommendation: 'Immediate promotion readiness',
            confidence: 'high'
        };
        
        if (score >= 0.70) return {
            timeline: '3-6 months',
            recommendation: 'Short-term development needed',
            confidence: 'medium'
        };
        
        if (score >= 0.50) return {
            timeline: '6-12 months',
            recommendation: 'Moderate development timeline',
            confidence: 'medium'
        };
        
        return {
            timeline: '12+ months',
            recommendation: 'Long-term development plan required',
            confidence: 'low'
        };
    }

    // Train model with historical data
    async trainModel(trainingData) {
        if (!this.model || trainingData.length < 10) {
            console.log('Insufficient training data or model not initialized');
            return false;
        }
        
        try {
            // Prepare features and labels
            const features = trainingData.map(item => item.features);
            const labels = trainingData.map(item => [item.score]);
            
            // Convert to tensors
            const featureTensor = tf.tensor2d(features);
            const labelTensor = tf.tensor2d(labels);
            
            // Train model
            const history = await this.model.fit(featureTensor, labelTensor, {
                epochs: 50,
                batchSize: 32,
                validationSplit: 0.2,
                verbose: 0,
                callbacks: {
                    onEpochEnd: (epoch, logs) => {
                        if (epoch % 10 === 0) {
                            console.log(`Epoch ${epoch}: loss = ${logs.loss.toFixed(4)}`);
                        }
                    }
                }
            });
            
            // Clean up tensors
            featureTensor.dispose();
            labelTensor.dispose();
            
            console.log('Model training completed');
            return true;
        } catch (error) {
            console.error('Model training failed:', error);
            return false;
        }
    }

    // Export model for future use
    async exportModel() {
        if (!this.model) return null;
        
        try {
            const saveResult = await this.model.save('downloads://succession-ai-model');
            return saveResult;
        } catch (error) {
            console.error('Failed to export model:', error);
            return null;
        }
    }

    // Import pre-trained model
    async importModel(modelUrl) {
        try {
            this.model = await tf.loadLayersModel(modelUrl);
            console.log('Model imported successfully');
            return true;
        } catch (error) {
            console.error('Failed to import model:', error);
            return false;
        }
    }

    // Generate visual analysis data for charts
    generateVisualizationData(analysisResult) {
        const recommendations = analysisResult.recommendations || [];
        
        // Data for readiness distribution chart
        const readinessData = {
            ready_now: recommendations.filter(r => r.readiness_category === 'ready_now').length,
            ready_soon: recommendations.filter(r => r.readiness_category === 'ready_soon').length,
            not_ready: recommendations.filter(r => r.readiness_category === 'not_ready').length
        };
        
        // Data for skill radar chart
        const skillRadarData = recommendations.map(rec => ({
            candidate: rec.candidate_name,
            skills: {
                skill_match: rec.features.skill_match * 100,
                experience: rec.features.experience_level * 100,
                performance: rec.features.performance_score * 100,
                leadership: rec.features.leadership_score * 100,
                training: rec.features.training_completion * 100
            }
        }));
        
        // Timeline data
        const timelineData = recommendations.map(rec => ({
            candidate: rec.candidate_name,
            timeline: this.getTimelineRecommendation(rec.readiness_score).timeline,
            confidence: this.getTimelineRecommendation(rec.readiness_score).confidence
        }));
        
        return {
            readiness_distribution: readinessData,
            skill_radar: skillRadarData,
            timeline_analysis: timelineData,
            risk_assessment: analysisResult.insights?.risk_level || 'unknown',
            overall_score: analysisResult.insights?.average_score || 0
        };
    }
}

// Example usage and integration with existing page
class SuccessionAIIntegration {
    constructor() {
        this.ai = new SuccessionAI();
        this.initialized = false;
    }

    // Initialize and setup AI
    async setup() {
        console.log('Setting up Succession Planning AI...');
        
        // Load TensorFlow.js if not already loaded
        if (typeof tf === 'undefined') {
            await this.loadTensorFlow();
        }
        
        // Initialize AI model
        this.initialized = await this.ai.initialize();
        
        if (this.initialized) {
            console.log('Succession AI ready');
            this.bindEvents();
            this.loadExistingData();
        }
        
        return this.initialized;
    }

    // Load TensorFlow.js dynamically
    async loadTensorFlow() {
        return new Promise((resolve, reject) => {
            if (typeof tf !== 'undefined') {
                resolve();
                return;
            }
            
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@latest';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Bind to page elements and events
    bindEvents() {
        // Bind to AI recommendation cards
        const aiCards = document.querySelectorAll('.bg-blue-50, .ai-recommendation-card');
        aiCards.forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                this.showAIAnalysis(card);
            });
        });
        
        // Add AI analysis button to role cards
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow');
        roleCards.forEach(card => {
            this.addAIAnalysisButton(card);
        });
        
        // Bind to existing buttons
        const aiButtons = document.querySelectorAll('button:contains("AI Analysis"), button:contains("Get AI")');
        aiButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.triggerAIAnalysis(e.target);
            });
        });
    }

    // Load existing employee and role data
    loadExistingData() {
        // Extract employee data from page
        const employees = this.extractEmployeeData();
        const roles = this.extractRoleData();
        
        // Store for later use
        this.employeeData = employees;
        this.roleData = roles;
        
        console.log(`Loaded ${employees.length} employees and ${roles.length} roles`);
    }

    // Extract employee data from page
    extractEmployeeData() {
        const employees = [];
        
        // Extract from table rows if available
        const rows = document.querySelectorAll('tbody tr, .employee-card');
        rows.forEach(row => {
            const employee = {
                id: this.extractId(row),
                name: this.extractText(row, '.employee-name, [data-name]'),
                position: this.extractText(row, '.position, [data-position]'),
                department: this.extractText(row, '.department, [data-department]'),
                readiness: this.extractReadiness(row)
            };
            
            if (employee.id && employee.name) {
                employees.push(employee);
            }
        });
        
        return employees;
    }

    // Extract role data from page
    extractRoleData() {
        const roles = [];
        
        // Extract from role cards
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow, .role-card');
        roleCards.forEach(card => {
            const role = {
                id: this.extractId(card),
                title: this.extractText(card, 'h3, .role-title, [data-role]'),
                department: this.extractText(card, '.department, [data-department]')
            };
            
            if (role.title) {
                roles.push(role);
            }
        });
        
        return roles;
    }

    // Helper extraction methods
    extractId(element) {
        return element.id || 
               element.dataset.id || 
               element.querySelector('[data-id]')?.dataset.id ||
               Math.random().toString(36).substr(2, 9);
    }

    extractText(element, selector) {
        const found = selector ? element.querySelector(selector) : element;
        return found?.textContent?.trim() || '';
    }

    extractReadiness(element) {
        const badge = element.querySelector('.px-3.py-1.rounded-full, .readiness-badge');
        if (badge) {
            const text = badge.textContent.trim().toLowerCase();
            if (text.includes('ready now') || text.includes('qualified')) return 'ready_now';
            if (text.includes('ready soon') || text.includes('in progress')) return 'ready_soon';
            if (text.includes('not ready') || text.includes('not qualified')) return 'not_ready';
        }
        return 'not_ready';
    }

    // Add AI analysis button to role card
    addAIAnalysisButton(card) {
        if (card.querySelector('.ai-analysis-btn')) return;
        
        const button = document.createElement('button');
        button.className = 'ai-analysis-btn mt-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg text-sm font-medium hover:shadow-lg transition-all flex items-center gap-2';
        button.innerHTML = `
            <i class="fas fa-robot"></i>
            AI Successor Analysis
        `;
        
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            this.analyzeRole(card);
        });
        
        const actionDiv = card.querySelector('.flex.gap-3.mt-6, .action-buttons');
        if (actionDiv) {
            actionDiv.appendChild(button);
        } else {
            card.appendChild(button);
        }
    }

    // Analyze a specific role
    async analyzeRole(roleCard) {
        if (!this.initialized) {
            alert('AI is still initializing. Please wait...');
            return;
        }
        
        const roleTitle = this.extractText(roleCard, 'h3, .role-title');
        const roleDepartment = this.extractText(roleCard, '.department, [data-department]');
        
        // Find matching role in data
        const role = this.roleData.find(r => 
            r.title === roleTitle || 
            r.department === roleDepartment
        ) || {
            title: roleTitle,
            department: roleDepartment,
            required_skills: [] // Default empty
        };
        
        // Find potential candidates (employees in same department or with similar roles)
        const candidates = this.findPotentialCandidates(role);
        
        if (candidates.length === 0) {
            this.showNoCandidatesMessage(roleCard);
            return;
        }
        
        // Show loading state
        this.showLoading(roleCard);
        
        try {
            // Run AI analysis
            const analysis = await this.ai.analyzeSuccession(role, candidates);
            
            // Display results
            this.displayAnalysisResults(analysis, roleCard);
            
            // Store analysis for later reference
            this.currentAnalysis = analysis;
            
        } catch (error) {
            console.error('AI analysis failed:', error);
            this.showError(roleCard, 'Analysis failed. Please try again.');
        }
    }

    // Find potential candidates for a role
    findPotentialCandidates(role) {
        return this.employeeData.filter(employee => {
            // Basic filtering - same department or similar role
            return employee.department === role.department ||
                   employee.position.toLowerCase().includes(role.title.toLowerCase()) ||
                   role.title.toLowerCase().includes(employee.position.toLowerCase());
        }).map(employee => ({
            ...employee,
            // Add mock data for demonstration
            skills: ['leadership', 'communication', 'problem_solving'],
            experience_years: Math.floor(Math.random() * 10) + 1,
            performance_rating: 3 + Math.random() * 2, // 3-5
            training_completed: Math.floor(Math.random() * 10),
            training_total: 10,
            competency_gap_score: Math.random(),
            leadership_assessments: [
                { score: 3 + Math.random() * 2 }
            ],
            tenure_months: Math.floor(Math.random() * 120) + 12
        }));
    }

    // Display analysis results
    displayAnalysisResults(analysis, roleCard) {
        // Remove loading state
        this.removeLoading(roleCard);
        
        // Create results container
        const resultsContainer = document.createElement('div');
        resultsContainer.className = 'ai-results-container mt-4 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200';
        resultsContainer.innerHTML = this.generateResultsHTML(analysis);
        
        // Add to role card
        const existingResults = roleCard.querySelector('.ai-results-container');
        if (existingResults) {
            existingResults.remove();
        }
        
        roleCard.appendChild(resultsContainer);
        
        // Add visualization
        this.addVisualizations(analysis, resultsContainer);
    }

    // Generate HTML for results
    generateResultsHTML(analysis) {
        const topCandidate = analysis.recommendations[0];
        
        return `
            <div class="ai-analysis-results">
                <div class="flex items-center justify-between mb-4">
                    <h4 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                        <i class="fas fa-robot text-blue-600"></i>
                        AI Successor Analysis
                    </h4>
                    <span class="px-3 py-1 rounded-full text-sm font-medium ${this.getRiskColor(analysis.insights.risk_level)}">
                        ${analysis.insights.risk_level.toUpperCase()} RISK
                    </span>
                </div>
                
                ${topCandidate ? `
                <div class="mb-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-medium text-gray-700">Top Candidate</span>
                        <span class="text-sm font-bold ${this.getScoreColor(topCandidate.match_percentage)}">
                            ${topCandidate.match_percentage}% Match
                        </span>
                    </div>
                    <div class="bg-white rounded-lg p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium text-gray-900">${topCandidate.candidate_name}</p>
                                <p class="text-sm text-gray-600">${topCandidate.candidate_role} • ${topCandidate.department}</p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-xs font-semibold ${this.getReadinessColor(topCandidate.readiness_category)}">
                                ${topCandidate.readiness_category.replace('_', ' ').toUpperCase()}
                            </span>
                        </div>
                        
                        <div class="mt-4">
                            <p class="text-sm font-medium text-gray-700 mb-2">Timeline: ${this.ai.getTimelineRecommendation(topCandidate.readiness_score).timeline}</p>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-green-600 h-2 rounded-full" style="width: ${topCandidate.match_percentage}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                ` : ''}
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div class="bg-white rounded-lg p-3 border border-gray-200">
                        <p class="text-xs text-gray-500">Total Candidates</p>
                        <p class="text-xl font-bold text-gray-900">${analysis.total_candidates}</p>
                    </div>
                    <div class="bg-white rounded-lg p-3 border border-gray-200">
                        <p class="text-xs text-gray-500">Average Score</p>
                        <p class="text-xl font-bold ${this.getScoreColor(analysis.insights.average_score)}">
                            ${analysis.insights.average_score}%
                        </p>
                    </div>
                </div>
                
                ${analysis.insights.common_development_needs?.length > 0 ? `
                <div class="mb-4">
                    <p class="text-sm font-medium text-gray-700 mb-2">Common Development Needs:</p>
                    <div class="space-y-2">
                        ${analysis.insights.common_development_needs.map(need => `
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-600">${need.feature}</span>
                                <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                                    ${need.percentage}% of candidates
                                </span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div class="mt-4 pt-4 border-t border-gray-200">
                    <button class="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors view-details-btn">
                        View Detailed Analysis
                    </button>
                </div>
            </div>
        `;
    }

    // Add visualizations to results
    addVisualizations(analysis, container) {
        const vizData = this.ai.generateVisualizationData(analysis);
        
        // Create canvas for simple chart
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 200;
        canvas.style.maxWidth = '100%';
        canvas.className = 'mt-4';
        
        container.appendChild(canvas);
        
        // Draw simple chart
        this.drawReadinessChart(canvas, vizData.readiness_distribution);
        
        // Add event listener for detailed view
        const detailsBtn = container.querySelector('.view-details-btn');
        if (detailsBtn) {
            detailsBtn.addEventListener('click', () => {
                this.showDetailedAnalysis(analysis);
            });
        }
    }

    // Draw simple readiness chart
    drawReadinessChart(canvas, data) {
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Chart configuration
        const colors = {
            ready_now: '#10b981',
            ready_soon: '#f59e0b',
            not_ready: '#ef4444'
        };
        
        const labels = {
            ready_now: 'Ready Now',
            ready_soon: 'Ready Soon',
            not_ready: 'Not Ready'
        };
        
        const total = data.ready_now + data.ready_soon + data.not_ready;
        if (total === 0) return;
        
        let startAngle = 0;
        
        // Draw pie chart
        Object.entries(data).forEach(([key, value]) => {
            if (value === 0) return;
            
            const sliceAngle = (value / total) * 2 * Math.PI;
            
            // Draw slice
            ctx.beginPath();
            ctx.moveTo(width / 2, height / 2);
            ctx.arc(width / 2, height / 2, Math.min(width, height) / 3, startAngle, startAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = colors[key];
            ctx.fill();
            
            // Draw label
            const angle = startAngle + sliceAngle / 2;
            const radius = Math.min(width, height) / 2.5;
            const x = width / 2 + Math.cos(angle) * radius;
            const y = height / 2 + Math.sin(angle) * radius;
            
            ctx.fillStyle = '#1f2937';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${value}`, x, y);
            
            startAngle += sliceAngle;
        });
        
        // Draw legend
        let legendY = height - 60;
        Object.entries(labels).forEach(([key, label]) => {
            if (data[key] === 0) return;
            
            ctx.fillStyle = colors[key];
            ctx.fillRect(20, legendY, 12, 12);
            
            ctx.fillStyle = '#374151';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(`${label}: ${data[key]}`, 40, legendY + 10);
            
            legendY += 20;
        });
    }

    // Show detailed analysis modal
    showDetailedAnalysis(analysis) {
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
        modal.innerHTML = this.generateDetailedModalHTML(analysis);
        
        // Add to page
        document.body.appendChild(modal);
        
        // Add close functionality
        const closeBtn = modal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.remove();
            });
        }
        
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    // Generate detailed modal HTML
    generateDetailedModalHTML(analysis) {
        return `
            <div class="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
                <div class="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900">AI Succession Analysis</h2>
                            <p class="text-gray-600">${analysis.role} • ${analysis.analysis_date ? new Date(analysis.analysis_date).toLocaleDateString() : 'Today'}</p>
                        </div>
                        <button class="close-modal p-2 hover:bg-gray-100 rounded-lg">
                            <i class="fas fa-times text-gray-500"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-6">
                    <!-- Summary -->
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Executive Summary</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Risk Level</p>
                                <p class="text-2xl font-bold ${this.getRiskColor(analysis.insights.risk_level)}">
                                    ${analysis.insights.risk_level.toUpperCase()}
                                </p>
                            </div>
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Succession Score</p>
                                <p class="text-2xl font-bold ${this.getScoreColor(analysis.insights.average_score)}">
                                    ${analysis.insights.average_score}/100
                                </p>
                            </div>
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Timeline</p>
                                <p class="text-2xl font-bold text-gray-900">
                                    ${analysis.insights.timeline_recommendation?.timeline || 'N/A'}
                                </p>
                            </div>
                        </div>
                        <p class="mt-4 text-gray-700">${analysis.insights.message}</p>
                    </div>
                    
                    <!-- Top Candidates -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recommended Successors</h3>
                        <div class="space-y-4">
                            ${analysis.recommendations.map((candidate, index) => `
                                <div class="bg-white border border-gray-200 rounded-xl p-6">
                                    <div class="flex items-center justify-between mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                                                <span class="text-lg font-bold text-blue-600">${index + 1}</span>
                                            </div>
                                            <div>
                                                <h4 class="font-semibold text-gray-900">${candidate.candidate_name}</h4>
                                                <p class="text-sm text-gray-600">${candidate.candidate_role} • ${candidate.department}</p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <span class="text-2xl font-bold ${this.getScoreColor(candidate.match_percentage)}">
                                                ${candidate.match_percentage}%
                                            </span>
                                            <p class="text-sm text-gray-500">Match Score</p>
                                        </div>
                                    </div>
                                    
                                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Readiness</p>
                                            <p class="font-medium ${this.getReadinessTextColor(candidate.readiness_category)}">
                                                ${candidate.readiness_category.replace('_', ' ')}
                                            </p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Timeline</p>
                                            <p class="font-medium text-gray-900">
                                                ${this.ai.getTimelineRecommendation(candidate.readiness_score).timeline}
                                            </p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Strengths</p>
                                            <p class="font-medium text-gray-900">${candidate.strengths?.length || 0}</p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Gaps</p>
                                            <p class="font-medium text-gray-900">${candidate.gaps?.length || 0}</p>
                                        </div>
                                    </div>
                                    
                                    ${candidate.strengths?.length > 0 ? `
                                    <div class="mb-3">
                                        <p class="text-sm font-medium text-gray-700 mb-2">Key Strengths:</p>
                                        <div class="flex flex-wrap gap-2">
                                            ${candidate.strengths.slice(0, 3).map(strength => `
                                                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                                                    ${strength.feature}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                    ` : ''}
                                    
                                    ${candidate.recommended_actions?.length > 0 ? `
                                    <div>
                                        <p class="text-sm font-medium text-gray-700 mb-2">Recommended Actions:</p>
                                        <ul class="space-y-1">
                                            ${candidate.recommended_actions.slice(0, 3).map(action => `
                                                <li class="text-sm text-gray-600 flex items-start gap-2">
                                                    <i class="fas fa-chevron-right text-blue-500 mt-1"></i>
                                                    ${action}
                                                </li>
                                            `).join('')}
                                        </ul>
                                    </div>
                                    ` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <!-- Development Plan -->
                    ${analysis.insights.common_development_needs?.length > 0 ? `
                    <div class="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recommended Development Plan</h3>
                        <div class="space-y-4">
                            ${analysis.insights.common_development_needs.map(need => `
                                <div class="bg-white rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="font-medium text-gray-900">${need.feature}</span>
                                        <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                                            ${need.percentage}% need improvement
                                        </span>
                                    </div>
                                    <p class="text-sm text-gray-600">Consider implementing targeted training programs to address this gap across multiple candidates.</p>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}
                    
                    <!-- Actions -->
                    <div class="flex gap-4">
                        <button class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors export-analysis-btn">
                            <i class="fas fa-download mr-2"></i> Export Analysis
                        </button>
                        <button class="flex-1 py-3 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl font-medium transition-colors create-plan-btn">
                            <i class="fas fa-plus mr-2"></i> Create Development Plan
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Helper methods for styling
    getRiskColor(riskLevel) {
        const colors = {
            high: 'bg-red-100 text-red-800',
            medium: 'bg-yellow-100 text-yellow-800',
            low: 'bg-green-100 text-green-800'
        };
        return colors[riskLevel] || 'bg-gray-100 text-gray-800';
    }

    getScoreColor(score) {
        if (score >= 80) return 'text-green-600';
        if (score >= 60) return 'text-yellow-600';
        return 'text-red-600';
    }

    getReadinessColor(category) {
        const colors = {
            ready_now: 'bg-green-100 text-green-600',
            ready_soon: 'bg-yellow-100 text-yellow-600',
            not_ready: 'bg-red-100 text-red-600'
        };
        return colors[category] || 'bg-gray-100 text-gray-600';
    }

    getReadinessTextColor(category) {
        const colors = {
            ready_now: 'text-green-600',
            ready_soon: 'text-yellow-600',
            not_ready: 'text-red-600'
        };
        return colors[category] || 'text-gray-600';
    }

    // Show loading state
    showLoading(element) {
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'ai-loading mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200';
        loadingDiv.innerHTML = `
            <div class="flex items-center justify-center gap-3">
                <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                <span class="text-gray-700">AI is analyzing potential successors...</span>
            </div>
        `;
        
        const existingLoading = element.querySelector('.ai-loading');
        if (existingLoading) existingLoading.remove();
        
        element.appendChild(loadingDiv);
    }

    removeLoading(element) {
        const loading = element.querySelector('.ai-loading');
        if (loading) loading.remove();
    }

    showNoCandidatesMessage(element) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-no-candidates mt-4 p-4 bg-yellow-50 rounded-xl border border-yellow-200';
        messageDiv.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas fa-exclamation-triangle text-yellow-600"></i>
                <div>
                    <p class="font-medium text-yellow-800">No suitable candidates found</p>
                    <p class="text-sm text-yellow-600 mt-1">Consider expanding search or developing internal talent.</p>
                </div>
            </div>
        `;
        
        const existing = element.querySelector('.ai-no-candidates, .ai-results-container');
        if (existing) existing.remove();
        
        element.appendChild(messageDiv);
    }

    showError(element, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'ai-error mt-4 p-4 bg-red-50 rounded-xl border border-red-200';
        errorDiv.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas fa-exclamation-circle text-red-600"></i>
                <div>
                    <p class="font-medium text-red-800">Analysis Error</p>
                    <p class="text-sm text-red-600 mt-1">${message}</p>
                </div>
            </div>
        `;
        
        const existing = element.querySelector('.ai-error, .ai-loading, .ai-results-container');
        if (existing) existing.remove();
        
        element.appendChild(errorDiv);
    }

    // Show AI analysis for clicked card
    showAIAnalysis(card) {
        // Find associated role card
        const roleCard = card.closest('.bg-white.rounded-xl.shadow, .role-card');
        if (roleCard) {
            this.analyzeRole(roleCard);
        } else {
            // If no role card found, analyze all roles
            this.analyzeAllRoles();
        }
    }

    // Analyze all roles on the page
    async analyzeAllRoles() {
        if (!this.initialized) {
            alert('AI is still initializing. Please wait...');
            return;
        }
        
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow, .role-card');
        const results = [];
        
        for (const card of roleCards) {
            const analysis = await this.analyzeRole(card);
            if (analysis) {
                results.push(analysis);
            }
        }
        
        // Generate summary report
        this.generateSummaryReport(results);
    }

    // Generate summary report for all analyses
    generateSummaryReport(analyses) {
        const summary = {
            total_roles: analyses.length,
            high_risk_roles: analyses.filter(a => a.insights.risk_level === 'high').length,
            medium_risk_roles: analyses.filter(a => a.insights.risk_level === 'medium').length,
            low_risk_roles: analyses.filter(a => a.insights.risk_level === 'low').length,
            average_succession_score: Math.round(
                analyses.reduce((sum, a) => sum + a.insights.average_score, 0) / analyses.length
            ),
            roles_without_successors: analyses.filter(a => a.recommendations.length === 0).length
        };
        
        // Create summary modal
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
        modal.innerHTML = `
            <div class="bg-white rounded-2xl w-full max-w-2xl">
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-2xl font-bold text-gray-900">Succession Planning Summary</h2>
                    <p class="text-gray-600">Overall organizational readiness analysis</p>
                </div>
                
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-blue-50 rounded-xl p-4">
                            <p class="text-sm text-gray-500">Total Roles Analyzed</p>
                            <p class="text-3xl font-bold text-gray-900">${summary.total_roles}</p>
                        </div>
                        <div class="bg-green-50 rounded-xl p-4">
                            <p class="text-sm text-gray-500">Overall Succession Score</p>
                            <p class="text-3xl font-bold ${this.getScoreColor(summary.average_succession_score)}">
                                ${summary.average_succession_score}/100
                            </p>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <h3 class="text-lg font-semibold text-gray-900">Risk Distribution</h3>
                        <div class="space-y-3">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-3 h-3 rounded-full bg-red-500"></div>
                                    <span class="text-gray-700">High Risk Roles</span>
                                </div>
                                <span class="font-medium">${summary.high_risk_roles} (${Math.round(summary.high_risk_roles / summary.total_roles * 100)}%)</span>
                            </div>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                                    <span class="text-gray-700">Medium Risk Roles</span>
                                </div>
                                <span class="font-medium">${summary.medium_risk_roles} (${Math.round(summary.medium_risk_roles / summary.total_roles * 100)}%)</span>
                            </div>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-3 h-3 rounded-full bg-green-500"></div>
                                    <span class="text-gray-700">Low Risk Roles</span>
                                </div>
                                <span class="font-medium">${summary.low_risk_roles} (${Math.round(summary.low_risk_roles / summary.total_roles * 100)}%)</span>
                            </div>
                        </div>
                    </div>
                    
                    ${summary.roles_without_successors > 0 ? `
                    <div class="bg-yellow-50 rounded-xl p-4">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-exclamation-triangle text-yellow-600"></i>
                            <div>
                                <p class="font-medium text-yellow-800">Critical Finding</p>
                                <p class="text-sm text-yellow-600 mt-1">
                                    ${summary.roles_without_successors} role${summary.roles_without_successors !== 1 ? 's' : ''} have no identified successors.
                                    Immediate action is recommended.
                                </p>
                            </div>
                        </div>
                    </div>
                    ` : ''}
                    
                    <div class="pt-4 border-t border-gray-200">
                        <button class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors close-summary-btn">
                            Close Summary
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-summary-btn').addEventListener('click', () => {
            modal.remove();
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    // Trigger analysis from button
    triggerAIAnalysis(button) {
        const card = button.closest('.bg-white.rounded-xl.shadow, .role-card, .employee-card');
        if (card) {
            this.analyzeRole(card);
        } else {
            this.analyzeAllRoles();
        }
    }
}

// Initialize and integrate when page loads
document.addEventListener('DOMContentLoaded', async () => {
    // Check if we're on the succession planning page
    if (document.querySelector('.succession-planning, [href*="succession"]')) {
        const successionAI = new SuccessionAIIntegration();
        
        // Show initialization message
        const initMessage = document.createElement('div');
        initMessage.className = 'fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-3 rounded-lg shadow-lg z-40';
        initMessage.innerHTML = `
            <div class="flex items-center gap-3">
                <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Initializing Succession Planning AI...</span>
            </div>
        `;
        document.body.appendChild(initMessage);
        
        // Initialize AI
        const initialized = await successionAI.setup();
        
        // Update message
        if (initialized) {
            initMessage.innerHTML = `
                <div class="flex items-center gap-3">
                    <i class="fas fa-robot"></i>
                    <span>Succession AI Ready ✓</span>
                </div>
            `;
            setTimeout(() => initMessage.remove(), 3000);
        } else {
            initMessage.innerHTML = `
                <div class="flex items-center gap-3">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>AI Initialization Failed</span>
                </div>
            `;
            initMessage.className = initMessage.className.replace('bg-blue-600', 'bg-red-600');
            setTimeout(() => initMessage.remove(), 5000);
        }
        
        // Make available globally for debugging
        window.successionAI = successionAI;
    }
});