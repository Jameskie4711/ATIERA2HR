<?php 
include('../session_check.php'); 
include('../db.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch employees
$employees = [];
$sql = "SELECT id, name, department, readiness FROM employees ORDER BY name ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $employees[] = $row;
  }
}

// Count stats for dashboard
$total_employees = count($employees);
$ready_count = array_filter($employees, fn($e) => $e['readiness'] === 'Ready Now');
$progress_count = array_filter($employees, fn($e) => $e['readiness'] === 'Ready Soon');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Succession Reports - ATIERA HRMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  body {
    overflow: hidden; /* Prevent body scrolling */
    height: 100vh;
    margin: 0;
  }
  
  /* Main content scrolling */
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 0.5rem;
  }
  
  .main-content-scroll::-webkit-scrollbar {
    width: 8px;
  }
  
  .main-content-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  /* Smooth scrolling */
  .main-content-scroll {
    scroll-behavior: smooth;
  }
  
  /* Table specific scrolling */
  .table-scroll {
    max-height: 500px;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
  }
  
  .table-scroll::-webkit-scrollbar {
    width: 6px;
  }
  
  .table-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 3px;
  }
  
  .table-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
  }
  
  .table-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
</style>
</head>

<body class="bg-gray-50 min-h-screen font-sans flex h-screen overflow-hidden">

<?php include __DIR__ . '/../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-hidden">
  <!-- Main content with scrolling -->
  <main class="main-content-scroll p-6">

    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
      <div>
        <h1 class="text-3xl font-bold text-gray-900">Succession Reports</h1>
        <p class="text-gray-600 mt-2">Generate and view employee succession planning reports</p>
      </div>
      <?php include __DIR__ . '/../profile.php'; ?>
    </div>

    <!-- Tabs -->
    <div class="bg-gray-800 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-xl mb-8">
      <a href="/succession/succession.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-home"></i>
        <span>Home</span>
      </a>
      <a href="/succession/succ_reports.php" class="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-file-alt"></i>
        <span>Manage Reports</span>
      </a>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Total Employees</p>
            <p class="text-3xl font-bold text-gray-900 mt-2"><?= $total_employees; ?></p>
          </div>
          <div class="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-users text-blue-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Available for report generation</p>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Ready Now</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= count($ready_count); ?></p>
          </div>
          <div class="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-check-circle text-green-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Immediate succession candidates</p>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">In Progress</p>
            <p class="text-3xl font-bold text-yellow-600 mt-2"><?= count($progress_count); ?></p>
          </div>
          <div class="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-clock text-yellow-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Developing for future roles</p>
        </div>
      </div>
    </div>

    <!-- Reports Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
      <!-- Header -->
      <div class="p-6 border-b border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 class="text-xl font-bold text-gray-900">Employee Succession Reports</h2>
            <p class="text-gray-600 mt-1">Select an employee to view their succession planning report</p>
          </div>
          
          <div class="flex flex-col sm:flex-row gap-3">
            <!-- Search -->
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i class="fas fa-search text-gray-400"></i>
              </div>
              <input
                type="text"
                id="searchInput"
                placeholder="Search employees..."
                class="pl-10 pr-4 py-2.5 w-full sm:w-64 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
            </div>
            
            <!-- Generate All Button -->
            <button class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg flex items-center gap-2 transition-colors">
              <i class="fas fa-file-export"></i>
              <span>Export All</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Table Container with Scroll -->
      <div class="table-scroll">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead>
              <tr class="bg-gray-50 border-b border-gray-200 sticky top-0">
                <th class="py-4 px-6 text-left">
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Employee</span>
                  </div>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Department</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Readiness</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Actions</span>
                </th>
              </tr>
            </thead>

            <tbody class="divide-y divide-gray-100">
              <?php foreach ($employees as $emp): ?>
                <tr class="employee-row hover:bg-gray-50 transition-colors"
                    data-name="<?= strtolower(htmlspecialchars($emp['name'])); ?>"
                    data-department="<?= strtolower(htmlspecialchars($emp['department'] ?? '')); ?>">
                  
                  <!-- Employee Name -->
                  <td class="py-4 px-6">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user text-indigo-600"></i>
                      </div>
                      <div>
                        <p class="font-medium text-gray-900"><?= htmlspecialchars($emp['name']); ?></p>
                        <p class="text-sm text-gray-500">ID: <?= $emp['id']; ?></p>
                      </div>
                    </div>
                  </td>
                  
                  <!-- Department -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                      <i class="fas fa-building"></i>
                      <?= htmlspecialchars($emp['department'] ?? 'Not specified'); ?>
                    </span>
                  </td>
                  
                  <!-- Readiness -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold
                      <?= ($emp['readiness'] ?? '') == 'Ready Now'
                        ? 'bg-green-100 text-green-700'
                        : (($emp['readiness'] ?? '') == 'Ready Soon'
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-gray-100 text-gray-700') ?>">
                      <div class="w-2 h-2 rounded-full 
                        <?= ($emp['readiness'] ?? '') == 'Ready Now'
                          ? 'bg-green-500'
                          : (($emp['readiness'] ?? '') == 'Ready Soon'
                            ? 'bg-yellow-500'
                            : 'bg-gray-500') ?>"></div>
                      <?= htmlspecialchars($emp['readiness'] ?? 'Not assessed'); ?>
                    </span>
                  </td>
                  
                  <!-- Actions -->
                  <td class="py-4 px-6">
                    <div class="flex items-center gap-2">
                      <!-- View Report -->
                      <a href="generate_report.php?id=<?= $emp['id']; ?>&view=1"
                         target="_blank"
                         class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors text-sm">
                        <i class="fas fa-eye"></i>
                        View Report
                      </a>
                      
                      <!-- Download PDF -->
                      <a href="generate_report.php?id=<?= $emp['id']; ?>&download=1"
                         class="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg font-medium transition-colors text-sm">
                        <i class="fas fa-download"></i>
                        PDF
                      </a>
                      
                      <!-- More Options -->
                      <div class="relative group">
                        <button class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                          <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10 hidden group-hover:block">
                          <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            <i class="fas fa-chart-line mr-2"></i>
                            Analytics
                          </a>
                          <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            <i class="fas fa-share-alt mr-2"></i>
                            Share Report
                          </a>
                          <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            <i class="fas fa-print mr-2"></i>
                            Print
                          </a>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>

              <!-- No Results -->
              <tr id="noResultRow" class="hidden">
                <td colspan="4" class="py-12 px-6 text-center">
                  <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-search text-gray-400 text-xl"></i>
                  </div>
                  <h3 class="text-lg font-semibold text-gray-700 mb-2">No matching employees found</h3>
                  <p class="text-gray-500">Try searching with different keywords</p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Footer -->
      <div class="p-6 border-t border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="text-sm text-gray-600">
            Showing <span class="font-medium"><?= count($employees); ?></span> employees
          </div>
          
          <div class="flex items-center gap-2">
            <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              <i class="fas fa-chevron-left"></i>
            </button>
            <span class="px-3 py-2 text-sm text-gray-700">Page 1 of 1</span>
            <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              <i class="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Quick Tips -->
    <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="bg-blue-50 border border-blue-100 rounded-xl p-6">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <i class="fas fa-lightbulb text-blue-600"></i>
          </div>
          <div>
            <h4 class="font-semibold text-gray-900 mb-2">Report Tips</h4>
            <ul class="text-sm text-gray-700 space-y-1">
              <li>• Reports include readiness assessment and successor recommendations</li>
              <li>• Download PDF versions for offline review</li>
              <li>• Use the search to quickly find specific employees</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div class="bg-green-50 border border-green-100 rounded-xl p-6">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <i class="fas fa-question-circle text-green-600"></i>
          </div>
          <div>
            <h4 class="font-semibold text-gray-900 mb-2">Need Help?</h4>
            <p class="text-sm text-gray-700 mb-3">Having trouble with reports or need customized analysis?</p>
            <button class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>

  </main>
</div>

<?php include __DIR__ . '/../chatbot.php'; ?>

<script>
// Search functionality
const searchInput = document.getElementById('searchInput');
const rows = document.querySelectorAll('.employee-row');
const noResultRow = document.getElementById('noResultRow');

searchInput.addEventListener('keyup', () => {
  let visible = 0;
  const val = searchInput.value.toLowerCase().trim();

  rows.forEach(row => {
    const name = row.dataset.name;
    const department = row.dataset.department;
    const matches = name.includes(val) || department.includes(val);
    
    row.style.display = matches ? '' : 'none';
    if (matches) visible++;
  });

  noResultRow.classList.toggle('hidden', visible !== 0);
});

// Add hover effects to action buttons
document.addEventListener('DOMContentLoaded', function() {
  const buttons = document.querySelectorAll('button, a');
  buttons.forEach(button => {
    button.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-1px)';
      this.style.transition = 'transform 0.2s ease';
    });
    
    button.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
  
  // Table row hover effect
  const tableRows = document.querySelectorAll('tbody tr');
  tableRows.forEach(row => {
    row.addEventListener('mouseenter', function() {
      this.classList.add('bg-gray-50');
    });
    
    row.addEventListener('mouseleave', function() {
      if (!this.classList.contains('hover:bg-gray-50')) {
        this.classList.remove('bg-gray-50');
      }
    });
  });
  
  // Clear search on escape key
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      searchInput.dispatchEvent(new Event('keyup'));
      searchInput.blur();
    }
  });
  
  // Ensure sidebar doesn't scroll
  const sidebar = document.querySelector('aside, .sidebar');
  if (sidebar) {
    sidebar.style.overflowY = 'auto';
    sidebar.style.position = 'sticky';
    sidebar.style.top = '0';
    sidebar.style.height = '100vh';
  }
});
</script>
</body>
</html>