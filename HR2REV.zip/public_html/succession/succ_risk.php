<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentPage = basename($_SERVER['PHP_SELF']);

// ======== CONNECT TO DATABASE =========
try {
    $pdo = new PDO("mysql:host=localhost;dbname=competency;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch employees with succession details
$stmt = $pdo->query("
    SELECT e.id, e.name, r.name AS role, 
           es.performance, es.engagement, es.peer_feedback, 
           es.development_progress, es.career_goal
    FROM employees e
    LEFT JOIN roles r ON e.role_id = r.id
    LEFT JOIN employee_succession es ON es.employee_id = e.id
");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ======== CRITICAL ROLES =========
$critical_roles = ['Front Office Manager','Head Chef','Restaurant Supervisor','Banquet Manager','Assistant General Manager'];

// ======== HELPERS =========
function getReadinessLevel($emp) {
    if ($emp['development_progress'] >= 85 && $emp['performance'] >= 4.2) return "Ready Now";
    elseif ($emp['development_progress'] >= 60) return "Ready in 1-2 Years";
    else return "Ready in >2 Years";
}

function hasSuccessor($role, $employees) {
    foreach ($employees as $emp) {
        if ($emp['career_goal'] === $role) return true;
    }
    return false;
}

function getSuccessors($role, $employees) {
    $list = [];
    foreach ($employees as $emp) {
        if ($emp['career_goal'] === $role) {
            $list[] = [
                'name' => $emp['name'],
                'readiness' => getReadinessLevel($emp)
            ];
        }
    }
    return $list;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Risk Roles - Succession Planning</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen overflow-hidden">

  <div class="flex h-full">

    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4">

        <!-- Header -->
        <div class="flex items-center justify-between border-b py-6">
          <h2 class="text-xl font-semibold text-gray-800">Succession Planning – Risk Roles</h2>
          <?php include '../profile.php'; ?>
        </div>

        <!-- Submodules Navigation -->
       <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
  <a href="succession.php" class="hover:text-blue-600">Overview</a>
  <a href="succ_readiness.php" class="hover:text-blue-600">Readiness</a>
  <a href="succ_risk.php" class="hover:text-blue-600">Risk Roles</a>
  <a href="succ_reports.php" class="hover:text-blue-600">Reports</a>
  <a href="succ_pipeline.php" class="hover:text-blue-600">Pipeline</a>
</div>

        <!-- Main Card -->
        <div class="bg-white shadow-md rounded-2xl p-10 w-full mx-auto mt-10 mb-10">
          <h3 class="font-semibold text-lg mb-6">🚨 Critical Roles at Risk</h3>

          <table class="table-auto w-full text-sm">
            <thead class="bg-gray-800 text-white">
              <tr>
                <th class="px-3 py-2 text-left">Critical Role</th>
                <th class="px-3 py-2">Status</th>
                <th class="px-3 py-2">Successors</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($critical_roles as $role): ?>
                <?php $successors = getSuccessors($role, $employees); ?>
                <tr class="border-b">
                  <td class="px-3 py-2 font-semibold"><?= htmlspecialchars($role) ?></td>
                  <td class="px-3 py-2">
                    <?php if (empty($successors)): ?>
                      <span class="bg-red-600 text-white px-2 py-1 rounded text-xs">🚨 No Successor</span>
                    <?php else: ?>
                      <?php 
                        $readyNow = array_filter($successors, fn($s) => $s['readiness'] === 'Ready Now');
                        if (count($readyNow) > 0): ?>
                          <span class="bg-green-600 text-white px-2 py-1 rounded text-xs">✅ Covered</span>
                        <?php else: ?>
                          <span class="bg-yellow-400 text-black px-2 py-1 rounded text-xs">⚠️ Not Ready</span>
                        <?php endif; ?>
                    <?php endif; ?>
                  </td>
                  <td class="px-3 py-2">
                    <?php if (!empty($successors)): ?>
                      <ul class="list-disc list-inside text-gray-700">
                        <?php foreach ($successors as $s): ?>
                          <li><?= htmlspecialchars($s['name']) ?> 
                            <span class="ml-2 text-xs px-2 py-1 rounded 
                              <?= $s['readiness']=='Ready Now'?'bg-teal-600 text-white':($s['readiness']=='Ready in 1-2 Years'?'bg-yellow-400 text-black':'bg-gray-500 text-white') ?>">
                              <?= $s['readiness'] ?>
                            </span>
                          </li>
                        <?php endforeach; ?>
                      </ul>
                    <?php else: ?>
                      <span class="text-gray-500">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  </div>

</body>
</html>
