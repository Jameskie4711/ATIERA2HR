<?php
// send_alert.php
header('Content-Type: application/json');

$role = $_POST['role'] ?? '';
if ($role) {
    // In real app: send email or save to alerts table
    error_log("ALERT: Risk role {$role} needs successor");
    echo json_encode(['status' => 'success']);
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid role']);
}
?>