<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// --- Sample data ---
$critical_roles = [
  [
    "role" => "IT Manager",
    "incumbent" => "Mark Dela Cruz",
    "successors" => [
      ["name" => "James Mangaring", "readiness" => "Ready Now"],
      ["name" => "Lailane Lulu", "readiness" => "Ready Soon"]
    ],
    "risk" => "High",
    "department" => "IT"
  ],
  [
    "role" => "HR Supervisor",
    "incumbent" => "Sarah Lopez",
    "successors" => [
      ["name" => "Carlo Santos", "readiness" => "Ready Soon"]
    ],
    "risk" => "Medium",
    "department" => "HR"
  ],
  [
    "role" => "Finance Director",
    "incumbent" => "Alex Tan",
    "successors" => [
      ["name" => "Maria Reyes", "readiness" => "Ready Now"],
      ["name" => "Leo Fernandez", "readiness" => "Ready Soon"],
      ["name" => "Anna Cruz", "readiness" => "Not Ready"]
    ],
    "risk" => "Low",
    "department" => "Finance"
  ],
];

$readiness_stats = [
  "ready_now" => 4,
  "ready_soon" => 6,
  "not_ready" => 3
];

$department_risk = [
  "IT" => 3,
  "HR" => 2,
  "Finance" => 1
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Succession Planning - ATIERA HRMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-slate-50 min-h-screen font-sans flex">

  <!-- Sidebar -->
  <?php include __DIR__ . '/../sidebar.php'; ?>

  <!-- Main Content -->
  <main class="flex-1 p-6">

    <!-- Header / Profile -->
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold text-gray-800">Succession Planning Dashboard</h1>
      <?php include __DIR__ . '/../profile.php'; ?>
    </div>

    <!-- Readiness Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
      <div class="bg-green-50 border-l-4 border-green-500 p-5 rounded-xl shadow hover:shadow-lg transition">
        <h2 class="text-gray-600 font-medium">Ready Now</h2>
        <p class="text-3xl font-bold text-green-600"><?= $readiness_stats['ready_now']; ?></p>
      </div>
      <div class="bg-yellow-50 border-l-4 border-yellow-400 p-5 rounded-xl shadow hover:shadow-lg transition">
        <h2 class="text-gray-600 font-medium">Ready Soon (1-2 yrs)</h2>
        <p class="text-3xl font-bold text-yellow-500"><?= $readiness_stats['ready_soon']; ?></p>
      </div>
      <div class="bg-red-50 border-l-4 border-red-400 p-5 rounded-xl shadow hover:shadow-lg transition">
        <h2 class="text-gray-600 font-medium">Not Ready</h2>
        <p class="text-3xl font-bold text-red-600"><?= $readiness_stats['not_ready']; ?></p>
      </div>
    </div>

    <!-- Critical Roles Cards -->
    <h2 class="text-2xl font-semibold text-gray-700 mb-4">Critical Roles & Successors</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php foreach ($critical_roles as $role): ?>
        <div class="bg-white rounded-2xl shadow p-5 hover:shadow-xl transition">
          <div class="flex justify-between items-start">
            <div>
              <h3 class="font-semibold text-lg"><?= $role['role']; ?></h3>
              <p class="text-sm text-gray-500">Incumbent: <?= $role['incumbent']; ?></p>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-semibold
              <?= $role['risk']=="High"?"bg-red-100 text-red-600":($role['risk']=="Medium"?"bg-yellow-100 text-yellow-600":"bg-green-100 text-green-600") ?>">
              <?= $role['risk']; ?>
            </span>
          </div>
          <div class="mt-3">
            <h4 class="text-sm font-medium text-gray-600 mb-1">Successors</h4>
            <ul class="space-y-1">
              <?php foreach ($role['successors'] as $index => $succ): ?>
                <li class="text-sm">
                  <span class="font-semibold"><?= ($index+1) . ". " . $succ['name']; ?></span>
                  <span class="ml-2 text-xs font-semibold 
                    <?= $succ['readiness']=="Ready Now"?"text-green-600":($succ['readiness']=="Ready Soon"?"text-yellow-500":"text-red-500") ?>">
                    (<?= $succ['readiness']; ?>)
                  </span>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- AI Forecast Insights -->
    <div class="bg-white rounded-2xl shadow p-6 mt-6">
      <h2 class="text-xl font-semibold text-gray-700 mb-4">AI Forecast Insights</h2>
      <ul class="space-y-2 text-gray-600">
        <li>✔ IT Manager role at <span class="font-semibold text-red-600">High Risk</span> — only 1 successor ready now.</li>
        <li>✔ HR Supervisor: training needed (<span class="italic">Leadership 101, People Management</span>) to make successor ready within 2 years.</li>
        <li>✔ Finance Director: strong pipeline with 3 successors across different readiness levels.</li>
        <li>✔ What-If: If Sarah Lopez (HR Supervisor) resigns today → backup successor readiness is only <span class="text-yellow-600 font-semibold">Soon</span>.</li>
      </ul>
    </div>

  </main>

  <!-- Chatbot -->
  <?php include __DIR__ . '/../chatbot.php'; ?>

  <!-- Draggable, Resizable, Collapsible Mini Heatmap -->
  <div id="riskMiniPlayer" 
       class="bg-white rounded-2xl shadow p-2 fixed top-20 left-20 cursor-move z-50"
       style="touch-action: none; width: 320px; height: 240px;">

    <!-- Header -->
    <div id="dragHeader" class="flex justify-between items-center bg-gray-100 rounded-t-xl px-3 py-2 cursor-move">
      <h2 class="text-sm font-semibold text-gray-700">Dept Risk Heatmap</h2>
      <button id="toggleRisk" class="text-gray-500 hover:text-gray-700 font-bold">−</button>
    </div>
    
    <!-- Chart Content -->
    <div id="riskContent" class="p-2 h-full">
      <canvas id="riskChartMini" class="h-full w-full"></canvas>
    </div>

    <!-- Resize handle -->
    <div id="resizeHandle" class="w-4 h-4 bg-gray-400 absolute bottom-1 right-1 cursor-se-resize rounded-sm"></div>
  </div>

<script>
const dragItem = document.getElementById("riskMiniPlayer");
const header = document.getElementById("dragHeader");
const resizeHandle = document.getElementById("resizeHandle");
let active=false, offset={x:0, y:0}, resizing=false;

// Drag
header.addEventListener("mousedown", dragStart);
header.addEventListener("touchstart", dragStart, {passive:false});

function dragStart(e){
    e.preventDefault();
    active=true;
    offset.x = e.type==="touchstart"? e.touches[0].clientX - dragItem.offsetLeft : e.clientX - dragItem.offsetLeft;
    offset.y = e.type==="touchstart"? e.touches[0].clientY - dragItem.offsetTop : e.clientY - dragItem.offsetTop;
    document.addEventListener("mousemove", dragMove);
    document.addEventListener("mouseup", dragEnd);
    document.addEventListener("touchmove", dragMove, {passive:false});
    document.addEventListener("touchend", dragEnd);
}

function dragMove(e){
    if(!active) return;
    let clientX = e.type.includes("touch")? e.touches[0].clientX : e.clientX;
    let clientY = e.type.includes("touch")? e.touches[0].clientY : e.clientY;
    
    let newLeft = clientX - offset.x;
    let newTop = clientY - offset.y;
    const maxLeft = window.innerWidth - dragItem.offsetWidth;
    const maxTop = window.innerHeight - dragItem.offsetHeight;
    dragItem.style.left = Math.min(Math.max(newLeft, 0), maxLeft) + "px";
    dragItem.style.top = Math.min(Math.max(newTop, 0), maxTop) + "px";
}

function dragEnd(){
    active=false;
    document.removeEventListener("mousemove", dragMove);
    document.removeEventListener("mouseup", dragEnd);
    document.removeEventListener("touchmove", dragMove);
    document.removeEventListener("touchend", dragEnd);
}

// Resize
resizeHandle.addEventListener("mousedown", startResize);
resizeHandle.addEventListener("touchstart", startResize, {passive:false});

function startResize(e){
    e.preventDefault(); resizing=true;
    document.addEventListener("mousemove", resizeMove);
    document.addEventListener("mouseup", stopResize);
    document.addEventListener("touchmove", resizeMove, {passive:false});
    document.addEventListener("touchend", stopResize);
}

function resizeMove(e){
    if(!resizing) return;
    let clientX = e.type.includes("touch")? e.touches[0].clientX : e.clientX;
    let clientY = e.type.includes("touch")? e.touches[0].clientY : e.clientY;
    let newWidth = clientX - dragItem.offsetLeft;
    let newHeight = clientY - dragItem.offsetTop;
    
    const maxWidth = window.innerWidth - dragItem.offsetLeft;
    const maxHeight = window.innerHeight - dragItem.offsetTop;
    
    dragItem.style.width = Math.max(Math.min(newWidth, maxWidth), 200)+"px";
    dragItem.style.height = Math.max(Math.min(newHeight, maxHeight), 150)+"px";
}

function stopResize(){
    resizing=false;
    document.removeEventListener("mousemove", resizeMove);
    document.removeEventListener("mouseup", stopResize);
    document.removeEventListener("touchmove", resizeMove);
    document.removeEventListener("touchend", stopResize);
}

// Minimize/Maximize
const toggleBtn = document.getElementById("toggleRisk");
const riskContent = document.getElementById("riskContent");
let minimized=false;
toggleBtn.addEventListener("click", ()=>{
    minimized = !minimized;
    riskContent.style.display = minimized ? "none":"block";
    toggleBtn.textContent = minimized ? "+":"−";
});

// Chart.js Mini Chart
const ctxMini = document.getElementById('riskChartMini');
new Chart(ctxMini, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_keys($department_risk)); ?>,
        datasets: [{
            label: 'Risk Level (1=Low,3=High)',
            data: <?= json_encode(array_values($department_risk)); ?>,
            backgroundColor: ['#ef4444','#facc15','#22c55e']
        }]
    },
    options: {
        scales:{ y:{ beginAtZero:true, max:3 } },
        plugins:{ legend:{ display:false } },
        responsive:true, maintainAspectRatio:false
    }
});
</script>

</body>
</html>
