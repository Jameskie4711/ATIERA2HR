<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentPage = basename($_SERVER['PHP_SELF']);

// ======== CONNECT TO DATABASE =========
try {
    $pdo = new PDO("mysql:host=localhost;dbname=competency;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch employees with succession details
$stmt = $pdo->query("
    SELECT e.id, e.name, r.name AS role, d.name AS department,
           es.performance, es.engagement, es.peer_feedback, 
           es.development_progress, es.career_goal
    FROM employees e
    LEFT JOIN roles r ON e.role_id = r.id
    LEFT JOIN departments d ON r.department_id = d.id
    LEFT JOIN employee_succession es ON es.employee_id = e.id
");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ======== HELPERS =========
function isHighPotential($emp) {
    $score = 0;
    if ($emp['performance'] >= 4.0) $score += 3;
    if ($emp['engagement'] >= 80) $score += 2;
    if ($emp['peer_feedback'] >= 4.0) $score += 2;
    if ($emp['development_progress'] >= 75) $score += 3;
    return $score >= 7;
}
function getReadinessLevel($emp) {
    if ($emp['development_progress'] >= 85 && $emp['performance'] >= 4.2) return "Ready Now";
    elseif ($emp['development_progress'] >= 60) return "Ready in 1-2 Years";
    else return "Ready in >2 Years";
}

// ======== CALCULATIONS =========
$readiness_counts = ["Ready Now"=>0,"Ready in 1-2 Years"=>0,"Ready in >2 Years"=>0];
foreach ($employees as $emp) { 
    $readiness_counts[getReadinessLevel($emp)]++; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Succession Readiness</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="h-screen overflow-hidden">

  <!-- FLEX LAYOUT: Sidebar + Main -->
  <div class="flex h-full">

    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">

      <!-- Top Header -->
      <main class="p-6 space-y-4">
        <!-- Header -->
        <div class="flex items-center justify-between border-b py-6">
          <h2 class="text-xl font-semibold text-gray-800">Succession Readiness</h2>
          <?php include '../profile.php'; ?>
        </div>

       <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
  <a href="succession.php" class="hover:text-blue-600">Overview</a>
  <a href="succ_readiness.php" class="hover:text-blue-600">Readiness</a>
  <a href="succ_risk.php" class="hover:text-blue-600">Risk Roles</a>
  <a href="succ_reports.php" class="hover:text-blue-600">Reports</a>
  <a href="succ_pipeline.php" class="hover:text-blue-600">Pipeline</a>
</div>


        <!-- Main Card -->
        <div class="bg-white shadow-md rounded-2xl p-10 w-full mx-auto mt-10 mb-10">
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <!-- Readiness Table -->
            <div class="lg:col-span-2 overflow-x-auto">
              <h3 class="font-semibold mb-4">🎯 Succession Readiness</h3>
              <table class="table-auto w-full text-sm">
                <thead class="bg-gray-800 text-white">
                  <tr>
                    <th class="px-3 py-2 text-left">Name</th>
                    <th class="px-3 py-2">Role</th>
                    <th class="px-3 py-2">Career Goal</th>
                    <th class="px-3 py-2">HiPo</th>
                    <th class="px-3 py-2">Progress</th>
                    <th class="px-3 py-2">Readiness</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ($employees as $emp): ?>
                  <tr class="border-b">
                    <td class="px-3 py-2 font-semibold"><?= htmlspecialchars($emp['name']) ?></td>
                    <td class="px-3 py-2"><?= htmlspecialchars($emp['role']) ?></td>
                    <td class="px-3 py-2"><?= htmlspecialchars($emp['career_goal']) ?></td>
                    <td class="px-3 py-2"><?= isHighPotential($emp)?'<span class="bg-green-600 text-white px-2 py-1 rounded text-xs">HiPo</span>':'—' ?></td>
                    <td class="px-3 py-2">
                      <div class="w-full bg-gray-200 rounded h-2">
                        <div class="bg-blue-500 h-2 rounded" style="width:<?= (int)$emp['development_progress'] ?>%"></div>
                      </div>
                      <small><?= (int)$emp['development_progress'] ?>%</small>
                    </td>
                    <td class="px-3 py-2">
                      <?php $lvl=getReadinessLevel($emp); ?>
                      <span class="px-2 py-1 rounded text-xs 
                        <?= $lvl=='Ready Now'?'bg-teal-600 text-white':($lvl=='Ready in 1-2 Years'?'bg-yellow-400 text-black':'bg-gray-500 text-white') ?>">
                        <?= $lvl ?>
                      </span>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>

            <!-- Readiness Chart -->
            <div class="space-y-6">
              <div class="bg-gray-50 rounded-xl shadow p-4">
                <h5 class="mb-2">Readiness Levels</h5>
                <canvas id="readinessChart" height="200"></canvas>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  </div>

<script>
document.addEventListener("DOMContentLoaded",function(){
  if (typeof lucide!=="undefined" && lucide.createIcons){ lucide.createIcons(); }

  new Chart(document.getElementById("readinessChart"),{
    type:"bar",
    data:{
      labels:["Ready Now","Ready in 1-2 Years","Ready in >2 Years"],
      datasets:[{data:[<?= $readiness_counts["Ready Now"] ?>,<?= $readiness_counts["Ready in 1-2 Years"] ?>,<?= $readiness_counts["Ready in >2 Years"] ?>],
      backgroundColor:["#0d9488","#facc15","#6b7280"]}]
    },
    options:{plugins:{legend:{display:false}}}
  });
});
</script>
</body>
</html>
