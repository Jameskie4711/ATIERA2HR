<?php 
include('../session_check.php'); 
include('../db.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch employees from database including department
$employees = [];
$sql = "SELECT id, name, role, readiness, department FROM employees";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $employees[] = $row;
  }
}

// Count readiness stats
$readiness_stats = ["ready_now" => 0, "ready_soon" => 0, "not_ready" => 0];
foreach ($employees as $e) {
  if ($e['readiness'] === 'Ready Now') $readiness_stats['ready_now']++;
  elseif ($e['readiness'] === 'Ready Soon') $readiness_stats['ready_soon']++;
  else $readiness_stats['not_ready']++;
}

// Prioritize by readiness
$ready_now = [];
$ready_soon = [];
$not_ready = [];

foreach ($employees as $emp) {
  if ($emp['readiness'] === 'Ready Now') {
    $ready_now[] = $emp;
  } elseif ($emp['readiness'] === 'Ready Soon') {
    $ready_soon[] = $emp;
  } else {
    $not_ready[] = $emp;
  }
}

$employees = array_merge($ready_now, $ready_soon, $not_ready);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Succession Planning - ATIERA HRMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  body {
    overflow: hidden; /* Prevent body scrolling */
    height: 100vh;
    margin: 0;
  }
  
  /* Main content scrolling */
  .main-content-scroll {
    overflow-y: auto;
    height: calc(100vh - 2rem);
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 0.5rem;
  }
  
  .main-content-scroll::-webkit-scrollbar {
    width: 8px;
  }
  
  .main-content-scroll::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  
  .main-content-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  /* Smooth scrolling */
  .main-content-scroll {
    scroll-behavior: smooth;
  }

  /* AI Styles */
  .ai-recommendation-card {
    cursor: pointer;
    transition: all 0.3s ease;
  }

  .ai-recommendation-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.2);
  }

  .ai-loading {
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
  }

  .ai-results-container {
    animation: slideDown 0.3s ease-out;
  }

  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .ai-badge {
    position: absolute;
    top: 1rem;
    right: 1rem;
    padding: 0.25rem 0.5rem;
    background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
    color: white;
    font-size: 0.7rem;
    font-weight: 600;
    border-radius: 9999px;
    display: flex;
    align-items: center;
    gap: 0.2rem;
    z-index: 10;
    line-height: 1;
    max-width: 60px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* Make role cards relative for positioning */
  .bg-white.rounded-xl.shadow.p-5 {
    position: relative;
    min-height: 320px;
    overflow: visible !important;
  }

  /* Fix for role header to prevent overlap */
  .bg-white.rounded-xl.shadow.p-5 .flex.justify-between.items-start {
    padding-right: 70px; /* Make space for AI badge */
    position: relative;
    z-index: 1;
  }

  /* Ensure readiness badge doesn't overlap */
  .bg-white.rounded-xl.shadow.p-5 .px-3.py-1.rounded-full {
    position: relative;
    z-index: 2;
    margin-left: auto;
  }

  /* Modal styles */
  .modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 1rem;
  }

  .modal-overlay.active {
    display: flex;
  }

  .modal-content {
    background: white;
    border-radius: 16px;
    padding: 1.5rem;
    max-width: 90%;
    width: 100%;
    max-height: 90vh;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    animation: modalSlideIn 0.3s ease-out;
    overflow-y: auto;
  }

  @keyframes modalSlideIn {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* Toast notification */
  .toast {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    z-index: 1001;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    animation: toastSlideIn 0.3s ease-out;
    max-width: 350px;
    word-wrap: break-word;
  }

  .toast.error {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  }

  @keyframes toastSlideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* Spinner animation */
  .animate-spin {
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  /* Fix for AI analysis results container */
  .ai-results-container {
    margin-top: 1rem;
    z-index: 5;
    position: relative;
  }

  /* Ensure text doesn't overflow in role cards */
  .bg-white.rounded-xl.shadow.p-5 h3.font-semibold.text-lg {
    font-size: 1.1rem;
    line-height: 1.3;
    margin-bottom: 0.5rem;
    max-width: calc(100% - 70px);
    word-wrap: break-word;
  }

  .bg-white.rounded-xl.shadow.p-5 p.text-sm {
    font-size: 0.875rem;
    line-height: 1.4;
    margin-bottom: 0.25rem;
  }

  /* Fix for action buttons area */
  .bg-white.rounded-xl.shadow.p-5 .flex.gap-3.mt-6 {
    margin-top: 1.5rem;
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
  }

  .bg-white.rounded-xl.shadow.p-5 .flex.gap-3.mt-6 button {
    flex: 1 1 calc(50% - 0.5rem);
    min-width: 120px;
    padding: 0.5rem 0.75rem;
    font-size: 0.8rem;
  }

  /* Add AI analysis button styling */
  .ai-analysis-action-btn {
    margin-top: 0.5rem !important;
    padding: 0.5rem 0.75rem !important;
    font-size: 0.8rem !important;
    width: 100% !important;
  }

  /* Fix for notification positioning */
  .fixed.bottom-4.right-4 {
    max-width: 300px;
    word-wrap: break-word;
    z-index: 1002;
  }

  /* Responsive fixes */
  @media (max-width: 768px) {
    .bg-white.rounded-xl.shadow.p-5 {
      min-height: 350px;
    }
    
    .bg-white.rounded-xl.shadow.p-5 .flex.justify-between.items-start {
      padding-right: 60px;
    }
    
    .ai-badge {
      top: 0.75rem;
      right: 0.75rem;
      font-size: 0.65rem;
      padding: 0.2rem 0.4rem;
      max-width: 50px;
    }
    
    .bg-white.rounded-xl.shadow.p-5 h3.font-semibold.text-lg {
      font-size: 1rem;
      max-width: calc(100% - 60px);
    }
    
    .modal-content {
      padding: 1rem;
      max-width: 95%;
    }
  }

  @media (max-width: 640px) {
    .bg-white.rounded-xl.shadow.p-5 {
      min-height: 380px;
    }
    
    .bg-white.rounded-xl.shadow.p-5 .flex.gap-3.mt-6 {
      flex-direction: column;
    }
    
    .bg-white.rounded-xl.shadow.p-5 .flex.gap-3.mt-6 button {
      flex: 1 1 100%;
      width: 100%;
    }
  }
</style>
</head>

<body class="bg-slate-50 min-h-screen font-sans flex h-screen overflow-hidden">

<?php include __DIR__ . '/../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-hidden">
  <!-- Main content with scrolling -->
  <main class="main-content-scroll p-6">

    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
      <h1 class="text-3xl font-bold text-gray-800">Succession Planning Dashboard</h1>
      <?php include __DIR__ . '/../profile.php'; ?>
    </div>

    <!-- Tabs -->
    <div class="bg-gray-800 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-md mb-8">
      <a href="/succession/succession.php" class="bg-gray-700 px-3 py-1 rounded flex items-center gap-2">
        <i class="fas fa-home"></i>
        Home
      </a>
      <a href="/succession/succ_reports.php" class="hover:bg-gray-700 px-3 py-1 rounded flex items-center gap-2">
        <i class="fas fa-chart-line"></i>
        Manage Reports
      </a>
    </div>

<!-- Readiness Cards - Compact Version -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
  <div class="bg-white rounded-lg shadow p-4 border-l-3 border-green-500">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-gray-600 font-medium text-sm">Qualified</h2>
        <p class="text-2xl font-bold text-green-600 mt-1"><?= $readiness_stats['ready_now']; ?></p>
      </div>
      <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
        <i class="fas fa-check-circle text-green-500"></i>
      </div>
    </div>
    <div class="flex items-center gap-2 mt-2">
      <div class="w-1.5 h-1.5 rounded-full bg-green-500"></div>
      <span class="text-xs text-gray-500">Ready for immediate promotion</span>
    </div>
  </div>

  <div class="bg-white rounded-lg shadow p-4 border-l-3 border-yellow-400">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-gray-600 font-medium text-sm">In Progress</h2>
        <p class="text-2xl font-bold text-yellow-500 mt-1"><?= $readiness_stats['ready_soon']; ?></p>
      </div>
      <div class="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
        <i class="fas fa-clock text-yellow-500"></i>
      </div>
    </div>
    <div class="flex items-center gap-2 mt-2">
      <div class="w-1.5 h-1.5 rounded-full bg-yellow-500"></div>
      <span class="text-xs text-gray-500">Need 6-12 months development</span>
    </div>
  </div>

  <div class="bg-white rounded-lg shadow p-4 border-l-3 border-red-400">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-gray-600 font-medium text-sm">Not Qualified</h2>
        <p class="text-2xl font-bold text-red-600 mt-1"><?= $readiness_stats['not_ready']; ?></p>
      </div>
      <div class="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
        <i class="fas fa-exclamation-circle text-red-500"></i>
      </div>
    </div>
    <div class="flex items-center gap-2 mt-2">
      <div class="w-1.5 h-1.5 rounded-full bg-red-500"></div>
      <span class="text-xs text-gray-500">Long-term development needed</span>
    </div>
  </div>
</div>

    <!-- Critical Roles Header -->
    <div class="mb-6">
      <h2 class="text-2xl font-semibold text-gray-700 mb-2">Critical Roles & Successors</h2>
      <p class="text-gray-600">Key positions requiring succession planning</p>
    </div>

    <!-- Critical Roles Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
      <?php if (!empty($employees)): ?>
        <?php foreach ($employees as $emp): ?>
          <div class="bg-white rounded-xl shadow p-5 hover:shadow-lg transition-shadow duration-300">
            <!-- Role Header -->
            <div class="flex justify-between items-start">
              <div style="padding-right: 70px;">
                <h3 class="font-semibold text-lg text-gray-900" style="max-width: calc(100% - 70px);"><?= htmlspecialchars($emp['role']); ?></h3>
                <p class="text-sm text-gray-500 mt-1">Employee: <?= htmlspecialchars($emp['name']); ?></p>
                <p class="text-sm text-blue-600 font-medium mt-2">
                  Department: <?= htmlspecialchars($emp['department']); ?>
                </p>
              </div>

              <span class="px-3 py-1 rounded-full text-xs font-semibold
                <?= $emp['readiness']=='Ready Now'
                  ?'bg-green-100 text-green-600'
                  :($emp['readiness']=='Ready Soon'
                    ?'bg-yellow-100 text-yellow-600'
                    :'bg-red-100 text-red-600') ?>">
                <?= htmlspecialchars($emp['readiness']); ?>
              </span>
            </div>

            <!-- Successors Section -->
            <div class="mt-6">
              <h4 class="text-sm font-medium text-gray-700 mb-3">Potential Successors</h4>
              
              <!-- AI Recommendation Card -->
              <div class="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-100 hover:bg-blue-100 transition-colors cursor-pointer ai-recommendation-card">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <i class="fas fa-robot text-blue-600"></i>
                  </div>
                  <div>
                    <p class="text-sm font-medium text-gray-900">AI Recommendations</p>
                    <p class="text-xs text-gray-600">Click to view AI analysis</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-blue-500"></i>
              </div>
              
              <!-- Info Message -->
              <div class="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <p class="text-sm text-gray-600 italic text-center">
                  Successors will be assigned based on AI analysis
                </p>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex gap-3 mt-6">
              <button class="flex-1 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors view-details-btn" data-role="<?= htmlspecialchars($emp['role']) ?>" data-employee="<?= htmlspecialchars($emp['name']) ?>">
                View Details
              </button>

            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="col-span-3 bg-white rounded-xl shadow p-8 text-center">
          <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-user-tie text-gray-400 text-2xl"></i>
          </div>
          <h3 class="text-lg font-semibold text-gray-700 mb-2">No Critical Roles Found</h3>
          <p class="text-gray-500 mb-6">Add critical roles to begin succession planning</p>
          <button class="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg flex items-center gap-2 mx-auto">
            <i class="fas fa-plus"></i>
            Add Critical Role
          </button>
        </div>
      <?php endif; ?>
    </div>

    <!-- Summary Section -->
    <div class="bg-white rounded-xl shadow p-6">
      <div class="flex items-center gap-3 mb-6">
        <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
          <i class="fas fa-chart-bar text-indigo-600"></i>
        </div>
        <div>
          <h3 class="font-semibold text-gray-900">Succession Readiness Summary</h3>
          <p class="text-sm text-gray-500">Overview of organizational readiness</p>
        </div>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Stats Summary -->
        <div>
          <h4 class="text-sm font-semibold text-gray-700 mb-4">Readiness Distribution</h4>
          <div class="space-y-4">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-3 h-3 rounded-full bg-green-500"></div>
                <span class="text-sm text-gray-700">Qualified (Ready Now)</span>
              </div>
              <div class="flex items-center gap-3">
                <span class="text-sm font-medium text-gray-900"><?= $readiness_stats['ready_now']; ?></span>
                <span class="text-xs text-gray-500">
                  <?= count($employees) > 0 ? round(($readiness_stats['ready_now'] / count($employees)) * 100, 1) : 0 ?>%
                </span>
              </div>
            </div>
            
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span class="text-sm text-gray-700">In Progress (Ready Soon)</span>
              </div>
              <div class="flex items-center gap-3">
                <span class="text-sm font-medium text-gray-900"><?= $readiness_stats['ready_soon']; ?></span>
                <span class="text-xs text-gray-500">
                  <?= count($employees) > 0 ? round(($readiness_stats['ready_soon'] / count($employees)) * 100, 1) : 0 ?>%
                </span>
              </div>
            </div>
            
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-3 h-3 rounded-full bg-red-500"></div>
                <span class="text-sm text-gray-700">Not Qualified</span>
              </div>
              <div class="flex items-center gap-3">
                <span class="text-sm font-medium text-gray-900"><?= $readiness_stats['not_ready']; ?></span>
                <span class="text-xs text-gray-500">
                  <?= count($employees) > 0 ? round(($readiness_stats['not_ready'] / count($employees)) * 100, 1) : 0 ?>%
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Quick Actions -->
        <div>
          <h4 class="text-sm font-semibold text-gray-700 mb-4">Quick Actions</h4>
          <div class="space-y-3">
            <a href="/succession/succ_reports.php" 
               class="flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors group">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-gray-200">
                  <i class="fas fa-file-export text-gray-600"></i>
                </div>
                <div>
                  <p class="text-sm font-medium text-gray-900">Generate Report</p>
                  <p class="text-xs text-gray-500">Export succession planning data</p>
                </div>
              </div>
              <i class="fas fa-chevron-right text-gray-400 group-hover:text-gray-600"></i>
            </a>
            
            <button class="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors group ai-analysis-btn">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-gray-200">
                  <i class="fas fa-robot text-gray-600"></i>
                </div>
                <div>
                  <p class="text-sm font-medium text-gray-900">AI Analysis</p>
                  <p class="text-xs text-gray-500">Get AI-powered recommendations</p>
                </div>
              </div>
              <i class="fas fa-chevron-right text-gray-400 group-hover:text-gray-600"></i>
            </button>
          </div>
        </div>
      </div>


  </main>
</div>

<?php include __DIR__ . '/../chatbot.php'; ?>

<!-- Add TensorFlow.js for AI capabilities -->
<script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@latest"></script>

<!-- AI JavaScript Code -->
<script>
// succession-ai.js - Pure JavaScript Succession Planning AI with TensorFlow.js

class SuccessionAI {
    constructor() {
        this.model = null;
        this.featureNames = [
            'skill_match', 'experience_level', 'performance_score',
            'readiness_score', 'training_completion', 'competency_gap',
            'department_match', 'leadership_score', 'tenure_months'
        ];
        this.weights = {
            skill_match: 0.25,
            experience_level: 0.20,
            performance_score: 0.15,
            readiness_score: 0.12,
            training_completion: 0.10,
            competency_gap: -0.08, // Negative because gap is negative
            department_match: 0.05,
            leadership_score: 0.08,
            tenure_months: 0.07
        };
        this.thresholds = {
            ready_now: 0.85,
            ready_soon: 0.70,
            not_ready: 0.50
        };
        this.trainingHistory = [];
    }

    // Initialize AI model
    async initialize() {
        console.log('Initializing Succession Planning AI...');
        
        try {
            // Create a simple neural network model
            this.model = tf.sequential();
            
            // Input layer
            this.model.add(tf.layers.dense({
                units: 16,
                activation: 'relu',
                inputShape: [this.featureNames.length]
            }));
            
            // Hidden layers
            this.model.add(tf.layers.dense({
                units: 8,
                activation: 'relu'
            }));
            
            this.model.add(tf.layers.dense({
                units: 4,
                activation: 'relu'
            }));
            
            // Output layer (readiness score 0-1)
            this.model.add(tf.layers.dense({
                units: 1,
                activation: 'sigmoid'
            }));
            
            // Compile model
            this.compileModel();
            
            console.log('AI Model initialized successfully');
            return true;
        } catch (error) {
            console.error('Failed to initialize AI model:', error);
            return false;
        }
    }

    // Compile model separately to handle async issues
    compileModel() {
        try {
            this.model.compile({
                optimizer: tf.train.adam(0.001),
                loss: 'meanSquaredError',
                metrics: ['accuracy']
            });
        } catch (error) {
            console.warn('Model compilation issue, using fallback mode:', error);
        }
    }

    // Calculate feature scores for an employee
    calculateFeatures(employee, targetRole) {
        const features = {};
        
        // 1. Skill Match (0-1)
        features.skill_match = this.calculateSkillMatch(
            employee.skills || [],
            targetRole.required_skills || []
        );
        
        // 2. Experience Level (0-1)
        features.experience_level = Math.min(
            (employee.experience_years || 0) / 
            (targetRole.min_experience || 5), 
            1
        );
        
        // 3. Performance Score (0-1)
        features.performance_score = (employee.performance_rating || 0) / 5;
        
        // 4. Readiness Score (from existing system)
        features.readiness_score = this.mapReadinessToScore(employee.readiness);
        
        // 5. Training Completion (0-1)
        features.training_completion = (employee.training_completed || 0) / 
                                     (employee.training_total || 1);
        
        // 6. Competency Gap (0-1, lower is better)
        features.competency_gap = Math.max(0, 1 - 
            (employee.competency_gap_score || 0.5)
        );
        
        // 7. Department Match (0 or 1)
        features.department_match = (employee.department === targetRole.department) ? 1 : 0.5;
        
        // 8. Leadership Score (0-1)
        features.leadership_score = employee.leadership_assessments ? 
            employee.leadership_assessments.reduce((a, b) => a + b.score, 0) / 
            (employee.leadership_assessments.length * 5) : 0.5;
        
        // 9. Tenure in months (normalized)
        features.tenure_months = Math.min((employee.tenure_months || 0) / 60, 1);
        
        return features;
    }

    // Calculate skill match between employee and role requirements
    calculateSkillMatch(employeeSkills, requiredSkills) {
        if (!requiredSkills || requiredSkills.length === 0) return 1;
        
        const employeeSkillSet = new Set(employeeSkills.map(s => s.toLowerCase()));
        const requiredSkillSet = new Set(requiredSkills.map(s => s.toLowerCase()));
        
        // Find intersection
        const matchingSkills = [...requiredSkillSet].filter(skill => 
            employeeSkillSet.has(skill)
        );
        
        return matchingSkills.length / requiredSkillSet.size;
    }

    // Map readiness text to numeric score
    mapReadinessToScore(readiness) {
        const readinessMap = {
            'ready_now': 1.0,
            'ready_soon': 0.75,
            'not_ready': 0.3,
            'qualified': 1.0,
            'in_progress': 0.75,
            'not_qualified': 0.3
        };
        
        return readinessMap[readiness?.toLowerCase()] || 0.5;
    }

    // Calculate weighted score (rule-based approach)
    calculateWeightedScore(features) {
        let totalScore = 0;
        let totalWeight = 0;
        
        for (const [feature, weight] of Object.entries(this.weights)) {
            if (features[feature] !== undefined) {
                totalScore += features[feature] * weight;
                totalWeight += Math.abs(weight);
            }
        }
        
        // Normalize score
        return totalWeight > 0 ? totalScore / totalWeight : 0;
    }

    // Predict using ML model (if available) or fallback to rule-based
    async predictReadiness(features) {
        try {
            if (this.model) {
                // Convert features to tensor
                const featureArray = this.featureNames.map(name => 
                    features[name] || 0
                );
                const inputTensor = tf.tensor2d([featureArray]);
                
                // Make prediction
                const prediction = this.model.predict(inputTensor);
                const score = await prediction.data();
                
                // Clean up tensors
                inputTensor.dispose();
                prediction.dispose();
                
                return score[0];
            }
        } catch (error) {
            console.warn('ML prediction failed, using rule-based scoring:', error);
        }
        
        // Fallback to rule-based scoring
        return this.calculateWeightedScore(features);
    }

    // Analyze and recommend successors for a role
    async analyzeSuccession(role, candidates, maxRecommendations = 3) {
        console.log(`Analyzing successors for role: ${role.title}`);
        
        const recommendations = [];
        
        // Analyze each candidate
        for (const candidate of candidates) {
            // Calculate features
            const features = this.calculateFeatures(candidate, role);
            
            // Predict readiness score
            const readinessScore = await this.predictReadiness(features);
            
            // Determine readiness category
            let readinessCategory = 'not_ready';
            if (readinessScore >= this.thresholds.ready_now) {
                readinessCategory = 'ready_now';
            } else if (readinessScore >= this.thresholds.ready_soon) {
                readinessCategory = 'ready_soon';
            }
            
            // Calculate strengths and gaps
            const analysis = this.generateAnalysis(features, readinessScore);
            
            recommendations.push({
                candidate_id: candidate.id,
                candidate_name: candidate.name,
                candidate_role: candidate.position,
                department: candidate.department,
                readiness_score: readinessScore,
                readiness_category: readinessCategory,
                features: features,
                strengths: analysis.strengths,
                gaps: analysis.gaps,
                recommended_actions: analysis.actions,
                match_percentage: Math.round(readinessScore * 100)
            });
            
            // Log for training data
            this.trainingHistory.push({
                features: Object.values(features),
                score: readinessScore,
                candidate: candidate.id,
                role: role.id
            });
        }
        
        // Sort by readiness score (highest first)
        recommendations.sort((a, b) => b.readiness_score - a.readiness_score);
        
        // Return top recommendations
        const topRecommendations = recommendations.slice(0, maxRecommendations);
        
        // Generate overall insights
        const insights = this.generateInsights(topRecommendations, role);
        
        return {
            role: role.title,
            role_id: role.id,
            total_candidates: candidates.length,
            recommendations: topRecommendations,
            insights: insights,
            analysis_date: new Date().toISOString()
        };
    }

    // Generate detailed analysis for a candidate
    generateAnalysis(features, overallScore) {
        const strengths = [];
        const gaps = [];
        const actions = [];
        
        // Identify strengths (features > 0.8)
        for (const [feature, value] of Object.entries(features)) {
            if (value >= 0.8) {
                strengths.push({
                    feature: this.formatFeatureName(feature),
                    score: value,
                    description: this.getFeatureDescription(feature, value)
                });
            } else if (value <= 0.4) {
                gaps.push({
                    feature: this.formatFeatureName(feature),
                    score: value,
                    description: this.getFeatureDescription(feature, value)
                });
                
                // Suggest actions for gaps
                const action = this.getImprovementAction(feature, value);
                if (action) actions.push(action);
            }
        }
        
        return { strengths, gaps, actions };
    }

    // Format feature name for display
    formatFeatureName(feature) {
        return feature
            .split('_')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    // Get description for feature score
    getFeatureDescription(feature, score) {
        const descriptions = {
            skill_match: score >= 0.8 ? 'Excellent skill alignment' : 
                        score >= 0.6 ? 'Good skill match' : 
                        'Skill development needed',
            experience_level: score >= 0.8 ? 'Extensive experience' : 
                           score >= 0.6 ? 'Adequate experience' : 
                           'Additional experience required',
            performance_score: score >= 0.8 ? 'Outstanding performance' : 
                             score >= 0.6 ? 'Strong performance' : 
                             'Performance improvement needed'
        };
        
        return descriptions[feature] || `Score: ${Math.round(score * 100)}%`;
    }

    // Get improvement actions for gaps
    getImprovementAction(feature, score) {
        const actions = {
            skill_match: {
                low: 'Enroll in skill-specific training programs',
                medium: 'Participate in cross-training opportunities'
            },
            training_completion: {
                low: 'Complete pending training modules',
                medium: 'Accelerate training plan completion'
            },
            competency_gap: {
                low: 'Focus on competency gap closure through mentoring',
                medium: 'Develop targeted competency improvement plan'
            },
            leadership_score: {
                low: 'Join leadership development program',
                medium: 'Take on small leadership roles to build experience'
            }
        };
        
        const actionSet = actions[feature];
        if (!actionSet) return null;
        
        if (score <= 0.3) return actionSet.low;
        if (score <= 0.6) return actionSet.medium;
        
        return null;
    }

    // Generate overall insights from recommendations
    generateInsights(recommendations, role) {
        if (recommendations.length === 0) {
            return {
                status: 'critical',
                message: 'No suitable successors identified',
                risk_level: 'high',
                immediate_actions: [
                    'Consider external recruitment',
                    'Develop internal talent pipeline',
                    'Review role requirements'
                ]
            };
        }
        
        const topScore = recommendations[0]?.readiness_score || 0;
        const avgScore = recommendations.reduce((sum, rec) => sum + rec.readiness_score, 0) / 
                        recommendations.length;
        
        let status = 'adequate';
        let riskLevel = 'low';
        let message = '';
        
        if (topScore >= 0.9) {
            status = 'excellent';
            message = 'Strong succession pipeline with highly qualified candidates';
        } else if (topScore >= 0.7) {
            status = 'good';
            message = 'Adequate succession options with some development needed';
            riskLevel = 'medium';
        } else {
            status = 'concern';
            message = 'Limited succession options requiring significant development';
            riskLevel = 'high';
        }
        
        // Identify common gaps across candidates
        const commonGaps = this.findCommonGaps(recommendations);
        
        return {
            status: status,
            message: message,
            risk_level: riskLevel,
            top_candidate_score: Math.round(topScore * 100),
            average_score: Math.round(avgScore * 100),
            common_development_needs: commonGaps,
            timeline_recommendation: this.getTimelineRecommendation(topScore)
        };
    }

    // Find common gaps across multiple candidates
    findCommonGaps(recommendations) {
        const gapFrequency = {};
        
        recommendations.forEach(rec => {
            rec.gaps?.forEach(gap => {
                const feature = gap.feature;
                gapFrequency[feature] = (gapFrequency[feature] || 0) + 1;
            });
        });
        
        // Return gaps that appear in at least half of candidates
        return Object.entries(gapFrequency)
            .filter(([_, count]) => count >= Math.ceil(recommendations.length / 2))
            .map(([feature, count]) => ({
                feature: feature,
                frequency: count,
                percentage: Math.round((count / recommendations.length) * 100)
            }));
    }

    // Recommend timeline based on readiness score
    getTimelineRecommendation(score) {
        if (score >= 0.85) return {
            timeline: '0-3 months',
            recommendation: 'Immediate promotion readiness',
            confidence: 'high'
        };
        
        if (score >= 0.70) return {
            timeline: '3-6 months',
            recommendation: 'Short-term development needed',
            confidence: 'medium'
        };
        
        if (score >= 0.50) return {
            timeline: '6-12 months',
            recommendation: 'Moderate development timeline',
            confidence: 'medium'
        };
        
        return {
            timeline: '12+ months',
            recommendation: 'Long-term development plan required',
            confidence: 'low'
        };
    }

    // Generate visual analysis data for charts
    generateVisualizationData(analysisResult) {
        const recommendations = analysisResult.recommendations || [];
        
        // Data for readiness distribution chart
        const readinessData = {
            ready_now: recommendations.filter(r => r.readiness_category === 'ready_now').length,
            ready_soon: recommendations.filter(r => r.readiness_category === 'ready_soon').length,
            not_ready: recommendations.filter(r => r.readiness_category === 'not_ready').length
        };
        
        // Data for skill radar chart
        const skillRadarData = recommendations.map(rec => ({
            candidate: rec.candidate_name,
            skills: {
                skill_match: rec.features.skill_match * 100,
                experience: rec.features.experience_level * 100,
                performance: rec.features.performance_score * 100,
                leadership: rec.features.leadership_score * 100,
                training: rec.features.training_completion * 100
            }
        }));
        
        // Timeline data
        const timelineData = recommendations.map(rec => ({
            candidate: rec.candidate_name,
            timeline: this.getTimelineRecommendation(rec.readiness_score).timeline,
            confidence: this.getTimelineRecommendation(rec.readiness_score).confidence
        }));
        
        return {
            readiness_distribution: readinessData,
            skill_radar: skillRadarData,
            timeline_analysis: timelineData,
            risk_assessment: analysisResult.insights?.risk_level || 'unknown',
            overall_score: analysisResult.insights?.average_score || 0
        };
    }
}

// Example usage and integration with existing page
class SuccessionAIIntegration {
    constructor() {
        this.ai = new SuccessionAI();
        this.initialized = false;
        this.employeeData = [];
        this.roleData = [];
        this.currentAnalysis = null;
    }

    // Initialize and setup AI
    async setup() {
        console.log('Setting up Succession Planning AI...');
        
        // Load TensorFlow.js if not already loaded
        if (typeof tf === 'undefined') {
            await this.loadTensorFlow();
        }
        
        // Initialize AI model
        this.initialized = await this.ai.initialize();
        
        if (this.initialized) {
            console.log('Succession AI ready');
            this.bindEvents();
            this.loadExistingData();
        }
        
        return this.initialized;
    }

    // Load TensorFlow.js dynamically
    async loadTensorFlow() {
        return new Promise((resolve, reject) => {
            if (typeof tf !== 'undefined') {
                resolve();
                return;
            }
            
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@latest';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Bind to page elements and events
    bindEvents() {
        // Bind to AI recommendation cards
        const aiCards = document.querySelectorAll('.ai-recommendation-card');
        aiCards.forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                this.showAIAnalysis(card);
            });
        });
        
        // Add AI analysis button to role cards
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
        roleCards.forEach(card => {
            this.addAIAnalysisButton(card);
        });
        
        // Bind to existing buttons
        const aiButtons = document.querySelectorAll('.ai-analysis-btn');
        aiButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.triggerAIAnalysis(e.target);
            });
        });

        // Bind view details buttons
        const viewDetailsButtons = document.querySelectorAll('.view-details-btn');
        viewDetailsButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const role = e.target.getAttribute('data-role');
                const employee = e.target.getAttribute('data-employee');
                this.showRoleDetails(role, employee);
            });
        });

        // Bind create plan buttons
        const createPlanButtons = document.querySelectorAll('.create-plan-btn');
        createPlanButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const roleId = e.target.getAttribute('data-role-id');
                this.createDevelopmentPlan(roleId);
            });
        });
    }

    // Load existing employee and role data
    loadExistingData() {
        // Extract employee data from page
        const employees = this.extractEmployeeData();
        const roles = this.extractRoleData();
        
        // Store for later use
        this.employeeData = employees;
        this.roleData = roles;
        
        console.log(`Loaded ${employees.length} employees and ${roles.length} roles`);
    }

    // Extract employee data from page
    extractEmployeeData() {
        const employees = [];
        
        // Extract from role cards
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
        roleCards.forEach(card => {
            const nameElement = card.querySelector('p.text-sm.text-gray-500.mt-1');
            const nameText = nameElement ? nameElement.textContent.replace('Employee: ', '') : '';
            
            if (nameText) {
                const roleElement = card.querySelector('h3.font-semibold.text-lg');
                const deptElement = card.querySelector('p.text-sm.text-blue-600');
                const readinessElement = card.querySelector('.px-3.py-1.rounded-full');
                
                const employee = {
                    id: card.getAttribute('data-id') || Math.random().toString(36).substr(2, 9),
                    name: nameText.trim(),
                    position: roleElement ? roleElement.textContent.trim() : '',
                    department: deptElement ? deptElement.textContent.replace('Department: ', '').trim() : '',
                    readiness: readinessElement ? this.extractReadinessFromBadge(readinessElement) : 'not_ready'
                };
                
                employees.push(employee);
            }
        });
        
        return employees;
    }

    // Extract role data from page
    extractRoleData() {
        const roles = [];
        
        // Extract from role cards
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
        roleCards.forEach(card => {
            const roleElement = card.querySelector('h3.font-semibold.text-lg');
            const deptElement = card.querySelector('p.text-sm.text-blue-600');
            
            if (roleElement) {
                const role = {
                    id: card.getAttribute('data-id') || Math.random().toString(36).substr(2, 9),
                    title: roleElement.textContent.trim(),
                    department: deptElement ? deptElement.textContent.replace('Department: ', '').trim() : '',
                    required_skills: [] // Will be populated from database or user input
                };
                
                roles.push(role);
            }
        });
        
        return roles;
    }

    // Extract readiness from badge
    extractReadinessFromBadge(badge) {
        const text = badge.textContent.trim().toLowerCase();
        if (text.includes('ready now') || text.includes('qualified')) return 'ready_now';
        if (text.includes('ready soon') || text.includes('in progress')) return 'ready_soon';
        return 'not_ready';
    }

    // Add AI analysis button to role card
    addAIAnalysisButton(card) {
        if (card.querySelector('.ai-analysis-action-btn')) return;
        
        const button = document.createElement('button');
        button.className = 'ai-analysis-action-btn mt-3 px-3 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg text-sm font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2 w-full';
        button.innerHTML = `
            <i class="fas fa-robot text-xs"></i>
            <span class="truncate">AI Analysis</span>
        `;
        
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            this.analyzeRole(card);
        });
        
        const actionDiv = card.querySelector('.flex.gap-3.mt-6');
        if (actionDiv) {
            // Create a wrapper for AI button
            const aiButtonWrapper = document.createElement('div');
            aiButtonWrapper.className = 'w-full mt-2';
            aiButtonWrapper.appendChild(button);
            
            // Insert AI button above existing buttons
            actionDiv.parentNode.insertBefore(aiButtonWrapper, actionDiv);
        }
    }

    // Analyze a specific role
    async analyzeRole(roleCard) {
        if (!this.initialized) {
            this.showNotification('AI is still initializing. Please wait...', 'warning');
            return;
        }
        
        const roleTitle = this.extractText(roleCard, 'h3.font-semibold.text-lg');
        const roleDepartment = this.extractText(roleCard, 'p.text-sm.text-blue-600');
        
        // Clean department text
        const cleanDept = roleDepartment ? roleDepartment.replace('Department: ', '').trim() : '';
        
        // Find matching role in data
        const role = this.roleData.find(r => 
            r.title === roleTitle || 
            r.department === cleanDept
        ) || {
            title: roleTitle,
            department: cleanDept,
            required_skills: ['leadership', 'management', 'communication'] // Default skills
        };
        
        // Find potential candidates (employees in same department or with similar roles)
        const candidates = this.findPotentialCandidates(role);
        
        if (candidates.length === 0) {
            this.showNoCandidatesMessage(roleCard);
            return;
        }
        
        // Show loading state
        this.showLoading(roleCard);
        
        try {
            // Run AI analysis
            const analysis = await this.ai.analyzeSuccession(role, candidates);
            
            // Display results
            this.displayAnalysisResults(analysis, roleCard);
            
            // Store analysis for later reference
            this.currentAnalysis = analysis;
            
        } catch (error) {
            console.error('AI analysis failed:', error);
            this.showError(roleCard, 'Analysis failed. Please try again.');
        }
    }

    // Extract text from element
    extractText(element, selector) {
        const found = selector ? element.querySelector(selector) : element;
        return found?.textContent?.trim() || '';
    }

    // Find potential candidates for a role
    findPotentialCandidates(role) {
        return this.employeeData.filter(employee => {
            // Basic filtering - same department or similar role
            return employee.department === role.department ||
                   employee.position.toLowerCase().includes(role.title.toLowerCase()) ||
                   role.title.toLowerCase().includes(employee.position.toLowerCase());
        }).map(employee => ({
            ...employee,
            // Add mock data for demonstration
            skills: ['leadership', 'communication', 'problem_solving', 'teamwork'],
            experience_years: Math.floor(Math.random() * 10) + 1,
            performance_rating: 3 + Math.random() * 2, // 3-5
            training_completed: Math.floor(Math.random() * 10),
            training_total: 10,
            competency_gap_score: Math.random() * 0.5,
            leadership_assessments: [
                { score: 3 + Math.random() * 2 }
            ],
            tenure_months: Math.floor(Math.random() * 120) + 12
        }));
    }

    // Display analysis results
    displayAnalysisResults(analysis, roleCard) {
        // Remove loading state
        this.removeLoading(roleCard);
        
        // Create results container
        const resultsContainer = document.createElement('div');
        resultsContainer.className = 'ai-results-container mt-4 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200';
        resultsContainer.innerHTML = this.generateResultsHTML(analysis);
        
        // Add to role card
        const existingResults = roleCard.querySelector('.ai-results-container');
        if (existingResults) {
            existingResults.remove();
        }
        
        roleCard.appendChild(resultsContainer);
        
        // Add visualization
        this.addVisualizations(analysis, resultsContainer);
        
        // Add event listener for detailed view
        const detailsBtn = resultsContainer.querySelector('.view-details-btn');
        if (detailsBtn) {
            detailsBtn.addEventListener('click', () => {
                this.showDetailedAnalysis(analysis);
            });
        }
    }

    // Generate HTML for results
    generateResultsHTML(analysis) {
        const topCandidate = analysis.recommendations[0];
        
        return `
            <div class="ai-analysis-results">
                <div class="flex items-center justify-between mb-4">
                    <h4 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                        <i class="fas fa-robot text-blue-600"></i>
                        AI Successor Analysis
                    </h4>
                    <span class="px-3 py-1 rounded-full text-sm font-medium ${this.getRiskColor(analysis.insights.risk_level)}">
                        ${analysis.insights.risk_level.toUpperCase()} RISK
                    </span>
                </div>
                
                ${topCandidate ? `
                <div class="mb-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-medium text-gray-700">Top Candidate</span>
                        <span class="text-sm font-bold ${this.getScoreColor(topCandidate.match_percentage)}">
                            ${topCandidate.match_percentage}% Match
                        </span>
                    </div>
                    <div class="bg-white rounded-lg p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium text-gray-900">${topCandidate.candidate_name}</p>
                                <p class="text-sm text-gray-600">${topCandidate.candidate_role} • ${topCandidate.department}</p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-xs font-semibold ${this.getReadinessColor(topCandidate.readiness_category)}">
                                ${topCandidate.readiness_category.replace('_', ' ').toUpperCase()}
                            </span>
                        </div>
                        
                        <div class="mt-4">
                            <p class="text-sm font-medium text-gray-700 mb-2">Timeline: ${this.ai.getTimelineRecommendation(topCandidate.readiness_score).timeline}</p>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-green-600 h-2 rounded-full" style="width: ${topCandidate.match_percentage}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                ` : ''}
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div class="bg-white rounded-lg p-3 border border-gray-200">
                        <p class="text-xs text-gray-500">Total Candidates</p>
                        <p class="text-xl font-bold text-gray-900">${analysis.total_candidates}</p>
                    </div>
                    <div class="bg-white rounded-lg p-3 border border-gray-200">
                        <p class="text-xs text-gray-500">Average Score</p>
                        <p class="text-xl font-bold ${this.getScoreColor(analysis.insights.average_score)}">
                            ${analysis.insights.average_score}%
                        </p>
                    </div>
                </div>
                
                ${analysis.insights.common_development_needs?.length > 0 ? `
                <div class="mb-4">
                    <p class="text-sm font-medium text-gray-700 mb-2">Common Development Needs:</p>
                    <div class="space-y-2">
                        ${analysis.insights.common_development_needs.map(need => `
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-600">${need.feature}</span>
                                <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                                    ${need.percentage}% of candidates
                                </span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div class="mt-4 pt-4 border-t border-gray-200">
                    <button class="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors view-details-btn">
                        View Detailed Analysis
                    </button>
                </div>
            </div>
        `;
    }

    // Add visualizations to results
    addVisualizations(analysis, container) {
        const vizData = this.ai.generateVisualizationData(analysis);
        
        // Create canvas for simple chart
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 200;
        canvas.style.maxWidth = '100%';
        canvas.className = 'mt-4';
        
        container.appendChild(canvas);
        
        // Draw simple chart
        this.drawReadinessChart(canvas, vizData.readiness_distribution);
    }

    // Draw simple readiness chart
    drawReadinessChart(canvas, data) {
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Chart configuration
        const colors = {
            ready_now: '#10b981',
            ready_soon: '#f59e0b',
            not_ready: '#ef4444'
        };
        
        const labels = {
            ready_now: 'Ready Now',
            ready_soon: 'Ready Soon',
            not_ready: 'Not Ready'
        };
        
        const total = data.ready_now + data.ready_soon + data.not_ready;
        if (total === 0) return;
        
        let startAngle = 0;
        
        // Draw pie chart
        Object.entries(data).forEach(([key, value]) => {
            if (value === 0) return;
            
            const sliceAngle = (value / total) * 2 * Math.PI;
            
            // Draw slice
            ctx.beginPath();
            ctx.moveTo(width / 2, height / 2);
            ctx.arc(width / 2, height / 2, Math.min(width, height) / 3, startAngle, startAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = colors[key];
            ctx.fill();
            
            // Draw label
            const angle = startAngle + sliceAngle / 2;
            const radius = Math.min(width, height) / 2.5;
            const x = width / 2 + Math.cos(angle) * radius;
            const y = height / 2 + Math.sin(angle) * radius;
            
            ctx.fillStyle = '#1f2937';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${value}`, x, y);
            
            startAngle += sliceAngle;
        });
        
        // Draw legend
        let legendY = height - 60;
        Object.entries(labels).forEach(([key, label]) => {
            if (data[key] === 0) return;
            
            ctx.fillStyle = colors[key];
            ctx.fillRect(20, legendY, 12, 12);
            
            ctx.fillStyle = '#374151';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(`${label}: ${data[key]}`, 40, legendY + 10);
            
            legendY += 20;
        });
    }

    // Show detailed analysis modal
    showDetailedAnalysis(analysis) {
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = this.generateDetailedModalHTML(analysis);
        
        // Add to page
        document.body.appendChild(modal);
        
        // Add close functionality
        const closeBtn = modal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.remove();
            });
        }
        
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        // Add export functionality
        const exportBtn = modal.querySelector('.export-analysis-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportAnalysis(analysis);
            });
        }

        // Add create plan functionality
        const createPlanBtn = modal.querySelector('.create-plan-btn');
        if (createPlanBtn) {
            createPlanBtn.addEventListener('click', () => {
                this.createDevelopmentPlanFromAnalysis(analysis);
            });
        }
    }

    // Generate detailed modal HTML
    generateDetailedModalHTML(analysis) {
        return `
            <div class="modal-content">
                <div class="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900">AI Succession Analysis</h2>
                            <p class="text-gray-600">${analysis.role} • ${analysis.analysis_date ? new Date(analysis.analysis_date).toLocaleDateString() : 'Today'}</p>
                        </div>
                        <button class="close-modal p-2 hover:bg-gray-100 rounded-lg">
                            <i class="fas fa-times text-gray-500"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
                    <!-- Summary -->
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Executive Summary</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Risk Level</p>
                                <p class="text-2xl font-bold ${this.getRiskColor(analysis.insights.risk_level)}">
                                    ${analysis.insights.risk_level.toUpperCase()}
                                </p>
                            </div>
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Succession Score</p>
                                <p class="text-2xl font-bold ${this.getScoreColor(analysis.insights.average_score)}">
                                    ${analysis.insights.average_score}/100
                                </p>
                            </div>
                            <div class="text-center p-4 bg-white rounded-lg">
                                <p class="text-sm text-gray-500">Timeline</p>
                                <p class="text-2xl font-bold text-gray-900">
                                    ${analysis.insights.timeline_recommendation?.timeline || 'N/A'}
                                </p>
                            </div>
                        </div>
                        <p class="mt-4 text-gray-700">${analysis.insights.message}</p>
                    </div>
                    
                    <!-- Top Candidates -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recommended Successors</h3>
                        <div class="space-y-4">
                            ${analysis.recommendations.map((candidate, index) => `
                                <div class="bg-white border border-gray-200 rounded-xl p-6">
                                    <div class="flex items-center justify-between mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                                                <span class="text-lg font-bold text-blue-600">${index + 1}</span>
                                            </div>
                                            <div>
                                                <h4 class="font-semibold text-gray-900">${candidate.candidate_name}</h4>
                                                <p class="text-sm text-gray-600">${candidate.candidate_role} • ${candidate.department}</p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <span class="text-2xl font-bold ${this.getScoreColor(candidate.match_percentage)}">
                                                ${candidate.match_percentage}%
                                            </span>
                                            <p class="text-sm text-gray-500">Match Score</p>
                                        </div>
                                    </div>
                                    
                                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Readiness</p>
                                            <p class="font-medium ${this.getReadinessTextColor(candidate.readiness_category)}">
                                                ${candidate.readiness_category.replace('_', ' ')}
                                            </p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Timeline</p>
                                            <p class="font-medium text-gray-900">
                                                ${this.ai.getTimelineRecommendation(candidate.readiness_score).timeline}
                                            </p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Strengths</p>
                                            <p class="font-medium text-gray-900">${candidate.strengths?.length || 0}</p>
                                        </div>
                                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                                            <p class="text-xs text-gray-500">Gaps</p>
                                            <p class="font-medium text-gray-900">${candidate.gaps?.length || 0}</p>
                                        </div>
                                    </div>
                                    
                                    ${candidate.strengths?.length > 0 ? `
                                    <div class="mb-3">
                                        <p class="text-sm font-medium text-gray-700 mb-2">Key Strengths:</p>
                                        <div class="flex flex-wrap gap-2">
                                            ${candidate.strengths.slice(0, 3).map(strength => `
                                                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                                                    ${strength.feature}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                    ` : ''}
                                    
                                    ${candidate.recommended_actions?.length > 0 ? `
                                    <div>
                                        <p class="text-sm font-medium text-gray-700 mb-2">Recommended Actions:</p>
                                        <ul class="space-y-1">
                                            ${candidate.recommended_actions.slice(0, 3).map(action => `
                                                <li class="text-sm text-gray-600 flex items-start gap-2">
                                                    <i class="fas fa-chevron-right text-blue-500 mt-1"></i>
                                                    ${action}
                                                </li>
                                            `).join('')}
                                        </ul>
                                    </div>
                                    ` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <!-- Development Plan -->
                    ${analysis.insights.common_development_needs?.length > 0 ? `
                    <div class="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recommended Development Plan</h3>
                        <div class="space-y-4">
                            ${analysis.insights.common_development_needs.map(need => `
                                <div class="bg-white rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="font-medium text-gray-900">${need.feature}</span>
                                        <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                                            ${need.percentage}% need improvement
                                        </span>
                                    </div>
                                    <p class="text-sm text-gray-600">Consider implementing targeted training programs to address this gap across multiple candidates.</p>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}
                    
                    <!-- Actions -->
                    <div class="flex gap-4">
                        <button class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors export-analysis-btn">
                            <i class="fas fa-download mr-2"></i> Export Analysis
                        </button>
                        <button class="flex-1 py-3 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl font-medium transition-colors create-plan-btn">
                            <i class="fas fa-plus mr-2"></i> Create Development Plan
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Helper methods for styling
    getRiskColor(riskLevel) {
        const colors = {
            high: 'bg-red-100 text-red-800',
            medium: 'bg-yellow-100 text-yellow-800',
            low: 'bg-green-100 text-green-800'
        };
        return colors[riskLevel] || 'bg-gray-100 text-gray-800';
    }

    getScoreColor(score) {
        if (score >= 80) return 'text-green-600';
        if (score >= 60) return 'text-yellow-600';
        return 'text-red-600';
    }

    getReadinessColor(category) {
        const colors = {
            ready_now: 'bg-green-100 text-green-600',
            ready_soon: 'bg-yellow-100 text-yellow-600',
            not_ready: 'bg-red-100 text-red-600'
        };
        return colors[category] || 'bg-gray-100 text-gray-600';
    }

    getReadinessTextColor(category) {
        const colors = {
            ready_now: 'text-green-600',
            ready_soon: 'text-yellow-600',
            not_ready: 'text-red-600'
        };
        return colors[category] || 'text-gray-600';
    }

    // Show loading state
    showLoading(element) {
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'ai-loading mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200';
        loadingDiv.innerHTML = `
            <div class="flex items-center justify-center gap-3">
                <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                <span class="text-gray-700">AI is analyzing potential successors...</span>
            </div>
        `;
        
        const existingLoading = element.querySelector('.ai-loading');
        if (existingLoading) existingLoading.remove();
        
        element.appendChild(loadingDiv);
    }

    removeLoading(element) {
        const loading = element.querySelector('.ai-loading');
        if (loading) loading.remove();
    }

    showNoCandidatesMessage(element) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-no-candidates mt-4 p-4 bg-yellow-50 rounded-xl border border-yellow-200';
        messageDiv.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas fa-exclamation-triangle text-yellow-600"></i>
                <div>
                    <p class="font-medium text-yellow-800">No suitable candidates found</p>
                    <p class="text-sm text-yellow-600 mt-1">Consider expanding search or developing internal talent.</p>
                </div>
            </div>
        `;
        
        const existing = element.querySelector('.ai-no-candidates, .ai-results-container');
        if (existing) existing.remove();
        
        element.appendChild(messageDiv);
    }

    showError(element, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'ai-error mt-4 p-4 bg-red-50 rounded-xl border border-red-200';
        errorDiv.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas fa-exclamation-circle text-red-600"></i>
                <div>
                    <p class="font-medium text-red-800">Analysis Error</p>
                    <p class="text-sm text-red-600 mt-1">${message}</p>
                </div>
            </div>
        `;
        
        const existing = element.querySelector('.ai-error, .ai-loading, .ai-results-container');
        if (existing) existing.remove();
        
        element.appendChild(errorDiv);
    }

    // Show notification - COMPLETED VERSION
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed bottom-4 right-4 px-4 py-3 rounded-lg shadow-lg z-50 ${
            type === 'warning' ? 'bg-yellow-500 text-white' : 
            type === 'error' ? 'bg-red-500 text-white' : 
            'bg-blue-500 text-white'
        }`;
        notification.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas fa-${type === 'warning' ? 'exclamation-triangle' : 
                type === 'error' ? 'exclamation-circle' : 
                'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        // Remove existing notification
        const existing = document.querySelector('.fixed.bottom-4.right-4');
        if (existing) existing.remove();
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    // Export analysis to JSON
    exportAnalysis(analysis) {
        const dataStr = JSON.stringify(analysis, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `succession-analysis-${analysis.role}-${new Date().toISOString().split('T')[0]}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        this.showNotification('Analysis exported successfully!', 'info');
    }

    // Create development plan from analysis
    createDevelopmentPlanFromAnalysis(analysis) {
        const plan = {
            id: 'plan-' + Date.now(),
            role: analysis.role,
            role_id: analysis.role_id,
            created_date: new Date().toISOString(),
            status: 'draft',
            timeline: analysis.insights.timeline_recommendation?.timeline || '6-12 months',
            candidates: analysis.recommendations.map(candidate => ({
                id: candidate.candidate_id,
                name: candidate.candidate_name,
                readiness: candidate.readiness_category,
                timeline: this.ai.getTimelineRecommendation(candidate.readiness_score).timeline,
                actions: candidate.recommended_actions || []
            })),
            development_areas: analysis.insights.common_development_needs || [],
            risk_level: analysis.insights.risk_level
        };
        
        // Store plan in localStorage (in real app, would send to server)
        const existingPlans = JSON.parse(localStorage.getItem('succession_plans') || '[]');
        existingPlans.push(plan);
        localStorage.setItem('succession_plans', JSON.stringify(existingPlans));
        
        this.showNotification(`Development plan created for ${analysis.role}!`, 'info');
        
        // Show plan creation modal
        this.showPlanCreationModal(plan);
        
        return plan;
    }

    // Show plan creation modal
    showPlanCreationModal(plan) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = this.generatePlanModalHTML(plan);
        
        document.body.appendChild(modal);
        
        // Add close functionality
        const closeBtn = modal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.remove();
            });
        }
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
        // Add save functionality
        const saveBtn = modal.querySelector('.save-plan-btn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveDevelopmentPlan(plan);
                modal.remove();
            });
        }
    }

    // Generate plan modal HTML
    generatePlanModalHTML(plan) {
        return `
            <div class="modal-content max-w-2xl">
                <div class="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900">Development Plan Created</h2>
                            <p class="text-gray-600">Succession plan for ${plan.role}</p>
                        </div>
                        <button class="close-modal p-2 hover:bg-gray-100 rounded-lg">
                            <i class="fas fa-times text-gray-500"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-6">
                    <!-- Plan Summary -->
                    <div class="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Plan Summary</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-white rounded-lg p-4">
                                <p class="text-sm text-gray-500">Status</p>
                                <p class="text-lg font-bold text-green-600">DRAFT</p>
                            </div>
                            <div class="bg-white rounded-lg p-4">
                                <p class="text-sm text-gray-500">Timeline</p>
                                <p class="text-lg font-bold text-gray-900">${plan.timeline}</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Selected Candidates -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Selected Successors</h3>
                        <div class="space-y-4">
                            ${plan.candidates.map((candidate, index) => `
                                <div class="bg-white border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                                                <span class="font-bold text-blue-600">${index + 1}</span>
                                            </div>
                                            <div>
                                                <p class="font-medium text-gray-900">${candidate.name}</p>
                                                <p class="text-sm text-gray-600">${candidate.readiness.replace('_', ' ')} • ${candidate.timeline}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <!-- Development Areas -->
                    ${plan.development_areas.length > 0 ? `
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Key Development Areas</h3>
                        <div class="space-y-3">
                            ${plan.development_areas.map(area => `
                                <div class="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                                    <span class="text-gray-700">${area.feature}</span>
                                    <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                                        ${area.percentage}% need improvement
                                    </span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}
                    
                    <!-- Next Steps -->
                    <div class="bg-gray-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Next Steps</h3>
                        <div class="space-y-3">
                            <div class="flex items-start gap-3">
                                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                                    <span class="text-xs font-bold text-blue-600">1</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Review the plan with HR</p>
                                    <p class="text-sm text-gray-600 mt-1">Schedule a meeting to discuss implementation</p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                                    <span class="text-xs font-bold text-blue-600">2</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Assign mentors</p>
                                    <p class="text-sm text-gray-600 mt-1">Identify experienced mentors for each candidate</p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                                    <span class="text-xs font-bold text-blue-600">3</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Schedule training</p>
                                    <p class="text-sm text-gray-600 mt-1">Plan development activities and training sessions</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex gap-4 pt-4">
                        <button class="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-colors close-modal">
                            Close
                        </button>
                        <button class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors save-plan-btn">
                            <i class="fas fa-save mr-2"></i> Save Plan
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Save development plan
    saveDevelopmentPlan(plan) {
        // In a real application, this would send data to the server
        console.log('Saving development plan:', plan);
        
        // Simulate API call
        setTimeout(() => {
            this.showNotification('Development plan saved successfully!', 'info');
            
            // Refresh page or update UI
            location.reload();
        }, 1000);
    }

    // Create development plan for specific role
    async createDevelopmentPlan(roleId) {
        // Find role by ID
        const roleCard = document.querySelector(`[data-role-id="${roleId}"]`)?.closest('.bg-white.rounded-xl.shadow.p-5');
        
        if (!roleCard) {
            this.showNotification('Role not found!', 'error');
            return;
        }
        
        // Analyze role first
        await this.analyzeRole(roleCard);
        
        // Use current analysis if available
        if (this.currentAnalysis) {
            this.createDevelopmentPlanFromAnalysis(this.currentAnalysis);
        } else {
            this.showNotification('Please run AI analysis first!', 'warning');
        }
    }

    // Show role details - WORKING VERSION
    showRoleDetails(role, employee) {
        // Create modal with role details
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = this.generateRoleDetailsHTML(role, employee);
        
        document.body.appendChild(modal);
        
        // Add close functionality
        const closeBtn = modal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.remove();
            });
        }
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    // Generate role details HTML
    generateRoleDetailsHTML(role, employee) {
        return `
            <div class="modal-content max-w-2xl">
                <div class="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900">Role Details</h2>
                            <p class="text-gray-600">${role}</p>
                        </div>
                        <button class="close-modal p-2 hover:bg-gray-100 rounded-lg">
                            <i class="fas fa-times text-gray-500"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-6 space-y-6">
                    <!-- Current Incumbent -->
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Current Incumbent</h3>
                        <div class="flex items-center gap-4">
                            <div class="w-16 h-16 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-user-tie text-blue-600 text-2xl"></i>
                            </div>
                            <div>
                                <p class="text-xl font-bold text-gray-900">${employee}</p>
                                <p class="text-gray-600">${role}</p>
                                <div class="flex items-center gap-3 mt-2">
                                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                                        Active
                                    </span>
                                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                                        Key Position
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Role Requirements -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Role Requirements</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <p class="text-sm text-gray-500">Minimum Experience</p>
                                <p class="text-lg font-bold text-gray-900">5+ Years</p>
                            </div>
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <p class="text-sm text-gray-500">Education Level</p>
                                <p class="text-lg font-bold text-gray-900">Bachelor's Degree</p>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <p class="text-sm font-medium text-gray-700 mb-2">Required Skills:</p>
                            <div class="flex flex-wrap gap-2">
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                                    Leadership
                                </span>
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                                    Strategic Planning
                                </span>
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                                    Team Management
                                </span>
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                                    Communication
                                </span>
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                                    Budget Management
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Succession Timeline -->
                    <div class="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Succession Timeline</h3>
                        <div class="space-y-4">
                            <div class="flex items-center gap-4">
                                <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center border-2 border-green-500">
                                    <i class="fas fa-check text-green-500"></i>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Immediate (0-3 months)</p>
                                    <p class="text-sm text-gray-600">Emergency backup identified</p>
                                </div>
                            </div>
                            <div class="flex items-center gap-4">
                                <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center border-2 border-yellow-500">
                                    <span class="text-yellow-500 font-bold">1</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Short-term (3-6 months)</p>
                                    <p class="text-sm text-gray-600">Primary successor development</p>
                                </div>
                            </div>
                            <div class="flex items-center gap-4">
                                <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center border-2 border-blue-500">
                                    <span class="text-blue-500 font-bold">2</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Long-term (6-12 months)</p>
                                    <p class="text-sm text-gray-600">Additional candidate pipeline</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex gap-4 pt-4">
                        <button class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors analyze-role-btn">
                            <i class="fas fa-robot mr-2"></i> AI Analysis
                        </button>
                        <button class="flex-1 py-3 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl font-medium transition-colors edit-role-btn">
                            <i class="fas fa-edit mr-2"></i> Edit Role
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Show AI analysis for clicked card
    showAIAnalysis(card) {
        const roleCard = card.closest('.bg-white.rounded-xl.shadow.p-5');
        if (roleCard) {
            this.analyzeRole(roleCard);
        }
    }

    // Trigger AI analysis for overall view
    triggerAIAnalysis(button) {
        // Run analysis for all roles
        const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
        
        if (roleCards.length === 0) {
            this.showNotification('No roles found for analysis!', 'warning');
            return;
        }
        
        this.showNotification('Starting AI analysis for all critical roles...', 'info');
        
        // Analyze first role as example
        if (roleCards[0]) {
            this.analyzeRole(roleCards[0]);
        }
    }
}

// Main execution
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Succession Planning page loaded');
    
    // Initialize AI integration
    const aiIntegration = new SuccessionAIIntegration();
    
    try {
        // Setup AI with timeout to prevent blocking
        setTimeout(async () => {
            const success = await aiIntegration.setup();
            if (success) {
                console.log('AI Integration ready');
                
                // Add AI badges to role cards
                const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
                roleCards.forEach(card => {
                    const aiBadge = document.createElement('div');
                    aiBadge.className = 'ai-badge';
                    aiBadge.innerHTML = '<i class="fas fa-brain text-xs"></i> AI';
                    
                    // Check if badge already exists
                    if (!card.querySelector('.ai-badge')) {
                        card.style.position = 'relative';
                        card.appendChild(aiBadge);
                    }
                });
                
                // Show welcome notification
                setTimeout(() => {
                    aiIntegration.showNotification('AI Succession Planning is ready! Click on any role card for analysis.', 'info');
                }, 1000);
            }
        }, 1000);
        
    } catch (error) {
        console.error('Failed to initialize AI:', error);
    }
    
    // Bind other event listeners
    bindEventListeners();
});

// Bind other event listeners
function bindEventListeners() {
    // Quick action buttons
    const quickActionButtons = document.querySelectorAll('.quick-action-btn');
    quickActionButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const action = button.getAttribute('data-action');
            handleQuickAction(action);
        });
    });
    
    // Tab navigation
    const tabLinks = document.querySelectorAll('.tab-link');
    tabLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = link.getAttribute('href');
            if (target && target !== '#') {
                window.location.href = target;
            }
        });
    });
    
    // Search functionality (if any)
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
    }
    
    // Direct event binding for View Details buttons as backup
    document.addEventListener('click', function(e) {
        if (e.target.closest('.view-details-btn')) {
            const button = e.target.closest('.view-details-btn');
            const role = button.getAttribute('data-role');
            const employee = button.getAttribute('data-employee');
            
            // Create AI integration instance if needed
            if (window.successionAI) {
                window.successionAI.showRoleDetails(role, employee);
            } else {
                // Fallback: Show simple modal
                showSimpleRoleDetails(role, employee);
            }
        }
        
        // Direct event binding for Create Plan buttons
        if (e.target.closest('.create-plan-btn')) {
            const button = e.target.closest('.create-plan-btn');
            const roleId = button.getAttribute('data-role-id');
            
            // Create AI integration instance if needed
            if (window.successionAI) {
                window.successionAI.createDevelopmentPlan(roleId);
            } else {
                // Fallback: Show alert
                alert(`Creating development plan for Role ID: ${roleId}`);
            }
        }
    });
}

// Fallback function for View Details
function showSimpleRoleDetails(role, employee) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 16px; padding: 1.5rem; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2 style="font-size: 1.5rem; font-weight: bold; color: #111827;">Role Details</h2>
                <button class="close-modal" style="padding: 0.5rem; border-radius: 0.5rem; background: #f3f4f6; border: none; cursor: pointer;">
                    <i class="fas fa-times" style="color: #6b7280;"></i>
                </button>
            </div>
            <div>
                <h3 style="font-size: 1.125rem; font-weight: 600; color: #111827; margin-bottom: 0.5rem;">${role}</h3>
                <p style="color: #6b7280; margin-bottom: 1rem;">Employee: ${employee}</p>
                <div style="background: #f0f9ff; padding: 1rem; border-radius: 0.75rem; margin-bottom: 1rem;">
                    <p style="font-weight: 600; color: #111827;">Role Information</p>
                    <p style="color: #6b7280;">This is a detailed view of the role. More information would be displayed here in a full implementation.</p>
                </div>
                <button style="width: 100%; padding: 0.75rem; background: #4f46e5; color: white; border: none; border-radius: 0.75rem; font-weight: 500; cursor: pointer;">
                    Close
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add close functionality
    const closeBtn = modal.querySelector('.close-modal');
    closeBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    // Close on background click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

// Handle quick actions
function handleQuickAction(action) {
    switch(action) {
        case 'export':
            exportData();
            break;
        case 'print':
            window.print();
            break;
        case 'refresh':
            location.reload();
            break;
        default:
            console.log('Action not implemented:', action);
    }
}

// Export data function
function exportData() {
    const data = {
        exported_at: new Date().toISOString(),
        page: 'succession_planning',
        data: collectPageData()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `succession-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('Data exported successfully!', 'success');
}

// Collect page data for export
function collectPageData() {
    const employees = [];
    const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
    
    roleCards.forEach(card => {
        const nameElement = card.querySelector('p.text-sm.text-gray-500.mt-1');
        const roleElement = card.querySelector('h3.font-semibold.text-lg');
        const deptElement = card.querySelector('p.text-sm.text-blue-600');
        const readinessElement = card.querySelector('.px-3.py-1.rounded-full');
        
        if (nameElement && roleElement) {
            employees.push({
                name: nameElement.textContent.replace('Employee: ', '').trim(),
                role: roleElement.textContent.trim(),
                department: deptElement ? deptElement.textContent.replace('Department: ', '').trim() : '',
                readiness: readinessElement ? readinessElement.textContent.trim() : 'Unknown'
            });
        }
    });
    
    return {
        employees: employees,
        stats: {
            total: employees.length,
            ready_now: document.querySelector('.text-3xl.font-bold.text-green-600')?.textContent || 0,
            ready_soon: document.querySelector('.text-3xl.font-bold.text-yellow-500')?.textContent || 0,
            not_ready: document.querySelector('.text-3xl.font-bold.text-red-600')?.textContent || 0
        }
    };
}

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'error' ? 'error' : ''}`;
    toast.innerHTML = `
        <div class="flex items-center gap-3">
            <i class="fas fa-${type === 'error' ? 'exclamation-circle' : 'check-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) existingToast.remove();
    
    document.body.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, 3000);
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle search
function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
    
    roleCards.forEach(card => {
        const cardText = card.textContent.toLowerCase();
        if (cardText.includes(searchTerm)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + S for save
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        exportData();
    }
    
    // Ctrl/Cmd + / for search focus
    if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Escape to close modals
    if (e.key === 'Escape') {
        const modal = document.querySelector('.modal-overlay.active');
        if (modal) {
            modal.remove();
        }
    }
});

// Initialize tooltips
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(event) {
    const tooltipText = event.target.getAttribute('data-tooltip');
    if (!tooltipText) return;
    
    const tooltip = document.createElement('div');
    tooltip.className = 'absolute z-50 px-3 py-2 text-sm text-white bg-gray-900 rounded-lg shadow-lg';
    tooltip.textContent = tooltipText;
    tooltip.style.top = (event.clientY + 10) + 'px';
    tooltip.style.left = (event.clientX + 10) + 'px';
    
    tooltip.id = 'dynamic-tooltip';
    document.body.appendChild(tooltip);
}

function hideTooltip() {
    const tooltip = document.getElementById('dynamic-tooltip');
    if (tooltip) {
        tooltip.remove();
    }
}

// Initialize when page loads
window.addEventListener('load', () => {
    initTooltips();
    
    // Add loading animation to AI cards
    const aiCards = document.querySelectorAll('.ai-recommendation-card');
    aiCards.forEach(card => {
        card.style.transition = 'all 0.3s ease';
    });
});

// Responsive adjustments
function handleResize() {
    const roleCards = document.querySelectorAll('.bg-white.rounded-xl.shadow.p-5');
    const isMobile = window.innerWidth < 768;
    
    roleCards.forEach(card => {
        if (isMobile) {
            card.style.minHeight = '350px';
        } else {
            card.style.minHeight = '320px';
        }
    });
}

window.addEventListener('resize', debounce(handleResize, 250));

// Initialize on page load
window.addEventListener('load', () => {
    handleResize(); // Set initial sizes
});

// Global reference for debugging
window.successionAI = new SuccessionAIIntegration();

console.log('Succession Planning JavaScript loaded successfully!');
</script>

<!-- Add any additional modals or hidden elements -->
<div id="notification-container" class="fixed bottom-0 right-0 p-4 space-y-2 z-50"></div>

</body>
</html>