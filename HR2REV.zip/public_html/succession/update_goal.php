<?php
// update_goal.php
$pdo = new PDO("mysql:host=localhost;dbname=competency;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$emp_id = $_POST['employee_id'] ?? 0;
$goal = $_POST['career_goal'] ?? '';

if ($emp_id && $goal) {
    $stmt = $pdo->prepare("UPDATE employee_succession SET career_goal = ? WHERE employee_id = ?");
    $stmt->execute([$goal, $emp_id]);
    echo "Updated";
} else {
    http_response_code(400);
    echo "Invalid input";
}
?>