<?php
// recommended_actions.php

// Database connection
try {
    $pdo = new PDO("mysql:host=localhost;dbname=competency;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}

// Assume $role is passed (e.g., from URL or parent script)
$role = $_GET['role'] ?? 'Front Office Manager'; // For demo

// Fetch employees who could be potential successors
$stmt = $pdo->prepare("
    SELECT e.id, e.name, r.name AS role, es.career_goal
    FROM employees e
    LEFT JOIN roles r ON e.role_id = r.id
    LEFT JOIN employee_succession es ON es.employee_id = e.id
    WHERE es.career_goal = ? OR es.career_goal IS NULL
    ORDER BY es.performance DESC
");
$stmt->execute([$role]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission: Assign Development Plan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_plan'])) {
    $emp_id = (int)$_POST['employee_id'];
    $plan_name = "Succession Prep: " . htmlspecialchars($role);
    $due_date = date('Y-m-d', strtotime('+3 months'));

    $insert = $pdo->prepare("INSERT INTO development_plans (employee_id, plan_name, status, due_date, created_at) 
                             VALUES (?, ?, 'Active', ?, NOW())");
    $insert->execute([$emp_id, $plan_name, $due_date]);

    $success_msg = "Development plan assigned to employee ID $emp_id.";
}
?>

<!-- Recommended Actions UI -->
<div class="bg-blue-50 border border-blue-200 rounded-xl p-6 space-y-5">
  <h4 class="font-semibold text-blue-800 flex items-center gap-2">
    <i data-lucide="lightbulb" class="w-5 h-5"></i>
    Recommended Actions for: <span class="font-bold text-blue-900"><?= htmlspecialchars($role) ?></span>
  </h4>

  <!-- Action 1: Assign Development Plan -->
  <div class="flex flex-wrap gap-3">
    <button 
      onclick="openDevPlanModal()" 
      class="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm px-4 py-2 rounded transition">
      <i data-lucide="clipboard-list" class="w-4 h-4"></i> Assign Development Plan
    </button>
  </div>

  <!-- Action 2: Notify Manager -->
  <button 
    onclick="notifyManager('<?= addslashes($role) ?>')"
    class="flex items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white text-sm px-4 py-2 rounded transition">
    <i data-lucide="bell" class="w-4 h-4"></i> Notify Department Head
  </button>

  <!-- Action 3: Edit Career Goal (for HR) -->
  <div class="mt-4">
    <label class="block text-sm font-medium text-gray-700 mb-2">Suggest Career Goal Update</label>
    <div class="flex gap-2">
      <select id="goalEmployee" class="border border-gray-300 rounded px-3 py-1 text-sm">
        <option value="">Select Employee</option>
        <?php foreach ($employees as $emp): ?>
          <option value="<?= $emp['id'] ?>">
            <?= htmlspecialchars($emp['name']) ?> (<?= htmlspecialchars($emp['role']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <input type="text" id="newGoal" placeholder="e.g., Assistant Manager" 
             class="border border-gray-300 rounded px-3 py-1 text-sm flex-1 max-w-xs">
      <button onclick="updateCareerGoal()" 
              class="bg-green-500 hover:bg-green-600 text-white text-sm px-3 py-2 rounded">
        Update
      </button>
    </div>
  </div>

  <!-- Success Message -->
  <?php if (isset($success_msg)): ?>
    <div class="mt-4 bg-green-100 border border-green-300 text-green-700 px-4 py-2 rounded text-sm">
      <?= $success_msg ?>
    </div>
  <?php endif; ?>
</div>

<!-- Modal: Assign Development Plan -->
<div id="devPlanModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg w-96 shadow-lg">
    <h5 class="font-semibold mb-4">Assign Development Plan</h5>
    <form method="POST">
      <input type="hidden" name="assign_plan" value="1">
      <label class="block text-sm font-medium mb-2">Select Employee</label>
      <select name="employee_id" class="w-full border border-gray-300 rounded px-2 py-1 mb-4" required>
        <option value="">-- Choose --</option>
        <?php foreach ($employees as $emp): ?>
          <option value="<?= $emp['id'] ?>">
            <?= htmlspecialchars($emp['name']) ?>
            (Goal: <?= $emp['career_goal'] ?: 'Not set' ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <div class="flex gap-2">
        <button type="submit" class="bg-green-500 text-white px-4 py-1 rounded text-sm hover:bg-green-600">Assign</button>
        <button type="button" onclick="closeDevPlanModal()" class="bg-gray-300 px-4 py-1 rounded text-sm">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Notify Manager Script -->
<script>
function notifyManager(role) {
    if (confirm(`Send alert to department head for role: ${role}?`)) {
        fetch('send_alert.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `role=${encodeURIComponent(role)}&type=risk_role`
        })
        .then(r => r.text())
        .then(data => {
            alert("Manager notified successfully!");
        })
        .catch(err => {
            alert("Failed to send notification.");
        });
    }
}

function updateCareerGoal() {
    const empId = document.getElementById('goalEmployee').value;
    const newGoal = document.getElementById('newGoal').value;

    if (!empId || !newGoal) {
        alert("Please select an employee and enter a goal.");
        return;
    }

    fetch('update_goal.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `employee_id=${empId}&career_goal=${encodeURIComponent(newGoal)}`
    })
    .then(r => r.text())
    .then(() => {
        alert("Career goal updated!");
        location.reload(); // Refresh to see changes
    });
}

function openDevPlanModal() {
    document.getElementById('devPlanModal').classList.remove('hidden');
}

function closeDevPlanModal() {
    document.getElementById('devPlanModal').classList.add('hidden');
}
</script>