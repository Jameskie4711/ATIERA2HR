<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include("../dblogin.php"); // DB connection

// Check if already logged in - PREVENT REDIRECT LOOPS
if (isset($_SESSION['hr_user']) && !empty($_SESSION['hr_user']['id'])) {
    // Already logged in, redirect directly WITHOUT token
    $redirect_url = "../index.php";
    if (isset($_GET['token'])) {
        // Remove token from URL to prevent re-processing
        $query_params = $_GET;
        unset($query_params['token']);
        if (!empty($query_params)) {
            $redirect_url .= '?' . http_build_query($query_params);
        }
    }
    header("Location: " . $redirect_url);
    exit;
}

// Check for token
if (!isset($_GET['token'])) {
    die("Token missing");
}

// Check if this token was already processed in this session
$token_hash = isset($_GET['token']) ? md5($_GET['token']) : null;
if (isset($_SESSION['processed_tokens']) && 
    in_array($token_hash, $_SESSION['processed_tokens'])) {
    // This token was already processed, redirect without it
    $redirect_url = "../index.php";
    $query_params = $_GET;
    unset($query_params['token']);
    if (!empty($query_params)) {
        $redirect_url .= '?' . http_build_query($query_params);
    }
    header("Location: " . $redirect_url);
    exit;
}

// Track processed token to prevent re-processing
if (!isset($_SESSION['processed_tokens'])) {
    $_SESSION['processed_tokens'] = [];
}
if ($token_hash && !in_array($token_hash, $_SESSION['processed_tokens'])) {
    $_SESSION['processed_tokens'][] = $token_hash;
    // Keep only last 5 tokens to avoid session bloat
    if (count($_SESSION['processed_tokens']) > 5) {
        array_shift($_SESSION['processed_tokens']);
    }
}

// decode token
$decoded = base64_decode($_GET['token']);
if (!$decoded) {
    // Invalid token, redirect to index without token
    $redirect_url = "../index.php";
    $query_params = $_GET;
    unset($query_params['token']);
    if (!empty($query_params)) {
        $redirect_url .= '?' . http_build_query($query_params);
    }
    header("Location: " . $redirect_url);
    exit;
}

$data = json_decode($decoded, true);
if (!$data || !isset($data['payload'], $data['signature'])) {
    die("Invalid token structure");
}

$signature = $data['signature'];

/**
 * Normalize payload
 */
if (is_array($data['payload'])) {
    $payload     = $data['payload'];
    $payloadJson = json_encode($payload, JSON_UNESCAPED_SLASHES);
} elseif (is_string($data['payload'])) {
    $payloadJson = $data['payload'];
    $payload     = json_decode($payloadJson, true);
} else {
    die("Invalid payload format");
}

if (!$payload) die("Invalid payload");

// Fetch HR2 secret for verification
$stmt = $conn->prepare("
    SELECT secret_key 
    FROM department_secrets 
    WHERE department='HR2' AND is_active=1 
    ORDER BY id DESC LIMIT 1
");
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
if (!$res) die("Secret not found");

$secret = $res['secret_key'];

// Verify signature (optional)
// $check = hash_hmac("sha256", $payloadJson, $secret);
// if (!hash_equals($check, $signature)) die("Invalid or tampered token");

// Check expiry
if ($payload['exp'] < time()) die("Token expired");

// Department validation
if ($payload['dept'] !== 'HR2') die("Invalid department access");

// Normalize role from token (case-insensitive)
$email = $payload['email'] ?? '';
$tokenRole = strtolower(trim($payload['role'] ?? ''));

if (empty($email) || empty($tokenRole)) die("Email or role missing in token");

// Map token roles to your system roles
$roleMap = [
    'admin'        => 'admin',
    'superadmin'   => 'admin',
    'super_admin'  => 'admin',   // ✅ fix for your token
    'user'         => 'user',
    'employee'     => 'user',
    'hr_manager'   => 'user'
];

if (!isset($roleMap[$tokenRole])) {
    die("Unknown role in token: " . htmlspecialchars($payload['role']));
}

$role = $roleMap[$tokenRole]; // normalized role for login.php session

// --------------------
// AUTO LOGIN (MATCH LOGIN.PHP SESSION)
// --------------------
if ($role === 'admin') {
    // single admin account
    $stmt_admin = $conn->prepare("SELECT id, user, role, mfa_enabled FROM admin LIMIT 1");
    $stmt_admin->execute();
    $admin_data = $stmt_admin->get_result()->fetch_assoc();
    $stmt_admin->close();

    if ($admin_data) {
        $_SESSION['hr_user'] = [
            "id"   => $admin_data['id'],
            "role" => 'admin',
            "user" => $admin_data['user']
        ];
        // ✅ ALSO set user_id for backward compatibility
        $_SESSION['user_id'] = $admin_data['id'];
        $_SESSION['last_activity'] = time();
        $login_success = true;
    }
} elseif ($role === 'user') {
    $stmt_user = $conn->prepare("SELECT id, Email, First_Name, Last_Name, role FROM users WHERE Email = ? LIMIT 1");
    $stmt_user->bind_param("s", $email);
    $stmt_user->execute();
    $user_data = $stmt_user->get_result()->fetch_assoc();
    $stmt_user->close();

    if ($user_data) {
        // Log activity
        $ip = $_SERVER['REMOTE_ADDR'];
        $stmt_log = $conn->prepare("INSERT INTO activity_logs (employee_id, action, details, ip_address) VALUES (?, 'Login', 'User logged in via SSO', ?)");
        $stmt_log->bind_param("is", $user_data['id'], $ip);
        $stmt_log->execute();
        $stmt_log->close();

        $_SESSION['hr_user'] = [
            "id"         => $user_data['id'],
            "role"       => 'user',
            "user"       => $user_data['Email'],
            "first_name" => $user_data['First_Name'],
            "last_name"  => $user_data['Last_Name']
        ];
        // ✅ ALSO set user_id for backward compatibility
        $_SESSION['user_id'] = $user_data['id'];
        $_SESSION['last_activity'] = time();
        $login_success = true;
    }
} elseif ($role === 'user') {
    $stmt_user = $conn->prepare("SELECT id, Email, First_Name, Last_Name, role FROM users WHERE Email = ? LIMIT 1");
    $stmt_user->bind_param("s", $email);
    $stmt_user->execute();
    $user_data = $stmt_user->get_result()->fetch_assoc();
    $stmt_user->close();

    if ($user_data) {
        // Log activity
        $ip = $_SERVER['REMOTE_ADDR'];
        $stmt_log = $conn->prepare("INSERT INTO activity_logs (employee_id, action, details, ip_address) VALUES (?, 'Login', 'User logged in via SSO', ?)");
        $stmt_log->bind_param("is", $user_data['id'], $ip);
        $stmt_log->execute();
        $stmt_log->close();

        $_SESSION['hr_user'] = [
            "id"         => $user_data['id'],
            "role"       => 'user',
            "user"       => $user_data['Email'],
            "first_name" => $user_data['First_Name'],
            "last_name"  => $user_data['Last_Name']
        ];
        $login_success = true;
    }
}

// --------------------
// Redirect to index.php - WITHOUT TOKEN
// --------------------
if ($login_success) {
    // Build redirect URL without token parameter
    $redirect_url = "../index.php";
    
    // Remove token from query parameters
    $query_params = $_GET;
    unset($query_params['token']);
    
    if (!empty($query_params)) {
        $redirect_url .= '?' . http_build_query($query_params);
    }
    
    // Use a 302 redirect (temporary) and exit immediately
    header("HTTP/1.1 302 Found");
    header("Location: " . $redirect_url);
    
    // Also output meta refresh as backup
    echo '<html><head><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($redirect_url) . '"></head></html>';
    exit;
} else {
    // Login failed, redirect to index without token
    $redirect_url = "../index.php";
    $query_params = $_GET;
    unset($query_params['token']);
    if (!empty($query_params)) {
        $redirect_url .= '?' . http_build_query($query_params);
    }
    header("Location: " . $redirect_url);
    exit;
}