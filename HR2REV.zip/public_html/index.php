<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* ─── Session Time-out ─── */
include_once __DIR__ . '/session_check.php';

/* ─── Database Connection ─── */
include_once __DIR__ . '/multi_db.php';  // connects to competency + rest_api_db

// Set all dashboard counts to 0 (remove all data)
$competencyCount = 0;
$learningCount   = 0;
$trainingCount   = 0;
$successionCount = 0;
$essCount        = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
  <style>
    :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --secondary: #f8fafc;
      --accent: #8b5cf6;
    }
    
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Animation classes */
    .fade-in {
      animation: fadeIn 0.5s ease-in-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    /* Card hover effect */
    .hover-lift {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .hover-lift:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1);
    }
    
    /* Gradient backgrounds */
    .gradient-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    /* Status indicators */
    .status-pulse {
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    
    /* Glass morphism effect */
    .glass-card {
      background: rgba(255, 255, 255, 0.7);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    /* Smooth time transition */
    .time-update {
      transition: opacity 0.3s ease;
    }
    
    .time-update.updating {
      opacity: 0.5;
    }
  </style>
</head>
<body class="h-screen overflow-hidden bg-gradient-to-br from-gray-50 to-blue-50">

  <!-- FLEX LAYOUT: Sidebar + Main -->
  <div class="flex h-full">

    <!-- Sidebar -->
    <?php include_once __DIR__ . '/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">

      <!-- Top Header -->
      <header class="bg-white shadow-sm border-b border-gray-200">
        <div class="px-6 py-4 flex items-center justify-between">
          <div class="flex items-center">
            <div class="mr-4">
              <div class="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shadow-md">
                <i data-lucide="layout-dashboard" class="w-6 h-6 text-white"></i>
              </div>
            </div>
          </div>
          
          <div class="flex items-center space-x-4">
            <div class="hidden md:flex items-center space-x-3">
              <div class="px-3 py-1.5 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                <div class="flex flex-col items-end">
                  <span class="text-xs text-gray-500" id="current-date"><?php echo date("D, M j"); ?></span>
                  <span class="text-sm text-gray-700 font-medium">
                    <i class="fas fa-clock mr-1.5 text-blue-500"></i>
                    <span id="header-time" class="time-update"><?php echo date("h:i:s A"); ?></span>
                  </span>
                </div>
              </div>
            </div>
            <?php include_once __DIR__ . '/profile.php'; ?>
          </div>
        </div>
      </header>

      <!-- Page Content -->
      <main class="flex-1 overflow-y-auto p-6">
      
       

        <!-- System Modules Grid -->
        <div class="mb-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800">System Modules</h3>
            <p class="text-sm text-gray-600">Click on any module to access</p>
          </div>
          
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            <!-- Competency -->
            <a href="competencies/competencies.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover-lift fade-in group" style="animation-delay: 0.2s">
              <div class="relative">
                <div class="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-md">
                      <i data-lucide="target" class="w-6 h-6 text-white"></i>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-medium px-2 py-1 rounded-full bg-indigo-50 text-indigo-700">Module</span>
                    </div>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-800 mb-2">Competency</h4>
                  <p class="text-sm text-gray-600 mb-4">Manage skills and competency assessments</p>
                  <div class="flex items-center justify-between">
                    <div>
                      <p class="text-3xl font-bold text-indigo-600"><?= $competencyCount ?></p>
                      <p class="text-xs text-gray-500">Total Records</p>
                    </div>
                    <div class="text-gray-400 group-hover:text-indigo-600 transition-colors">
                      <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </div>
                  </div>
                </div>
              </div>
            </a>

            <!-- Learning -->
            <a href="learning/learning.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover-lift fade-in group" style="animation-delay: 0.3s">
              <div class="relative">
                <div class="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-gradient-to-br from-blue-100 to-cyan-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-md">
                      <i data-lucide="book-open" class="w-6 h-6 text-white"></i>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-medium px-2 py-1 rounded-full bg-blue-50 text-blue-700">Module</span>
                    </div>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-800 mb-2">Learning</h4>
                  <p class="text-sm text-gray-600 mb-4">Access learning materials and courses</p>
                  <div class="flex items-center justify-between">
                    <div>
                      <p class="text-3xl font-bold text-blue-600"><?= $learningCount ?></p>
                      <p class="text-xs text-gray-500">Total Records</p>
                    </div>
                    <div class="text-gray-400 group-hover:text-blue-600 transition-colors">
                      <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </div>
                  </div>
                </div>
              </div>
            </a>

            <!-- Training -->
            <a href="training/traindash.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover-lift fade-in group" style="animation-delay: 0.4s">
              <div class="relative">
                <div class="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-gradient-to-br from-green-100 to-emerald-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-md">
                      <i data-lucide="briefcase" class="w-6 h-6 text-white"></i>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-medium px-2 py-1 rounded-full bg-green-50 text-green-700">Module</span>
                    </div>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-800 mb-2">Training</h4>
                  <p class="text-sm text-gray-600 mb-4">Schedule and manage training programs</p>
                  <div class="flex items-center justify-between">
                    <div>
                      <p class="text-3xl font-bold text-green-600"><?= $trainingCount ?></p>
                      <p class="text-xs text-gray-500">Total Records</p>
                    </div>
                    <div class="text-gray-400 group-hover:text-green-600 transition-colors">
                      <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </div>
                  </div>
                </div>
              </div>
            </a>

            <!-- Succession -->
            <a href="succession/succession.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover-lift fade-in group" style="animation-delay: 0.5s">
              <div class="relative">
                <div class="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-gradient-to-br from-rose-100 to-pink-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center shadow-md">
                      <i data-lucide="users" class="w-6 h-6 text-white"></i>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-medium px-2 py-1 rounded-full bg-rose-50 text-rose-700">Module</span>
                    </div>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-800 mb-2">Succession</h4>
                  <p class="text-sm text-gray-600 mb-4">Plan for leadership and role transitions</p>
                  <div class="flex items-center justify-between">
                    <div>
                      <p class="text-3xl font-bold text-rose-600"><?= $successionCount ?></p>
                      <p class="text-xs text-gray-500">Total Records</p>
                    </div>
                    <div class="text-gray-400 group-hover:text-rose-600 transition-colors">
                      <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </div>
                  </div>
                </div>
              </div>
            </a>

            <!-- ESS -->
            <a href="ess/ess_admin.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover-lift fade-in group" style="animation-delay: 0.6s">
              <div class="relative">
                <div class="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-gradient-to-br from-amber-100 to-yellow-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center shadow-md">
                      <i data-lucide="user" class="w-6 h-6 text-white"></i>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-medium px-2 py-1 rounded-full bg-amber-50 text-amber-700">Module</span>
                    </div>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-800 mb-2">ESS</h4>
                  <p class="text-sm text-gray-600 mb-4">Employee Self-Service portal</p>
                  <div class="flex items-center justify-between">
                    <div>
                      <p class="text-3xl font-bold text-amber-600"><?= $essCount ?></p>
                      <p class="text-xs text-gray-500">Total Records</p>
                    </div>
                    <div class="text-gray-400 group-hover:text-amber-600 transition-colors">
                      <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>

        <!-- Quick Actions & Recent Activity -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div class="lg:col-span-2">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                <span class="text-xs text-gray-500 px-3 py-1 bg-gray-100 rounded-full">Most Used</span>
              </div>
              <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                
                
                <button class="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 hover:from-blue-100 hover:to-cyan-100 rounded-xl border border-blue-100 transition-all duration-200 group">
                  <div class="flex flex-col items-center text-center">
                    <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                      <i data-lucide="file-text" class="w-5 h-5 text-white"></i>
                    </div>
                    <span class="text-sm font-medium text-gray-700">Generate Report</span>
                  </div>
                </button>
                
               
                
             
              </div>
            </div>
          </div>
          
          <div class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl shadow-lg p-6 text-white">
            <h3 class="text-lg font-semibold mb-6">System Status</h3>
            <div class="space-y-4">
              <div class="flex items-center justify-between">
                <span class="text-sm text-gray-300">Database</span>
                <span class="flex items-center text-sm text-green-400">
                  <span class="w-2 h-2 rounded-full bg-green-500 mr-1.5"></span>
                  Connected
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-sm text-gray-300">API Services</span>
                <span class="flex items-center text-sm text-green-400">
                  <span class="w-2 h-2 rounded-full bg-green-500 mr-1.5"></span>
                  Operational
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-sm text-gray-300">Security</span>
                <span class="flex items-center text-sm text-green-400">
                  <span class="w-2 h-2 rounded-full bg-green-500 mr-1.5"></span>
                  Active
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-sm text-gray-300">Session</span>
                <span class="flex items-center text-sm text-green-400">
                  <span class="w-2 h-2 rounded-full bg-green-500 mr-1.5"></span>
                  Valid
                </span>
              </div>
            </div>
            <div class="mt-8 pt-6 border-t border-gray-700">
              <div class="text-center">
                <p class="text-sm text-gray-400 mb-2">Last updated</p>
                <p class="text-lg font-medium time-update" id="status-time"><?php echo date("M j, Y g:i:s A"); ?></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <footer class="mt-8 pt-6 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>© <?php echo date('Y'); ?> HR Management System • Dashboard v2.1 • All systems operational</p>
        </footer>

      </main>
    </div>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      lucide.createIcons();
      
      // Function to format time with leading zeros
      function formatTime(date) {
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let seconds = date.getSeconds();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        hours = hours % 12;
        hours = hours ? hours : 12; // Convert 0 to 12
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;
        
        return `${hours}:${minutes}:${seconds} ${ampm}`;
      }
      
      // Function to format date
      function formatDate(date) {
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        const dayName = days[date.getDay()];
        const month = months[date.getMonth()];
        const day = date.getDate();
        
        return `${dayName}, ${month} ${day}`;
      }
      
      // Function to format date-time for status
      function formatDateTime(date) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const month = months[date.getMonth()];
        const day = date.getDate();
        const year = date.getFullYear();
        
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let seconds = date.getSeconds();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;
        
        return `${month} ${day}, ${year} ${hours}:${minutes}:${seconds} ${ampm}`;
      }
      
      // Function to update all time displays
      function updateAllTimes() {
        const now = new Date();
        
        // Update header time with animation
        const headerTime = document.getElementById('header-time');
        if (headerTime) {
          headerTime.classList.add('updating');
          setTimeout(() => {
            headerTime.textContent = formatTime(now);
            headerTime.classList.remove('updating');
          }, 150);
        }
        
        // Update current date
        const currentDate = document.getElementById('current-date');
        if (currentDate) {
          currentDate.textContent = formatDate(now);
        }
        
        // Update status time with animation
        const statusTime = document.getElementById('status-time');
        if (statusTime) {
          statusTime.classList.add('updating');
          setTimeout(() => {
            statusTime.textContent = formatDateTime(now);
            statusTime.classList.remove('updating');
          }, 150);
        }
      }
      
      // Initialize time
      updateAllTimes();
      
      // Update time every second
      setInterval(updateAllTimes, 1000);
      
      // Add hover effects to cards
      document.querySelectorAll('.hover-lift').forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.style.zIndex = '10';
        });
        
        card.addEventListener('mouseleave', function() {
          this.style.zIndex = '1';
        });
      });
      
      // Optional: Display timezone information
      const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      console.log('Dashboard initialized. Time zone:', timeZone);
    });
  </script>
</body>
</html>

<?php
// ─── Close DB Connections ───
if (isset($connCompetency) && $connCompetency instanceof mysqli) { $connCompetency->close(); }
if (isset($connRestApi) && $connRestApi instanceof mysqli) { $connRestApi->close(); }
?>