<?php
include('../dblogin.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    // ✅ Fetch data from HR1 API
    $apiUrl = "https://hr1.atierahotelandrestaurant.com/api/onboarding_api.php";
    $json = file_get_contents($apiUrl);
    if (!$json) {
        throw new Exception("Failed to fetch data from HR1 API");
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        throw new Exception("Invalid JSON format from HR1 API");
    }

    // ✅ Prepare insert query
    $stmt = $conn->prepare("
        INSERT INTO onboarding_competencies (onboarding_id, applicant_id, name, department)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            name = VALUES(name),
            department = VALUES(department)
    ");

    $inserted = 0;
    foreach ($data as $item) {
        $onboarding_id = $item['onboarding_id'] ?? 0;
        $applicant_id = $item['applicant_id'] ?? 0;
        $name = $item['name'] ?? 'Unknown';
        $department = $item['department'] ?? null;

        if ($onboarding_id && $applicant_id) {
            $stmt->bind_param("iiss", $onboarding_id, $applicant_id, $name, $department);
            $stmt->execute();
            $inserted++;
        }
    }

    echo json_encode([
        "status" => "success",
        "message" => "Synced $inserted onboarding records from HR1."
    ]);

} catch (Exception $e) {
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}
