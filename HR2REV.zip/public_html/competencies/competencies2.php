<?php
include('../session_check.php'); 
include('../dblogin.php'); // your DB connection

error_reporting(E_ALL);
ini_set('display_errors', 1);

$currentPage = basename($_SERVER['PHP_SELF']);
$currentUri = $_SERVER['REQUEST_URI'];

// ✅ Fetch employees from onboarding_competencies table
$employees = [];
$positions = []; // instead of departments

$result = $conn->query("SELECT onboarding_id, applicant_id, name AS employee_name, department AS position, created_at
                        FROM onboarding_competencies 
                        ORDER BY name ASC");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
        if ($row['position'] && !in_array($row['position'], $positions)) {
            $positions[] = $row['position'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Competency Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">

<div class="flex h-full">

  <!-- Sidebar -->
  <?php include '../sidebar.php'; ?>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-4 max-w-7xl mx-auto">

      <!-- Header -->
      <div class="flex items-center justify-between border-b pb-4">
        <div>
          <h1 class="text-2xl font-semibold">Admin Competency Management</h1>
          <p class="text-slate-500 text-sm">Manage competencies and move employees to Learning phase</p>
        </div>

        <!-- Shared Profile -->
        <?php include __DIR__ . '/../profile.php'; ?>
      </div>

      <!-- Submodules Header -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
        <a href="/competencies/competencies.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Competencies</a>
        <a href="/competencies/gap_analysis.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Gap Analysis</a>
      </div>

      <!-- Main Grid -->
      <div class="grid grid-cols-9 gap-6 mt-6">

        <!-- Sidebar: Employee List -->
        <aside class="col-span-3 bg-white rounded-lg p-4 shadow-sm">
          <h2 class="font-medium mb-3">Employees</h2>
          <input id="searchInput" class="w-full mb-3 px-3 py-2 border rounded text-sm" placeholder="Search employees..." />
          <select id="positionFilter" class="w-full mb-3 px-3 py-2 border rounded text-sm">
            <option value="">All Positions</option>
            <?php foreach ($positions as $pos): ?>
                <option value="<?= htmlspecialchars($pos) ?>"><?= htmlspecialchars($pos) ?></option>
            <?php endforeach; ?>
          </select>
          <ul id="employeeList" class="space-y-2 max-h-96 overflow-y-auto">
            <?php if(count($employees) > 0): ?>
                <?php foreach($employees as $emp): ?>
                    <li class="p-3 rounded-md cursor-pointer hover:bg-slate-100 flex items-center justify-between border"
                        data-position="<?= htmlspecialchars($emp['position']) ?>"
                        data-onboarding-id="<?= $emp['onboarding_id'] ?>"
                        data-applicant-id="<?= $emp['applicant_id'] ?>"
                        data-name="<?= htmlspecialchars($emp['employee_name']) ?>"
                        data-created-at="<?= $emp['created_at'] ?>">
                        <div>
                            <div class="font-medium"><?= htmlspecialchars($emp['employee_name']) ?></div>
                            <div class="text-xs text-slate-500">Position: <?= htmlspecialchars($emp['position']) ?: 'N/A' ?></div>
                        </div>
                        <span class="text-xs text-gray-400">#<?= $emp['onboarding_id'] ?></span>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class='text-gray-400 text-sm text-center py-3'>No employees found.</li>
            <?php endif; ?>
          </ul>
        </aside>

        <!-- Main Profile & Competencies -->
        <section class="col-span-6 bg-white rounded-lg p-6 shadow-sm">
          <div id="employeeProfile" class="hidden">
            <div class="flex items-start justify-between">
              <div>
                <h3 id="empName" class="text-lg font-semibold"></h3>
                <p id="empPosition" class="text-sm text-slate-500"></p>
              </div>
              <div class="flex gap-2">
                <button onclick="proceedToLearning()" class="px-3 py-1 border rounded bg-green-600 text-white hover:bg-green-700 transition">
                  Proceed
                </button>
              </div>
            </div>

            <hr class="my-4" />

            <!-- Competency Table -->
            <div>
              <h4 class="font-medium mb-3">Assigned Competencies</h4>
              <div class="overflow-x-auto">
                <table class="table-fixed w-full border text-sm">
                  <thead class="bg-slate-50">
                    <tr class="text-slate-500">
                      <th class="w-3/12 py-2 px-2 text-left">Employee ID</th>
                      <th class="w-3/12 py-2 px-2 text-left">Position</th>
                      <th class="w-3/12 py-2 px-2 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody id="competencyTable"></tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  </div>
</div>

<script>
const employeeList = document.getElementById("employeeList");
const empName = document.getElementById("empName");
const empPosition = document.getElementById("empPosition");
const competencyTable = document.getElementById("competencyTable");
const employeeProfile = document.getElementById("employeeProfile");
const positionFilter = document.getElementById("positionFilter");

let currentEmployee = null;

// ✅ Show employee profile and populate Assigned Competencies
employeeList.querySelectorAll("li").forEach(li => {
    li.addEventListener("click", () => {
        currentEmployee = {
            onboarding_id: li.dataset.onboardingId,
            applicant_id: li.dataset.applicantId, // <-- employee ID
            name: li.dataset.name,
            position: li.dataset.position,
            created_at: li.dataset.createdAt
        };
        empName.textContent = currentEmployee.name;
        empPosition.textContent = currentEmployee.position || "No position assigned";

        // ✅ Populate table with Applicant ID instead of name
        competencyTable.innerHTML = `
            <tr class="border-t hover:bg-slate-50">
                <td class="p-2">${currentEmployee.applicant_id}</td>
                <td class="p-2">${currentEmployee.position || 'N/A'}</td>
                <td class="p-2 text-center">Assigned</td>
            </tr>
        `;

        employeeProfile.classList.remove("hidden");
    });
});

// ✅ Filter by position
positionFilter.addEventListener("change", () => {
    const filter = positionFilter.value;
    employeeList.querySelectorAll("li").forEach(li => {
        li.style.display = (filter && li.dataset.position !== filter) ? "none" : "flex";
    });
});

// ✅ Proceed to Learning
async function proceedToLearning() {
    if (!currentEmployee) {
        alert("Please select an employee first.");
        return;
    }

    const confirmProceed = confirm(`Proceed onboarding for ${currentEmployee.name} to Learning?`);
    if (!confirmProceed) return;

    try {
        const response = await fetch("/competencies/proceed_to_learning.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(currentEmployee)
        });

        const result = await response.json();
        if (result.status === "success") {
            alert(result.message);
            const li = employeeList.querySelector(`li[data-onboarding-id="${currentEmployee.onboarding_id}"]`);
            if(li) li.remove();
            employeeProfile.classList.add("hidden");
        } else {
            alert("Error: " + result.message);
        }
    } catch (err) {
        console.error("Error proceeding:", err);
        alert("Failed to proceed employee.");
    }
}
</script>
</body>
</html>
