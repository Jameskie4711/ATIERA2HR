<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if(empty($data['competency_id']) || empty($data['employee_id'])){
    echo json_encode(['success'=>false, 'message'=>'Missing required data.']);
    exit;
}

$competency_id = intval($data['competency_id']);
$employee_id = intval($data['employee_id']); // now using employee_id
$required_level = intval($data['required_level'] ?? 3);
$current_level = intval($data['current_level'] ?? 1);

try {
    // 1️⃣ Fetch the onboarding_competencies record
    $stmt = $conn->prepare("SELECT * FROM onboarding_competencies WHERE competency_id=? LIMIT 1");
    $stmt->bind_param("i", $competency_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows === 0){
        echo json_encode(['success'=>false, 'message'=>'Competency not found.']);
        exit;
    }
    $row = $result->fetch_assoc();

    // 2️⃣ Insert into learning_emp
    $insert = $conn->prepare("
        INSERT INTO learning_emp 
        (employee_id, applicant_id, competency_id, employee_name, department, position, role, competency_gap, required_level, current_level, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $applicant_id = $row['applicant_id'];  // keep original applicant_id
    $employee_name = $row['name'];
    $department = $row['department'] ?? '';
    $position = ''; // optional
    $role = ''; // optional
    $competency_gap = $required_level - $current_level;
    $status = $row['status'] ?? 'Pending';

    $insert->bind_param(
        "iiissssiiis",
        $employee_id,
        $applicant_id,
        $competency_id,
        $employee_name,
        $department,
        $position,
        $role,
        $competency_gap,
        $required_level,
        $current_level,
        $status
    );
    $insert->execute();

    if($insert->affected_rows === 0){
        echo json_encode(['success'=>false, 'message'=>'Failed to insert into learning_emp.']);
        exit;
    }

    // 3️⃣ Delete from onboarding_competencies
    $del = $conn->prepare("DELETE FROM onboarding_competencies WHERE competency_id=?");
    $del->bind_param("i", $competency_id);
    $del->execute();

    echo json_encode(['success'=>true]);

} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
?>
