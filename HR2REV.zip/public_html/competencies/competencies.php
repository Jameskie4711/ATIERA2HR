<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Competencies</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" type="image/png" href="/web/picture/logo2.png" />
<!-- Add SheetJS for Excel export -->
<script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
<!-- Add Chart.js for graphs -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- Add html2canvas for converting charts to images -->
<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<!-- Add jsPDF for PDF generation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .gradient-bg {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  .sidebar-gradient {
    background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    transition: all 0.3s ease;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
  }
  
  .btn-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
  }
  
  .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  
  .btn-warning {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    transition: all 0.3s ease;
  }
  
  .btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(245, 158, 11, 0.3);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .avatar-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateX(5px);
    border-left-color: #3b82f6;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  }
  
  .status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
  }
  
  /* Keep original tab styling */
  .tab-active {
    background: rgba(59, 130, 246, 0.1);
    border-bottom: 3px solid #3b82f6;
    color: #3b82f6 !important;
  }
  
  /* Gap Analysis Colors */
  .gap-high { background-color: #fef2f2; color: #dc2626; }
  .gap-medium { background-color: #fffbeb; color: #d97706; }
  .gap-low { background-color: #f0fdf4; color: #16a34a; }
  
  /* Chart styling */
  .chart-container {
    position: relative;
    margin: auto;
  }
  
  .chart-legend {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 10px;
  }
  
  .legend-item {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #666;
  }
  
  .legend-color {
    width: 12px;
    height: 12px;
    border-radius: 2px;
  }
  
  /* Progress bar for gap visualization */
  .gap-progress {
    height: 6px;
    background-color: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
  }
  
  .gap-progress-high {
    background: linear-gradient(90deg, #fca5a5, #dc2626);
  }
  
  .gap-progress-medium {
    background: linear-gradient(90deg, #fcd34d, #d97706);
  }
  
  .gap-progress-low {
    background: linear-gradient(90deg, #86efac, #16a34a);
  }
  
  /* FIXED SCROLLING STYLES */
  #employeeList {
    -webkit-overflow-scrolling: touch;
    scroll-behavior: smooth;
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
  }
  
  #employeeList li {
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    touch-action: manipulation;
    transition: all 0.2s ease;
  }
  
  #employeeList li.active-employee {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%) !important;
    border-color: #93c5fd !important;
    border-left-width: 4px !important;
    border-left-color: #3b82f6 !important;
    transform: translateX(2px);
  }
  
  #employeeList li:not(.active-employee):hover {
    background-color: #f8fafc;
    border-color: #e2e8f0;
  }
  
  #employeeList li:active {
    transform: scale(0.98);
    transition: transform 0.1s ease;
  }
  
  #employeeList li:focus {
    outline: 2px solid #3b82f6;
    outline-offset: 2px;
  }
  
  /* Prevent text selection */
  .prevent-select {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }
  
  /* Mobile optimizations */
  @media (max-width: 768px) {
    #employeeList li {
      padding: 12px;
      min-height: 64px;
    }
  }
  
  /* ===== EMPLOYEE PROFILE SCROLLING FIXES ===== */
  .grid.grid-cols-9 {
    height: calc(100vh - 180px);
  }
  
  section.col-span-6 {
    position: relative;
    display: flex;
    flex-direction: column;
    height: 100%;
  }
  
  #employeeProfile {
    flex: 1;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f1f5f9;
    padding-right: 8px;
  }
  
  #employeeProfile::-webkit-scrollbar {
    width: 6px;
  }
  
  #employeeProfile::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
    margin-top: 5px;
    margin-bottom: 5px;
  }
  
  #employeeProfile::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  #employeeProfile::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  /* Fix gap details table scrolling */
  #gapDetails {
    max-height: 300px;
    overflow-y: auto;
  }
  
  #gapDetails table {
    min-width: 100%;
  }
  
  /* Keep action buttons visible when scrolling */
  #employeeProfile > div:first-child {
    position: sticky;
    top: 0;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(8px);
    z-index: 20;
    padding-bottom: 1rem;
    margin-bottom: 0.5rem;
    border-bottom: 1px solid #f1f5f9;
  }
  
  /* Adjust chart containers for better scrolling */
  .chart-container {
    max-height: 200px;
    position: relative;
  }
  
  /* Make sure tables don't overflow */
  .glass-card.rounded-xl.border.border-gray-200.overflow-hidden {
    overflow: visible;
  }
  
  /* Fix for the gap analysis preview container */
  #gapAnalysisPreview {
    position: relative;
  }
  
  /* Fix button alignment in employee profile header */
  #employeeProfile > div:first-child {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
  }
  
  #employeeProfile > div:first-child > div:first-child {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  #actionButtons {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    flex-shrink: 0;
  }
  
  /* Compact button styling */
  .compact-btn {
    padding: 0.375rem 0.875rem !important;
    font-size: 0.8125rem !important;
    border-radius: 0.5rem !important;
    height: fit-content;
  }
  
  /* Ensure proper alignment on smaller screens */
  @media (max-width: 1024px) {
    .grid.grid-cols-9 {
      height: calc(100vh - 200px);
    }
    
    #employeeProfile {
      padding-right: 4px;
    }
    
    #employeeProfile > div:first-child {
      flex-direction: column;
      align-items: flex-start;
      gap: 1rem;
    }
    
    #actionButtons {
      width: 100%;
      justify-content: flex-start;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
  }
  
  @media (max-width: 768px) {
    #employeeProfile > div:first-child {
      flex-direction: column;
      align-items: stretch;
    }
    
    #employeeProfile > div:first-child > div:first-child {
      flex-direction: column;
      align-items: flex-start;
      gap: 0.75rem;
    }
    
    #actionButtons {
      flex-direction: row;
      width: 100%;
      justify-content: space-between;
    }
    
    #actionButtons button {
      flex: 1;
      min-width: 0;
      padding: 0.375rem 0.5rem !important;
      font-size: 0.75rem !important;
    }
    
    #actionButtons button span {
      display: none;
    }
    
    #actionButtons button i {
      margin: 0 !important;
    }
  }
  
  @media (max-width: 480px) {
    #actionButtons {
      gap: 0.25rem;
    }
    
    #actionButtons button {
      padding: 0.375rem !important;
      font-size: 0.75rem !important;
    }
    
    #actionButtons button i {
      width: 14px !important;
      height: 14px !important;
    }
  }
  
  /* Toast notification styling */
  .toast-notification {
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }
  
  /* Hidden chart containers for export */
  .export-chart {
    position: fixed;
    top: -9999px;
    left: -9999px;
    width: 800px;
    height: 400px;
    background: white;
    padding: 20px;
  }
</style>
<script>
document.addEventListener("DOMContentLoaded", function () {
    lucide.createIcons();
});
</script>

<script>
const HR1_BASE_URL = "https://hr1.atierahotelandrestaurant.com/";
</script>

</head>
<body class="h-screen overflow-hidden">

<div class="flex h-full">
  <?php include '../sidebar.php'; ?>

  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6 max-w-7xl mx-auto w-full">

      <!-- Enhanced Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50">
            <i data-lucide="award" class="w-7 h-7 text-blue-600"></i>
          </div>
          <div>
            <h2 class="text-2xl font-bold text-gray-900">Competency Management</h2>
            <p class="text-sm text-gray-500">Review and assign competencies to applicants</p>
          </div>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- RESTORE ORIGINAL TOP TABS -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
        <a href="/competencies/competencies.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
          <i data-lucide="list-check" class="w-4 h-4"></i> Competencies
        </a>
        <a href="/competencies/gap_analysis.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
          <i data-lucide="clipboard" class="w-4 h-4"></i> Criteria
        </a>
        <a href="/competencies/record.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
          <i data-lucide="file-text" class="w-4 h-4"></i> Record
        </a>
      </div>

      <!-- Main Grid -->
      <div class="grid grid-cols-9 gap-6 mt-2">

        <!-- Modern Sidebar -->
        <aside class="col-span-3 glass-card rounded-2xl p-6 shadow-lg border border-gray-100">
          <div class="mb-6">
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-lg font-semibold text-gray-900">Applicants</h3>
              <div class="flex items-center gap-2">
                <span id="applicantCount" class="bg-blue-100 text-blue-700 text-xs font-medium px-3 py-1 rounded-full">0</span>
                <div class="dropdown">
                  <button class="btn-warning px-3 py-1.5 rounded-xl text-white font-medium flex items-center gap-2 shadow-sm text-xs compact-btn dropdown-toggle" type="button" id="exportDropdown" data-toggle="dropdown">
                    <i data-lucide="download" class="w-3 h-3"></i> Export All
                  </button>
                  <div class="dropdown-menu" aria-labelledby="exportDropdown">
                    <a class="dropdown-item" href="#" onclick="generateAllReports('excel')">Export to Excel</a>
                    <a class="dropdown-item" href="#" onclick="generateAllReports('pdf')">Export to PDF</a>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="bg-gradient-to-r from-blue-50 to-indigo-50 p-3 rounded-xl mb-4">
              <div class="flex items-center gap-2 mb-2">
                <div class="p-2 bg-white rounded-lg shadow-sm">
                  <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Available for competency assignment</p>
                  <p class="text-xs text-gray-500">Click "Export All" to download gap analysis for all applicants</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Search and Filter -->
          <div class="space-y-4 mb-6">
            <div class="relative">
              <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <input id="searchInput" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Search by name or ID..." />
            </div>
            
            <div class="relative">
              <i data-lucide="filter" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
              <select id="positionFilter" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">All Positions</option>
              </select>
              <i data-lucide="chevron-down" class="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none"></i>
            </div>
          </div>

          <!-- Applicant List -->
          <div class="mb-4">
            <h4 class="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
              <i data-lucide="user-check" class="w-4 h-4"></i> Select Applicant
            </h4>
            <ul id="employeeList" class="space-y-3 max-h-[400px] overflow-y-auto scrollbar-thin pr-2">
              <li class="text-gray-400 text-sm text-center py-6">
                <div class="animate-pulse space-y-3">
                  <div class="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
                  <div class="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                </div>
              </li>
            </ul>
          </div>
          
          <div class="text-xs text-gray-500 text-center pt-4 border-t border-gray-100">
            <i data-lucide="info" class="w-3 h-3 inline mr-1"></i>
            Click on an applicant to view details and generate gap analysis report
          </div>
        </aside>

        <!-- Employee Profile Card -->
        <section class="col-span-6 glass-card rounded-2xl p-6 shadow-lg border border-gray-100">
          <div id="noDataNote" class="text-center py-12">
            <div class="mx-auto w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center mb-6">
              <i data-lucide="user" class="w-12 h-12 text-gray-400"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-700 mb-2">No Applicant Selected</h3>
            <p class="text-gray-500 max-w-md mx-auto">Please select an applicant from the list to view their profile and assign competencies.</p>
          </div>

          <div id="employeeProfile" class="hidden">
            <!-- Profile Header - COMPACT BUTTONS -->
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
              <div class="flex items-center gap-4">
                <div class="avatar-gradient p-3 rounded-xl shadow-md flex-shrink-0">
                  <i data-lucide="user" class="w-7 h-7 text-white"></i>
                </div>
                <div class="min-w-0">
                  <h3 id="empName" class="text-xl font-bold text-gray-900 mb-1 truncate"></h3>
                  <div class="flex flex-wrap items-center gap-2">
                    <span id="empId" class="text-sm font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-full truncate"></span>
                    <span id="empPosition" class="text-sm font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full truncate"></span>
                  </div>
                </div>
              </div>
              
              <div class="flex flex-wrap items-center gap-2" id="actionButtons">
                <button onclick="viewResume()" class="btn-primary px-3 py-1.5 rounded-lg text-white font-medium flex items-center gap-1.5 shadow-sm text-sm hover:scale-[1.02] transition-all duration-200">
                  <i data-lucide="file-text" class="w-3.5 h-3.5"></i>
                  <span class="whitespace-nowrap">View Resume</span>
                </button>
                <div class="dropdown">
                  <button class="btn-warning px-3 py-1.5 rounded-lg text-white font-medium flex items-center gap-1.5 shadow-sm text-sm hover:scale-[1.02] transition-all duration-200 dropdown-toggle" type="button" id="reportDropdown" data-toggle="dropdown">
                    <i data-lucide="file-spreadsheet" class="w-3.5 h-3.5"></i>
                    <span class="whitespace-nowrap">Generate Report</span>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="reportDropdown">
                    <a class="dropdown-item" href="#" onclick="generateGapReport('excel')">Export to Excel</a>
                    <a class="dropdown-item" href="#" onclick="generateGapReport('pdf')">Export to PDF</a>
                  </div>
                </div>
                <button onclick="proceedToCriteria()" class="btn-success px-3 py-1.5 rounded-lg text-white font-medium flex items-center gap-1.5 shadow-sm text-sm hover:scale-[1.02] transition-all duration-200">
                  <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                  <span class="whitespace-nowrap">Proceed</span>
                </button>
              </div>
            </div>

            <div class="border-t border-gray-100 pt-6">
              <div class="flex items-center gap-3 mb-6">
                <div class="p-2 bg-indigo-50 rounded-lg">
                  <i data-lucide="award" class="w-5 h-5 text-indigo-600"></i>
                </div>
                <h4 class="text-lg font-semibold text-gray-900">Competency Information</h4>
              </div>
              
              <div class="overflow-hidden rounded-xl border border-gray-200 shadow-sm">
                <table class="w-full">
                  <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                    <tr>
                      <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Employee ID</th>
                      <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Position</th>
                      <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                    </tr>
                  </thead>
                  <tbody id="competencyTable" class="divide-y divide-gray-100"></tbody>
                </table>
              </div>
              
              <!-- Gap Analysis Preview with Graphs -->
              <div id="gapAnalysisPreview" class="mt-6 hidden">
                <div class="flex items-center gap-3 mb-4">
                  <div class="p-2 bg-amber-50 rounded-lg">
                    <i data-lucide="bar-chart-3" class="w-5 h-5 text-amber-600"></i>
                  </div>
                  <h4 class="text-lg font-semibold text-gray-900">Gap Analysis Preview</h4>
                </div>
                
                <!-- Summary Cards -->
                <div class="grid grid-cols-3 gap-4 mb-6">
                  <div class="bg-gradient-to-r from-red-50 to-pink-50 p-4 rounded-xl border border-red-100">
                    <div class="text-sm font-medium text-gray-700 mb-1">High Gaps</div>
                    <div id="highGaps" class="text-2xl font-bold text-red-600">0</div>
                    <div class="text-xs text-gray-500 mt-1">Need urgent development</div>
                  </div>
                  <div class="bg-gradient-to-r from-amber-50 to-yellow-50 p-4 rounded-xl border border-amber-100">
                    <div class="text-sm font-medium text-gray-700 mb-1">Medium Gaps</div>
                    <div id="mediumGaps" class="text-2xl font-bold text-amber-600">0</div>
                    <div class="text-xs text-gray-500 mt-1">Moderate improvement needed</div>
                  </div>
                  <div class="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-100">
                    <div class="text-sm font-medium text-gray-700 mb-1">Low Gaps</div>
                    <div id="lowGaps" class="text-2xl font-bold text-green-600">0</div>
                    <div class="text-xs text-gray-500 mt-1">Minor improvement needed</div>
                  </div>
                </div>
                
                <!-- Graph Container -->
                <div class="grid grid-cols-2 gap-6 mb-6">
                  <!-- Gap Distribution Chart -->
                  <div class="glass-card p-6 rounded-xl border border-gray-200">
                    <div class="flex items-center justify-between mb-4">
                      <h5 class="font-medium text-gray-900">Gap Distribution</h5>
                      <div class="flex items-center gap-2">
                        <div class="flex items-center gap-1">
                          <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span class="text-xs text-gray-600">High</span>
                        </div>
                        <div class="flex items-center gap-1">
                          <div class="w-3 h-3 bg-amber-500 rounded-full"></div>
                          <span class="text-xs text-gray-600">Medium</span>
                        </div>
                        <div class="flex items-center gap-1">
                          <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span class="text-xs text-gray-600">Low</span>
                        </div>
                      </div>
                    </div>
                    <div class="h-48">
                      <canvas id="gapDistributionChart" class="w-full h-full"></canvas>
                    </div>
                  </div>
                  
                  <!-- Gap Severity Chart -->
                  <div class="glass-card p-6 rounded-xl border border-gray-200">
                    <div class="flex items-center justify-between mb-4">
                      <h5 class="font-medium text-gray-900">Gap Severity</h5>
                      <div class="text-xs text-gray-500">
                        <span id="totalCompetencies">0</span> competencies assessed
                      </div>
                    </div>
                    <div class="h-48">
                      <canvas id="gapSeverityChart" class="w-full h-full"></canvas>
                    </div>
                  </div>
                </div>
                
                <!-- Competency Gaps Radar Chart -->
                <div class="glass-card p-6 rounded-xl border border-gray-200 mb-6">
                  <div class="flex items-center justify-between mb-4">
                    <h5 class="font-medium text-gray-900">Competency Gap Analysis</h5>
                    <div class="text-xs text-gray-500">Current vs Required Levels</div>
                  </div>
                  <div class="h-64">
                    <canvas id="competencyRadarChart" class="w-full h-full"></canvas>
                  </div>
                </div>
                
                <!-- Gap Details Table -->
                <div class="glass-card rounded-xl border border-gray-200 overflow-hidden">
                  <div class="p-4 border-b border-gray-200">
                    <h5 class="font-medium text-gray-900">Detailed Competency Gaps</h5>
                  </div>
                  <div id="gapDetails" class="overflow-x-auto">
                    <!-- Gap details table will be populated here -->
                  </div>
                </div>
              </div>
              
              <div class="mt-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
                <div class="flex items-start gap-3">
                  <i data-lucide="lightbulb" class="w-5 h-5 text-blue-600 mt-0.5"></i>
                  <div>
                    <p class="text-sm font-medium text-gray-800 mb-1">Ready for Assessment</p>
                    <p class="text-xs text-gray-600">Click "Generate Report" to export gap analysis to Excel or PDF with charts or "Proceed" to continue assessment.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  </div>
</div>

<!-- Hidden container for export charts -->
<div id="exportCharts" class="export-chart"></div>

<!-- Modern Proceed Modal -->
<div id="proceedModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
  <div class="glass-card rounded-2xl w-96 p-8 shadow-2xl transform transition-all">
    <div class="text-center mb-6">
      <div class="mx-auto w-16 h-16 bg-gradient-to-br from-green-50 to-emerald-100 rounded-full flex items-center justify-center mb-4">
        <i data-lucide="shield-check" class="w-8 h-8 text-green-600"></i>
      </div>
      <h3 class="text-xl font-bold text-gray-900 mb-2">Confirm Proceed</h3>
      <p id="proceedMessage" class="text-gray-600 mb-6"></p>
    </div>
    <div class="flex justify-center gap-4">
      <button id="proceedCancelBtn" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-all duration-200 flex-1">Cancel</button>
      <button id="proceedConfirmBtn" class="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-200 flex-1 shadow-sm">Confirm & Proceed</button>
    </div>
  </div>
</div>

<!-- Modern Loading Overlay -->
<div id="loadingOverlay" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
  <div class="glass-card rounded-2xl px-8 py-6 flex flex-col items-center gap-4 shadow-2xl">
    <div class="relative">
      <div class="w-16 h-16 border-4 border-blue-100 rounded-full"></div>
      <div class="w-16 h-16 border-4 border-transparent border-t-blue-600 rounded-full animate-spin absolute top-0 left-0"></div>
    </div>
    <div class="text-center">
      <p class="font-medium text-gray-800">Processing Request</p>
      <p class="text-sm text-gray-500 mt-1">Please wait while we proceed the applicant...</p>
    </div>
  </div>
</div>

<!-- Modern Resume Modal -->
<div id="resumeModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
  <div class="glass-card rounded-2xl w-11/12 max-w-5xl h-5/6 p-6 shadow-2xl flex flex-col">
    <div class="flex justify-between items-center mb-6">
      <div>
        <h3 class="text-xl font-bold text-gray-900" id="resumeModalTitle">Resume</h3>
        <p class="text-sm text-gray-500" id="resumeSubtitle">Viewing applicant resume</p>
      </div>
      <button onclick="closeResumeModal()" class="p-2 hover:bg-gray-100 rounded-xl transition-colors">
        <i data-lucide="x" class="w-6 h-6 text-gray-500"></i>
      </button>
    </div>
    <div class="flex-1 rounded-xl overflow-hidden border border-gray-200 bg-white">
      <iframe id="resumeIframe" src="" class="w-full h-full"></iframe>
    </div>
    <div class="mt-6 flex justify-end">
      <button onclick="closeResumeModal()" class="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
        Close Viewer
      </button>
    </div>
  </div>
</div>

<script>
const employeeList = document.getElementById("employeeList");
const empName = document.getElementById("empName");
const empId = document.getElementById("empId");
const empPosition = document.getElementById("empPosition");
const competencyTable = document.getElementById("competencyTable");
const employeeProfile = document.getElementById("employeeProfile");
const noDataNote = document.getElementById("noDataNote");
const positionFilter = document.getElementById("positionFilter");
const searchInput = document.getElementById("searchInput");
const applicantCount = document.getElementById("applicantCount");
const gapAnalysisPreview = document.getElementById("gapAnalysisPreview");
const highGaps = document.getElementById("highGaps");
const mediumGaps = document.getElementById("mediumGaps");
const lowGaps = document.getElementById("lowGaps");
const gapDetails = document.getElementById("gapDetails");

let applicants = [];
let proceededIds = [];
let currentEmployee = null;
let gapAnalysisData = [];

// Chart instances
let gapDistributionChart = null;
let gapSeverityChart = null;
let competencyRadarChart = null;

// Initialize charts
function initCharts() {
  const gapDistributionCtx = document.getElementById('gapDistributionChart')?.getContext('2d');
  const gapSeverityCtx = document.getElementById('gapSeverityChart')?.getContext('2d');
  const competencyRadarCtx = document.getElementById('competencyRadarChart')?.getContext('2d');
  
  // Destroy existing charts if they exist
  if (gapDistributionChart) gapDistributionChart.destroy();
  if (gapSeverityChart) gapSeverityChart.destroy();
  if (competencyRadarChart) competencyRadarChart.destroy();
  
  if (gapDistributionCtx) {
    gapDistributionChart = new Chart(gapDistributionCtx, {
      type: 'doughnut',
      data: {
        labels: ['High Gaps', 'Medium Gaps', 'Low Gaps'],
        datasets: [{
          data: [0, 0, 0],
          backgroundColor: [
            '#dc2626', // red-600
            '#d97706', // amber-600
            '#16a34a'  // green-600
          ],
          borderWidth: 2,
          borderColor: '#ffffff',
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            titleColor: '#1f2937',
            bodyColor: '#4b5563',
            borderColor: '#e5e7eb',
            borderWidth: 1,
            padding: 12,
            boxPadding: 6,
            callbacks: {
              label: function(context) {
                const label = context.label || '';
                const value = context.raw || 0;
                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                return `${label}: ${value} gap${value !== 1 ? 's' : ''} (${percentage}%)`;
              }
            }
          }
        }
      }
    });
  }
  
  if (gapSeverityCtx) {
    gapSeverityChart = new Chart(gapSeverityCtx, {
      type: 'bar',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Current Level',
            data: [],
            backgroundColor: '#3b82f6', // blue-500
            borderColor: '#1d4ed8', // blue-700
            borderWidth: 1,
            borderRadius: 6,
            barPercentage: 0.7
          },
          {
            label: 'Required Level',
            data: [],
            backgroundColor: '#10b981', // green-500
            borderColor: '#059669', // green-700
            borderWidth: 1,
            borderRadius: 6,
            barPercentage: 0.7
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            max: 5,
            ticks: {
              stepSize: 1,
              color: '#6b7280',
              font: {
                size: 11
              }
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.05)',
              drawBorder: false
            },
            title: {
              display: true,
              text: 'Competency Level (1-5)',
              color: '#6b7280',
              font: {
                size: 12,
                weight: 'normal'
              }
            }
          },
          x: {
            grid: {
              display: false
            },
            ticks: {
              color: '#6b7280',
              font: {
                size: 11
              }
            }
          }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              boxWidth: 12,
              padding: 15,
              color: '#374151',
              font: {
                size: 12
              },
              usePointStyle: true,
              pointStyle: 'circle'
            }
          },
          tooltip: {
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            titleColor: '#1f2937',
            bodyColor: '#4b5563',
            borderColor: '#e5e7eb',
            borderWidth: 1,
            padding: 12,
            boxPadding: 6,
            callbacks: {
              label: function(context) {
                return `${context.dataset.label}: ${context.raw}/5`;
              }
            }
          }
        }
      }
    });
  }
  
  if (competencyRadarCtx) {
    competencyRadarChart = new Chart(competencyRadarCtx, {
      type: 'radar',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Current Level',
            data: [],
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderColor: '#3b82f6',
            borderWidth: 2,
            pointBackgroundColor: '#3b82f6',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 6
          },
          {
            label: 'Required Level',
            data: [],
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            borderColor: '#10b981',
            borderWidth: 2,
            pointBackgroundColor: '#10b981',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          r: {
            beginAtZero: true,
            max: 5,
            ticks: {
              stepSize: 1,
              display: true,
              color: '#6b7280',
              backdropColor: 'transparent'
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            pointLabels: {
              font: {
                size: 11
              },
              color: '#374151'
            },
            angleLines: {
              color: 'rgba(0, 0, 0, 0.05)'
            }
          }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              boxWidth: 12,
              padding: 15,
              color: '#374151',
              font: {
                size: 12
              },
              usePointStyle: true,
              pointStyle: 'circle'
            }
          },
          tooltip: {
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            titleColor: '#1f2937',
            bodyColor: '#4b5563',
            borderColor: '#e5e7eb',
            borderWidth: 1,
            padding: 12,
            boxPadding: 6,
            callbacks: {
              label: function(context) {
                return `${context.dataset.label}: ${context.raw}/5`;
              }
            }
          }
        }
      }
    });
  }
}

// Update charts with data
function updateCharts(gapData) {
  if (!gapData || !gapData.competencies || gapData.competencies.length === 0) {
    // Show empty state for charts
    if (gapDistributionChart) {
      gapDistributionChart.data.datasets[0].data = [0, 0, 0];
      gapDistributionChart.update();
    }
    
    if (gapSeverityChart) {
      gapSeverityChart.data.labels = ['No Data'];
      gapSeverityChart.data.datasets[0].data = [0];
      gapSeverityChart.data.datasets[1].data = [0];
      gapSeverityChart.update();
    }
    
    if (competencyRadarChart) {
      competencyRadarChart.data.labels = ['No Data'];
      competencyRadarChart.data.datasets[0].data = [0];
      competencyRadarChart.data.datasets[1].data = [0];
      competencyRadarChart.update();
    }
    
    document.getElementById('totalCompetencies').textContent = '0';
    return;
  }
  
  const summary = gapData.summary;
  
  // Update distribution chart
  if (gapDistributionChart) {
    gapDistributionChart.data.datasets[0].data = [
      summary.high_gap,
      summary.medium_gap,
      summary.low_gap
    ];
    gapDistributionChart.update();
  }
  
  // Update severity chart (show top 5 competencies with largest gaps)
  const topCompetencies = [...gapData.competencies]
    .sort((a, b) => b.gap - a.gap)
    .slice(0, 5);
  
  if (gapSeverityChart) {
    gapSeverityChart.data.labels = topCompetencies.map(c => 
      c.name.length > 15 ? c.name.substring(0, 12) + '...' : c.name
    );
    gapSeverityChart.data.datasets[0].data = topCompetencies.map(c => c.current_level);
    gapSeverityChart.data.datasets[1].data = topCompetencies.map(c => c.required_level);
    gapSeverityChart.update();
  }
  
  // Update radar chart (show top 6 competencies)
  const radarCompetencies = [...gapData.competencies]
    .sort((a, b) => b.gap - a.gap)
    .slice(0, Math.min(6, gapData.competencies.length));
  
  if (competencyRadarChart) {
    competencyRadarChart.data.labels = radarCompetencies.map(c => 
      c.name.length > 15 ? c.name.substring(0, 12) + '...' : c.name
    );
    competencyRadarChart.data.datasets[0].data = radarCompetencies.map(c => c.current_level);
    competencyRadarChart.data.datasets[1].data = radarCompetencies.map(c => c.required_level);
    competencyRadarChart.update();
  }
  
  // Update total competencies count
  document.getElementById('totalCompetencies').textContent = summary.total_competencies;
}

// Display gap analysis preview with graphs
function displayGapAnalysisPreview() {
    if (!gapAnalysisData || !gapAnalysisData.competencies) return;
    
    const summary = gapAnalysisData.summary;
    
    highGaps.textContent = summary.high_gap;
    mediumGaps.textContent = summary.medium_gap;
    lowGaps.textContent = summary.low_gap;
    
    // Update charts with data
    updateCharts(gapAnalysisData);
    
    // Create gap details table
    let detailsHTML = `
        <table class="w-full">
            <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Competency</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Current</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Required</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Gap</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Priority</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
    `;
    
    gapAnalysisData.competencies.forEach(comp => {
        const priorityClass = {
            "High": "gap-high",
            "Medium": "gap-medium",
            "Low": "gap-low"
        }[comp.priority] || "";
        
        // Create progress bar for visualization
        const gapPercentage = Math.min(100, (comp.gap / 4) * 100);
        
        detailsHTML += `
            <tr class="hover:bg-gray-50 transition-colors">
                <td class="py-3 px-4">
                    <div class="font-medium text-gray-900">${comp.name}</div>
                </td>
                <td class="py-3 px-4">
                    <div class="flex items-center">
                        <div class="text-center font-medium ${comp.current_level < comp.required_level ? 'text-red-600' : 'text-green-600'}">
                            ${comp.current_level}/5
                        </div>
                    </div>
                </td>
                <td class="py-3 px-4">
                    <div class="text-center font-medium text-gray-700">
                        ${comp.required_level}/5
                    </div>
                </td>
                <td class="py-3 px-4">
                    <div class="flex flex-col gap-1">
                        <div class="text-center font-bold ${comp.gap > 0 ? 'text-red-600' : 'text-green-600'}">
                            ${comp.gap}
                        </div>
                        <div class="w-20 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                            <div class="h-full ${comp.priority === 'High' ? 'bg-red-500' : comp.priority === 'Medium' ? 'bg-amber-500' : 'bg-green-500'}" 
                                 style="width: ${gapPercentage}%"></div>
                        </div>
                    </div>
                </td>
                <td class="py-3 px-4">
                    <span class="status-badge ${priorityClass}">
                        <i data-lucide="${comp.priority === 'High' ? 'alert-triangle' : comp.priority === 'Medium' ? 'alert-circle' : 'check-circle'}" class="w-3 h-3 inline mr-1"></i>
                        ${comp.priority}
                    </span>
                </td>
                <td class="py-3 px-4">
                    <span class="text-xs font-medium ${comp.gap === 0 ? 'text-green-600' : comp.gap <= 1 ? 'text-amber-600' : 'text-red-600'}">
                        ${comp.gap === 0 ? '✓ Met' : comp.gap <= 1 ? '~ Partial' : '✗ Gap'}
                    </span>
                </td>
            </tr>
        `;
    });
    
    detailsHTML += `
            </tbody>
        </table>
    `;
    
    gapDetails.innerHTML = detailsHTML;
    gapAnalysisPreview.classList.remove("hidden");
    
    // Create icons
    setTimeout(() => lucide.createIcons(), 50);
}

// Fetch proceeded APP-IDs
async function fetchProceededIds() {
    try {
        const res = await fetch("/competencies/get_learning_ids.php");
        proceededIds = await res.json();
    } catch (err) {
        console.error("Failed to fetch proceeded IDs:", err);
        proceededIds = [];
    }
}

// Update applicant count
function updateApplicantCount() {
    applicantCount.textContent = applicants.length;
}

// Render position filter
function renderPositionFilter(list){
    const positions = [...new Set(list.map(e=>e.position))].filter(Boolean);
    positionFilter.innerHTML = `<option value="">All Positions</option>`;
    positions.forEach(p=>{
        const option = document.createElement("option");
        option.value = p;
        option.textContent = p;
        positionFilter.appendChild(option);
    });
}

// Render employee list (sidebar) - FIXED SCROLLING ISSUE
function renderEmployeeList(list){
    const filterText = searchInput.value.toLowerCase();
    const filterPos = positionFilter.value;
    const filtered = list.filter(emp => 
        (!filterPos || emp.position === filterPos) &&
        (!filterText || emp.name.toLowerCase().includes(filterText) || 
         emp.employee_id.toLowerCase().includes(filterText))
    );

    employeeList.innerHTML = "";
    
    if(filtered.length === 0){
        employeeList.innerHTML = `
            <li class='text-center py-8 prevent-select'>
                <div class="mx-auto w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                    <i data-lucide="users" class="w-6 h-6 text-gray-400"></i>
                </div>
                <p class="text-gray-500 text-sm">No applicants found</p>
                <p class="text-gray-400 text-xs mt-1">Try adjusting your search or filter</p>
            </li>`;
        return;
    }

    filtered.forEach((emp, index) => {
        const li = document.createElement("li");
        li.className = "highlight-card p-4 rounded-xl cursor-pointer bg-white border border-gray-100 hover:shadow-md prevent-select";
        li.setAttribute('data-employee-id', emp.employee_id);
        li.setAttribute('data-index', index);
        li.setAttribute('tabindex', '0');
        li.setAttribute('role', 'button');
        li.setAttribute('aria-label', `Select ${emp.name}, ${emp.position}`);
        
        li.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3 min-w-0">
                    <div class="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg flex items-center justify-center">
                        <i data-lucide="user" class="w-5 h-5 text-blue-600"></i>
                    </div>
                    <div class="min-w-0 flex-1">
                        <div class="font-semibold text-gray-900 truncate">${emp.name}</div>
                        <div class="text-xs text-gray-500 truncate">${emp.position}</div>
                    </div>
                </div>
                <div class="text-right flex-shrink-0 ml-2">
                    <div class="text-xs font-medium text-gray-600">#${emp.employee_id}</div>
                    <div class="text-xs text-gray-400 mt-1 hidden sm:block">Click to view</div>
                </div>
            </div>
        `;
        
        // Click handler with proper event handling
        let clickTimer;
        
        // Handle single click
        li.addEventListener('click', function(e) {
            clearTimeout(clickTimer);
            clickTimer = setTimeout(() => {
                handleEmployeeSelection(emp, li);
            }, 150);
        }, { passive: true });
        
        // Handle double-click (optional)
        li.addEventListener('dblclick', function(e) {
            clearTimeout(clickTimer);
            e.preventDefault();
            handleEmployeeSelection(emp, li);
        }, { passive: true });
        
        // Touch handler for mobile
        li.addEventListener('touchstart', function(e) {
            // Prevent default to avoid scrolling issues
            if (e.touches.length === 1) {
                e.preventDefault();
                handleEmployeeSelection(emp, li);
            }
        }, { passive: false });
        
        // Keyboard support
        li.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleEmployeeSelection(emp, li);
            }
            
            // Keyboard navigation
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                navigateEmployeeList(e.key, index);
            }
        });
        
        // Focus styling
        li.addEventListener('focus', function() {
            this.classList.add('ring-2', 'ring-blue-500', 'ring-opacity-50');
        });
        
        li.addEventListener('blur', function() {
            this.classList.remove('ring-2', 'ring-blue-500', 'ring-opacity-50');
        });
        
        employeeList.appendChild(li);
    });
    
    // Highlight current employee if exists
    if (currentEmployee) {
        highlightSelectedEmployee(currentEmployee.employee_id);
    }
}

// Handle employee selection with proper scrolling
function handleEmployeeSelection(emp, listItem) {
    // Remove active class from all items
    document.querySelectorAll('#employeeList li').forEach(item => {
        item.classList.remove('bg-blue-50', 'border-blue-200', 'active-employee');
        item.classList.add('bg-white', 'border-gray-100');
    });
    
    // Add active class to clicked item
    listItem.classList.remove('bg-white', 'border-gray-100');
    listItem.classList.add('bg-blue-50', 'border-blue-200', 'active-employee');
    
    // Focus the item for keyboard navigation (without scrolling)
    listItem.focus({ preventScroll: true });
    
    // Show profile
    showProfile(emp);
    
    // Smooth scroll to make sure item is visible (only if needed)
    setTimeout(() => {
        const container = employeeList;
        const itemRect = listItem.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        
        // Check if item is outside visible area
        if (itemRect.top < containerRect.top || itemRect.bottom > containerRect.bottom) {
            listItem.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'start'
            });
        }
    }, 50);
}

// Highlight the selected employee
function highlightSelectedEmployee(employeeId) {
    const listItems = document.querySelectorAll('#employeeList li');
    listItems.forEach(item => {
        if (item.getAttribute('data-employee-id') === employeeId) {
            item.classList.remove('bg-white', 'border-gray-100');
            item.classList.add('bg-blue-50', 'border-blue-200', 'active-employee');
        } else {
            item.classList.remove('bg-blue-50', 'border-blue-200', 'active-employee');
            item.classList.add('bg-white', 'border-gray-100');
        }
    });
}

// Keyboard navigation function
function navigateEmployeeList(key, currentIndex) {
    const employeeItems = Array.from(document.querySelectorAll('#employeeList li'));
    if (employeeItems.length === 0) return;
    
    let newIndex = currentIndex;
    
    if (key === 'ArrowDown') {
        newIndex = currentIndex < employeeItems.length - 1 ? currentIndex + 1 : 0;
    } else if (key === 'ArrowUp') {
        newIndex = currentIndex > 0 ? currentIndex - 1 : employeeItems.length - 1;
    }
    
    const selectedItem = employeeItems[newIndex];
    const employeeId = selectedItem.getAttribute('data-employee-id');
    const employee = applicants.find(emp => emp.employee_id === employeeId);
    
    if (employee) {
        handleEmployeeSelection(employee, selectedItem);
    }
}

// Show employee profile
async function showProfile(emp){
    currentEmployee = emp;
    noDataNote.classList.add("hidden");
    empName.textContent = emp.name;
    empId.textContent = `ID: ${emp.employee_id}`;
    empPosition.textContent = emp.position;

    // Assigned competencies table
    competencyTable.innerHTML = `
        <tr class="hover:bg-gray-50 transition-colors">
            <td class="py-3 px-4">
                <div class="flex items-center gap-2">
                    <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span class="font-medium">${emp.employee_id}</span>
                </div>
            </td>
            <td class="py-3 px-4">
                <div class="flex items-center gap-2">
                    <i data-lucide="briefcase" class="w-4 h-4 text-gray-400"></i>
                    <span>${emp.position}</span>
                </div>
            </td>
            <td class="py-3 px-4">
                <span class="status-badge bg-green-100 text-green-800">
                    <i data-lucide="check-circle" class="w-3 h-3 inline mr-1"></i>
                    Ready for Assessment
                </span>
            </td>
        </tr>
    `;
    document.getElementById("actionButtons").classList.remove("hidden");
    employeeProfile.classList.remove("hidden");
    
    // Highlight the selected employee in the list
    highlightSelectedEmployee(emp.employee_id);
    
    // Load gap analysis data
    await fetchGapAnalysis(emp);
}

// Fetch gap analysis data from server
async function fetchGapAnalysis(emp) {
    try {
        // Initialize charts if not already done
        initCharts();
        
        // Fetch actual gap analysis data
        const response = await fetch(`/competencies/get_gap_analysis.php?employee_id=${emp.employee_id}&position=${encodeURIComponent(emp.position)}&name=${encodeURIComponent(emp.name)}`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch gap analysis');
        }
        
        gapAnalysisData = await response.json();
        displayGapAnalysisPreview();
    } catch (err) {
        console.error("Failed to fetch gap analysis:", err);
        // Fallback to empty data
        gapAnalysisData = {
            employee_id: emp.employee_id,
            employee_name: emp.name,
            position: emp.position,
            assessment_date: new Date().toISOString().split('T')[0],
            competencies: [],
            summary: {
                total_competencies: 0,
                high_gap: 0,
                medium_gap: 0,
                low_gap: 0,
                overall_gap_score: 0
            }
        };
        displayGapAnalysisPreview();
    }
}

// Helper function to get recommendation
function getRecommendation(competency) {
    if (competency.gap === 0) {
        return "✓ Competency met - maintain current level";
    } else if (competency.gap === 1) {
        return "● Minor training - workshops or mentoring";
    } else if (competency.gap === 2) {
        return "▲ Significant development - formal training";
    } else if (competency.gap >= 3) {
        return "⚠ Major gap - intensive training required";
    }
    return "Review required";
}

// Helper function to get overall status
function getOverallStatus(summary) {
    if (summary.high_gap === 0 && summary.medium_gap === 0) return "Excellent";
    if (summary.high_gap === 0 && summary.medium_gap <= 2) return "Good";
    if (summary.high_gap <= 1 && summary.medium_gap <= 3) return "Fair";
    if (summary.high_gap <= 2) return "Needs Improvement";
    return "Critical";
}

// Create export charts
async function createExportCharts() {
    const exportChartsDiv = document.getElementById('exportCharts');
    exportChartsDiv.innerHTML = '';
    
    // Create charts for export
    const chartsHTML = `
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div style="text-align: center; margin-bottom: 10px;">
                <h2 style="font-size: 18px; font-weight: bold;">Gap Analysis Charts</h2>
                <p style="font-size: 12px; color: #666;">${currentEmployee.name} - ${currentEmployee.position}</p>
            </div>
            
            <div style="display: flex; gap: 20px;">
                <div style="flex: 1; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                    <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">Gap Distribution</h3>
                    <canvas id="exportGapDistributionChart" width="400" height="300"></canvas>
                </div>
                
                <div style="flex: 1; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                    <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">Top 5 Competencies</h3>
                    <canvas id="exportGapSeverityChart" width="400" height="300"></canvas>
                </div>
            </div>
            
            <div style="border: 1px solid #ddd; padding: 10px; border-radius: 5px; margin-top: 10px;">
                <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">Competency Radar Chart</h3>
                <canvas id="exportCompetencyRadarChart" width="800" height="400"></canvas>
            </div>
        </div>
    `;
    
    exportChartsDiv.innerHTML = chartsHTML;
    
    // Create the charts
    const gapDistributionCtx = document.getElementById('exportGapDistributionChart').getContext('2d');
    const gapSeverityCtx = document.getElementById('exportGapSeverityChart').getContext('2d');
    const competencyRadarCtx = document.getElementById('exportCompetencyRadarChart').getContext('2d');
    
    // Gap Distribution Chart
    new Chart(gapDistributionCtx, {
        type: 'pie',
        data: {
            labels: ['High Gaps', 'Medium Gaps', 'Low Gaps'],
            datasets: [{
                data: [
                    gapAnalysisData.summary.high_gap,
                    gapAnalysisData.summary.medium_gap,
                    gapAnalysisData.summary.low_gap
                ],
                backgroundColor: ['#dc2626', '#d97706', '#16a34a'],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        font: {
                            size: 12
                        }
                    }
                },
                title: {
                    display: true,
                    text: 'Gap Distribution',
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            }
        }
    });
    
    // Top 5 Competencies Chart
    const topCompetencies = [...gapAnalysisData.competencies]
        .sort((a, b) => b.gap - a.gap)
        .slice(0, 5);
    
    new Chart(gapSeverityCtx, {
        type: 'bar',
        data: {
            labels: topCompetencies.map(c => c.name.length > 15 ? c.name.substring(0, 12) + '...' : c.name),
            datasets: [
                {
                    label: 'Current Level',
                    data: topCompetencies.map(c => c.current_level),
                    backgroundColor: '#3b82f6',
                    borderColor: '#1d4ed8',
                    borderWidth: 1
                },
                {
                    label: 'Required Level',
                    data: topCompetencies.map(c => c.required_level),
                    backgroundColor: '#10b981',
                    borderColor: '#059669',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 5,
                    ticks: {
                        stepSize: 1
                    },
                    title: {
                        display: true,
                        text: 'Level (1-5)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Competencies'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: 'Current vs Required Levels',
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            }
        }
    });
    
    // Radar Chart (Top 6 Competencies)
    const radarCompetencies = [...gapAnalysisData.competencies]
        .sort((a, b) => b.gap - a.gap)
        .slice(0, Math.min(6, gapAnalysisData.competencies.length));
    
    new Chart(competencyRadarCtx, {
        type: 'radar',
        data: {
            labels: radarCompetencies.map(c => c.name.length > 15 ? c.name.substring(0, 12) + '...' : c.name),
            datasets: [
                {
                    label: 'Current Level',
                    data: radarCompetencies.map(c => c.current_level),
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderColor: '#3b82f6',
                    borderWidth: 2
                },
                {
                    label: 'Required Level',
                    data: radarCompetencies.map(c => c.required_level),
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderColor: '#10b981',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 5,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: 'Competency Gap Analysis',
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            }
        }
    });
    
    // Wait for charts to render
    await new Promise(resolve => setTimeout(resolve, 500));
}

// Generate gap analysis report (Excel or PDF)
async function generateGapReport(format = 'excel') {
    if (!currentEmployee || !gapAnalysisData) {
        alert("No employee selected or gap analysis data not available.");
        return;
    }
    
    const loadingOverlay = document.getElementById("loadingOverlay");
    loadingOverlay.classList.remove("hidden");
    loadingOverlay.classList.add("flex");
    
    try {
        if (format === 'pdf') {
            await generatePDFReport();
        } else {
            await generateExcelReport();
        }
    } catch (err) {
        console.error("Failed to generate report:", err);
        showToast("Failed to generate report. Please try again.", "error");
    } finally {
        loadingOverlay.classList.add("hidden");
        loadingOverlay.classList.remove("flex");
    }
}

// Generate Excel report
async function generateExcelReport() {
    try {
        // Prepare data for Excel
        const worksheetData = [
            // Header
            ["GAP ANALYSIS REPORT", "", "", "", "", "", "", ""],
            ["Generated Date:", new Date().toLocaleDateString(), "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["Employee Information", "", "", "", "", "", "", ""],
            ["Employee ID:", gapAnalysisData.employee_id, "", "", "", "", "", ""],
            ["Employee Name:", gapAnalysisData.employee_name, "", "", "", "", "", ""],
            ["Position:", gapAnalysisData.position, "", "", "", "", "", ""],
            ["Assessment Date:", gapAnalysisData.assessment_date, "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["Summary Statistics", "", "", "", "", "", "", ""],
            ["Total Competencies Assessed:", gapAnalysisData.summary.total_competencies, "", "", "", "", "", ""],
            ["High Priority Gaps:", gapAnalysisData.summary.high_gap, "", "", "", "", "", ""],
            ["Medium Priority Gaps:", gapAnalysisData.summary.medium_gap, "", "", "", "", "", ""],
            ["Low Priority Gaps:", gapAnalysisData.summary.low_gap, "", "", "", "", "", ""],
            ["Overall Gap Score:", gapAnalysisData.summary.overall_gap_score.toFixed(2), "", "", "", "", "", ""],
            ["Overall Status:", getOverallStatus(gapAnalysisData.summary), "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["Competency Gap Analysis", "", "", "", "", "", "", ""],
            ["Competency", "Current Level (1-5)", "Required Level (1-5)", "Gap", "Priority", "Recommendation", "Status", ""],
        ];
        
        // Add competency data
        gapAnalysisData.competencies.forEach(comp => {
            worksheetData.push([
                comp.name,
                comp.current_level,
                comp.required_level,
                comp.gap,
                comp.priority,
                getRecommendation(comp),
                comp.gap === 0 ? 'Met' : comp.gap <= 1 ? 'Partial' : 'Gap',
                ""
            ]);
        });
        
        // Add chart data
        worksheetData.push(["", "", "", "", "", "", "", ""]);
        worksheetData.push(["Chart Data - Gap Distribution", "", "", "", "", "", "", ""]);
        worksheetData.push(["Gap Type", "Count", "Percentage", "", "", "", "", ""]);
        
        const total = gapAnalysisData.summary.total_competencies;
        const highPercentage = total > 0 ? (gapAnalysisData.summary.high_gap / total * 100).toFixed(1) : 0;
        const mediumPercentage = total > 0 ? (gapAnalysisData.summary.medium_gap / total * 100).toFixed(1) : 0;
        const lowPercentage = total > 0 ? (gapAnalysisData.summary.low_gap / total * 100).toFixed(1) : 0;
        
        worksheetData.push(["High Gaps", gapAnalysisData.summary.high_gap, `${highPercentage}%`, "", "", "", "", ""]);
        worksheetData.push(["Medium Gaps", gapAnalysisData.summary.medium_gap, `${mediumPercentage}%`, "", "", "", "", ""]);
        worksheetData.push(["Low Gaps", gapAnalysisData.summary.low_gap, `${lowPercentage}%`, "", "", "", "", ""]);
        
        // Add top competencies data
        worksheetData.push(["", "", "", "", "", "", "", ""]);
        worksheetData.push(["Top 5 Competencies with Largest Gaps", "", "", "", "", "", "", ""]);
        worksheetData.push(["Competency", "Current Level", "Required Level", "Gap", "Priority", "Recommendation", "", ""]);
        
        const topCompetencies = [...gapAnalysisData.competencies]
            .sort((a, b) => b.gap - a.gap)
            .slice(0, 5);
        
        topCompetencies.forEach(comp => {
            worksheetData.push([
                comp.name,
                comp.current_level,
                comp.required_level,
                comp.gap,
                comp.priority,
                getRecommendation(comp),
                "",
                ""
            ]);
        });
        
        // Add development recommendations
        worksheetData.push(["", "", "", "", "", "", "", ""]);
        worksheetData.push(["Development Recommendations", "", "", "", "", "", "", ""]);
        worksheetData.push(["Priority", "Action", "Timeline", "Resources Needed", "", "", "", ""]);
        
        if (gapAnalysisData.summary.high_gap > 0) {
            worksheetData.push(["High", "Immediate training intervention", "1-2 months", "Intensive training, mentoring, practical exercises", "", "", "", ""]);
        }
        if (gapAnalysisData.summary.medium_gap > 0) {
            worksheetData.push(["Medium", "Structured development plan", "3-4 months", "Workshops, online courses, guided practice", "", "", "", ""]);
        }
        if (gapAnalysisData.summary.low_gap > 0) {
            worksheetData.push(["Low", "On-the-job coaching", "5-6 months", "Mentoring, peer feedback, self-study", "", "", "", ""]);
        }
        
        // Create workbook
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(worksheetData);
        
        // Set column widths
        const wscols = [
            { wch: 40 }, // Competency
            { wch: 15 }, // Current Level
            { wch: 15 }, // Required Level
            { wch: 10 }, // Gap
            { wch: 15 }, // Priority
            { wch: 40 }, // Recommendation
            { wch: 15 }, // Status
            { wch: 5 }   // Spacer
        ];
        ws['!cols'] = wscols;
        
        // Add worksheet to workbook
        XLSX.utils.book_append_sheet(wb, ws, "Gap Analysis");
        
        // Create Visual Data Sheet
        const visualData = [
            ["VISUAL GAP ANALYSIS DATA", "", "", "", ""],
            ["", "", "", "", ""],
            ["Gap Visualization", "", "", "", ""],
            ["Gap Size", "Count", "Visual Representation", "Color Code", "Priority"],
            ["Critical (4+)", gapAnalysisData.competencies.filter(c => c.gap >= 4).length, 
             "██████████", "Red", "High"],
            ["High (3)", gapAnalysisData.competencies.filter(c => c.gap === 3).length, 
             "██████░░░░", "Dark Orange", "High"],
            ["Medium (2)", gapAnalysisData.competencies.filter(c => c.gap === 2).length, 
             "████░░░░░░", "Orange", "Medium"],
            ["Low (1)", gapAnalysisData.competencies.filter(c => c.gap === 1).length, 
             "██░░░░░░░░", "Yellow", "Low"],
            ["None (0)", gapAnalysisData.competencies.filter(c => c.gap === 0).length, 
             "░░░░░░░░░░", "Green", "None"],
            ["", "", "", "", ""],
            ["Competency Level Summary", "", "", "", ""],
            ["Level", "Current Count", "Required Count", "Difference", ""],
            ["Level 5", gapAnalysisData.competencies.filter(c => c.current_level === 5).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 5).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 5).length - 
             gapAnalysisData.competencies.filter(c => c.current_level === 5).length, ""],
            ["Level 4", gapAnalysisData.competencies.filter(c => c.current_level === 4).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 4).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 4).length - 
             gapAnalysisData.competencies.filter(c => c.current_level === 4).length, ""],
            ["Level 3", gapAnalysisData.competencies.filter(c => c.current_level === 3).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 3).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 3).length - 
             gapAnalysisData.competencies.filter(c => c.current_level === 3).length, ""],
            ["Level 2", gapAnalysisData.competencies.filter(c => c.current_level === 2).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 2).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 2).length - 
             gapAnalysisData.competencies.filter(c => c.current_level === 2).length, ""],
            ["Level 1", gapAnalysisData.competencies.filter(c => c.current_level === 1).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 1).length,
             gapAnalysisData.competencies.filter(c => c.required_level === 1).length - 
             gapAnalysisData.competencies.filter(c => c.current_level === 1).length, ""]
        ];
        
        const visualWs = XLSX.utils.aoa_to_sheet(visualData);
        visualWs['!cols'] = [
            { wch: 20 }, { wch: 15 }, { wch: 25 }, { wch: 15 }, { wch: 15 }
        ];
        XLSX.utils.book_append_sheet(wb, visualWs, "Visual Data");
        
        // Generate filename
        const filename = `Gap_Analysis_${currentEmployee.name.replace(/\s+/g, '_')}_${currentEmployee.employee_id}_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        // Export to Excel
        XLSX.writeFile(wb, filename);
        
        // Show success message
        showToast("Excel report generated successfully with visual data!", "success");
        
    } catch (err) {
        console.error("Failed to generate Excel report:", err);
        throw err;
    }
}

// Generate PDF report with charts
async function generatePDFReport() {
    try {
        // Create export charts first
        await createExportCharts();
        
        // Create PDF
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('p', 'mm', 'a4');
        
        // Add header
        doc.setFontSize(20);
        doc.setTextColor(40);
        doc.text('GAP ANALYSIS REPORT', 105, 20, { align: 'center' });
        
        doc.setFontSize(12);
        doc.setTextColor(100);
        doc.text(`Generated: ${new Date().toLocaleDateString()}`, 105, 28, { align: 'center' });
        
        // Add employee information
        doc.setFontSize(14);
        doc.setTextColor(40);
        doc.text('Employee Information', 20, 40);
        
        doc.setFontSize(11);
        doc.setTextColor(80);
        doc.text(`Employee ID: ${gapAnalysisData.employee_id}`, 20, 48);
        doc.text(`Employee Name: ${gapAnalysisData.employee_name}`, 20, 54);
        doc.text(`Position: ${gapAnalysisData.position}`, 20, 60);
        doc.text(`Assessment Date: ${gapAnalysisData.assessment_date}`, 20, 66);
        
        // Add summary statistics
        doc.setFontSize(14);
        doc.setTextColor(40);
        doc.text('Summary Statistics', 20, 78);
        
        const summaryY = 86;
        doc.setFontSize(11);
        doc.setTextColor(80);
        doc.text(`Total Competencies Assessed: ${gapAnalysisData.summary.total_competencies}`, 20, summaryY);
        doc.text(`High Priority Gaps: ${gapAnalysisData.summary.high_gap}`, 20, summaryY + 6);
        doc.text(`Medium Priority Gaps: ${gapAnalysisData.summary.medium_gap}`, 20, summaryY + 12);
        doc.text(`Low Priority Gaps: ${gapAnalysisData.summary.low_gap}`, 20, summaryY + 18);
        doc.text(`Overall Gap Score: ${gapAnalysisData.summary.overall_gap_score.toFixed(2)}`, 20, summaryY + 24);
        doc.text(`Overall Status: ${getOverallStatus(gapAnalysisData.summary)}`, 20, summaryY + 30);
        
        // Convert charts to images
        const exportChartsDiv = document.getElementById('exportCharts');
        const canvasElements = exportChartsDiv.querySelectorAll('canvas');
        
        let yPosition = 120;
        
        // Add charts to PDF
        for (let i = 0; i < canvasElements.length; i++) {
            const canvas = canvasElements[i];
            const chartImage = canvas.toDataURL('image/png');
            
            // Add chart title
            if (i === 0) {
                doc.setFontSize(14);
                doc.setTextColor(40);
                doc.text('Gap Analysis Charts', 105, yPosition, { align: 'center' });
                yPosition += 8;
            }
            
            // Add chart image
            const imgWidth = 170;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            
            if (yPosition + imgHeight > 280) {
                doc.addPage();
                yPosition = 20;
            }
            
            doc.addImage(chartImage, 'PNG', 20, yPosition, imgWidth, imgHeight);
            yPosition += imgHeight + 10;
            
            if (yPosition > 280 && i < canvasElements.length - 1) {
                doc.addPage();
                yPosition = 20;
            }
        }
        
        // Add competency table on new page
        doc.addPage();
        doc.setFontSize(16);
        doc.setTextColor(40);
        doc.text('Competency Gap Analysis', 105, 20, { align: 'center' });
        
        // Prepare table data
        const tableData = gapAnalysisData.competencies.map(comp => [
            comp.name.length > 30 ? comp.name.substring(0, 27) + '...' : comp.name,
            comp.current_level.toString(),
            comp.required_level.toString(),
            comp.gap.toString(),
            comp.priority,
            comp.gap === 0 ? 'Met' : comp.gap <= 1 ? 'Partial' : 'Gap'
        ]);
        
        // Add table
        doc.autoTable({
            head: [['Competency', 'Current', 'Required', 'Gap', 'Priority', 'Status']],
            body: tableData,
            startY: 30,
            theme: 'grid',
            headStyles: { fillColor: [59, 130, 246] },
            columnStyles: {
                0: { cellWidth: 60 },
                1: { cellWidth: 20 },
                2: { cellWidth: 20 },
                3: { cellWidth: 15 },
                4: { cellWidth: 25 },
                5: { cellWidth: 20 }
            },
            didParseCell: function(data) {
                if (data.section === 'body' && data.column.index === 4) {
                    if (data.cell.text === 'High') {
                        data.cell.styles.textColor = [220, 38, 38];
                    } else if (data.cell.text === 'Medium') {
                        data.cell.styles.textColor = [217, 119, 6];
                    } else {
                        data.cell.styles.textColor = [22, 163, 74];
                    }
                }
            }
        });
        
        // Add development recommendations on new page
        doc.addPage();
        doc.setFontSize(16);
        doc.setTextColor(40);
        doc.text('Development Recommendations', 105, 20, { align: 'center' });
        
        let recY = 30;
        doc.setFontSize(12);
        
        if (gapAnalysisData.summary.high_gap > 0) {
            doc.setTextColor(220, 38, 38);
            doc.setFont(undefined, 'bold');
            doc.text('High Priority Actions:', 20, recY);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(80);
            doc.text('• Immediate training intervention required', 25, recY + 6);
            doc.text('• Focus on competencies with largest gaps first', 25, recY + 12);
            doc.text('• Timeline: 1-2 months', 25, recY + 18);
            recY += 30;
        }
        
        if (gapAnalysisData.summary.medium_gap > 0) {
            doc.setTextColor(217, 119, 6);
            doc.setFont(undefined, 'bold');
            doc.text('Medium Priority Actions:', 20, recY);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(80);
            doc.text('• Structured development plan needed', 25, recY + 6);
            doc.text('• Consider workshops and online courses', 25, recY + 12);
            doc.text('• Timeline: 3-4 months', 25, recY + 18);
            recY += 30;
        }
        
        if (gapAnalysisData.summary.low_gap > 0) {
            doc.setTextColor(22, 163, 74);
            doc.setFont(undefined, 'bold');
            doc.text('Low Priority Actions:', 20, recY);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(80);
            doc.text('• On-the-job mentoring and coaching', 25, recY + 6);
            doc.text('• Peer feedback and self-study', 25, recY + 12);
            doc.text('• Timeline: 5-6 months', 25, recY + 18);
        }
        
        // Add footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(10);
            doc.setTextColor(150);
            doc.text(`Page ${i} of ${pageCount}`, 105, 287, { align: 'center' });
            doc.text('Generated by Competency Management System', 105, 292, { align: 'center' });
        }
        
        // Save PDF
        const filename = `Gap_Analysis_${currentEmployee.name.replace(/\s+/g, '_')}_${currentEmployee.employee_id}_${new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(filename);
        
        // Show success message
        showToast("PDF report generated successfully with charts!", "success");
        
    } catch (err) {
        console.error("Failed to generate PDF report:", err);
        throw err;
    }
}

// Generate reports for all applicants
async function generateAllReports(format = 'excel') {
    if (applicants.length === 0) {
        alert("No applicants available for report generation.");
        return;
    }
    
    const loadingOverlay = document.getElementById("loadingOverlay");
    loadingOverlay.classList.remove("hidden");
    loadingOverlay.classList.add("flex");
    
    try {
        if (format === 'pdf') {
            await generateAllPDFReports();
        } else {
            await generateAllExcelReports();
        }
    } catch (err) {
        console.error("Failed to generate reports:", err);
        showToast("Failed to generate reports. Please try again.", "error");
    } finally {
        loadingOverlay.classList.add("hidden");
        loadingOverlay.classList.remove("flex");
    }
}

// Generate all Excel reports
async function generateAllExcelReports() {
    try {
        // Create a workbook
        const wb = XLSX.utils.book_new();
        
        // Create Summary Sheet
        const summaryData = [
            ["COMPETENCY GAP ANALYSIS - ALL APPLICANTS", "", "", "", "", "", "", ""],
            ["Generated Date:", new Date().toLocaleDateString(), "", "", "", "", "", ""],
            ["Total Applicants:", applicants.length, "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["Applicant Name", "Employee ID", "Position", "High Gaps", "Medium Gaps", "Low Gaps", "Overall Score", "Status"],
        ];
        
        // Collect all gap analysis data
        const allGapData = [];
        
        for (const emp of applicants) {
            try {
                const response = await fetch(`/competencies/get_gap_analysis.php?employee_id=${emp.employee_id}&position=${encodeURIComponent(emp.position)}&name=${encodeURIComponent(emp.name)}`);
                
                if (response.ok) {
                    const gapData = await response.json();
                    allGapData.push(gapData);
                    
                    // Add to summary
                    summaryData.push([
                        gapData.employee_name,
                        gapData.employee_id,
                        gapData.position,
                        gapData.summary.high_gap,
                        gapData.summary.medium_gap,
                        gapData.summary.low_gap,
                        gapData.summary.overall_gap_score.toFixed(2),
                        getOverallStatus(gapData.summary)
                    ]);
                }
            } catch (err) {
                console.error(`Failed to fetch data for ${emp.name}:`, err);
            }
        }
        
        // Add summary statistics
        summaryData.push(["", "", "", "", "", "", "", ""]);
        summaryData.push(["SUMMARY STATISTICS", "", "", "", "", "", "", ""]);
        if (allGapData.length > 0) {
            const avgHigh = allGapData.reduce((sum, data) => sum + data.summary.high_gap, 0) / allGapData.length;
            const avgMedium = allGapData.reduce((sum, data) => sum + data.summary.medium_gap, 0) / allGapData.length;
            const avgLow = allGapData.reduce((sum, data) => sum + data.summary.low_gap, 0) / allGapData.length;
            const avgScore = allGapData.reduce((sum, data) => sum + data.summary.overall_gap_score, 0) / allGapData.length;
            
            summaryData.push(["Average High Gaps:", avgHigh.toFixed(1), "", "", "", "", "", ""]);
            summaryData.push(["Average Medium Gaps:", avgMedium.toFixed(1), "", "", "", "", "", ""]);
            summaryData.push(["Average Low Gaps:", avgLow.toFixed(1), "", "", "", "", "", ""]);
            summaryData.push(["Average Overall Score:", avgScore.toFixed(2), "", "", "", "", "", ""]);
        }
        
        const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
        summaryWs['!cols'] = [
            { wch: 25 }, { wch: 15 }, { wch: 20 }, 
            { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 15 }, { wch: 15 }
        ];
        XLSX.utils.book_append_sheet(wb, summaryWs, "Summary");
        
        // Create Chart Data Sheet
        if (allGapData.length > 0) {
            const chartData = [
                ["CHART DATA - GAP DISTRIBUTION BY APPLICANT", "", "", ""],
                ["Applicant", "High Gaps", "Medium Gaps", "Low Gaps"],
                ...allGapData.map(data => [
                    data.employee_name.length > 15 ? data.employee_name.substring(0, 12) + "..." : data.employee_name,
                    data.summary.high_gap,
                    data.summary.medium_gap,
                    data.summary.low_gap
                ])
            ];
            
            const chartWs = XLSX.utils.aoa_to_sheet(chartData);
            chartWs['!cols'] = [
                { wch: 20 }, { wch: 12 }, { wch: 14 }, { wch: 12 }
            ];
            XLSX.utils.book_append_sheet(wb, chartWs, "Chart Data");
        }
        
        // Generate filename
        const filename = `Competency_Gap_Analysis_All_Applicants_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        // Export to Excel
        XLSX.writeFile(wb, filename);
        
        showToast(`Generated Excel reports for ${allGapData.length} applicants`, "success");
        
    } catch (err) {
        console.error("Failed to generate Excel reports:", err);
        throw err;
    }
}

// Generate all PDF reports (creates separate PDFs)
async function generateAllPDFReports() {
    try {
        // This would generate separate PDFs for each applicant
        // For simplicity, we'll create a summary PDF
        
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('p', 'mm', 'a4');
        
        // Add header
        doc.setFontSize(20);
        doc.setTextColor(40);
        doc.text('ALL APPLICANTS GAP ANALYSIS SUMMARY', 105, 20, { align: 'center' });
        
        doc.setFontSize(12);
        doc.setTextColor(100);
        doc.text(`Generated: ${new Date().toLocaleDateString()}`, 105, 28, { align: 'center' });
        doc.text(`Total Applicants: ${applicants.length}`, 105, 34, { align: 'center' });
        
        // Collect all gap analysis data
        const allGapData = [];
        
        for (const emp of applicants) {
            try {
                const response = await fetch(`/competencies/get_gap_analysis.php?employee_id=${emp.employee_id}&position=${encodeURIComponent(emp.position)}&name=${encodeURIComponent(emp.name)}`);
                
                if (response.ok) {
                    const gapData = await response.json();
                    allGapData.push(gapData);
                }
            } catch (err) {
                console.error(`Failed to fetch data for ${emp.name}:`, err);
            }
        }
        
        // Prepare table data
        const tableData = allGapData.map(data => [
            data.employee_name.length > 20 ? data.employee_name.substring(0, 17) + '...' : data.employee_name,
            data.employee_id,
            data.position.length > 15 ? data.position.substring(0, 12) + '...' : data.position,
            data.summary.high_gap.toString(),
            data.summary.medium_gap.toString(),
            data.summary.low_gap.toString(),
            data.summary.overall_gap_score.toFixed(2),
            getOverallStatus(data.summary)
        ]);
        
        // Add summary table
        doc.autoTable({
            head: [['Applicant Name', 'ID', 'Position', 'High', 'Medium', 'Low', 'Score', 'Status']],
            body: tableData,
            startY: 40,
            theme: 'grid',
            headStyles: { fillColor: [59, 130, 246] },
            columnStyles: {
                0: { cellWidth: 30 },
                1: { cellWidth: 20 },
                2: { cellWidth: 25 },
                3: { cellWidth: 15 },
                4: { cellWidth: 18 },
                5: { cellWidth: 15 },
                6: { cellWidth: 18 },
                7: { cellWidth: 20 }
            }
        });
        
        // Add statistics
        const finalY = doc.lastAutoTable.finalY + 10;
        
        if (allGapData.length > 0) {
            const avgHigh = allGapData.reduce((sum, data) => sum + data.summary.high_gap, 0) / allGapData.length;
            const avgMedium = allGapData.reduce((sum, data) => sum + data.summary.medium_gap, 0) / allGapData.length;
            const avgLow = allGapData.reduce((sum, data) => sum + data.summary.low_gap, 0) / allGapData.length;
            const avgScore = allGapData.reduce((sum, data) => sum + data.summary.overall_gap_score, 0) / allGapData.length;
            
            doc.setFontSize(14);
            doc.setTextColor(40);
            doc.text('Summary Statistics', 20, finalY);
            
            doc.setFontSize(11);
            doc.setTextColor(80);
            doc.text(`Average High Gaps: ${avgHigh.toFixed(1)}`, 20, finalY + 8);
            doc.text(`Average Medium Gaps: ${avgMedium.toFixed(1)}`, 20, finalY + 16);
            doc.text(`Average Low Gaps: ${avgLow.toFixed(1)}`, 20, finalY + 24);
            doc.text(`Average Overall Score: ${avgScore.toFixed(2)}`, 20, finalY + 32);
        }
        
        // Add footer
        doc.setFontSize(10);
        doc.setTextColor(150);
        doc.text('Generated by Competency Management System', 105, 287, { align: 'center' });
        
        // Save PDF
        const filename = `All_Applicants_Gap_Analysis_Summary_${new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(filename);
        
        showToast(`Generated PDF summary for ${allGapData.length} applicants`, "success");
        
    } catch (err) {
        console.error("Failed to generate PDF reports:", err);
        throw err;
    }
}

// Show toast notification
function showToast(message, type = "info") {
    // Remove existing toast
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) existingToast.remove();
    
    const colors = {
        success: "bg-green-500",
        error: "bg-red-500",
        info: "bg-blue-500",
        warning: "bg-amber-500"
    };
    
    const toast = document.createElement('div');
    toast.className = `toast-notification fixed top-6 right-6 ${colors[type]} text-white px-6 py-3 rounded-xl shadow-lg z-50 transform transition-all duration-300 translate-x-full`;
    toast.innerHTML = `
        <div class="flex items-center gap-3">
            <i data-lucide="${type === 'success' ? 'check-circle' : type === 'error' ? 'alert-circle' : 'info'}" class="w-5 h-5"></i>
            <span>${message}</span>
        </div>
    `;
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.classList.remove('translate-x-full');
        toast.classList.add('translate-x-0');
    }, 10);
    
    // Animate out and remove
    setTimeout(() => {
        toast.classList.remove('translate-x-0');
        toast.classList.add('translate-x-full');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
    
    // Create icons
    setTimeout(() => lucide.createIcons(), 50);
}

// Fetch applicants from HR1
async function fetchApplicants() {
    await fetchProceededIds();

    try {
        const res = await fetch("https://hr1.atierahotelandrestaurant.com/api/hr2_api.php");
        const data = await res.json();
        const proceededSet = new Set(proceededIds.map(String));

        applicants = data.map(e=>{
            const o = e.onboarding;
            return {
                onboarding_id: o.id,      
                employee_id: String(o.employee_id),
                name: `${o.first_name} ${o.middle_name ? o.middle_name + ' ' : ''}${o.last_name}`,
                position: o.job_position || 'Unassigned',
                resume: o.resume || '',
                is_old: o.status === "old"
            };
        }).filter(emp => !emp.is_old && !proceededSet.has(String(emp.onboarding_id)));

        updateApplicantCount();
        renderPositionFilter(applicants);
        renderEmployeeList(applicants);

    } catch(err){
        employeeList.innerHTML = `
            <li class='text-center py-8 prevent-select'>
                <div class="mx-auto w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-3">
                    <i data-lucide="alert-triangle" class="w-6 h-6 text-red-500"></i>
                </div>
                <p class="text-red-500 text-sm">Failed to load applicants</p>
                <p class="text-gray-400 text-xs mt-1">Please check your connection</p>
            </li>`;
        console.error(err);
    }
}

// View resume
function viewResume(){
    if(!currentEmployee || !currentEmployee.resume){
        alert("No resume available.");
        return;
    }

    const resumeModal = document.getElementById("resumeModal");
    const resumeIframe = document.getElementById("resumeIframe");
    const resumeModalTitle = document.getElementById("resumeModalTitle");
    const resumeSubtitle = document.getElementById("resumeSubtitle");

    const cleanPath = currentEmployee.resume.replace(/^\/+/, "");
    const fullResumeUrl = HR1_BASE_URL + cleanPath;

    resumeModalTitle.textContent = `${currentEmployee.name}'s Resume`;
    resumeSubtitle.textContent = `Position: ${currentEmployee.position}`;
    resumeIframe.src = fullResumeUrl;

    resumeModal.classList.remove("hidden");
    resumeModal.classList.add("flex");
}

// Close resume modal
function closeResumeModal(){
    const resumeModal = document.getElementById("resumeModal");
    const resumeIframe = document.getElementById("resumeIframe");
    resumeIframe.src = "";
    resumeModal.classList.add("hidden");
    resumeModal.classList.remove("flex");
}

// Proceed employee to competencies
function proceedToCriteria(){
    if(!currentEmployee){ 
        alert("Please select an applicant first"); 
        return; 
    }

    const proceedModal = document.getElementById("proceedModal");
    const proceedMessage = document.getElementById("proceedMessage");
    const proceedConfirmBtn = document.getElementById("proceedConfirmBtn");
    const proceedCancelBtn = document.getElementById("proceedCancelBtn");
    const loadingOverlay = document.getElementById("loadingOverlay");

    proceedMessage.textContent = `Proceed "${currentEmployee.name}" to competency criteria assessment?`;
    proceedModal.classList.remove("hidden");
    proceedModal.classList.add("flex");

    proceedConfirmBtn.replaceWith(proceedConfirmBtn.cloneNode(true));
    const newConfirmBtn = document.getElementById("proceedConfirmBtn");

    newConfirmBtn.addEventListener("click", async () => {
        proceedModal.classList.add("hidden");

        const formData = new FormData();
        formData.append('employee_id', currentEmployee.employee_id);
        formData.append('onboarding_id', currentEmployee.onboarding_id);
        formData.append('name', currentEmployee.name);
        formData.append('department', currentEmployee.position);
        formData.append('current_level', 1);
        formData.append('required_level', 3);

        loadingOverlay.classList.remove("hidden");
        loadingOverlay.classList.add("flex");

        try {
            const res = await fetch('/competencies/proceed_to_competencies.php', { 
                method:'POST', 
                body: formData 
            });
            const data = await res.json();

            loadingOverlay.classList.add("hidden");
            loadingOverlay.classList.remove("flex");

            if(data.success){
                proceededIds.push(data.applicant_id);
                applicants = applicants.filter(emp => emp.onboarding_id !== data.applicant_id && emp.employee_id !== data.applicant_id);
                updateApplicantCount();
                renderEmployeeList(applicants);

                employeeProfile.classList.add("hidden");
                noDataNote.classList.remove("hidden");

                window.location.href = `/competencies/gap_analysis.php?employee_id=${encodeURIComponent(currentEmployee.employee_id)}`;
            } else {
                alert('Error: ' + data.message);
            }

        } catch(err){
            loadingOverlay.classList.add("hidden");
            loadingOverlay.classList.remove("flex");
            console.error(err);
            alert('Failed to proceed. Please try again.');
        }
    });

    proceedCancelBtn.onclick = () => {
        proceedModal.classList.add("hidden");
    };
}

// Filters
searchInput.addEventListener("input", () => {
    renderEmployeeList(applicants);
});

positionFilter.addEventListener("change", () => {
    renderEmployeeList(applicants);
});

// Add scroll prevention for employee list
employeeList.addEventListener('wheel', function(e) {
    // Allow normal scrolling
}, { passive: true });

// Add touch handling for better mobile experience
let touchStartY = 0;
let touchStartX = 0;
let isScrolling = false;

employeeList.addEventListener('touchstart', function(e) {
    if (e.touches.length === 1) {
        touchStartY = e.touches[0].clientY;
        touchStartX = e.touches[0].clientX;
        isScrolling = false;
    }
}, { passive: true });

employeeList.addEventListener('touchmove', function(e) {
    if (e.touches.length === 1) {
        const touchY = e.touches[0].clientY;
        const touchX = e.touches[0].clientX;
        
        // Check if it's a scroll (vertical movement > horizontal movement)
        if (Math.abs(touchY - touchStartY) > Math.abs(touchX - touchStartX)) {
            isScrolling = true;
        }
    }
}, { passive: true });

employeeList.addEventListener('touchend', function(e) {
    // If it was a scroll, don't trigger click
    if (isScrolling) {
        e.preventDefault();
    }
    isScrolling = false;
}, { passive: false });

// Initialize
document.addEventListener("DOMContentLoaded", function() {
    fetchApplicants();
    // Initialize charts
    initCharts();
    
    // Add dropdown functionality
    document.addEventListener('click', function(e) {
        if (e.target.closest('.dropdown-toggle')) {
            const dropdown = e.target.closest('.dropdown');
            const menu = dropdown.querySelector('.dropdown-menu');
            menu.classList.toggle('show');
        } else {
            document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });
});
</script>

<style>
.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-menu {
    display: none;
    position: absolute;
    background-color: white;
    min-width: 160px;
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    z-index: 1000;
    border-radius: 8px;
    overflow: hidden;
    margin-top: 5px;
}

.dropdown-menu.show {
    display: block;
}

.dropdown-item {
    color: #333;
    padding: 10px 16px;
    text-decoration: none;
    display: block;
    font-size: 14px;
    border-bottom: 1px solid #f1f5f9;
    transition: background-color 0.2s;
}

.dropdown-item:hover {
    background-color: #f8fafc;
    color: #3b82f6;
}

.dropdown-item:last-child {
    border-bottom: none;
}
</style>

</body>
</html>