<?php
// competencies/api/get_records.php
include('../../dblogin.php'); // Adjust path as needed
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get filters from query parameters
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$department = $_GET['department'] ?? '';
$date_range = $_GET['date_range'] ?? '';

try {
    // First, check if the table exists
    $check_table = $conn->query("SHOW TABLES LIKE 'competency_records'");
    if ($check_table->num_rows == 0) {
        // Table doesn't exist, return empty data
        echo json_encode([
            'success' => true,
            'records' => [],
            'stats' => [
                'total' => 0,
                'completed' => 0,
                'in_progress' => 0,
                'pending' => 0,
                'failed' => 0
            ],
            'departments' => [],
            'count' => 0,
            'message' => 'No competency records table found.'
        ]);
        exit;
    }
    
    // Build the base query
    $sql = "SELECT 
                id,
                employee_id,
                employee_name,
                position,
                department,
                status,
                DATE_FORMAT(start_date, '%Y-%m-%d') as start_date,
                DATE_FORMAT(last_updated, '%Y-%m-%d') as last_updated,
                notes,
                created_at
            FROM competency_records 
            WHERE 1=1";
    
    $params = [];
    $types = '';
    
    // Apply search filter
    if (!empty($search)) {
        $sql .= " AND (
            employee_id LIKE ? OR 
            employee_name LIKE ? OR 
            position LIKE ? OR 
            department LIKE ?
        )";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= 'ssss';
    }
    
    // Apply status filter
    if (!empty($status) && in_array($status, ['pending', 'in-progress', 'completed', 'failed'])) {
        $sql .= " AND status = ?";
        $params[] = $status;
        $types .= 's';
    }
    
    // Apply department filter
    if (!empty($department)) {
        $sql .= " AND department = ?";
        $params[] = $department;
        $types .= 's';
    }
    
    // Apply date range filter
    if (!empty($date_range)) {
        switch ($date_range) {
            case 'today':
                $sql .= " AND DATE(last_updated) = CURDATE()";
                break;
            case 'week':
                $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
                break;
            case 'quarter':
                $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
                break;
            case 'year':
                $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)";
                break;
        }
    }
    
    // Order by last_updated descending
    $sql .= " ORDER BY last_updated DESC";
    
    // Prepare and execute query
    if (!empty($params)) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    
    $records = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $records[] = [
                'id' => $row['id'],
                'employee_id' => $row['employee_id'],
                'employee_name' => $row['employee_name'],
                'position' => $row['position'],
                'department' => $row['department'],
                'status' => $row['status'],
                'start_date' => $row['start_date'],
                'last_updated' => $row['last_updated'],
                'notes' => $row['notes'],
                'created_at' => $row['created_at']
            ];
        }
    }
    
    // Get stats for the dashboard
    $stats_sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
                  FROM competency_records";
    
    $stats_result = $conn->query($stats_sql);
    $stats = $stats_result ? $stats_result->fetch_assoc() : [
        'total' => 0,
        'completed' => 0,
        'in_progress' => 0,
        'pending' => 0,
        'failed' => 0
    ];
    
    // Get unique departments for filter
    $dept_sql = "SELECT DISTINCT department FROM competency_records WHERE department IS NOT NULL AND department != '' ORDER BY department";
    $dept_result = $conn->query($dept_sql);
    $departments = [];
    if ($dept_result) {
        while ($dept = $dept_result->fetch_assoc()) {
            $departments[] = $dept['department'];
        }
    }
    
    echo json_encode([
        'success' => true,
        'records' => $records,
        'stats' => $stats,
        'departments' => $departments,
        'count' => count($records)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching records: ' . $e->getMessage()
    ]);
}

$conn->close();
?>