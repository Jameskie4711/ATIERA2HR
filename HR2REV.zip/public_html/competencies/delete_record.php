<?php
// delete_record.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Include session check and database connection
include('../session_check.php');
include('../dblogin.php');

// Set headers
header('Content-Type: application/json');

// Initialize response
$response = [
    'status' => 'error',
    'message' => '',
    'redirect' => ''
];

try {
    // Check if it's a POST request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Get the record ID to delete
    $record_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    if ($record_id <= 0) {
        throw new Exception('Invalid record ID');
    }

    // First, check if the record exists
    $check_sql = "SELECT id, employee_name FROM competency_records WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    
    if (!$check_stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $check_stmt->bind_param("i", $record_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        throw new Exception('Record not found');
    }
    
    $record = $check_result->fetch_assoc();
    $employee_name = $record['employee_name'];
    
    $check_stmt->close();

    // Log the deletion attempt (optional - create an audit log table if needed)
    // This is useful for tracking who deleted what and when
    if (true) { // You can add a condition here if you have an audit_log table
        try {
            $audit_sql = "INSERT INTO audit_log (user_id, action, details, ip_address, user_agent) 
                          VALUES (?, ?, ?, ?, ?)";
            $audit_stmt = $conn->prepare($audit_sql);
            
            if ($audit_stmt) {
                $user_id = $_SESSION['user_id'] ?? 0;
                $action = 'DELETE_RECORD';
                $details = "Deleted competency record #$record_id for employee: $employee_name";
                $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
                $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                
                $audit_stmt->bind_param("issss", $user_id, $action, $details, $ip_address, $user_agent);
                $audit_stmt->execute();
                $audit_stmt->close();
            }
        } catch (Exception $e) {
            // Silently fail audit logging - don't stop the main deletion
            error_log("Audit logging failed: " . $e->getMessage());
        }
    }

    // Perform the deletion
    $delete_sql = "DELETE FROM competency_records WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    
    if (!$delete_stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $delete_stmt->bind_param("i", $record_id);
    $delete_stmt->execute();
    
    // Check if deletion was successful
    if ($delete_stmt->affected_rows > 0) {
        $response['status'] = 'success';
        $response['message'] = 'Record deleted successfully';
        $response['redirect'] = 'record.php?deleted=1';
        
        // Set a session flash message for confirmation
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Record for $employee_name has been deleted successfully."
        ];
    } else {
        throw new Exception('No record was deleted. Please try again.');
    }
    
    $delete_stmt->close();

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    
    // Log the error
    error_log("Delete record error: " . $e->getMessage());
    
    // Set error flash message
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => $e->getMessage()
    ];
} finally {
    // Return JSON response for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode($response);
        exit;
    }
    
    // For regular form submissions, redirect back
    if ($response['status'] === 'success') {
        header('Location: ' . $response['redirect']);
    } else {
        header('Location: record.php?error=1&message=' . urlencode($response['message']));
    }
    exit;
}
?>