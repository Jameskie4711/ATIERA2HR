<?php
include('../session_check.php'); 
include('../dblogin.php'); // HR2 DB connection
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if(!$data || empty($data['applicant_id'])){
    echo json_encode(['status'=>'error','message'=>'Invalid data']);
    exit;
}

// Check if employee already exists in HR2
$check = $conn->prepare("SELECT id FROM hr2_employees WHERE employee_id = ?");
$check->bind_param("s", $data['applicant_id']);
$check->execute();
$check->store_result();

if($check->num_rows > 0){
    echo json_encode(['status'=>'error','message'=>'Employee already exists in HR2']);
    exit;
}

// Insert employee into HR2 database
$insert = $conn->prepare("INSERT INTO hr2_employees (employee_id, first_name, middle_name, last_name, job_position, created_at) VALUES (?,?,?,?,?,NOW())");
$first_name = explode(" ", $data['name'])[0];
$middle_name = count(explode(" ", $data['name'])) === 3 ? explode(" ", $data['name'])[1] : '';
$last_name = explode(" ", $data['name'])[count(explode(" ", $data['name']))-1];
$job_position = $data['position'];

$insert->bind_param("sssss", $data['applicant_id'], $first_name, $middle_name, $last_name, $job_position);

if($insert->execute()){
    echo json_encode(['status'=>'success','message'=>'Employee data copied successfully']);
} else {
    echo json_encode(['status'=>'error','message'=>'Database error: '.$conn->error]);
}
?>
