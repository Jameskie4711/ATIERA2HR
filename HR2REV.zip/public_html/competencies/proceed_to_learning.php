<?php
include('../session_check.php');
include('../dblogin.php');

$data = json_decode(file_get_contents('php://input'), true);
if(!$data) { echo json_encode(['status'=>'error','message'=>'No data received']); exit; }

$applicant_id = intval($data['applicant_id']);
$name = $conn->real_escape_string($data['name']);
$position = $conn->real_escape_string($data['position']);
$department = $conn->real_escape_string($data['department'] ?? '');

$stmt = $conn->prepare("INSERT INTO learning_employees (applicant_id, name, position, department, created_at) VALUES (?,?,?,?,NOW())");
$stmt->bind_param("isss",$applicant_id,$name,$position,$department);

if($stmt->execute()){
    echo json_encode(['status'=>'success','message'=>'Employee moved to Learning.']);
} else {
    echo json_encode(['status'=>'error','message'=>$stmt->error]);
}
?>
