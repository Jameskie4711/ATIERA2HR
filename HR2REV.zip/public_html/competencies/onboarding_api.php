so what should i need to do this ?

make a new file onboarding_employee.php? 

<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once _DIR_ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;

/* =========================
   REQUEST METHOD
========================= */
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    /* =========================
       GET (ALL / SINGLE)
    ========================== */
    case 'GET':
        if (!empty($_GET['id'])) {
            $stmt = $db->prepare("SELECT * FROM onboarding WHERE id = ?");
            $stmt->execute([intval($_GET['id'])]);
            $row = $stmt->fetch();
            echo json_encode($row ?: []);
        } else {
            $stmt = $db->query(
                "SELECT * FROM onboarding ORDER BY created_at DESC"
            );
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST (CREATE)
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        $sql = "INSERT INTO onboarding (
                    employee_id, job_position, first_name, middle_name, last_name,
                    email, contact_number, address, date_of_birth, hire_date,
                    status, created_at, updated_at
                ) VALUES (
                    :employee_id, :job_position, :first_name, :middle_name, :last_name,
                    :email, :contact_number, :address, :date_of_birth, :hire_date,
                    :status, NOW(), NOW()
                )";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            ":employee_id"   => $data['employee_id'],
            ":job_position"  => $data['job_position'],
            ":first_name"    => $data['first_name'],
            ":middle_name"   => $data['middle_name'],
            ":last_name"     => $data['last_name'],
            ":email"         => $data['email'],
            ":contact_number"=> $data['contact_number'],
            ":address"       => $data['address'],
            ":date_of_birth" => $data['date_of_birth'],
            ":hire_date"     => $data['hire_date'],
            ":status"        => $data['status']
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT (UPDATE)
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $sql = "UPDATE onboarding SET
                    employee_id = :employee_id,
                    job_position = :job_position,
                    first_name = :first_name,
                    middle_name = :middle_name,
                    last_name = :last_name,
                    email = :email,
                    contact_number = :contact_number,
                    address = :address,
                    date_of_birth = :date_of_birth,
                    hire_date = :hire_date,
                    status = :status,
                    updated_at = NOW()
                WHERE id = :id";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            ":employee_id"   => $data['employee_id'],
            ":job_position"  => $data['job_position'],
            ":first_name"    => $data['first_name'],
            ":middle_name"   => $data['middle_name'],
            ":last_name"     => $data['last_name'],
            ":email"         => $data['email'],
            ":contact_number"=> $data['contact_number'],
            ":address"       => $data['address'],
            ":date_of_birth" => $data['date_of_birth'],
            ":hire_date"     => $data['hire_date'],
            ":status"        => $data['status'],
            ":id"            => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare("DELETE FROM onboarding WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}