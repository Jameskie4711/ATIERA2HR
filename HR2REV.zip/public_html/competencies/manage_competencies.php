<?php
include('../session_check.php');
include('../dblogin.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle search
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Build query
$sql = "
    SELECT 
        id,
        onboarding_id,
        applicant_id,
        name,
        department,
        created_at
    FROM onboarding_competencies
";

if (!empty($search)) {
    $safe = $conn->real_escape_string($search);
    $sql .= " WHERE name LIKE '%$safe%' 
              OR department LIKE '%$safe%' 
              OR applicant_id LIKE '%$safe%'";
}

$sql .= " ORDER BY created_at DESC";

$result = $conn->query($sql);

$rows = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Competencies</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50">

<div class="flex h-full">
  <!-- Sidebar -->
  <?php include '../sidebar.php'; ?>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-4 w-full">

      <!-- Header -->
      <div class="flex items-center justify-between border-b py-6">
        <div>
          <h2 class="text-2xl font-semibold text-gray-800">Manage Competencies</h2>
          <p class="text-slate-500 text-sm">Onboarding competency records</p>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Submodules Header -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
        <a href="/competencies/competencies.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Competencies</a>
        <a href="/competencies/gap_analysis.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors">Criteria</a>
      </div>

      <!-- Search -->
      <form method="get" class="flex gap-2 mt-4">
        <input
          type="text"
          name="search"
          placeholder="Search by name, department, or applicant ID"
          value="<?= htmlspecialchars($search) ?>"
          class="flex-1 px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300"
        />
        <button class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Search
        </button>
      </form>

      <!-- Table -->
      <div class="overflow-x-auto bg-white shadow rounded-lg w-full mt-4">
        <table class="min-w-full border-collapse text-sm">
          <thead class="bg-gray-100 text-gray-700">
            <tr>
              <th class="p-3 text-left">Onboarding ID</th>
              <th class="p-3 text-left">Applicant ID</th>
              <th class="p-3 text-left">Name</th>
              <th class="p-3 text-left">Department</th>
              <th class="p-3 text-left">Created At</th>
            </tr>
          </thead>
          <tbody class="text-gray-700">
            <?php if (count($rows) > 0): ?>
              <?php foreach ($rows as $r): ?>
                <tr class="border-b hover:bg-slate-50">
                  <td class="p-3"><?= htmlspecialchars($r['onboarding_id']) ?></td>
                  <td class="p-3"><?= htmlspecialchars($r['applicant_id']) ?></td>
                  <td class="p-3 font-medium"><?= htmlspecialchars($r['name']) ?></td>
                  <td class="p-3"><?= htmlspecialchars($r['department']) ?></td>
                  <td class="p-3 text-xs text-gray-500"><?= htmlspecialchars($r['created_at']) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="5" class="p-4 text-center text-gray-500">
                  No records found.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </main>
  </div>
</div>

</body>
</html>
