<?php
// fetch_employees.php — acts as a proxy to avoid CORS issues
header("Content-Type: application/json");

$url = "https://hr1.atierahotelandrestaurant.com/api/api_onboarding.php?endpoint=onboarding";
$response = file_get_contents($url);

if ($response === FALSE) {
  echo json_encode(["error" => "Failed to connect to API"]);
  exit;
}

echo $response;
?>
