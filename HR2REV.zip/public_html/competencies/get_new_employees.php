<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $sql = "SELECT onboarding_id, employee_id, name, position FROM new_employees ORDER BY created_at DESC";
    $result = $conn->query($sql);

    $newEmployees = [];
    if($result && $result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $newEmployees[] = $row;
        }
    }

    echo json_encode($newEmployees);
    $conn->close();

} catch(Exception $e){
    echo json_encode(['error' => $e->getMessage()]);
}
