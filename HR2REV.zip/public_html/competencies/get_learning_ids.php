<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Get all proceeded entries from onboarding_competencies
    $result = $conn->query("SELECT applicant_id FROM onboarding_competencies WHERE status = 'Proceeded'");

    $ids = [];

    if($result){
        while($row = $result->fetch_assoc()){
            if(!empty($row['applicant_id'])){
                // Ensure it's a string for JS comparison
                $ids[] = (string)$row['applicant_id'];
            }
        }
    }

    echo json_encode($ids);

} catch (Exception $e) {
    echo json_encode([]);
}
?>
