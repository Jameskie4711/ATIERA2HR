<?php
include('../dblogin.php'); // make sure this points to your DB connection file

header('Content-Type: text/html; charset=UTF-8');

// Optional: get employee ID if passed via GET
$employee_id = $_GET['employee_id'] ?? null;

try {
  if ($employee_id) {
    $stmt = $conn->prepare("SELECT Applicant_ID, Resume, SSS, PhilHealth, PagIbig FROM applicant_documents WHERE Applicant_ID = ?");
    $stmt->execute([$employee_id]);
  } else {
    // fallback for testing (shows latest document)
    $stmt = $conn->prepare("SELECT Applicant_ID, Resume, SSS, PhilHealth, PagIbig FROM applicant_documents ORDER BY Applicant_ID DESC LIMIT 1");
    $stmt->execute();
  }

  $doc = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$doc) {
    echo "<p class='text-center text-gray-500'>No assessment data found.</p>";
    exit;
  }
?>
<div class="space-y-3">
  <div class="border-b pb-2">
    <p><strong>Applicant ID:</strong> <?= htmlspecialchars($doc['Applicant_ID']) ?></p>
  </div>

  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
    <div>
      <p class="font-medium text-gray-700">Resume:</p>
      <?php if (!empty($doc['Resume'])): ?>
        <a href="/uploads/<?= htmlspecialchars($doc['Resume']) ?>" target="_blank" class="text-blue-600 underline">View File</a>
      <?php else: ?>
        <p class="text-gray-500 text-sm">No file uploaded</p>
      <?php endif; ?>
    </div>

    <div>
      <p class="font-medium text-gray-700">SSS:</p>
      <?php if (!empty($doc['SSS'])): ?>
        <a href="/uploads/<?= htmlspecialchars($doc['SSS']) ?>" target="_blank" class="text-blue-600 underline">View File</a>
      <?php else: ?>
        <p class="text-gray-500 text-sm">No file uploaded</p>
      <?php endif; ?>
    </div>

    <div>
      <p class="font-medium text-gray-700">PhilHealth:</p>
      <?php if (!empty($doc['PhilHealth'])): ?>
        <a href="/uploads/<?= htmlspecialchars($doc['PhilHealth']) ?>" target="_blank" class="text-blue-600 underline">View File</a>
      <?php else: ?>
        <p class="text-gray-500 text-sm">No file uploaded</p>
      <?php endif; ?>
    </div>

    <div>
      <p class="font-medium text-gray-700">Pag-IBIG:</p>
      <?php if (!empty($doc['PagIbig'])): ?>
        <a href="/uploads/<?= htmlspecialchars($doc['PagIbig']) ?>" target="_blank" class="text-blue-600 underline">View File</a>
      <?php else: ?>
        <p class="text-gray-500 text-sm">No file uploaded</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php
} catch (PDOException $e) {
  echo "<p class='text-center text-red-500'>Error loading assessment: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
