<?php
include('../session_check.php'); 
include('../dblogin.php'); 
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Level labels mapping
$levelLabels = [1=>'Beginner',2=>'Intermediate',3=>'Advanced',4=>'Expert'];

// Fetch employee competencies
function getEmployeeCompetencies($conn, $employee_id = null) {
    if(!empty($employee_id)){
        $stmt = $conn->prepare("SELECT * FROM onboarding_competencies WHERE applicant_id=?");
        $stmt->bind_param("i", $employee_id);
    } else {
        $stmt = $conn->prepare("SELECT * FROM onboarding_competencies");
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $competencies = [];
    while($row = $result->fetch_assoc()){
        $competencies[] = [
             'competency_id' => $row['competency_id'],
             'employee_id'   => $row['applicant_id'],  // use applicant_id as employee_id
             'applicant_id'  => $row['applicant_id'],
             'name'          => $row['name'],
             'department'    => $row['department'] ?? '',
             'required_level'=> $row['required_level'] ?? 3,
             'status'        => $row['status'] ?? 'Pending'
        ];
            
    }
    return $competencies;
}

// Use employee_id for filtering
$employee_id = $_GET['employee_id'] ?? '';
$employeeCompetencies = getEmployeeCompetencies($conn, $employee_id);
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Gap Analysis</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" type="image/png" href="/web/picture/logo2.png" />
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  }
  
  .glass-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
  }
  
  .gradient-bg {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    transition: all 0.3s ease;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
  }
  
  .btn-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
  }
  
  .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
  }
  
  .btn-danger {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    transition: all 0.3s ease;
  }
  
  .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 10px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
  }
  
  .highlight-card {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }
  
  .highlight-card:hover {
    transform: translateX(5px);
    border-left-color: #3b82f6;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  }
  
  .status-badge {
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  
  .table-row-hover:hover {
    background: linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.02) 100%);
  }
  
  .modal-enter {
    animation: modalEnter 0.3s ease-out;
  }
  
  @keyframes modalEnter {
    from {
      opacity: 0;
      transform: scale(0.95) translateY(-20px);
    }
    to {
      opacity: 1;
      transform: scale(1) translateY(0);
    }
  }
</style>
<script>
document.addEventListener("DOMContentLoaded", ()=>{
    lucide.createIcons();

    const current = '<?= $currentPage ?>';
    document.querySelectorAll('.submodule-link').forEach(link=>{
        if(link.dataset.page === current){
            link.classList.add('bg-gray-700');
            const icon = link.querySelector('i');
            if(icon) icon.setAttribute('stroke', 'white');
        }
    });
});
</script>
</head>
<body class="h-screen overflow-hidden">
<div class="flex h-full">
<?php include '../sidebar.php'; ?>
<div class="flex-1 flex flex-col overflow-y-auto">
<main class="p-6 space-y-6 max-w-7xl mx-auto w-full">

<!-- Enhanced Header -->
<div class="flex items-center justify-between">
    <div class="flex items-center gap-4">
        <div class="p-3 rounded-xl bg-gradient-to-br from-indigo-50 to-purple-50">
            <i data-lucide="clipboard-check" class="w-7 h-7 text-indigo-600"></i>
        </div>
        <div>
            <h2 class="text-2xl font-bold text-gray-900">Competency Gap Analysis</h2>
            <p class="text-sm text-gray-500">Review and assess competency criteria for employees</p>
        </div>
    </div>
    <?php include '../profile.php'; ?>
</div>

<!-- Submodule Header -->
<div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-lg">
    <a href="/competencies/competencies.php" data-page="competencies.php" class="submodule-link hover:bg-gray-700 px-3 py-1 rounded flex items-center gap-2">
        <i data-lucide="list-check" class="w-4 h-4"></i> Competencies
    </a>
    <a href="/competencies/gap_analysis.php" data-page="gap_analysis.php" class="submodule-link hover:bg-gray-700 px-3 py-1 rounded flex items-center gap-2">
        <i data-lucide="clipboard" class="w-4 h-4"></i> Criteria
    </a>
    <a href="/competencies/record.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
        <i data-lucide="file-text" class="w-4 h-4"></i> Record
    </a>
</div>

<!-- Summary Cards -->
<div class="grid grid-cols-3 gap-4">
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Competencies</p>
                <p class="text-2xl font-bold text-gray-900"><?= count($employeeCompetencies) ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-xl">
                <i data-lucide="award" class="w-6 h-6 text-blue-600"></i>
            </div>
        </div>
    </div>
    
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Pending</p>
                <p class="text-2xl font-bold text-gray-900">
                    <?= count(array_filter($employeeCompetencies, fn($c) => strtolower($c['status']) === 'pending')) ?>
                </p>
            </div>
            <div class="p-3 bg-yellow-50 rounded-xl">
                <i data-lucide="clock" class="w-6 h-6 text-yellow-600"></i>
            </div>
        </div>
    </div>
    
    <div class="glass-card rounded-2xl p-4 border border-gray-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Completed</p>
                <p class="text-2xl font-bold text-gray-900">
                    <?= count(array_filter($employeeCompetencies, fn($c) => strtolower($c['status']) === 'completed')) ?>
                </p>
            </div>
            <div class="p-3 bg-green-50 rounded-xl">
                <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
        </div>
    </div>
</div>

<!-- Competencies Table -->
<div class="glass-card rounded-2xl p-6 shadow-lg border border-gray-100">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <i data-lucide="table" class="w-5 h-5 text-indigo-600"></i>
                Competency Records
            </h3>
            <p class="text-sm text-gray-500 mt-1">Manage and assess employee competencies</p>
        </div>
        <?php if($employee_id): ?>
        <div class="px-4 py-2 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-100">
            <p class="text-sm text-gray-700">
                <span class="font-medium">Employee Filter:</span> 
                <span class="text-indigo-600"><?= htmlspecialchars($employee_id) ?></span>
            </p>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="overflow-hidden rounded-xl border border-gray-200">
        <table class="w-full">
            <thead class="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr>
                    <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Employee ID</th>
                    <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Name</th>
                    <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Required Level</th>
                    <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Status</th>
                    <th class="py-4 px-6 text-left text-sm font-semibold text-gray-700">Actions</th>
                </tr>
            </thead>
            <tbody id="criteriaTable" class="divide-y divide-gray-100">
                <?php if(empty($employeeCompetencies)): ?>
                <tr>
                    <td colspan="5" class="text-center py-12">
                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                            <i data-lucide="inbox" class="w-8 h-8 text-gray-400"></i>
                        </div>
                        <h3 class="text-lg font-medium text-gray-700 mb-2">No Competencies Found</h3>
                        <p class="text-gray-500 max-w-md mx-auto">
                            <?= $employee_id ? "No competencies found for employee {$employee_id}" : "No competency records available" ?>
                        </p>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach($employeeCompetencies as $c): ?>
                <tr class="table-row-hover openModalBtn cursor-pointer transition-colors duration-200"
                    data-row-id="<?= $c['competency_id'] ?>"
                    data-id="<?= htmlspecialchars($c['applicant_id']) ?>"
                    data-employee-id="<?= htmlspecialchars($c['employee_id']) ?>"
                    data-name="<?= htmlspecialchars($c['name']) ?>"
                    data-department="<?= htmlspecialchars($c['department']) ?>"
                    data-required="<?= $c['required_level'] ?>"
                    data-status="<?= $c['status'] ?>">
                    
                    <td class="py-4 px-6">
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                            <span class="font-mono text-gray-700"><?= htmlspecialchars($c['employee_id']) ?></span>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center">
                                <i data-lucide="user" class="w-4 h-4 text-indigo-600"></i>
                            </div>
                            <div>
                                <div class="font-medium text-gray-900"><?= htmlspecialchars($c['name']) ?></div>
                                <div class="text-xs text-gray-500"><?= htmlspecialchars($c['department']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex items-center gap-2">
                            <div class="px-3 py-1 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                                <span class="text-sm font-medium text-blue-700"><?= $levelLabels[$c['required_level']] ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <?php
                        $status = strtolower($c['status']);
                        $statusConfig = [
                            'pending' => ['class' => 'bg-yellow-100 text-yellow-800', 'icon' => 'clock'],
                            'completed' => ['class' => 'bg-green-100 text-green-800', 'icon' => 'check-circle'],
                            'default' => ['class' => 'bg-red-100 text-red-800', 'icon' => 'alert-circle']
                        ];
                        $config = $statusConfig[$status] ?? $statusConfig['default'];
                        ?>
                        <div class="status-badge <?= $config['class'] ?>">
                            <i data-lucide="<?= $config['icon'] ?>" class="w-3 h-3"></i>
                            <?= $c['status'] ?>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex gap-2">
                            <button class="btn-primary px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2 editBtn">
                                <i data-lucide="edit" class="w-4 h-4"></i> Edit
                            </button>
                            <button class="btn-danger px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2 deleteBtn">
                                <i data-lucide="trash-2" class="w-4 h-4"></i> Delete
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</main>
</div>
</div>

<!-- Enhanced Edit Modal -->
<div id="employeeModal" class="fixed inset-0 bg-black bg-opacity-40 hidden flex items-center justify-center z-50 backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-96 p-8 shadow-2xl modal-enter">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
                <div class="p-2 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg">
                    <i data-lucide="edit-2" class="w-5 h-5 text-indigo-600"></i>
                </div>
                <div>
                    <h3 class="text-xl font-bold text-gray-900">Edit Competency</h3>
                    <p class="text-sm text-gray-500">Update competency details</p>
                </div>
            </div>
            <button id="closeModal" class="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="x" class="w-5 h-5 text-gray-500"></i>
            </button>
        </div>
        
        <input type="hidden" id="modalRowId">
        
        <div class="space-y-4 mb-6">
            <!-- Employee Info Card -->
            <div class="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                        <i data-lucide="user" class="w-5 h-5 text-white"></i>
                    </div>
                    <div>
                        <div class="font-semibold text-gray-900" id="modalEmpName"></div>
                        <div class="text-sm text-gray-600" id="modalEmpDept"></div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div class="text-sm">
                        <div class="text-gray-500">Employee ID</div>
                        <div class="font-medium text-gray-900" id="modalEmpId"></div>
                    </div>
                    <div class="text-sm">
                        <div class="text-gray-500">Status</div>
                        <div id="modalEmpStatus" class="font-medium"></div>
                    </div>
                </div>
            </div>
            
            <!-- Required Level Selector -->
            <div class="space-y-2">
                <label class="block text-sm font-medium text-gray-700">Required Level</label>
                <select id="modalEmpReq" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                    <option value="1">Beginner</option>
                    <option value="2">Intermediate</option>
                    <option value="3">Advanced</option>
                    <option value="4">Expert</option>
                </select>
            </div>
        </div>
        
        <div class="flex gap-3">
            <button id="saveChanges" class="flex-1 btn-primary px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                <i data-lucide="save" class="w-4 h-4"></i> Save Changes
            </button>
            <button id="proceedBtn" class="flex-1 btn-success px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                <svg id="proceedSpinner" class="hidden animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                <i data-lucide="arrow-right" class="w-4 h-4" id="proceedIcon"></i>
                <span id="proceedText">Proceed</span>
            </button>
            <button id="closeModalBtn" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Enhanced Delete Modal -->
<div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-40 hidden z-50 flex items-center justify-center backdrop-blur-sm">
    <div class="glass-card rounded-2xl w-96 p-8 shadow-2xl modal-enter">
        <div class="text-center mb-6">
            <div class="mx-auto w-16 h-16 bg-gradient-to-br from-red-50 to-pink-50 rounded-full flex items-center justify-center mb-4">
                <i data-lucide="alert-triangle" class="w-8 h-8 text-red-600"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Confirm Deletion</h3>
            <p id="deleteMessage" class="text-gray-600 mb-2">Are you sure you want to delete this competency?</p>
            <p class="text-sm text-gray-500">This action cannot be undone.</p>
        </div>
        <div class="flex gap-3">
            <button id="cancelDelete" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Cancel
            </button>
            <button id="confirmDelete" class="flex-1 btn-danger px-4 py-3 rounded-xl text-white font-medium flex items-center justify-center gap-2">
                <i data-lucide="trash-2" class="w-4 h-4"></i> Delete
            </button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" class="fixed bottom-6 right-6 flex flex-col gap-2 z-50"></div>

<script>
// Toast function
function showToast(message, type='success', duration=3000){
    const toastContainer = document.getElementById('toastContainer');
    const colors = { 
        success: 'bg-gradient-to-r from-green-500 to-emerald-600', 
        error: 'bg-gradient-to-r from-red-500 to-rose-600', 
        info: 'bg-gradient-to-r from-blue-500 to-indigo-600' 
    };
    const icons = {
        success: 'check-circle',
        error: 'alert-circle',
        info: 'info'
    };
    
    const toast = document.createElement('div');
    toast.className = `text-white px-4 py-3 rounded-xl shadow-lg ${colors[type]||'bg-gray-500'} opacity-0 transform translate-y-4 transition-all duration-300 flex items-center gap-3`;
    
    toast.innerHTML = `
        <i data-lucide="${icons[type] || 'info'}" class="w-5 h-5"></i>
        <span>${message}</span>
    `;
    
    toastContainer.appendChild(toast);
    lucide.createIcons();
    
    requestAnimationFrame(() => { 
        toast.classList.remove('opacity-0', 'translate-y-4'); 
        toast.classList.add('opacity-100', 'translate-y-0'); 
    });
    
    setTimeout(() => {
        toast.classList.remove('opacity-100', 'translate-y-0'); 
        toast.classList.add('opacity-0', 'translate-y-4'); 
        toast.addEventListener('transitionend', () => toast.remove());
    }, duration);
}

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('employeeModal');
    const closeModal = document.getElementById('closeModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const saveBtn = document.getElementById('saveChanges');
    const proceedBtn = document.getElementById('proceedBtn');
    const modalRowIdInput = document.getElementById('modalRowId');
    const modalEmpReq = document.getElementById('modalEmpReq');
    const modalEmpStatus = document.getElementById('modalEmpStatus');
    const modalEmpId = document.getElementById('modalEmpId');
    const modalEmpName = document.getElementById('modalEmpName');
    const modalEmpDept = document.getElementById('modalEmpDept');
    const levelMap = {1:'Beginner',2:'Intermediate',3:'Advanced',4:'Expert'};

    // Open Edit Modal
    document.querySelectorAll('.openModalBtn').forEach(row => {
        row.addEventListener('click', e => {
            if(e.target.closest('.deleteBtn')) return;
            modal.classList.remove('hidden');
            
            modalRowIdInput.value = row.dataset.rowId;
            modalEmpId.textContent = row.dataset.employeeId;
            modalEmpName.textContent = row.dataset.name;
            modalEmpDept.textContent = row.dataset.department;
            modalEmpReq.value = row.dataset.required;

            const status = row.dataset.status.toLowerCase();
            modalEmpStatus.textContent = row.dataset.status;
            modalEmpStatus.className = 'font-medium ' + (
                status === 'pending' ? 'text-yellow-600' :
                status === 'completed' ? 'text-green-600' :
                'text-red-600'
            );
        });
    });

    closeModal.addEventListener('click', () => modal.classList.add('hidden'));
    closeModalBtn.addEventListener('click', () => modal.classList.add('hidden'));
    window.addEventListener('click', e => {
        if(e.target.id === 'employeeModal') modal.classList.add('hidden');
    });

    // Save functionality
    saveBtn.addEventListener('click', () => {
        const newLevel = modalEmpReq.value;
        const rowId = modalRowIdInput.value;
        
        document.querySelectorAll('#criteriaTable tr').forEach(row => {
            if(row.dataset.rowId === rowId){
                row.dataset.required = newLevel;
                row.querySelector('td:nth-child(3) .text-blue-700').textContent = levelMap[newLevel];
                showToast('Competency updated successfully', 'success');
            }
        });
        
        modal.classList.add('hidden');
    });

    // Proceed functionality with spinner + toast
    proceedBtn.addEventListener('click', () => {
        const rowId = modalRowIdInput.value;
        const employeeId = modalEmpId.textContent;
        const requiredLevel = modalEmpReq.value;

        const spinner = document.getElementById('proceedSpinner');
        const icon = document.getElementById('proceedIcon');
        const text = document.getElementById('proceedText');

        proceedBtn.disabled = true;
        spinner.classList.remove('hidden');
        icon.classList.add('hidden');
        text.textContent = 'Processing...';
        proceedBtn.classList.add('opacity-70', 'cursor-not-allowed');

        fetch('/competencies/proceed_to_learning_emp.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ 
                competency_id: rowId, 
                employee_id: employeeId, 
                required_level: requiredLevel 
            })
        })
        .then(res => res.json())
        .then(resp => {
            if(resp.success){
                document.querySelectorAll('#criteriaTable tr').forEach(row => {
                    if(row.dataset.rowId === rowId){
                        row.classList.add('opacity-50');
                        setTimeout(() => row.remove(), 300);
                    }
                });
                modal.classList.add('hidden');
                showToast('Successfully proceeded to learning module', 'success');
            } else {
                showToast('Error: ' + resp.message, 'error');
            }
        })
        .catch(err => {
            console.error(err);
            showToast('Failed to proceed. Please try again.', 'error');
        })
        .finally(() => {
            proceedBtn.disabled = false;
            spinner.classList.add('hidden');
            icon.classList.remove('hidden');
            text.textContent = 'Proceed';
            proceedBtn.classList.remove('opacity-70', 'cursor-not-allowed');
        });
    });

    // Delete functionality
    const deleteModal = document.getElementById('deleteModal');
    const deleteMessage = document.getElementById('deleteMessage');
    const cancelDelete = document.getElementById('cancelDelete');
    const confirmDelete = document.getElementById('confirmDelete');
    let rowToDelete = null;

    document.querySelectorAll('.deleteBtn').forEach(btn => {
        btn.addEventListener('click', e => {
            e.stopPropagation();
            rowToDelete = e.target.closest('tr');
            const empName = rowToDelete.dataset.name;
            deleteMessage.textContent = `Delete competency for "${empName}"?`;
            deleteModal.classList.remove('hidden');
        });
    });

    cancelDelete.addEventListener('click', () => {
        deleteModal.classList.add('hidden');
        rowToDelete = null;
    });

    confirmDelete.addEventListener('click', () => {
        if(!rowToDelete) return;
        const competencyId = rowToDelete.dataset.rowId;
        
        confirmDelete.disabled = true;
        confirmDelete.classList.add('opacity-70', 'cursor-not-allowed');
        confirmDelete.innerHTML = '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Deleting...';
        lucide.createIcons();

        fetch('/competencies/delete_competency.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({competency_id: competencyId})
        })
        .then(res => res.json())
        .then(resp => {
            if(resp.success){
                rowToDelete.remove();
                deleteModal.classList.add('hidden');
                showToast('Competency deleted successfully', 'success');
                
                // Update summary counts
                const pendingCount = document.querySelectorAll('.status-badge.bg-yellow-100').length;
                const completedCount = document.querySelectorAll('.status-badge.bg-green-100').length;
                
                document.querySelectorAll('p.text-2xl.font-bold')[0].textContent = 
                    document.querySelectorAll('#criteriaTable tr').length - 1; // minus empty row
                document.querySelectorAll('p.text-2xl.font-bold')[1].textContent = pendingCount;
                document.querySelectorAll('p.text-2xl.font-bold')[2].textContent = completedCount;
            } else {
                showToast('Error: ' + resp.message, 'error');
            }
            rowToDelete = null;
        })
        .catch(err => {
            console.error(err);
            showToast('Failed to delete competency', 'error');
            rowToDelete = null;
        })
        .finally(() => {
            confirmDelete.disabled = false;
            confirmDelete.classList.remove('opacity-70', 'cursor-not-allowed');
            confirmDelete.innerHTML = '<i data-lucide="trash-2" class="w-4 h-4"></i> Delete';
            lucide.createIcons();
        });
    });

    window.addEventListener('click', e => {
        if(e.target.id === 'deleteModal'){
            deleteModal.classList.add('hidden');
            rowToDelete = null;
        }
    });
});
</script>
</body>
</html>