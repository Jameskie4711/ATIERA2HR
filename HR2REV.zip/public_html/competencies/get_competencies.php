<?php
include('../db.php');
header('Content-Type: application/json');

try {
    $result = $conn->query("SELECT onboarding_id, applicant_id, name, department FROM onboarding_competencies ORDER BY name ASC");

    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }

    echo json_encode($employees);
} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
