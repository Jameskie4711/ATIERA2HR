<?php
include('../dblogin.php');
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

$employee_id   = $data['employee_id'] ?? 0;
$employee_name = $data['employee_name'] ?? '';
$department    = $data['department'] ?? '';
$competency_gap = $data['competency_gap'] ?? '';

if (!$employee_id || !$employee_name) {
    echo json_encode(['status'=>'error','message'=>'Invalid employee ID or name']);
    exit;
}

try {
    // Insert into learning_emp table
    $stmt = $conn->prepare("
        INSERT INTO learning_emp (id, employee_name, department, competency_gap /*, created_at */) 
        VALUES (?, ?, ?, ? /*, NOW() */)
    ");
    $stmt->bind_param("isss", $employee_id, $employee_name, $department, $competency_gap /*, $created_at */);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['status'=>'success','message'=>'Employee moved to Learning successfully!']);
} catch(Exception $e) {
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}
?>
