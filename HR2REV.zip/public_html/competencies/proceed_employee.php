<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents('php://input'), true);

if(!$data || !isset($data['employee_id'], $data['onboarding_id'])){
    echo json_encode(['status' => 'error', 'message' => 'Invalid request: missing employee_id or onboarding_id']);
    exit;
}

$applicant_id   = $data['employee_id'];
$onboarding_id  = $data['onboarding_id'];
$name           = $data['name'] ?? '';
$position       = $data['position'] ?? '';
$current_level  = $data['current_level'] ?? 1;
$required_level = $data['required_level'] ?? 3;

try {
    // Check if already in new_employees
    $checkStmt = $conn->prepare("SELECT id FROM new_employees WHERE employee_id=? AND onboarding_id=?");
    $checkStmt->bind_param("ss", $applicant_id, $onboarding_id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if($checkResult->num_rows > 0){
        echo json_encode(['status'=>'error', 'message'=>'Employee already proceeded.']);
        exit;
    }

    // Insert into new_employees
    $stmt = $conn->prepare("
        INSERT INTO new_employees 
        (onboarding_id, employee_id, name, position, current_level, required_level, created_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("ssssii", $onboarding_id, $applicant_id, $name, $position, $current_level, $required_level);

    if($stmt->execute()){
        // Return the inserted employee so frontend can append immediately
        $insertedEmployee = [
            'onboarding_id' => $onboarding_id,
            'employee_id'   => $applicant_id,
            'name'          => $name,
            'position'      => $position,
            'current_level' => $current_level,
            'required_level'=> $required_level
        ];

        echo json_encode([
            'status'   => 'success',
            'message'  => 'Employee successfully proceeded.',
            'employee' => $insertedEmployee
        ]);
    } else {
        echo json_encode(['status'=>'error','message'=>'Failed to insert employee: '.$stmt->error]);
    }

    $stmt->close();
    $checkStmt->close();
    $conn->close();

} catch(Exception $e){
    echo json_encode(['status'=>'error','message'=>'Exception: '.$e->getMessage()]);
}
?>
