<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');

// Fetch records directly from database
$records = [];
$departments = [];
$stats = [
    'total' => 0,
    'completed' => 0,
    'in_progress' => 0,
    'pending' => 0,
    'failed' => 0
];

try {
    // Check if table exists
    $check_table = $conn->query("SHOW TABLES LIKE 'competency_records'");
    
    if ($check_table && $check_table->num_rows > 0) {
        // Get filter parameters
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $department = $_GET['department'] ?? '';
        $date_range = $_GET['date_range'] ?? '';
        
        // Build query
        $sql = "SELECT 
                    id,
                    employee_id,
                    employee_name,
                    position,
                    department,
                    status,
                    DATE_FORMAT(start_date, '%Y-%m-%d') as start_date,
                    DATE_FORMAT(last_updated, '%Y-%m-%d') as last_updated,
                    notes,
                    created_at
                FROM competency_records 
                WHERE 1=1";
        
        $params = [];
        $types = '';
        
        // Apply search filter
        if (!empty($search)) {
            $sql .= " AND (
                employee_id LIKE ? OR 
                employee_name LIKE ? OR 
                position LIKE ? OR 
                department LIKE ?
            )";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $types .= 'ssss';
        }
        
        // Apply status filter
        if (!empty($status) && in_array($status, ['pending', 'in-progress', 'completed', 'failed'])) {
            $sql .= " AND status = ?";
            $params[] = $status;
            $types .= 's';
        }
        
        // Apply department filter
        if (!empty($department)) {
            $sql .= " AND department = ?";
            $params[] = $department;
            $types .= 's';
        }
        
        // Apply date range filter
        if (!empty($date_range)) {
            switch ($date_range) {
                case 'today':
                    $sql .= " AND DATE(last_updated) = CURDATE()";
                    break;
                case 'week':
                    $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
                    break;
                case 'month':
                    $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
                    break;
                case 'quarter':
                    $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
                    break;
                case 'year':
                    $sql .= " AND last_updated >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)";
                    break;
            }
        }
        
        $sql .= " ORDER BY last_updated DESC";
        
        // Execute query
        if (!empty($params)) {
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $result = $stmt->get_result();
        } else {
            $result = $conn->query($sql);
        }
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
        }
        
        // Get stats
        $stats_sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                        SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
                      FROM competency_records";
        
        $stats_result = $conn->query($stats_sql);
        if ($stats_result) {
            $stats = $stats_result->fetch_assoc();
        }
        
        // Get unique departments
        $dept_sql = "SELECT DISTINCT department FROM competency_records WHERE department IS NOT NULL AND department != '' ORDER BY department";
        $dept_result = $conn->query($dept_sql);
        if ($dept_result) {
            while ($dept = $dept_result->fetch_assoc()) {
                $departments[] = $dept['department'];
            }
        }
    }
} catch (Exception $e) {
    $error_message = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Competency Records</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="icon" type="image/png" href="/web/picture/logo2.png" />
<script>
document.addEventListener("DOMContentLoaded", function () {
    lucide.createIcons();
});
</script>

<style>
/* Additional styling for records */
.status-completed { background-color: #10b981; color: white; }
.status-pending { background-color: #f59e0b; color: white; }
.status-failed { background-color: #ef4444; color: white; }
.status-in-progress { background-color: #3b82f6; color: white; }

/* Modal animations */
@keyframes modalFadeIn {
    from { opacity: 0; transform: translateY(-20px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

@keyframes backdropFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.modal-enter {
    animation: modalFadeIn 0.3s ease-out forwards;
}

.backdrop-enter {
    animation: backdropFadeIn 0.2s ease-out forwards;
}
</style>

</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">

<div class="flex h-full">
  <?php include '../sidebar.php'; ?>

  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-4 max-w-7xl mx-auto">

      <!-- Header -->
      <div class="flex items-center justify-between border-b pb-4">
        <div>
          <h2 class="text-2xl font-extrabold text-gray-800 flex items-center gap-2">
            <i data-lucide="file-text" class="w-6 h-6"></i> Competency Records
          </h2>
        </div>
        <?php include '../profile.php'; ?>
      </div>

      <!-- Submodule Header -->
      <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
        <a href="/competencies/competencies.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
          <i data-lucide="list-check" class="w-4 h-4"></i> Competencies
        </a>
        <a href="/competencies/gap_analysis.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
          <i data-lucide="clipboard" class="w-4 h-4"></i> Criteria
        </a>
        <a href="/competencies/record.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2 bg-gray-700">
          <i data-lucide="file-text" class="w-4 h-4"></i> Record
        </a>
      </div>

      <!-- Filters and Actions -->
      <form method="GET" action="" class="flex flex-wrap gap-4 items-center justify-between bg-white p-4 rounded-lg shadow-sm">
        <div class="flex flex-wrap gap-3">
          <div class="relative">
            <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4"></i>
            <input type="text" name="search" id="searchInput" placeholder="Search records..." 
                   value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" 
                   class="pl-10 pr-4 py-2 border rounded-lg text-sm w-64">
          </div>
          
          <select name="status" id="statusFilter" class="border rounded-lg px-3 py-2 text-sm">
            <option value="">All Status</option>
            <option value="completed" <?= ($_GET['status'] ?? '') == 'completed' ? 'selected' : '' ?>>Completed</option>
            <option value="pending" <?= ($_GET['status'] ?? '') == 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="in-progress" <?= ($_GET['status'] ?? '') == 'in-progress' ? 'selected' : '' ?>>In Progress</option>
            <option value="failed" <?= ($_GET['status'] ?? '') == 'failed' ? 'selected' : '' ?>>Failed</option>
          </select>
          
          <select name="department" id="departmentFilter" class="border rounded-lg px-3 py-2 text-sm">
            <option value="">All Departments</option>
            <?php foreach ($departments as $dept): ?>
                <option value="<?= htmlspecialchars($dept) ?>" 
                        <?= ($_GET['department'] ?? '') == $dept ? 'selected' : '' ?>>
                    <?= htmlspecialchars($dept) ?>
                </option>
            <?php endforeach; ?>
          </select>
          
          <select name="date_range" id="dateFilter" class="border rounded-lg px-3 py-2 text-sm">
            <option value="">All Time</option>
            <option value="today" <?= ($_GET['date_range'] ?? '') == 'today' ? 'selected' : '' ?>>Today</option>
            <option value="week" <?= ($_GET['date_range'] ?? '') == 'week' ? 'selected' : '' ?>>This Week</option>
            <option value="month" <?= ($_GET['date_range'] ?? '') == 'month' ? 'selected' : '' ?>>This Month</option>
            <option value="quarter" <?= ($_GET['date_range'] ?? '') == 'quarter' ? 'selected' : '' ?>>This Quarter</option>
            <option value="year" <?= ($_GET['date_range'] ?? '') == 'year' ? 'selected' : '' ?>>This Year</option>
          </select>
        </div>
        
        <div class="flex gap-2">
          <button type="button" id="exportBtn" class="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
            <i data-lucide="download" class="w-4 h-4"></i> Export
          </button>
          <button type="submit" class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            <i data-lucide="filter" class="w-4 h-4"></i> Apply Filters
          </button>
          <a href="record.php" class="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition">
            <i data-lucide="refresh-cw" class="w-4 h-4"></i> Reset
          </a>
        </div>
      </form>

      <!-- Stats Summary -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white p-4 rounded-lg shadow-sm border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Total Records</p>
              <p class="text-2xl font-bold"><?= $stats['total'] ?? 0 ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-full">
              <i data-lucide="file-text" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
        
        <div class="bg-white p-4 rounded-lg shadow-sm border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Completed</p>
              <p class="text-2xl font-bold text-green-600"><?= $stats['completed'] ?? 0 ?></p>
            </div>
            <div class="p-3 bg-green-50 rounded-full">
              <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
            </div>
          </div>
        </div>
        
        <div class="bg-white p-4 rounded-lg shadow-sm border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">In Progress</p>
              <p class="text-2xl font-bold text-blue-600"><?= $stats['in_progress'] ?? 0 ?></p>
            </div>
            <div class="p-3 bg-blue-50 rounded-full">
              <i data-lucide="clock" class="w-6 h-6 text-blue-600"></i>
            </div>
          </div>
        </div>
        
        <div class="bg-white p-4 rounded-lg shadow-sm border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500">Pending + Failed</p>
              <p class="text-2xl font-bold text-amber-600"><?= ($stats['pending'] ?? 0) + ($stats['failed'] ?? 0) ?></p>
            </div>
            <div class="p-3 bg-amber-50 rounded-full">
              <i data-lucide="alert-circle" class="w-6 h-6 text-amber-600"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content - Records Table -->
      <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full border-collapse">
            <thead class="bg-gray-50">
              <tr class="text-left text-gray-600 text-sm">
                <th class="p-4 font-medium">Employee ID</th>
                <th class="p-4 font-medium">Employee Name</th>
                <th class="p-4 font-medium">Position</th>
                <th class="p-4 font-medium">Department</th>
                <th class="p-4 font-medium">Status</th>
                <th class="p-4 font-medium">Last Updated</th>
                <th class="p-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody id="recordsTable">
              <?php if (!empty($records)): ?>
                <?php foreach ($records as $record): ?>
                  <tr class="border-t hover:bg-gray-50 transition-colors">
                    <td class="p-4"><?= htmlspecialchars($record['employee_id']) ?></td>
                    <td class="p-4 font-medium"><?= htmlspecialchars($record['employee_name']) ?></td>
                    <td class="p-4"><?= htmlspecialchars($record['position']) ?></td>
                    <td class="p-4"><?= htmlspecialchars($record['department']) ?></td>
                    <td class="p-4">
                      <span class="inline-block px-3 py-1 rounded-full text-xs font-medium status-<?= $record['status'] ?>">
                        <?php 
                          $statusText = [
                            'completed' => 'Completed',
                            'pending' => 'Pending',
                            'in-progress' => 'In Progress',
                            'failed' => 'Failed'
                          ];
                          echo $statusText[$record['status']] ?? 'Pending';
                        ?>
                      </span>
                    </td>
                    <td class="p-4 text-sm text-gray-500">
                      <?= date('M d, Y', strtotime($record['last_updated'])) ?>
                    </td>
                    <td class="p-4">
                      <div class="flex gap-2">
                        <button onclick="viewRecordDetails(<?= $record['id'] ?>)" 
                                class="p-2 text-blue-600 hover:bg-blue-50 rounded">
                          <i data-lucide="eye" class="w-4 h-4"></i>
                        </button>
                        <button onclick="editRecord(<?= $record['id'] ?>)" 
                                class="p-2 text-green-600 hover:bg-green-50 rounded">
                          <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>
                        <button onclick="deleteRecord(<?= $record['id'] ?>)" 
                                class="p-2 text-red-600 hover:bg-red-50 rounded">
                          <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7" class="p-8 text-center text-gray-400">
                    <div class="flex flex-col items-center justify-center space-y-3">
                      <i data-lucide="file-search" class="w-12 h-12"></i>
                      <p>No records found</p>
                      <p class="text-sm"><?= isset($error_message) ? $error_message : 'Try adjusting your filters' ?></p>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        
        <!-- Pagination (simple version for server-side) -->
        <?php if (!empty($records)): ?>
        <div class="flex items-center justify-between p-4 border-t">
          <div class="text-sm text-gray-500">
            Showing <?= count($records) ?> records
          </div>
        </div>
        <?php endif; ?>
      </div>

    </main>
  </div>
</div>

<!-- View Details Modal -->
<div id="detailsModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
  <div class="bg-white rounded-lg w-11/12 max-w-4xl p-6 shadow-lg">
    <div class="flex justify-between items-center mb-6">
      <h3 class="text-xl font-semibold" id="detailTitle">Record Details</h3>
      <button onclick="closeDetailsModal()" class="text-gray-500 hover:text-gray-700">
        <i data-lucide="x" class="w-6 h-6"></i>
      </button>
    </div>
    
    <div class="space-y-6">
      <!-- Basic Info -->
      <div class="grid grid-cols-2 gap-4">
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Employee ID</p>
          <p class="font-medium" id="detailEmployeeId"></p>
        </div>
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Employee Name</p>
          <p class="font-medium" id="detailEmployeeName"></p>
        </div>
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Position</p>
          <p class="font-medium" id="detailPosition"></p>
        </div>
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Department</p>
          <p class="font-medium" id="detailDepartment"></p>
        </div>
      </div>
      
      <hr>
      
      <!-- Status and Dates -->
      <div class="grid grid-cols-2 gap-4">
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Status</p>
          <p class="font-medium" id="detailStatus"></p>
        </div>
        <div class="space-y-2">
          <p class="text-sm text-gray-500">Last Updated</p>
          <p class="font-medium" id="detailLastUpdated"></p>
        </div>
      </div>
      
      <hr>
      
      <!-- Timeline -->
      <div>
        <h4 class="font-medium mb-3">Assessment Timeline</h4>
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-2 h-2 bg-green-500 rounded-full"></div>
              <span class="text-sm">Assessment Started</span>
            </div>
            <span class="text-sm text-gray-500" id="detailStartDate"></span>
          </div>
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span class="text-sm">Last Evaluation</span>
            </div>
            <span class="text-sm text-gray-500" id="detailLastEvaluated"></span>
          </div>
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span class="text-sm">Expected Completion</span>
            </div>
            <span class="text-sm text-gray-500" id="detailCompletionDate"></span>
          </div>
        </div>
      </div>
      
      <!-- Notes -->
      <div>
        <h4 class="font-medium mb-3">Assessment Notes</h4>
        <div class="bg-gray-50 p-4 rounded-lg">
          <p id="detailNotes" class="text-sm">No notes available.</p>
        </div>
      </div>
    </div>
    
    <div class="flex justify-end gap-3 mt-8">
      <button onclick="closeDetailsModal()" class="px-4 py-2 border rounded hover:bg-gray-50 transition">Close</button>
      <button id="printDetailBtn" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Print</button>
    </div>
  </div>
</div>

<!-- Enhanced Delete Confirmation Modal -->
<div id="deleteConfirmationModal" class="fixed inset-0 bg-black bg-opacity-60 hidden items-center justify-center z-50 backdrop-blur-sm backdrop-enter">
  <div class="bg-white rounded-2xl w-full max-w-md p-8 shadow-2xl modal-enter">
    <div class="text-center mb-6">
      <div class="mx-auto w-20 h-20 bg-gradient-to-br from-red-50 to-pink-50 rounded-full flex items-center justify-center mb-5">
        <i data-lucide="alert-triangle" class="w-10 h-10 text-red-600"></i>
      </div>
      <h3 class="text-2xl font-bold text-gray-900 mb-3">Confirm Deletion</h3>
      <div class="space-y-4">
        <p class="text-gray-600 mb-2">Are you sure you want to delete this competency record?</p>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 text-left">
          <div class="flex items-start gap-3">
            <i data-lucide="alert-circle" class="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0"></i>
            <div>
              <p class="text-sm font-medium text-red-800 mb-1">Warning: This action is permanent</p>
              <p class="text-xs text-red-600">• All competency assessment data will be permanently removed</p>
              <p class="text-xs text-red-600">• This action cannot be undone or recovered</p>
              <p class="text-xs text-red-600">• Related progress tracking will be lost</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="flex flex-col sm:flex-row gap-3">
      <button onclick="closeDeleteModal()" 
              class="flex-1 px-5 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-all duration-200 flex items-center justify-center gap-2">
        <i data-lucide="x" class="w-4 h-4"></i> Cancel
      </button>
      <button id="confirmDeleteBtn" 
              class="flex-1 px-5 py-3 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 shadow-sm">
        <i data-lucide="trash-2" class="w-4 h-4"></i> Delete Permanently
      </button>
    </div>
  </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50 backdrop-blur-sm">
  <div class="bg-white rounded-2xl px-8 py-6 flex flex-col items-center gap-4 shadow-2xl">
    <div class="relative">
      <div class="w-16 h-16 border-4 border-blue-100 rounded-full"></div>
      <div class="w-16 h-16 border-4 border-transparent border-t-blue-600 rounded-full animate-spin absolute top-0 left-0"></div>
    </div>
    <div class="text-center">
      <p class="font-medium text-gray-800">Processing Request</p>
      <p class="text-sm text-gray-500 mt-1">Please wait while we delete the record...</p>
    </div>
  </div>
</div>

<script>
// Store records data for JavaScript access
const recordsData = <?= json_encode($records) ?>;
const departmentsData = <?= json_encode($departments) ?>;
const statsData = <?= json_encode($stats) ?>;

let recordToDelete = null;

function viewRecordDetails(recordId) {
    const record = recordsData.find(r => r.id == recordId);
    if (!record) return;
    
    // Calculate completion date (3 months after start date)
    let completionDate = 'N/A';
    if (record.start_date) {
        const start = new Date(record.start_date);
        start.setMonth(start.getMonth() + 3);
        completionDate = formatDate(start);
    }
    
    // Populate modal
    document.getElementById("detailTitle").textContent = `Record: ${record.employee_name || 'Unknown'}`;
    document.getElementById("detailEmployeeId").textContent = record.employee_id || 'N/A';
    document.getElementById("detailEmployeeName").textContent = record.employee_name || 'N/A';
    document.getElementById("detailPosition").textContent = record.position || 'N/A';
    document.getElementById("detailDepartment").textContent = record.department || 'N/A';
    document.getElementById("detailStatus").textContent = getStatusText(record.status);
    document.getElementById("detailStartDate").textContent = formatDate(record.start_date);
    document.getElementById("detailLastUpdated").textContent = formatDate(record.last_updated);
    document.getElementById("detailLastEvaluated").textContent = formatDate(record.last_updated);
    document.getElementById("detailCompletionDate").textContent = completionDate;
    document.getElementById("detailNotes").textContent = record.notes || 'No notes available.';
    
    // Show modal
    document.getElementById("detailsModal").classList.remove("hidden");
    document.getElementById("detailsModal").classList.add("flex");
}

function closeDetailsModal() {
    document.getElementById("detailsModal").classList.add("hidden");
    document.getElementById("detailsModal").classList.remove("flex");
}

function editRecord(recordId) {
    alert(`Edit record ${recordId} - This functionality needs to be implemented.`);
    // You would typically redirect to an edit page: window.location.href = `edit_record.php?id=${recordId}`;
}

function deleteRecord(recordId) {
    recordToDelete = recordId;
    
    // Show the custom confirmation modal
    document.getElementById("deleteConfirmationModal").classList.remove("hidden");
    document.getElementById("deleteConfirmationModal").classList.add("flex");
    
    // Reset and setup confirm button
    const confirmBtn = document.getElementById("confirmDeleteBtn");
    confirmBtn.innerHTML = '<i data-lucide="trash-2" class="w-4 h-4"></i> Delete Permanently';
    confirmBtn.onclick = processDelete;
    
    lucide.createIcons();
}

function closeDeleteModal() {
    recordToDelete = null;
    document.getElementById("deleteConfirmationModal").classList.add("hidden");
    document.getElementById("deleteConfirmationModal").classList.remove("flex");
}

function processDelete() {
    if (!recordToDelete) return;
    
    showLoading(true);
    
    // Update button to show loading state
    const confirmBtn = document.getElementById("confirmDeleteBtn");
    confirmBtn.innerHTML = '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Deleting...';
    confirmBtn.disabled = true;
    lucide.createIcons();
    
    // Submit form to delete record
    setTimeout(() => {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_record.php';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'id';
        input.value = recordToDelete;
        form.appendChild(input);
        
        document.body.appendChild(form);
        form.submit();
    }, 500); // Small delay for visual feedback
}

function getStatusText(status) {
    const statusMap = {
        'completed': 'Completed',
        'pending': 'Pending',
        'in-progress': 'In Progress',
        'failed': 'Failed'
    };
    return statusMap[status] || 'Pending';
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function showLoading(show) {
    const overlay = document.getElementById("loadingOverlay");
    if (show) {
        overlay.classList.remove("hidden");
        overlay.classList.add("flex");
    } else {
        overlay.classList.add("hidden");
        overlay.classList.remove("flex");
    }
}

// Export functionality
document.getElementById('exportBtn').addEventListener('click', function() {
    showLoading(true);
    
    // Build export URL with current filters
    const searchValue = document.getElementById('searchInput').value.trim();
    const statusValue = document.getElementById('statusFilter').value;
    const departmentValue = document.getElementById('departmentFilter').value;
    const dateValue = document.getElementById('dateFilter').value;
    
    let exportUrl = 'export_records.php?';
    const params = [];
    
    if (searchValue) params.push(`search=${encodeURIComponent(searchValue)}`);
    if (statusValue) params.push(`status=${encodeURIComponent(statusValue)}`);
    if (departmentValue) params.push(`department=${encodeURIComponent(departmentValue)}`);
    if (dateValue) params.push(`date_range=${encodeURIComponent(dateValue)}`);
    
    exportUrl += params.join('&');
    
    // Redirect to export script
    window.location.href = exportUrl;
    
    setTimeout(() => {
        showLoading(false);
    }, 1000);
});

// Initialize icons
document.addEventListener("DOMContentLoaded", function() {
    lucide.createIcons();
    
    // Close modals when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target.id === 'deleteConfirmationModal') {
            closeDeleteModal();
        }
        if (e.target.id === 'detailsModal') {
            closeDetailsModal();
        }
    });
});
</script>

</body>
</html>