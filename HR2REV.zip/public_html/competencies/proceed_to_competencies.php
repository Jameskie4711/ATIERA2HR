<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $employee_id = $_POST['employee_id'] ?? null; // EMP-ID
    $onboarding_id = $_POST['onboarding_id'] ?? null; // APP-ID
    $name = $_POST['name'] ?? null;
    $department = $_POST['department'] ?? null;
    $current_level = $_POST['current_level'] ?? null;
    $required_level = $_POST['required_level'] ?? null;

    if(!$employee_id || !$onboarding_id || !$name || !$department || !$current_level || !$required_level){
        echo json_encode(['success'=>false, 'message'=>'Missing required fields']);
        exit;
    }

    // Check if this employee has already been proceeded
    $stmt = $conn->prepare("SELECT applicant_id FROM onboarding_competencies WHERE applicant_id = ?");
    $stmt->bind_param("s", $onboarding_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        echo json_encode(['success'=>false, 'message'=>'Employee already proceeded']);
        exit;
    }

    // Insert into onboarding_competencies
    $stmt = $conn->prepare("
        INSERT INTO onboarding_competencies 
        (onboarding_id, applicant_id, name, department, current_level, required_level, created_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("ssssii", $onboarding_id, $employee_id, $name, $department, $current_level, $required_level);
    $stmt->execute();

    echo json_encode(['success'=>true, 'applicant_id'=>$onboarding_id]);

} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
