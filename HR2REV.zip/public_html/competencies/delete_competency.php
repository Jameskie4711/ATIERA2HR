<?php
include('../session_check.php');
include('../dblogin.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Read JSON body
$data = json_decode(file_get_contents('php://input'), true);
$competency_id = intval($data['competency_id'] ?? 0);

if(!$competency_id){
    echo json_encode(['success'=>false,'message'=>'Missing competency_id']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM onboarding_competencies WHERE competency_id=?");
$stmt->bind_param("i", $competency_id);

if($stmt->execute()){
    echo json_encode(['success'=>true,'message'=>'Deleted successfully']);
} else {
    echo json_encode(['success'=>false,'message'=>$stmt->error]);
}

$stmt->close();
$conn->close();
?>
