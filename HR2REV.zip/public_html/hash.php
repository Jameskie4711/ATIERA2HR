<?php
echo password_hash("123", PASSWORD_DEFAULT);