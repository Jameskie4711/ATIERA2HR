<?php
$servername = "localhost";
$dbusername = "hr2_atiera";     // your actual database username
$dbpassword = "DAJK^PNEBoIi#Otk"; // your actual password
$dbname     = "hr2_competency";   // your actual database name

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
