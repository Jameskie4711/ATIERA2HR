<?php
$servername = "localhost"; // or the remote host, if MySQL is external
$username   = "hratiera1";  // check in cPanel
$password   = "F71jvVX7Qnr9JH"; 
$database   = "hr1_application_db"; // ✅ update this to your actual DB name

$connections = new mysqli($servername, $username, $password, $database);

if ($connections->connect_error) {
    die("Database Connection Failed: " . $connections->connect_error);
}
?>
