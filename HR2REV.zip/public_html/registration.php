<?php
include("dblogin.php");
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $gender = $_POST['gender'] ?? '';
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);

    // Validation
    if ($password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        // Check if email exists
        $check = $conn->prepare("SELECT id FROM users WHERE Email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "Email already registered.";
        } else {
            // Generate unique user_id and employee_id
            $user_id = "ATIERA-" . strtoupper(substr($first_name, 0, 2)) . rand(1000, 9999);
            $employee_id = "EMP-" . rand(1000, 9999);

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("
                INSERT INTO users 
                (user_id, First_Name, Last_Name, Email, Password, Gender, Phone_Number, Address, Employee_ID, Role) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'user')
            ");
            $stmt->bind_param("sssssssss", $user_id, $first_name, $last_name, $email, $hashed_password, $gender, $phone, $address, $employee_id);

            if ($stmt->execute()) {
                header("Location: login.php?registered=1");
                exit;
            } else {
                $message = "Registration failed. Please try again.";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Register — Atiera Hotel & Restaurant</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

<div class="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
  <h2 class="text-2xl font-bold mb-6 text-center text-blue-700">Create Account</h2>

  <?php if ($message): ?>
    <p class="bg-red-100 text-red-700 px-3 py-2 rounded mb-4 text-sm text-center"><?= htmlspecialchars($message) ?></p>
  <?php endif; ?>

  <form method="POST" class="space-y-4">
    <div class="grid grid-cols-2 gap-2">
      <input type="text" name="first_name" placeholder="First Name" required class="border p-2 rounded w-full">
      <input type="text" name="last_name" placeholder="Last Name" required class="border p-2 rounded w-full">
    </div>

    <input type="email" name="email" placeholder="Email Address" required class="border p-2 rounded w-full">
    <div class="grid grid-cols-2 gap-2">
      <input type="password" name="password" placeholder="Password" required class="border p-2 rounded w-full">
      <input type="password" name="confirm_password" placeholder="Confirm Password" required class="border p-2 rounded w-full">
    </div>

    <select name="gender" class="border p-2 rounded w-full">
      <option value="">Select Gender</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>

    <input type="text" name="phone" placeholder="Phone Number" class="border p-2 rounded w-full">
    <textarea name="address" placeholder="Address" class="border p-2 rounded w-full"></textarea>

    <button type="submit" class="w-full bg-blue-700 text-white font-semibold py-2 rounded hover:bg-blue-800">
      Register
    </button>
  </form>

  <p class="text-center text-sm text-gray-600 mt-4">
    Already have an account? <a href="login.php" class="text-blue-700 font-semibold">Login here</a>
  </p>
</div>

</body>
</html>
