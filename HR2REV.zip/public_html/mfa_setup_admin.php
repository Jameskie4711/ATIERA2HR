<?php
session_start();
include('dblogin.php');
require_once __DIR__ . '/PHPGangsta/GoogleAuthenticator.php';

$ga = new PHPGangsta_GoogleAuthenticator();

// ✅ Fix: Match session variables used in login.php
if (!isset($_SESSION['pending_user_id']) || $_SESSION['pending_user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$admin_id = $_SESSION['pending_user_id'];

// Get or create MFA secret for this admin
$stmt = $conn->prepare("SELECT mfa_secret, mfa_enabled FROM admin WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($secret, $enabled);
$stmt->fetch();
$stmt->close();

// Generate new secret if missing
if (!$secret) {
    $secret = $ga->createSecret();
    $stmt = $conn->prepare("UPDATE admin SET mfa_secret = ? WHERE id = ?");
    $stmt->bind_param("si", $secret, $admin_id);
    $stmt->execute();
    $stmt->close();
}

// ✅ Different QR label for admin accounts
$qrCodeUrl = $ga->getQRCodeGoogleUrl('ATIERA-ADMIN', $secret);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin MFA Setup — ATIERA</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-2xl font-bold mb-4 text-center text-blue-700">Admin Multi-Factor Authentication Setup</h2>
        <p class="mb-2 text-gray-700 text-center">Scan this QR code with your Google Authenticator app:</p>

        <div class="flex justify-center mb-4">
            <img src="<?= $qrCodeUrl ?>" alt="Admin MFA QR Code">
        </div>

        <p class="text-center mb-4 text-gray-700">Or manually enter this code:</p>
        <p class="text-center font-mono text-lg mb-4"><?= htmlspecialchars($secret) ?></p>

        <form method="POST" action="mfa_verify_admin.php" class="text-center">
            <input type="text" name="otp" placeholder="Enter code from app"
                   class="border p-2 rounded w-full mb-4 text-center" required>
            <button type="submit"
                    class="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800">
                Verify & Enable MFA
            </button>
        </form>
    </div>
</body>
</html>
