<?php 
include('../session_check.php');
include('../multi_db.php'); // still okay to include for consistency

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ API endpoint for Time and Attendance
$api_url = "https://hr3.atierahotelandrestaurant.com/api/TimeandAttendance.php";

// ✅ Fetch data from API
$response = @file_get_contents($api_url);
$data = [];

if ($response !== false) {
    $data = json_decode($response, true);
} else {
    $data = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Attendance Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-6 flex-1">

        <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h1 class="text-2xl font-semibold">Attendance Management</h1>
            
          </div>
          <?php include '../profile.php'; ?>
        </div>

        <!-- Breadcrumb -->
        <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
          <a href="ess_admin.php" class="hover:text-blue-600 transition-colors">Home</a>   
        </div>

        <!-- Attendance Table -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Attendance Records</h2>

          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="bg-gray-100 text-left">
                <th class="p-2 border">Employee ID</th>
                <th class="p-2 border">Name</th>
                <th class="p-2 border">Department</th>
                <th class="p-2 border">Position</th>
                <th class="p-2 border">Username</th>
                <th class="p-2 border">Work Date</th>
                <th class="p-2 border">Clock In</th>
                <th class="p-2 border">Clock Out</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($data && is_array($data)) {
                  if (count($data) > 0) {
                      foreach ($data as $row) {
                          echo "<tr>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['employee_id'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['employee_name'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['department'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['position'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['username'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars(isset($row['clock_in']) ? substr($row['clock_in'], 0, 10) : '-') . "</td>";
                          echo "<td class='p-2 border text-green-600 font-medium'>" . htmlspecialchars($row['clock_in'] ?? '-') . "</td>";
                          echo "<td class='p-2 border text-red-600 font-medium'>" . htmlspecialchars($row['clock_out'] ?? '-') . "</td>";
                          echo "</tr>";
                      }
                  } else {
                      echo "<tr><td colspan='8' class='p-4 text-center text-gray-500 border'>No attendance records found.</td></tr>";
                  }
              } else {
                  echo "<tr><td colspan='8' class='p-4 text-center text-red-500 border'>Failed to fetch data from API.</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>

        <!-- Back button -->
        <div>
          <a href="ess_admin.php" 
             class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
             ← Back
          </a>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
         Attendance • Admin Module
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
