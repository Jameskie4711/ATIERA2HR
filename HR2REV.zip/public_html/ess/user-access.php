<?php include('../session_check.php'); ?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Access Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4 flex-1">

        <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h1 class="text-2xl font-semibold">User Access Management</h1>
            <p class="text-slate-500 text-sm">Manage employee accounts and system access</p>
          </div>
          <?php include '../profile.php'; ?>
        </div>


        <!-- User Accounts Table -->
        <div class="bg-white shadow rounded-xl p-6 mt-6">
          <h2 class="text-lg font-semibold mb-4">Employee Accounts</h2>
          <table class="w-full text-sm border rounded-lg overflow-hidden">
            <thead class="bg-gray-100">
              <tr>
                <th class="border p-2 text-left">Employee</th>
                <th class="border p-2 text-left">Role</th>
                <th class="border p-2 text-left">Status</th>
                <th class="border p-2 text-left">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="border p-2">John Doe</td>
                <td class="border p-2">Manager</td>
                <td class="border p-2 text-green-600">Active</td>
                <td class="border p-2 space-x-2">
                  <button class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded">Edit</button>
                  <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">Deactivate</button>
                </td>
              </tr>
              <tr>
                <td class="border p-2">Jane Smith</td>
                <td class="border p-2">Employee</td>
                <td class="border p-2 text-orange-500">Pending</td>
                <td class="border p-2 space-x-2">
                  <button class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">Approve</button>
                  <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">Reject</button>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="mt-4">
            <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg">
              + Add New Account
            </button>
          </div>
        </div>

        <div>
          <a href="ess_admin.php" 
             class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
             ← Back
          </a>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
          User Access Management • Admin Module
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
