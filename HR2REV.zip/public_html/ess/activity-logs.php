<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Activity Logs | ESS Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4 w-full">

        <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h2 class="text-2xl font-extrabold text-gray-800 flex items-center gap-2">
              Admin
            </h2>
          </div>
          <?php include '../profile.php'; ?>
        </div>

        <!-- Navigation Bar with Icons -->
        <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
          <a href="activity-logs.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
            <!-- Activity Logs Icon -->
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-6h6v6m2 0H7a2 2 0 01-2-2V7a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2z" />
            </svg>
            Activity Logs
          </a>
          <a href="leave.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
            <!-- Leave Icon -->
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-3.866 0-7 1.343-7 3v5a1 1 0 001 1h12a1 1 0 001-1v-5c0-1.657-3.134-3-7-3z" />
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v4" />
            </svg>
            Leave
          </a>
        </div>

        <!-- Activity Logs Table -->
        <div class="bg-white shadow rounded-2xl p-6 mt-6">
          <h2 class="text-xl font-semibold mb-4">System Activity</h2>

          <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 text-sm">
              <thead class="bg-gray-100 text-gray-700">
                <tr>
                  <th class="px-4 py-2 text-left">Date & Time</th>
                  <th class="px-4 py-2 text-left">Employee ID</th>
                  <th class="px-4 py-2 text-left">Action</th>
                  <th class="px-4 py-2 text-left">Details</th>
                  <th class="px-4 py-2 text-left">IP Address</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                <?php
                $sql = "SELECT * FROM activity_logs ORDER BY datetime DESC";
                $result = mysqli_query($conn, $sql);
                if ($result && mysqli_num_rows($result) > 0) {
                  while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($row['datetime']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($row['employee_id']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($row['action']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($row['details']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($row['ip_address']) . "</td>";
                    echo "</tr>";
                  }
                } else {
                  echo "<tr><td colspan='5' class='text-center py-4 text-gray-500'>No activity logs found</td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
          ESS Admin • Activity Logs • Updated Prototype
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
