<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');

// Get activity stats
$count_sql = "SELECT COUNT(*) as total FROM activity_logs";
$count_result = mysqli_query($conn, $count_sql);
$count_row = mysqli_fetch_assoc($count_result);

$user_sql = "SELECT COUNT(DISTINCT employee_id) as users FROM activity_logs WHERE employee_id != ''";
$user_result = mysqli_query($conn, $user_sql);
$user_row = mysqli_fetch_assoc($user_result);

$today_sql = "SELECT COUNT(*) as today FROM activity_logs WHERE DATE(datetime) = CURDATE()";
$today_result = mysqli_query($conn, $today_sql);
$today_row = mysqli_fetch_assoc($today_result);

$action_sql = "SELECT COUNT(DISTINCT action) as actions FROM activity_logs";
$action_result = mysqli_query($conn, $action_sql);
$action_row = mysqli_fetch_assoc($action_result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Activity Logs | ESS Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
  <style>
    body {
      overflow: hidden; /* Prevent body scrolling */
      height: 100vh;
      margin: 0;
    }
    
    /* Main content scrolling */
    .main-content-scroll {
      overflow-y: auto;
      height: calc(100vh - 2rem);
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
      padding-right: 0.5rem;
    }
    
    .main-content-scroll::-webkit-scrollbar {
      width: 8px;
    }
    
    .main-content-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    /* Smooth scrolling */
    .main-content-scroll {
      scroll-behavior: smooth;
    }
    
    /* Table specific scrolling */
    .table-scroll {
      max-height: 500px;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
    }
    
    .table-scroll::-webkit-scrollbar {
      width: 6px;
    }
    
    .table-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 3px;
    }
    
    .table-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 3px;
    }
    
    .table-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  </style>
</head>
<body class="bg-gray-50 min-h-screen font-sans flex h-screen overflow-hidden">

<?php include '../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-hidden">
  <!-- Main content with scrolling -->
  <main class="main-content-scroll p-6">

    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
      <div>
        <h1 class="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <p class="text-gray-600 mt-2">Monitor and analyze system activity logs and reports</p>
      </div>
      <?php include '../profile.php'; ?>
    </div>

    <!-- Tabs - Updated to match succession reports style -->
    <div class="bg-gray-800 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-xl mb-8">
      <a href="activity-logs.php" class="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-history"></i>
        <span>Activity Logs</span>
      </a>
      <a href="user_accounts.php" class="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-history"></i>
        <span>Accounts</span>
      </a>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Total Activities</p>
            <p class="text-3xl font-bold text-gray-900 mt-2"><?= $count_row['total']; ?></p>
          </div>
          <div class="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-history text-blue-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">All system activities recorded</p>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Unique Users</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= $user_row['users']; ?></p>
          </div>
          <div class="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-users text-green-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Distinct system users</p>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Today's Logs</p>
            <p class="text-3xl font-bold text-yellow-600 mt-2"><?= $today_row['today']; ?></p>
          </div>
          <div class="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-calendar-day text-yellow-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Activities recorded today</p>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Action Types</p>
            <p class="text-3xl font-bold text-purple-600 mt-2"><?= $action_row['actions']; ?></p>
          </div>
          <div class="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-tags text-purple-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Different action categories</p>
        </div>
      </div>
    </div>

    <!-- Activity Logs Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
      <!-- Header -->
      <div class="p-6 border-b border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 class="text-xl font-bold text-gray-900">System Activity Logs</h2>
            <p class="text-gray-600 mt-1">Detailed records of all system activities and user actions</p>
          </div>
          
          <div class="flex flex-col sm:flex-row gap-3">
            <!-- Search -->
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i class="fas fa-search text-gray-400"></i>
              </div>
              <input
                type="text"
                id="searchInput"
                placeholder="Search logs..."
                class="pl-10 pr-4 py-2.5 w-full sm:w-64 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
            </div>
            
            <!-- Export Button -->
            <button class="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg flex items-center gap-2 transition-colors">
              <i class="fas fa-download"></i>
              <span>Export Logs</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Table Container with Scroll -->
      <div class="table-scroll">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead>
              <tr class="bg-gray-50 border-b border-gray-200 sticky top-0">
                <th class="py-4 px-6 text-left">
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Date & Time</span>
                  </div>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Employee ID</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Action</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Details</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">IP Address</span>
                </th>
              </tr>
            </thead>

            <tbody class="divide-y divide-gray-100">
              <?php
              $sql = "SELECT * FROM activity_logs ORDER BY datetime DESC LIMIT 100";
              $result = mysqli_query($conn, $sql);
              if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                  $action_color = match(true) {
                    str_contains(strtolower($row['action']), 'login') => 'bg-green-100 text-green-700',
                    str_contains(strtolower($row['action']), 'delete') => 'bg-red-100 text-red-700',
                    str_contains(strtolower($row['action']), 'update') => 'bg-yellow-100 text-yellow-700',
                    str_contains(strtolower($row['action']), 'create') => 'bg-blue-100 text-blue-700',
                    str_contains(strtolower($row['action']), 'logout') => 'bg-gray-100 text-gray-700',
                    default => 'bg-indigo-100 text-indigo-700'
                  };
              ?>
                <tr class="hover:bg-gray-50 transition-colors">
                  <!-- Date & Time -->
                  <td class="py-4 px-6">
                    <div class="flex flex-col">
                      <p class="font-medium text-gray-900"><?= date('M d, Y', strtotime($row['datetime'])); ?></p>
                      <p class="text-sm text-gray-500"><?= date('h:i A', strtotime($row['datetime'])); ?></p>
                    </div>
                  </td>
                  
                  <!-- Employee ID -->
                  <td class="py-4 px-6">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user text-blue-600"></i>
                      </div>
                      <div>
                        <p class="font-medium text-gray-900"><?= htmlspecialchars($row['employee_id']); ?></p>
                      </div>
                    </div>
                  </td>
                  
                  <!-- Action -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold <?= $action_color; ?>">
                      <div class="w-2 h-2 rounded-full 
                        <?= str_contains(strtolower($row['action']), 'login') ? 'bg-green-500' : 
                          (str_contains(strtolower($row['action']), 'delete') ? 'bg-red-500' : 
                          (str_contains(strtolower($row['action']), 'update') ? 'bg-yellow-500' : 
                          (str_contains(strtolower($row['action']), 'create') ? 'bg-blue-500' : 
                          'bg-gray-500'))); ?>"></div>
                      <?= htmlspecialchars($row['action']); ?>
                    </span>
                  </td>
                  
                  <!-- Details -->
                  <td class="py-4 px-6">
                    <p class="text-sm text-gray-700 max-w-xs truncate"><?= htmlspecialchars($row['details']); ?></p>
                  </td>
                  
                  <!-- IP Address -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                      <i class="fas fa-network-wired"></i>
                      <?= htmlspecialchars($row['ip_address']); ?>
                    </span>
                  </td>
                </tr>
              <?php
                }
              } else {
              ?>
                <tr id="noResultRow">
                  <td colspan="5" class="py-12 px-6 text-center">
                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i class="fas fa-inbox text-gray-400 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-700 mb-2">No activity logs found</h3>
                    <p class="text-gray-500">System activity will appear here once recorded</p>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Footer -->
      <div class="p-6 border-t border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="text-sm text-gray-600">
            Showing last <span class="font-medium">100</span> records
          </div>
          
          <div class="flex items-center gap-2">
            <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              <i class="fas fa-chevron-left"></i>
            </button>
            <span class="px-3 py-2 text-sm text-gray-700">Page 1 of 1</span>
            <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              <i class="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Reports Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
      <!-- Header -->
      <div class="p-6 border-b border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 class="text-xl font-bold text-gray-900">Activity Reports & Insights</h2>
            <p class="text-gray-600 mt-1">Analytics and system performance reports</p>
          </div>
          
          <button class="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg flex items-center gap-2 transition-colors">
            <i class="fas fa-file-export"></i>
            <span>Generate Report</span>
          </button>
        </div>
      </div>

      <!-- Reports Content -->
      <div class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <!-- Weekly Activity -->
          <div class="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <i class="fas fa-chart-line text-blue-500"></i>
              Weekly Activity
            </h3>
            <?php
            $weekly_sql = "SELECT 
              DATE_FORMAT(datetime, '%a') as day,
              COUNT(*) as count
              FROM activity_logs 
              WHERE datetime >= DATE_SUB(NOW(), INTERVAL 7 DAY)
              GROUP BY DATE(datetime)
              ORDER BY datetime
              LIMIT 7";
            $weekly_result = mysqli_query($conn, $weekly_sql);
            
            if (mysqli_num_rows($weekly_result) > 0) {
              echo "<div class='space-y-3'>";
              while ($row = mysqli_fetch_assoc($weekly_result)) {
                $percentage = min(100, ($row['count'] / 50) * 100);
                echo "<div>";
                echo "<div class='flex justify-between text-sm mb-1'>";
                echo "<span class='font-medium'>" . $row['day'] . "</span>";
                echo "<span class='text-gray-600'>" . $row['count'] . "</span>";
                echo "</div>";
                echo "<div class='h-2 bg-gray-200 rounded-full overflow-hidden'>";
                echo "<div class='h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full' style='width: " . $percentage . "%'></div>";
                echo "</div>";
                echo "</div>";
              }
              echo "</div>";
            } else {
              echo "<p class='text-gray-400 text-sm'>No recent activity data</p>";
            }
            ?>
          </div>

          <!-- Top Actions -->
          <div class="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <i class="fas fa-bolt text-yellow-500"></i>
              Top Actions
            </h3>
            <?php
            $top_actions_sql = "SELECT action, COUNT(*) as count 
                              FROM activity_logs 
                              GROUP BY action 
                              ORDER BY count DESC 
                              LIMIT 6";
            $top_actions_result = mysqli_query($conn, $top_actions_sql);
            
            if (mysqli_num_rows($top_actions_result) > 0) {
              echo "<div class='space-y-3'>";
              while ($row = mysqli_fetch_assoc($top_actions_result)) {
                echo "<div class='flex items-center justify-between'>";
                echo "<div class='flex items-center gap-2'>";
                echo "<div class='w-2 h-2 rounded-full bg-yellow-400'></div>";
                echo "<span class='text-sm font-medium'>" . htmlspecialchars($row['action']) . "</span>";
                echo "</div>";
                echo "<span class='px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full'>" . $row['count'] . "</span>";
                echo "</div>";
              }
              echo "</div>";
            }
            ?>
          </div>

          <!-- Quick Reports -->
          <div class="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <i class="fas fa-file-alt text-green-500"></i>
              Quick Reports
            </h3>
            <div class="space-y-3">
              <a href="#" class="flex items-center justify-between p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors group">
                <div class="flex items-center gap-3">
                  <div class="p-2 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors">
                    <i class="fas fa-user-clock text-blue-600"></i>
                  </div>
                  <div>
                    <p class="font-medium text-sm text-gray-800">Login Activity Report</p>
                    <p class="text-xs text-gray-500">Past 30 days</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400 group-hover:text-blue-600"></i>
              </a>
              
              <a href="#" class="flex items-center justify-between p-3 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors group">
                <div class="flex items-center gap-3">
                  <div class="p-2 bg-purple-100 rounded-lg group-hover:bg-purple-200 transition-colors">
                    <i class="fas fa-exclamation-triangle text-purple-600"></i>
                  </div>
                  <div>
                    <p class="font-medium text-sm text-gray-800">System Error Report</p>
                    <p class="text-xs text-gray-500">All error logs</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400 group-hover:text-purple-600"></i>
              </a>
              
              <a href="#" class="flex items-center justify-between p-3 bg-green-50 hover:bg-green-100 rounded-lg transition-colors group">
                <div class="flex items-center gap-3">
                  <div class="p-2 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors">
                    <i class="fas fa-chart-bar text-green-600"></i>
                  </div>
                  <div>
                    <p class="font-medium text-sm text-gray-800">Monthly Summary</p>
                    <p class="text-xs text-gray-500">Current month</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400 group-hover:text-green-600"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Quick Tips -->
    <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="bg-blue-50 border border-blue-100 rounded-xl p-6">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <i class="fas fa-lightbulb text-blue-600"></i>
          </div>
          <div>
            <h4 class="font-semibold text-gray-900 mb-2">Activity Log Tips</h4>
            <ul class="text-sm text-gray-700 space-y-1">
              <li>• Activity logs are automatically recorded for all system actions</li>
              <li>• Use the search to quickly find specific activities</li>
              <li>• Export logs for audit and compliance purposes</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div class="bg-green-50 border border-green-100 rounded-xl p-6">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <i class="fas fa-question-circle text-green-600"></i>
          </div>
          <div>
            <h4 class="font-semibold text-gray-900 mb-2">Need Assistance?</h4>
            <p class="text-sm text-gray-700 mb-3">Contact system administrators for log analysis or custom reports</p>
            <button class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>

  </main>
</div>

<script>
// Search functionality
const searchInput = document.getElementById('searchInput');
const rows = document.querySelectorAll('tbody tr');
const noResultRow = document.getElementById('noResultRow');

searchInput.addEventListener('keyup', () => {
  let visible = 0;
  const val = searchInput.value.toLowerCase().trim();

  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    const matches = text.includes(val);
    
    row.style.display = matches ? '' : 'none';
    if (matches) visible++;
  });

  if (noResultRow) {
    noResultRow.style.display = visible === 0 ? '' : 'none';
  }
});

// Add hover effects to action buttons
document.addEventListener('DOMContentLoaded', function() {
  const buttons = document.querySelectorAll('button, a');
  buttons.forEach(button => {
    button.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-1px)';
      this.style.transition = 'transform 0.2s ease';
    });
    
    button.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
  
  // Clear search on escape key
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      searchInput.dispatchEvent(new Event('keyup'));
      searchInput.blur();
    }
  });
  
  // Ensure sidebar doesn't scroll
  const sidebar = document.querySelector('aside, .sidebar');
  if (sidebar) {
    sidebar.style.overflowY = 'auto';
    sidebar.style.position = 'sticky';
    sidebar.style.top = '0';
    sidebar.style.height = '100vh';
  }
});
</script>
</body>
</html>