<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS Admin - Schedules</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen overflow-hidden bg-gray-50">
  <div class="flex h-full">

    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4">
        <div class="flex items-center justify-between border-b py-6">
          <h2 class="text-xl font-semibold text-gray-800">Employee Self-Service (ESS) - Schedules</h2>
        </div>

        <!-- ESS Submodules Navigation -->
        <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
          <a href="ess_admin.php" class="hover:text-blue-600">Profiles</a>
          <a href="essleave.php" class="hover:text-blue-600">Leave Requests</a>
          <a href="esspayroll.php" class="hover:text-blue-600">Payroll</a>
          <a href="essschedules.php" class="text-blue-600 font-semibold">Schedules</a>
          <a href="essreports.php" class="hover:text-blue-600">Reports</a>
        </div>

        <!-- Content -->
        <div class="bg-white shadow-md rounded-xl p-6 mt-6">
          <h3 class="text-lg font-semibold mb-4">Schedules Management</h3>
          <p class="text-gray-600 text-sm">This is where admins can manage employee work schedules and shifts.</p>
        </div>
      </main>
    </div>
  </div>
</body>
</html>
