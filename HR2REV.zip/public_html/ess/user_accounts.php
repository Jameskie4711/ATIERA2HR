<?php include('../session_check.php'); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../dblogin.php');

// Get user account stats
$total_users_sql = "SELECT COUNT(*) as total FROM users";
$total_users_result = mysqli_query($conn, $total_users_sql);
$total_users_row = mysqli_fetch_assoc($total_users_result);
$total_users = $total_users_row['total'];

// Active users query
$active_users_sql = "SELECT COUNT(*) as active FROM users WHERE status = 'active'";
$active_users_result = mysqli_query($conn, $active_users_sql);
$active_users_row = mysqli_fetch_assoc($active_users_result);

// Admin users query - you don't have a role column, so let's check by position
$admin_users_sql = "SELECT COUNT(*) as admins FROM users WHERE Position LIKE '%admin%' OR Position LIKE '%administrator%' OR Department LIKE '%admin%'";
$admin_users_result = mysqli_query($conn, $admin_users_sql);
$admin_users_row = mysqli_fetch_assoc($admin_users_result);

// Today registered users query
$today_registered_sql = "SELECT COUNT(*) as today FROM users WHERE DATE(created_at) = CURDATE()";
$today_registered_result = mysqli_query($conn, $today_registered_sql);
$today_registered_row = mysqli_fetch_assoc($today_registered_result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Accounts | ESS Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
  <style>
    body {
      overflow: hidden;
      height: 100vh;
      margin: 0;
    }
    
    .main-content-scroll {
      overflow-y: auto;
      height: calc(100vh - 2rem);
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
      padding-right: 0.5rem;
    }
    
    .main-content-scroll::-webkit-scrollbar {
      width: 8px;
    }
    
    .main-content-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
    
    .main-content-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    .main-content-scroll {
      scroll-behavior: smooth;
    }
    
    .table-scroll {
      max-height: 500px;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 #f1f5f9;
    }
    
    .table-scroll::-webkit-scrollbar {
      width: 6px;
    }
    
    .table-scroll::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 3px;
    }
    
    .table-scroll::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 3px;
    }
    
    .table-scroll::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
    
    .glass-card {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
    }
    
    .status-active {
      background-color: #d1fae5;
      color: #065f46;
    }
    
    .status-inactive {
      background-color: #fee2e2;
      color: #991b1b;
    }
    
    .status-pending {
      background-color: #fef3c7;
      color: #92400e;
    }
    
    .role-admin {
      background-color: #e0e7ff;
      color: #3730a3;
    }
    
    .role-user {
      background-color: #f3f4f6;
      color: #374151;
    }
    
    .role-manager {
      background-color: #fef3c7;
      color: #92400e;
    }
    
    .role-hr {
      background-color: #fce7f3;
      color: #9d174d;
    }
    
    .modal-enter {
      animation: modalFadeIn 0.3s ease-out forwards;
    }
    
    @keyframes modalFadeIn {
      from { opacity: 0; transform: translateY(-20px) scale(0.95); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
  </style>
</head>
<body class="bg-gray-50 min-h-screen font-sans flex h-screen overflow-hidden">

<?php include '../sidebar.php'; ?>

<div class="flex-1 flex flex-col overflow-hidden">
  <main class="main-content-scroll p-6">

    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
      <div>
        <h1 class="text-3xl font-bold text-gray-900">User Accounts Management</h1>
        <p class="text-gray-600 mt-2">Manage and monitor all user accounts in the system</p>
      </div>
      <?php include '../profile.php'; ?>
    </div>

    <!-- Tabs -->
    <div class="bg-gray-800 px-6 py-3 flex gap-4 text-sm font-medium text-white rounded-xl mb-8">
      <a href="activity-logs.php" class="flex items-center gap-2 hover:bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-history"></i>
        <span>Activity Logs</span>
      </a>
      <a href="user_accounts.php" class="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded transition-colors">
        <i class="fas fa-user-cog"></i>
        <span>Accounts</span>
      </a>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="glass-card rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Total Users</p>
            <p class="text-3xl font-bold text-gray-900 mt-2"><?= $total_users_row['total']; ?></p>
          </div>
          <div class="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-users text-blue-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">All registered accounts</p>
        </div>
      </div>

      <div class="glass-card rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Active Users</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= $active_users_row['active']; ?></p>
          </div>
          <div class="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-user-check text-green-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Currently active accounts</p>
        </div>
      </div>

      <div class="glass-card rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Admin Accounts</p>
            <p class="text-3xl font-bold text-purple-600 mt-2"><?= $admin_users_row['admins']; ?></p>
          </div>
          <div class="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-user-shield text-purple-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Administrative users</p>
        </div>
      </div>

      <div class="glass-card rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">New Today</p>
            <p class="text-3xl font-bold text-yellow-600 mt-2"><?= $today_registered_row['today']; ?></p>
          </div>
          <div class="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center">
            <i class="fas fa-user-plus text-yellow-600 text-xl"></i>
          </div>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100">
          <p class="text-xs text-gray-500">Accounts created today</p>
        </div>
      </div>
    </div>

    <!-- User Accounts Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
      <!-- Header -->
      <div class="p-6 border-b border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 class="text-xl font-bold text-gray-900">All User Accounts</h2>
            <p class="text-gray-600 mt-1">Manage user permissions, status, and account details</p>
          </div>
          
          <div class="flex flex-col sm:flex-row gap-3">
            <!-- Search -->
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i class="fas fa-search text-gray-400"></i>
              </div>
              <input
                type="text"
                id="searchInput"
                placeholder="Search users..."
                class="pl-10 pr-4 py-2.5 w-full sm:w-64 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
            </div>
            
            <!-- Filter Dropdown -->
            <div class="relative">
              <select id="filterDepartment" class="pl-4 pr-10 py-2.5 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none">
                <option value="">All Departments</option>
                <?php
                $dept_sql = "SELECT DISTINCT Department FROM users WHERE Department IS NOT NULL AND Department != '' ORDER BY Department";
                $dept_result = mysqli_query($conn, $dept_sql);
                while ($dept = mysqli_fetch_assoc($dept_result)) {
                  echo '<option value="' . htmlspecialchars($dept['Department']) . '">' . htmlspecialchars($dept['Department']) . '</option>';
                }
                ?>
              </select>
              <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <i class="fas fa-chevron-down text-gray-400"></i>
              </div>
            </div>
            
            <!-- Add User Button -->
            <button onclick="openAddUserModal()" class="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg flex items-center gap-2 transition-colors">
              <i class="fas fa-user-plus"></i>
              <span>Add User</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Table Container with Scroll -->
      <div class="table-scroll">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead>
              <tr class="bg-gray-50 border-b border-gray-200 sticky top-0">
                <th class="py-4 px-6 text-left">
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">User</span>
                  </div>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Email</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Position</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Status</span>
                </th>
                <th class="py-4 px-6 text-left">
                  <span class="text-sm font-semibold text-gray-700 uppercase tracking-wider">Created</span>
                </th>
              </tr>
            </thead>

            <tbody class="divide-y divide-gray-100">
              <?php
              // Fetch users with pagination
              $limit = 20;
              $page = isset($_GET['page']) ? $_GET['page'] : 1;
              $offset = ($page - 1) * $limit;
              
              $users_sql = "SELECT 
                           u.id,
                           u.First_Name,
                           u.Last_Name,
                           u.Middle_Initial,
                           u.Email,
                           u.Position,
                           u.Department,
                           u.status,
                           u.created_at,
                           u.Employee_ID,
                           u.Employment_Status
                           FROM users u 
                           ORDER BY u.created_at DESC 
                           LIMIT $limit OFFSET $offset";
              
              $users_result = mysqli_query($conn, $users_sql);
              
              $total_users_sql = "SELECT COUNT(*) as total FROM users";
              $total_users_result = mysqli_query($conn, $total_users_sql);
              $total_users = mysqli_fetch_assoc($total_users_result)['total'];
              $total_pages = ceil($total_users / $limit);
              
              if (mysqli_num_rows($users_result) > 0) {
                while ($user = mysqli_fetch_assoc($users_result)) {
                  // Build full name
                  $full_name = trim($user['First_Name'] . ' ' . ($user['Middle_Initial'] ? $user['Middle_Initial'] . '. ' : '') . $user['Last_Name']);
                  if (empty($full_name)) {
                    $full_name = 'User #' . $user['id'];
                  }
                  
                  // Determine role based on position
                  $position = $user['Position'] ?? '';
                  $role_class = 'role-user';
                  $role_display = $position ?: 'User';
                  
                  if (stripos($position, 'admin') !== false || stripos($position, 'administrator') !== false) {
                    $role_class = 'role-admin';
                  } elseif (stripos($position, 'manager') !== false || stripos($position, 'supervisor') !== false) {
                    $role_class = 'role-manager';
                  } elseif (stripos($position, 'hr') !== false || stripos($position, 'human resource') !== false) {
                    $role_class = 'role-hr';
                  }
                  
                  // Status badge styling
                  $status_class = '';
                  $status_dot = '';
                  $status = $user['status'] ?? 'active';
                  switch(strtolower($status)) {
                    case 'active':
                      $status_class = 'status-active';
                      $status_dot = 'bg-green-500';
                      break;
                    case 'inactive':
                      $status_class = 'status-inactive';
                      $status_dot = 'bg-red-500';
                      break;
                    default:
                      $status_class = 'status-pending';
                      $status_dot = 'bg-yellow-500';
                  }
              ?>
                <tr class="hover:bg-gray-50 transition-colors user-row" data-id="<?= $user['id']; ?>" data-department="<?= htmlspecialchars($user['Department'] ?? ''); ?>">
                  <!-- User Info -->
                  <td class="py-4 px-6">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-blue-600"></i>
                      </div>
                      <div>
                        <p class="font-medium text-gray-900"><?= htmlspecialchars($full_name); ?></p>
                        <p class="text-sm text-gray-500">
                          <?= !empty($user['Employee_ID']) ? 'ID: ' . htmlspecialchars($user['Employee_ID']) : 'ID: N/A'; ?>
                          <?php if(!empty($user['Department'])): ?>
                            • <?= htmlspecialchars($user['Department']); ?>
                          <?php endif; ?>
                        </p>
                      </div>
                    </div>
                  </td>
                  
                  <!-- Email -->
                  <td class="py-4 px-6">
                    <div class="flex items-center gap-2">
                      <i class="fas fa-envelope text-gray-400 text-sm"></i>
                      <span class="text-sm text-gray-700"><?= htmlspecialchars($user['Email']); ?></span>
                    </div>
                  </td>
                  
                  <!-- Position/Role -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold <?= $role_class; ?>">
                      <i class="fas fa-user-tag text-xs"></i>
                      <?= htmlspecialchars($role_display); ?>
                    </span>
                  </td>
                  
                  <!-- Status -->
                  <td class="py-4 px-6">
                    <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold <?= $status_class; ?>">
                      <div class="w-2 h-2 rounded-full <?= $status_dot; ?>"></div>
                      <?= ucfirst(htmlspecialchars($status)); ?>
                    </span>
                  </td>
                  
                  <!-- Created Date -->
                  <td class="py-4 px-6">
                    <div class="flex flex-col">
                      <?php if(!empty($user['created_at'])): ?>
                        <p class="text-sm text-gray-900"><?= date('M d, Y', strtotime($user['created_at'])); ?></p>
                        <p class="text-xs text-gray-500"><?= date('h:i A', strtotime($user['created_at'])); ?></p>
                      <?php else: ?>
                        <p class="text-sm text-gray-900">Not recorded</p>
                        <p class="text-xs text-gray-500">N/A</p>
                      <?php endif; ?>
                    </div>
                  </td>
                  
                 
                </tr>
              <?php
                }
              } else {
              ?>
                <tr id="noResultRow">
                  <td colspan="6" class="py-12 px-6 text-center">
                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i class="fas fa-users text-gray-400 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-700 mb-2">No users found</h3>
                    <p class="text-gray-500">Click "Add User" to create a new account</p>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Footer with Pagination -->
      <div class="p-6 border-t border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="text-sm text-gray-600">
            Showing <span class="font-medium"><?= min($limit, mysqli_num_rows($users_result)); ?></span> of <span class="font-medium"><?= $total_users; ?></span> users
          </div>
          
          <div class="flex items-center gap-2">
            <?php if($page > 1): ?>
              <a href="?page=<?= $page - 1; ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                <i class="fas fa-chevron-left"></i>
              </a>
            <?php else: ?>
              <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-300 cursor-not-allowed">
                <i class="fas fa-chevron-left"></i>
              </button>
            <?php endif; ?>
            
            <span class="px-3 py-2 text-sm text-gray-700">Page <?= $page; ?> of <?= $total_pages; ?></span>
            
            <?php if($page < $total_pages): ?>
              <a href="?page=<?= $page + 1; ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                <i class="fas fa-chevron-right"></i>
              </a>
            <?php else: ?>
              <button class="px-4 py-2 border border-gray-300 rounded-lg text-gray-300 cursor-not-allowed">
                <i class="fas fa-chevron-right"></i>
              </button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- User Analytics Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
      <div class="p-6 border-b border-gray-200">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 class="text-xl font-bold text-gray-900">User Analytics</h2>
            <p class="text-gray-600 mt-1">User distribution and activity insights</p>
          </div>
        </div>
      </div>

      <div class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          <!-- Department Distribution -->
          <div>
            <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <i class="fas fa-chart-pie text-blue-500"></i>
              Department Distribution
            </h3>
            <?php
            $dept_dist_sql = "SELECT Department, COUNT(*) as count FROM users WHERE Department IS NOT NULL AND Department != '' GROUP BY Department ORDER BY count DESC";
            $dept_dist_result = mysqli_query($conn, $dept_dist_sql);
            
            if (mysqli_num_rows($dept_dist_result) > 0) {
              echo "<div class='space-y-4'>";
              while ($row = mysqli_fetch_assoc($dept_dist_result)) {
                $percentage = ($row['count'] / $total_users) * 100;
                $colors = ['from-blue-400 to-blue-600', 'from-green-400 to-green-600', 'from-purple-400 to-purple-600', 'from-yellow-400 to-yellow-600', 'from-red-400 to-red-600', 'from-indigo-400 to-indigo-600'];
                $color_class = $colors[array_rand($colors)];
                
                echo "<div>";
                echo "<div class='flex justify-between text-sm mb-1'>";
                echo "<span class='font-medium'>" . htmlspecialchars($row['Department']) . "</span>";
                echo "<span class='text-gray-600'>" . $row['count'] . " (" . round($percentage, 1) . "%)</span>";
                echo "</div>";
                echo "<div class='h-2 bg-gray-200 rounded-full overflow-hidden'>";
                echo "<div class='h-full bg-gradient-to-r " . $color_class . " rounded-full' style='width: " . $percentage . "%'></div>";
                echo "</div>";
                echo "</div>";
              }
              echo "</div>";
            } else {
              echo "<p class='text-gray-500 text-center py-8'>No department data available</p>";
            }
            ?>
          </div>

          <!-- Status Overview -->
          <div>
            <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <i class="fas fa-chart-bar text-green-500"></i>
              Status Overview
            </h3>
            <?php
            $status_dist_sql = "SELECT status, COUNT(*) as count FROM users GROUP BY status";
            $status_dist_result = mysqli_query($conn, $status_dist_sql);
            
            if (mysqli_num_rows($status_dist_result) > 0) {
              echo "<div class='space-y-4'>";
              while ($row = mysqli_fetch_assoc($status_dist_result)) {
                $percentage = ($row['count'] / $total_users) * 100;
                $color_class = match(strtolower($row['status'])) {
                  'active' => 'from-green-400 to-green-600',
                  'inactive' => 'from-red-400 to-red-600',
                  default => 'from-yellow-400 to-yellow-600'
                };
                
                echo "<div>";
                echo "<div class='flex justify-between text-sm mb-1'>";
                echo "<span class='font-medium'>" . ucfirst(htmlspecialchars($row['status'])) . "</span>";
                echo "<span class='text-gray-600'>" . $row['count'] . " (" . round($percentage, 1) . "%)</span>";
                echo "</div>";
                echo "<div class='h-2 bg-gray-200 rounded-full overflow-hidden'>";
                echo "<div class='h-full bg-gradient-to-r " . $color_class . " rounded-full' style='width: " . $percentage . "%'></div>";
                echo "</div>";
                echo "</div>";
              }
              echo "</div>";
            } else {
              echo "<p class='text-gray-500 text-center py-8'>No status data available</p>";
            }
            ?>
          </div>
        </div>
      </div>
    </div>

  

      <div class="bg-blue-50 border border-blue-100 rounded-xl p-6">
        <h3 class="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <i class="fas fa-lightbulb text-blue-500"></i>
          Account Management Tips
        </h3>
        <ul class="text-sm text-gray-700 space-y-2">
          <li>• Regularly review user permissions and access levels</li>
          <li>• Deactivate accounts for users who have left the organization</li>
          <li>• Use strong passwords and enable two-factor authentication</li>
          <li>• Monitor failed login attempts for security alerts</li>
        </ul>
      </div>
    </div>

  </main>
</div>

<!-- Add User Modal -->
<div id="addUserModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
  <div class="bg-white rounded-xl w-full max-w-md mx-4 modal-enter">
    <div class="p-6 border-b border-gray-200">
      <h3 class="text-xl font-bold text-gray-900">Add New User</h3>
      <p class="text-gray-600 text-sm mt-1">Create a new user account</p>
    </div>
    
    <div class="p-6">
      <form id="addUserForm" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">First Name *</label>
          <input type="text" name="first_name" required 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Last Name *</label>
          <input type="text" name="last_name" required 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
          <input type="email" name="email" required 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Password *</label>
          <input type="password" name="password" required 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Position</label>
          <input type="text" name="position" 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Department</label>
          <input type="text" name="department" 
                 class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select name="status" 
                  class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="pending">Pending</option>
          </select>
        </div>
      </form>
    </div>
    
    <div class="p-6 border-t border-gray-200 flex gap-3">
      <button onclick="closeAddUserModal()" class="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors">
        Cancel
      </button>
      <button onclick="saveUser()" class="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
        Create User
      </button>
    </div>
  </div>
</div>

<script>
// Search functionality
const searchInput = document.getElementById('searchInput');
const filterDepartment = document.getElementById('filterDepartment');
const userRows = document.querySelectorAll('.user-row');
const noResultRow = document.getElementById('noResultRow');

function filterUsers() {
  const searchVal = searchInput.value.toLowerCase().trim();
  const deptVal = filterDepartment.value.toLowerCase();
  let visible = 0;

  userRows.forEach(row => {
    const text = row.textContent.toLowerCase();
    const dept = row.dataset.department ? row.dataset.department.toLowerCase() : '';
    
    const matchesSearch = text.includes(searchVal);
    const matchesDept = !deptVal || dept.includes(deptVal);
    
    row.style.display = (matchesSearch && matchesDept) ? '' : 'none';
    if (matchesSearch && matchesDept) visible++;
  });

  if (noResultRow) {
    noResultRow.style.display = visible === 0 ? '' : 'none';
  }
}

searchInput.addEventListener('keyup', filterUsers);
filterDepartment.addEventListener('change', filterUsers);

// Modal Functions
function openAddUserModal() {
  document.getElementById('addUserModal').classList.remove('hidden');
  document.getElementById('addUserModal').classList.add('flex');
}

function closeAddUserModal() {
  document.getElementById('addUserModal').classList.add('hidden');
  document.getElementById('addUserModal').classList.remove('flex');
  document.getElementById('addUserForm').reset();
}

// User Management Functions
function viewUser(userId) {
  window.location.href = 'view_user.php?id=' + userId;
}

function editUser(userId) {
  window.location.href = 'edit_user.php?id=' + userId;
}

function deleteUser(userId) {
  if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
    fetch('delete_user.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: userId
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        location.reload();
      } else {
        alert('Error deleting user: ' + data.message);
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Error deleting user');
    });
  }
}

function toggleStatus(userId, newStatus) {
  if (confirm('Are you sure you want to change this user\'s status?')) {
    fetch('update_user_status.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: userId,
        status: newStatus
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        location.reload();
      } else {
        alert('Error updating user status: ' + data.message);
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Error updating user status');
    });
  }
}

function saveUser() {
  const form = document.getElementById('addUserForm');
  const formData = new FormData(form);
  
  if (!formData.get('first_name') || !formData.get('last_name') || !formData.get('email') || !formData.get('password')) {
    alert('Please fill in all required fields');
    return;
  }
  
  fetch('create_user.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert('User created successfully');
      closeAddUserModal();
      location.reload();
    } else {
      alert('Error creating user: ' + data.message);
    }
  })
  .catch(error => {
    console.error('Error:', error);
    alert('Error creating user');
  });
}

// Bulk Actions
function exportUsers() {
  window.location.href = 'export_users.php';
}

function sendMassEmail() {
  alert('Mass email functionality will be implemented here');
}

function resetAllPasswords() {
  if (confirm('Are you sure you want to reset ALL user passwords? Users will need to use "Forgot Password" to regain access.')) {
    alert('Password reset functionality will be implemented here');
  }
}

// Close modal when clicking outside
document.getElementById('addUserModal').addEventListener('click', function(e) {
  if (e.target === this) {
    closeAddUserModal();
  }
});

// Add hover effects
document.addEventListener('DOMContentLoaded', function() {
  const buttons = document.querySelectorAll('button, a');
  buttons.forEach(button => {
    button.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-1px)';
      this.style.transition = 'transform 0.2s ease';
    });
    
    button.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
  
  // Clear search on escape key
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      searchInput.dispatchEvent(new Event('keyup'));
      searchInput.blur();
    }
  });
});
</script>
</body>
</html>