<?php 
include('../session_check.php');
include('../multi_db.php'); // still okay to include for consistency

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ API endpoint for Leave
$api_url = "https://hr3.atierahotelandrestaurant.com/api/leaveApi.php";

// ✅ Fetch data from API
$response = @file_get_contents($api_url);
$data = [];

if ($response !== false) {
    $data = json_decode($response, true);
} else {
    $data = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Leave Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
   <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4 w-full">

        <!-- Header -->
           <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h2 class="text-2xl font-extrabold text-gray-800 flex items-center gap-2">Leave</h2>
          </div>
          <?php include '../profile.php'; ?>
        </div>

        <!-- Submodule Header / Tabs -->
        <div class="bg-gray-800 border-b border-gray-700 px-6 py-3 flex gap-4 text-sm font-medium text-white">
          <a href="activity-logs.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
            <!-- Activity Logs Icon -->
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-6h6v6m2 0H7a2 2 0 01-2-2V7a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2z" />
            </svg>
            Activity Logs
          </a>
          <a href="leave.php" class="hover:bg-gray-700 px-3 py-1 rounded transition-colors flex items-center gap-2">
            <!-- Leave Icon -->
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-3.866 0-7 1.343-7 3v5a1 1 0 001 1h12a1 1 0 001-1v-5c0-1.657-3.134-3-7-3z" />
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v4" />
            </svg>
            Leave
          </a>
        </div>
        <!-- Leave Table -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Leave Records</h2>

          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="bg-gray-100 text-left">
                <th class="p-2 border">Leave ID</th>
                <th class="p-2 border">Employee</th>
                <th class="p-2 border">Leave Type</th>
                <th class="p-2 border">Dates</th>
                <th class="p-2 border">Days</th>
                <th class="p-2 border">Status</th>
                <th class="p-2 border">Approved By</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($data && is_array($data)) {
                  if (count($data) > 0) {
                      foreach ($data as $row) {
                          $dates = (isset($row['from']) && isset($row['to'])) ? $row['from'] . ' to ' . $row['to'] : '-';
                          echo "<tr>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['id'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['employee_name'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['type'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($dates) . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['days'] ?? '-') . "</td>";
                          echo "<td class='p-2 border text-yellow-700 font-medium'>" . htmlspecialchars($row['status'] ?? '-') . "</td>";
                          echo "<td class='p-2 border'>" . htmlspecialchars($row['approved_by'] ?? '-') . "</td>";
                          echo "</tr>";
                      }
                  } else {
                      echo "<tr><td colspan='7' class='p-4 text-center text-gray-500 border'>No leave records found.</td></tr>";
                  }
              } else {
                  echo "<tr><td colspan='7' class='p-4 text-center text-red-500 border'>Failed to fetch data from API.</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>

        <!-- Back button -->
        <div>
          <a href="ess_admin.php" 
             class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
             ← Back
          </a>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
         Leave • Admin Module
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
