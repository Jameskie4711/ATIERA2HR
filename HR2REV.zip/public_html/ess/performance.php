<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Performance & Appraisals</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-6 flex-1">

        <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h1 class="text-2xl font-semibold">Performance & Appraisals</h1>
            <p class="text-slate-500 text-sm">Track reviews and manage appraisal processes</p>
          </div>
          <?php include '../profile.php'; ?>
        </div>

        <!-- Breadcrumb -->
        <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
          <a href="ess_admin.php" class="hover:text-blue-600 transition-colors">Home</a>   
        </div>

        <!-- Performance Reviews Table -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Employee Performance Reviews</h2>
          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="bg-gray-100 text-left">
                <th class="p-2 border">Employee</th>
                <th class="p-2 border">Review Period</th>
                <th class="p-2 border">Rating</th>
                <th class="p-2 border">Status</th>
                <th class="p-2 border">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="p-2 border">Ana Cruz</td>
                <td class="p-2 border">Jan - Jun 2025</td>
                <td class="p-2 border">4.5 / 5</td>
                <td class="p-2 border text-green-600">Completed</td>
                <td class="p-2 border">
                  <button class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-lg">View</button>
                </td>
              </tr>
              <tr>
                <td class="p-2 border">Mark Reyes</td>
                <td class="p-2 border">Jan - Jun 2025</td>
                <td class="p-2 border">-</td>
                <td class="p-2 border text-yellow-600">Pending</td>
                <td class="p-2 border">
                  <button class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-lg">Start</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Appraisal Form -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Start New Appraisal</h2>
          <form class="space-y-4">
            <div>
              <label class="block text-sm font-medium">Select Employee</label>
              <select class="mt-1 w-64 border rounded-lg p-2">
                <option>-- Choose Employee --</option>
                <option>Ana Cruz</option>
                <option>Mark Reyes</option>
                <option>Maria Santos</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-medium">Review Period</label>
              <input type="text" class="mt-1 w-64 border rounded-lg p-2" placeholder="e.g. Jul - Dec 2025">
            </div>
            <div>
              <label class="block text-sm font-medium">Reviewer</label>
              <input type="text" class="mt-1 w-64 border rounded-lg p-2" placeholder="Manager Name">
            </div>
            <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">Start Appraisal</button>
          </form>
        </div>

        <!-- Back button -->
        <div>
          <a href="ess_admin.php" 
             class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
             ← Back
          </a>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
          Performance & Appraisals • Admin Module
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
