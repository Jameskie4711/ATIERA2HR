<?php
include 'db.php';


if (isset($_POST['update_profile'])) {
    $id = $_POST['employee_id'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];


    $sql = "UPDATE employees SET full_name='$full_name', email='$email' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        header("Location: ess_admin.php?success=1");
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>





