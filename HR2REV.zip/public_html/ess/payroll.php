<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payroll & Compensation Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />
</head>
<body class="h-screen overflow-hidden bg-slate-50 font-sans">
  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-6 flex-1">

        <!-- Header -->
        <div class="flex items-center justify-between border-b pb-4">
          <div>
            <h1 class="text-2xl font-semibold">Payroll & Compensation Management</h1>
            <p class="text-slate-500 text-sm">Manage payslips, deductions, and payroll settings</p>
          </div>
          <?php include '../profile.php'; ?>
        </div>
        
        <!-- Breadcrumb -->
        <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium text-gray-700">
          <a href="ess_admin.php" class="hover:text-blue-600 transition-colors">Home</a>   
        </div>

        <!-- Employee Payslips -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Employee Payslips</h2>
          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="bg-gray-100 text-left">
                <th class="p-2 border">Employee</th>
                <th class="p-2 border">Month</th>
                <th class="p-2 border">Gross Salary</th>
                <th class="p-2 border">Deductions</th>
                <th class="p-2 border">Net Salary</th>
                <th class="p-2 border">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="p-2 border">Maria Santos</td>
                <td class="p-2 border">September 2025</td>
                <td class="p-2 border">₱45,000</td>
                <td class="p-2 border">₱5,000</td>
                <td class="p-2 border">₱40,000</td>
                <td class="p-2 border">
                  <button class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-lg">View</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Payroll Configuration -->
        <div class="bg-white rounded-xl shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Payroll Configuration</h2>
          <form class="space-y-4">
            <div>
              <label class="block text-sm font-medium">Show Payslips in ESS</label>
              <select class="mt-1 w-48 border rounded-lg p-2">
                <option>Enabled</option>
                <option>Disabled</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-medium">Tax Deduction Rate (%)</label>
              <input type="number" class="mt-1 w-32 border rounded-lg p-2" value="12">
            </div>
            <div>
              <label class="block text-sm font-medium">Default Payroll Cycle</label>
              <select class="mt-1 w-48 border rounded-lg p-2">
                <option>Monthly</option>
                <option>Semi-Monthly</option>
                <option>Weekly</option>
              </select>
            </div>
            <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg">Save Changes</button>
          </form>
        </div>

        <!-- Back button -->
        <div>
          <a href="ess_admin.php" 
             class="inline-block bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
             ← Back
          </a>
        </div>

        <footer class="mt-6 text-xs text-slate-400 text-center">
          Payroll & Compensation • Admin Module
        </footer>

      </main>
    </div>
  </div>
</body>
</html>
