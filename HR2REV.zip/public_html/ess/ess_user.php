<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ESS - Employee Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="icon" type="image/png" href="/web/picture/logo2.png" />

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      lucide.createIcons();
    });
  </script>
</head>
<body class="h-screen overflow-hidden bg-gray-50">

  <div class="flex h-full">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
      <main class="p-6 space-y-4">
        
        <!-- Header -->
        <div class="flex items-center justify-between border-b py-6">
          <h2 class="text-xl font-semibold text-gray-800">Employee Self-Service (User)</h2>
          <?php include '../profile.php'; ?>
        </div>
        

        <!-- Second Header: Submodules -->
        <div class="bg-gray-100 border-b px-6 py-3 flex gap-4 text-sm font-medium">
          <a href="#">Profile</a>
          <a href="#">Leave</a>
          <a href="#">Payroll</a>
          <a href="#">Schedule</a>
          <a href="#">Training</a>
          <a href="#">Requests</a>
          <a href="#">Benefits</a>
          <a href="#">Feedback</a>
        </div>

        <!-- ESS User Dashboard -->
        <div class="grid md:grid-cols-2 gap-6 mt-6">

          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">My Profile</h3>
            <p class="text-sm text-gray-600">Update personal details, emergency contacts, and documents.</p>
          </div>


          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">Payroll</h3>
            <p class="text-sm text-gray-600">View payslips, allowances, deductions, and tax documents.</p>
          </div>

          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">Schedule</h3>
            <p class="text-sm text-gray-600">Check work schedule and shift assignments.</p>
          </div>

          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">Training</h3>
            <p class="text-sm text-gray-600">View assigned courses, enroll in training, and track progress.</p>
          </div>

          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">Requests</h3>
            <p class="text-sm text-gray-600">File HR requests such as COE, ID replacement, or uniform.</p>
          </div>

          

          <div class="bg-white shadow rounded-xl p-6">
            <h3 class="font-semibold mb-2">Feedback</h3>
            <p class="text-sm text-gray-600">Send feedback, suggestions, or concerns directly to HR.</p>
          </div>

        </div>
      </main>
    </div>
  </div>
</body>
</html>
