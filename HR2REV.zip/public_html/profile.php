<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('session_check.php');
include('dblogin.php');

// 🚨 Redirect BEFORE any HTML or includes like sidebar.php
//if (!isset($_SESSION['user_id'])) {
   // header('Location: login.php');
    //exit();
//}

//$admin_id = $_SESSION['user_id'];

// Fetch admin info
$stmt = $conn->prepare("SELECT user, role FROM admin WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$username = $admin['user'] ?? 'Admin';
$role     = $admin['role'] ?? 'Administrator';
$fullName = $username;

// Generate initials avatar
$initials = strtoupper(substr($username, 0, 2));
$bg = '#d4af37';
$fg = '#0f1c49';
$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">'
     . '<defs><clipPath id="r"><circle cx="32" cy="32" r="32"/></clipPath></defs>'
     . '<g clip-path="url(#r)"><rect width="64" height="64" fill="'.$bg.'"/>'
     . '<text x="50%" y="50%" dy=".32em" text-anchor="middle" font-family="Segoe UI, Inter, Arial, sans-serif" font-size="28" font-weight="700" fill="'.$fg.'">'
     . htmlspecialchars($initials, ENT_QUOTES) . '</text></g></svg>';

$avatarSrc = 'data:image/svg+xml;base64,' . base64_encode($svg);
?>

<!-- Admin Info Dropdown -->
<div class="relative">
  <button id="userDropdownToggle" class="flex items-center gap-2 focus:outline-none">
    <img src="<?= $avatarSrc ?>" alt="Admin profile picture" class="w-8 h-8 rounded-full border object-cover" />
    <div class="flex flex-col items-start">
      <span class="text-sm text-gray-800 font-medium"><?= htmlspecialchars($fullName) ?></span>
      <span class="text-xs text-gray-500"><?= htmlspecialchars($role) ?></span>
    </div>
    <i data-lucide="chevron-down" class="w-4 h-4 text-gray-600"></i>
  </button>

  <div id="userDropdown" class="absolute right-0 mt-2 w-40 bg-white rounded shadow-lg hidden z-20">
    <a href="/admin_profile.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
    <a href="/admin_settings.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
    <a href="/logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function(){
  const toggle = document.getElementById("userDropdownToggle");
  const menu   = document.getElementById("userDropdown");
  if (!toggle || !menu) return;
  toggle.addEventListener("click", function(e){
    e.stopPropagation();
    menu.classList.toggle("hidden");
  });
  document.addEventListener("click", function(e){
    if (!menu.contains(e.target) && !toggle.contains(e.target)){
      menu.classList.add("hidden");
    }
  });
});
</script>
