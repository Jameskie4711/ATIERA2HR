<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE
========================= */
require_once __DIR__ . '/../db.php'; // uses $conn (mysqli)

/* =========================
   REQUEST METHOD
========================= */
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    /* =========================
       GET - Fetch onboarding employees (all or by ID)
    ========================== */
    case 'GET':
        $onboarding_id = isset($_GET['onboarding_id']) ? intval($_GET['onboarding_id']) : 0;

        if ($onboarding_id) {
            // Return competencies for a single onboarding ID
            $stmt = $conn->prepare("SELECT * FROM onboarding_competencies WHERE onboarding_id = ?");
            $stmt->bind_param("i", $onboarding_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            echo json_encode($rows);
            exit;
        } else {
            // Return all onboarding employees for competencies.php
            $result = $conn->query("SELECT id, employee_id, first_name, middle_name, last_name, job_position, resume FROM onboarding ORDER BY id DESC");
            $employees = [];
            while ($row = $result->fetch_assoc()) {
                $employees[] = [
                    "onboarding" => [
                        "id" => $row['id'],
                        "employee_id" => $row['employee_id'],
                        "job_position" => $row['job_position'],
                        "first_name" => $row['first_name'],
                        "middle_name" => $row['middle_name'],
                        "last_name" => $row['last_name'],
                        "resume" => $row['resume']
                    ],
                    "employee" => false,
                    "employment_details" => [],
                    "government_ids" => [],
                    "dependents" => []
                ];
            }
            echo json_encode($employees);
            exit;
        }
        break;

    /* =========================
       POST - Add new competency
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data || !isset($data['onboarding_id'], $data['name'], $data['department'])) {
            http_response_code(400);
            echo json_encode(["error" => "Missing data"]);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO onboarding_competencies (onboarding_id, applicant_id, name, department, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param(
            "iiss",
            $data['onboarding_id'],
            $data['applicant_id'],
            $data['name'],
            $data['department']
        );
        $stmt->execute();

        echo json_encode(["success" => true, "id" => $stmt->insert_id]);
        break;

    /* =========================
       DELETE - Remove competency
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM onboarding_competencies WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
