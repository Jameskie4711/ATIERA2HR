<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";      // XAMPP default host
$user = "hr2_atiera";           // Default user in XAMPP
$pass = "DAJK^PNEBoIi#Otk";               // Default password (empty unless you set one in phpMyAdmin)
$db = "hr2_competency";   // 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Get HTTP method
$method = $_SERVER['REQUEST_METHOD'];

// ---------------------------
// GET: Fetch all employees
// ---------------------------
if ($method == 'GET') {
    $result = $conn->query("SELECT * FROM training_complete ORDER BY id ASC");
    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    echo json_encode(["status" => "success", "data" => $employees]);
    exit;
}

// ---------------------------
// POST: Add a new employee
// ---------------------------
if ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (empty($data['employee_name']) || empty($data['department'])) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "employee_name and department are required"]);
        exit;
    }

    $employee_name = $data['employee_name'];
    $department = $data['department'];

    // Prevent duplicates
    $stmt = $conn->prepare("SELECT 1 FROM training_complete WHERE employee_name = ? AND department = ?");
    $stmt->bind_param("ss", $employee_name, $department);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Employee already exists"]);
        exit;
    }

    // Insert new employee
    $stmt = $conn->prepare("INSERT INTO training_complete (employee_name, department) VALUES (?, ?)");
    $stmt->bind_param("ss", $employee_name, $department);
    
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Employee added successfully",
            "data" => [
                "id" => $conn->insert_id,
                "employee_name" => $employee_name,
                "department" => $department
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to add employee"]);
    }

    exit;
}

// ---------------------------
// DELETE: Remove employee by ID
// ---------------------------
if ($method == 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "id is required"]);
        exit;
    }

    $id = intval($data['id']);
    $stmt = $conn->prepare("DELETE FROM training_complete WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Employee deleted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to delete employee"]);
    }

    exit;
}

// ---------------------------
// If method not allowed
// ---------------------------
http_response_code(405);
echo json_encode(["status" => "error", "message" => "Method not allowed"]);

$conn->close();
?>
