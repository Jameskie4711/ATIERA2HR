<?php
// employees.php - API for hr2_competency.employees

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *"); // optional: allow cross-origin requests
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = "localhost";      // XAMPP default host
$user = "hr2_atiera";           // Default user in XAMPP
$pass = "DAJK^PNEBoIi#Otk";               // Default password (empty unless you set one in phpMyAdmin)
$db = "hr2_competency";

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Fetch all employees
$sql = "SELECT id, name, role, readiness, department FROM employees ORDER BY id ASC";
$result = $conn->query($sql);

$employees = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}

// Return JSON response
echo json_encode([
    'status' => 'success',
    'count' => count($employees),
    'data' => $employees
]);

$conn->close();
?>
