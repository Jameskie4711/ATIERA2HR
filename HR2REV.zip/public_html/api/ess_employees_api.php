<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include('../db.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$method = $_SERVER['REQUEST_METHOD'];

// Handle preflight request (CORS)
if ($method === "OPTIONS") {
    http_response_code(200);
    exit;
}

switch ($method) {
    case 'GET':
        // ✅ Fetch all or specific employee by ID
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM ESS_Employees WHERE id = ?");
            $stmt->bind_param("i", $id);
        } else {
            $stmt = $conn->prepare("SELECT * FROM ESS_Employees ORDER BY id ASC");
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $employees = $result->fetch_all(MYSQLI_ASSOC);

        echo json_encode(["status" => "success", "data" => $employees]);
        break;

    case 'POST':
        // ✅ Create new employee (auto Employee_ID via trigger)
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['Employee_Name']) || empty($data['Role']) || empty($data['Department'])) {
            echo json_encode(["status" => "error", "message" => "Missing required fields."]);
            exit;
        }

        $Employee_Name = $data['Employee_Name'];
        $Role = $data['Role'];
        $Department = $data['Department'];
        $Training_Status = $data['Training_Status'] ?? 'Pending';
        $Email = $data['Email'] ?? '';

        $stmt = $conn->prepare("
            INSERT INTO ESS_Employees (Employee_Name, Role, Department, Training_Status, Email)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("sssss", $Employee_Name, $Role, $Department, $Training_Status, $Email);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Employee added successfully."]);
        break;

    case 'PUT':
        // ✅ Update existing employee
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['id'])) {
            echo json_encode(["status" => "error", "message" => "Employee ID required."]);
            exit;
        }

        $id = intval($data['id']);
        $Employee_Name = $data['Employee_Name'] ?? null;
        $Role = $data['Role'] ?? null;
        $Department = $data['Department'] ?? null;
        $Training_Status = $data['Training_Status'] ?? null;
        $Email = $data['Email'] ?? null;

        $stmt = $conn->prepare("
            UPDATE ESS_Employees 
            SET Employee_Name = ?, Role = ?, Department = ?, Training_Status = ?, Email = ?
            WHERE id = ?
        ");
        $stmt->bind_param("sssssi", $Employee_Name, $Role, $Department, $Training_Status, $Email, $id);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Employee updated successfully."]);
        break;

    case 'DELETE':
        // ✅ Delete employee by ID
        parse_str(file_get_contents("php://input"), $data);

        if (empty($data['id'])) {
            echo json_encode(["status" => "error", "message" => "Employee ID required."]);
            exit;
        }

        $id = intval($data['id']);
        $stmt = $conn->prepare("DELETE FROM ESS_Employees WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        echo json_encode(["status" => "success", "message" => "Employee deleted successfully."]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["status" => "error", "message" => "Method not allowed."]);
        break;
}

$conn->close();
?>
