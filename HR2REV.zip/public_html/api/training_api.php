<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include('../db.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    // ✅ GET — fetch all or single record
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM training_assigned WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            echo json_encode(["status" => "success", "data" => $result]);
        } else {
            $result = $conn->query("SELECT * FROM training_assigned ORDER BY assigned_date DESC");
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            echo json_encode(["status" => "success", "data" => $rows]);
        }
        break;

    // ✅ POST — insert new record
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (
            empty($data['employee_name']) ||
            empty($data['department']) ||
            empty($data['role'])
        ) {
            echo json_encode(["status" => "error", "message" => "Missing required fields."]);
            exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO training_assigned (employee_name, department, role, assigned_date, status)
            VALUES (?, ?, ?, NOW(), ?)
        ");
        $status = $data['status'] ?? 'Assigned';
        $stmt->bind_param("ssss", $data['employee_name'], $data['department'], $data['role'], $status);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Training assigned successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to insert record."]);
        }
        break;

    // ✅ PUT — update existing record
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data['id'])) {
            echo json_encode(["status" => "error", "message" => "Missing record ID."]);
            exit;
        }

        $fields = [];
        $params = [];
        $types = '';

        if (isset($data['employee_name'])) {
            $fields[] = "employee_name = ?";
            $params[] = $data['employee_name'];
            $types .= 's';
        }
        if (isset($data['department'])) {
            $fields[] = "department = ?";
            $params[] = $data['department'];
            $types .= 's';
        }
        if (isset($data['role'])) {
            $fields[] = "role = ?";
            $params[] = $data['role'];
            $types .= 's';
        }
        if (isset($data['status'])) {
            $fields[] = "status = ?";
            $params[] = $data['status'];
            $types .= 's';
        }

        if (count($fields) === 0) {
            echo json_encode(["status" => "error", "message" => "No fields to update."]);
            exit;
        }

        $params[] = $data['id'];
        $types .= 'i';

        $sql = "UPDATE training_assigned SET " . implode(", ", $fields) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Record updated successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update record."]);
        }
        break;

    // ✅ DELETE — remove record
    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data['id'])) {
            echo json_encode(["status" => "error", "message" => "Missing record ID."]);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM training_assigned WHERE id = ?");
        $stmt->bind_param("i", $data['id']);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Record deleted successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to delete record."]);
        }
        break;

    default:
        echo json_encode(["status" => "error", "message" => "Unsupported request method."]);
        break;
}

$conn->close();
?>
