<?php
include('../db.php');
header('Content-Type: application/json');

// Get input
$input = json_decode(file_get_contents("php://input"), true);
$targetRole = isset($input['role']) ? $input['role'] : null;

if (!$targetRole) {
    echo json_encode([]);
    exit;
}

/*
  1. Get the “old employee” (current holder of the role)
*/
$stmt = $conn->prepare("
  SELECT e.id, c.comp1, c.comp2, c.comp3, c.comp4, c.comp5
  FROM employees e
  JOIN employee_competencies c ON e.id = c.employee_id
  WHERE e.role = ?
  LIMIT 1
");
$stmt->bind_param("s", $targetRole);
$stmt->execute();
$result = $stmt->get_result();
$target = $result->fetch_assoc();

if (!$target) {
    echo json_encode([]);
    exit;
}

// Target competency vector
$targetVec = array(
    $target['comp1'],
    $target['comp2'],
    $target['comp3'],
    $target['comp4'],
    $target['comp5']
);

/*
  2. Compare all other employees
*/
$res = $conn->query("
  SELECT e.id, e.name, c.comp1, c.comp2, c.comp3, c.comp4, c.comp5
  FROM employees e
  JOIN employee_competencies c ON e.id = c.employee_id
  WHERE e.role != '{$targetRole}'
");

$results = array();

if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $vec = array(
            $row['comp1'],
            $row['comp2'],
            $row['comp3'],
            $row['comp4'],
            $row['comp5']
        );

        // Simple similarity score (difference)
        $diff = 0;
        for ($i = 0; $i < 5; $i++) {
            $diff += abs($targetVec[$i] - $vec[$i]);
        }

        $score = max(0, 100 - ($diff * 10)); // Convert to percentage

        $results[] = array(
            "name" => $row['name'],
            "score" => $score
        );
    }

    // Sort by highest score
    usort($results, function($a, $b) {
        if ($a['score'] == $b['score']) return 0;
        return ($a['score'] < $b['score']) ? 1 : -1;
    });

    // Take top 3 successors
    $results = array_slice($results, 0, 3);
}

echo json_encode($results);
