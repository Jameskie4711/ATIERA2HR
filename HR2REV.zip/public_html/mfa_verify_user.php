<?php
session_start();
include('dblogin.php');
require_once __DIR__ . '/PHPGangsta/GoogleAuthenticator.php'; 
$ga = new PHPGangsta_GoogleAuthenticator();

// Ensure there's a pending login
if (!isset($_SESSION['pending_user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';

// Handle POST (verify code)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = trim($_POST['otp'] ?? '');

    $stmt = $conn->prepare("SELECT mfa_secret FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $_SESSION['pending_user_id']);
    $stmt->execute();
    $stmt->bind_result($secret);
    $stmt->fetch();
    $stmt->close();

    if (!empty($secret) && $ga->verifyCode($secret, $otp, 2)) {
        // Verified - finalize login
        $_SESSION['user_id'] = $_SESSION['pending_user_id'];
        $_SESSION['role'] = $_SESSION['pending_user_role'] ?? 'user';

        // clean up pending
        unset($_SESSION['pending_user_id']);
        unset($_SESSION['pending_user_role']);

        // redirect based on role
        if ($_SESSION['role'] === 'admin') {
            header("Location: index.php");
            exit;
        } else {
            header("Location: /ess_user/userinfo2.php");
            exit;
        }
    } else {
        $error = 'Invalid code. Please try again.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Verify MFA — ATIERA</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<style>
body {
  min-height: 100vh;
  background: linear-gradient(to bottom right, #e2e8f0, #f8fafc);
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  font-family: 'Inter', sans-serif;
}
.watermark {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 8rem;
  font-weight: 900;
  color: rgba(200, 210, 230, 0.25);
  z-index: 0;
  user-select: none;
}
.card {
  z-index: 10;
  background: white;
  padding: 2rem;
  border-radius: 1rem;
  box-shadow: 0 12px 24px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 420px;
}
.logo {
  width: 70px;
  height: 70px;
  margin: 0 auto 1rem;
}
.dark body { background: #0f172a; }
</style>
<script>
  // Countdown logic (1 minute = 60 seconds)
  let timeLeft = 60;

  function startCountdown() {
      const timerDisplay = document.getElementById('timer');
      const interval = setInterval(() => {
          timeLeft--;
          timerDisplay.textContent = timeLeft;

          if (timeLeft <= 0) {
              clearInterval(interval);
              alert("Session expired. Please log in again.");
              window.location.href = "logout.php?timeout=1";
          }
      }, 1000);
  }

  window.onload = startCountdown;
</script>
</head>
<body>
<div class="watermark">ATIÉRA</div>
<div class="card text-center">
  <img src="/logo2.png" alt="ATIERA Logo" class="logo">
  <h2 class="text-2xl font-bold text-gray-800 mb-2">Multi-Factor Verification</h2>
  <p class="text-red-600 text-sm font-semibold mb-4">
      Session expires in <span id="timer">60</span> seconds
  </p>

  <?php if (!empty($error)): ?>
    <div class="bg-red-100 border border-red-200 text-red-700 p-3 rounded mb-3">
        <?= htmlspecialchars($error) ?>
    </div>
  <?php endif; ?>

  <form method="post" class="space-y-4">
    <label class="block text-sm font-medium text-gray-700">
      Enter 6-digit code from your Authenticator app
    </label>
    <input name="otp" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" required
           class="w-full border border-gray-300 rounded px-3 py-2 text-center focus:outline-none focus:ring-2 focus:ring-blue-500">
    <div class="flex justify-center gap-2 mt-4">
      <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded font-semibold">
        Verify
      </button>
      <a href="login.php" class="inline-block px-6 py-2 border rounded text-sm text-gray-600 hover:bg-gray-100">
        Cancel
      </a>
    </div>
  </form>
</div>
</body>
</html>
